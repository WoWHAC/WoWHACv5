-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2026 wealdly
-- JustAC: the priority list as ONE custom AceGUI widget, mounted into the normal options
-- table with `dialogControl`. Everything else in the panel stays declarative Ace options.
--
-- Why a widget at all: the list is the one place the option table's layout fights the
-- content. An entry rendered as an inline group costs a bordered box, a title line and a
-- row of full-height buttons - about 84px - so four entries fill the panel and a 14-entry
-- list is mostly below the fold. Ace lays widgets out by width fraction with each widget
-- keeping its own height, so a one-line row of mixed controls cannot be expressed there.
-- One frame we draw ourselves gives a 26px row and, more importantly, lets the list say
-- things the option table cannot: which slot the game owns, and which entries the addon
-- is unable to time.
--
-- What it deliberately does NOT do itself: anything Ace or another module already owns.
-- The rows, dragging and the settings strip are the ones every list uses
-- (Options/ListWidget.lua); an ability's settings are the same controls its Abilities card
-- shows; and the name lookup, settings store, rank sort and baseline snapshot all come
-- from the modules that own them. What is left here is what only this list has: the
-- tabs, the pinned first slot and the two comparison columns.
local Type, Version = "JustACPriorityList", 1
local AceGUI = LibStub and LibStub("AceGUI-3.0", true)
if not AceGUI or (AceGUI:GetWidgetVersion(Type) or 0) >= Version then return end

local PriorityList = LibStub:NewLibrary("JustAC-PriorityList", 1)
if not PriorityList then return end

local L = LibStub("AceLocale-3.0"):GetLocale("JustAssistedCombat")
-- Loaded well before this file (see the TOC), so a file-scope capture is safe, and the
-- confirmations below all need its popup raise.
local UIFrameFactory = LibStub("JustAC-UIFrameFactory", true)
local CreateFrame = CreateFrame

local ListWidget = LibStub("JustAC-ListWidget")
local ROW_H, DETAIL_H = ListWidget.ROW_H, ListWidget.DETAIL_H
local PIN_H, TAB_H, HEAD_H = 26, 24, 16
local LOCK_ATLAS, LOCK_H = "QuestSharing-Padlock", 13
local LOCK_TEXTURE = "Interface\\Buttons\\LockButton-Locked-Up"
-- The pinned row is about the game's own assist, so it wears what the assist wears: an
-- action button with the helper's circling arrow drawn over it. An EMPTY button - the
-- slot is the subject, not whatever spell happens to be sitting in it, and an empty one
-- is also honest about a row nobody can put anything into. Both are atlases the game
-- already ships, and both are the same art a queue icon uses for its own empty slot.
local ASSIST_ATLAS = "UI-HUD-RotationHelper-Inactive"
local BUTTON_ATLAS, BUTTON_FRAME_ATLAS = ListWidget.BUTTON_ATLAS, ListWidget.BUTTON_FRAME_ATLAS
local HasAtlas = ListWidget.HasAtlas
-- Everything on a row that is NOT the two text columns: number, icon, rank, the four
-- buttons and the gaps between them. What is left is split between name and
-- condition, so a wider panel widens both instead of only one.
local ROW_FIXED = 165

local INK_DIM, GOLD, GREEN = ListWidget.INK_DIM, ListWidget.GOLD, ListWidget.GREEN
local BLUE, RED = ListWidget.BLUE, ListWidget.RED

--------------------------------------------------------------------------------
-- Model
--------------------------------------------------------------------------------
local function Addon() return LibStub("AceAddon-3.0"):GetAddon("JustAssistedCombat", true) end
local function SpecKey()
    local SpellDB = LibStub("JustAC-SpellDB", true)
    return SpellDB and SpellDB.GetSpecKey and SpellDB.GetSpecKey() or nil
end
local function CustomQueueFor(profile)
    local specKey = SpecKey()
    return specKey and profile and profile.customQueue and profile.customQueue[specKey] or nil
end

--- Which source the QUEUE is using right now. Deliberately independent of `orderExact`:
--- "show my order literally" is a different question from "whose order", and folding both
--- into one profile field made ticking either silently move the other.
--- Is there an imported priority for this spec? Without one the engine falls back to the
--- pick-matching heuristic, so the theorycraft tab would show the game's own order under a
--- name the queue is not using.
function PriorityList.HasSimc()
    local RI = LibStub("JustAC-RotationImport", true)
    return (RI and RI.HasRotation and RI.HasRotation()) or false
end

function PriorityList.LiveSource(profile)
    local cq = CustomQueueFor(profile)
    if cq and cq.enabled then return "custom" end
    if (profile and profile.contextOrder or "simc") == "simc" and PriorityList.HasSimc() then
        return "simc"
    end
    return "blizzard"
end

--- The source ON SCREEN: the previewed tab, else whichever is live. Controls outside the
--- widget key off this so they can hide when they make no sense for the tab being shown.
function PriorityList.CurrentSource(profile)
    local view = PriorityList.view
    -- Module state outlives a spec change: a theorycraft preview kept into a spec with no
    -- theorycraft data drew a hidden tab and offered a Use button that could not take.
    if view == "simc" and not PriorityList.HasSimc() then view = nil end
    return view or PriorityList.LiveSource(profile)
end

--- Point the queue at a source. The settings that decide it are written together, so a
--- player comparing sources flips one control instead of remembering the pair.
function PriorityList.SetLiveSource(addon, source)
    local profile = addon and addon:GetProfile()
    local specKey = SpecKey()
    if not (profile and specKey) then return end
    profile.customQueue = profile.customQueue or {}
    profile.customQueue[specKey] = profile.customQueue[specKey] or { enabled = false, spells = {} }
    local cq = profile.customQueue[specKey]
    if source == "custom" then
        cq.enabled = true
        -- Nothing edits contextOrder now the source select is gone, and a list left on
        -- the old "ac" value ranks by the pick-matching heuristic with nothing saying so.
        if PriorityList.HasSimc() then profile.contextOrder = "simc" end
    else
        cq.enabled = false
        profile.contextOrder = (source == "simc") and "simc" or "ac"
    end
    PriorityList.Changed(addon)
end

--- Sort ids into priority order for a source, in place. The ONE ranker: the reset button
--- and the previews below both call it, so two copies cannot drift apart.
function PriorityList.SortByPriority(ids, source)
    local RI = LibStub("JustAC-RotationImport", true)
    if not RI then return ids end
    local key, pos = {}, {}
    for i, id in ipairs(ids) do
        pos[id] = pos[id] or i
        local rec = RI.GetEntry and RI.GetEntry(id, "st")
        if source == "blizzard" then
            key[id] = (RI.GetBlizzardRank and RI.GetBlizzardRank(id)) or 999
        else
            -- Unranked entries (poisons, utility) fall below everything the data ranks.
            key[id] = (rec and rec.rank) or (1000 + ((RI.GetBlizzardRank and RI.GetBlizzardRank(id)) or 999))
        end
    end
    table.sort(ids, function(a, b)
        if key[a] ~= key[b] then return (key[a] or 999) < (key[b] or 999) end
        -- Ties keep the incoming order. On Forever nothing is ranked, so every id ties and
        -- the incoming order IS the player's action-bar order; sorting by id scrambled it.
        return pos[a] < pos[b]
    end)
    return ids
end

--- Copy the source the player is LOOKING AT into their own list, and show it. This is how
--- a list begins: there is no blank-page state to explain, and the order they just compared
--- is the order they get. It does not switch the queue to it - Use This Order does that.
function PriorityList.StartFrom(addon, source)
    local profile = addon and addon:GetProfile()
    local specKey = SpecKey()
    if not (profile and specKey) then return end
    local rows = PriorityList.Rows(addon, source)
    if #rows == 0 then return end
    profile.customQueue = profile.customQueue or {}
    profile.customQueue[specKey] = profile.customQueue[specKey] or {}
    local cq = profile.customQueue[specKey]
    cq.spells = {}
    for i = 1, #rows do cq.spells[i] = rows[i].id end
    -- The baseline is the game's pool as it stands now, so the "new abilities since you
    -- made this" notice keeps working. Same snapshot the reset button takes.
    local CustomQueue = LibStub("JustAC-OptionsCustomQueue", true)
    if CustomQueue and CustomQueue.SnapshotBaseline then CustomQueue.SnapshotBaseline(cq) end
    PriorityList.view = "custom"
    ListWidget.selected.custom = nil
    PriorityList.Changed(addon)
end

--- Add everything the source lists that your own list has not got yet, at the end, in
--- the order the source has them. Your own order is left alone, and nothing is removed,
--- so there is nothing to confirm and nothing to undo.
function PriorityList.MergeFrom(addon, source)
    local cq = CustomQueueFor(addon and addon:GetProfile())
    if not (cq and cq.spells) then return 0 end
    local have = {}
    for _, id in ipairs(cq.spells) do have[id] = true end
    local added = 0
    for _, row in ipairs(PriorityList.Rows(addon, source)) do
        if not have[row.id] and not row.upkeep then
            cq.spells[#cq.spells + 1] = row.id
            have[row.id] = true
            added = added + 1
        end
    end
    if added > 0 then
        PriorityList.view = "custom"
        PriorityList.Changed(addon)
    end
    if addon and addon.Print then
        -- Say so either way, and say WHY: merging compares membership, not order, so a
        -- list holding the same abilities in a different sequence is a no-op. Reporting
        -- only "nothing to add" reads as a broken button.
        if added > 0 then
            addon:Print(string.format(L["Priority Merged"], added))
        else
            addon:Print(L["Priority Merge None"])
        end
    end
    return added
end

--- Empty the list and hand the queue back to the game. Leaves the entries' own settings
--- alone: those are ability-level and shared with the other lists.
function PriorityList.ClearList(addon)
    local cq = CustomQueueFor(addon and addon:GetProfile())
    if not cq then return end
    cq.spells, cq.baseline, cq.enabled = {}, nil, false
    ListWidget.selected.custom = nil
    PriorityList.Changed(addon)
end

--- Upkeep, not rotation: poisons, weapon imbues and long-duration self/raid buffs. The
--- game surfaces these one at a time out of combat and holds its other picks until each is
--- applied, so a list that owns the order can sit on one of them and never move on. They
--- belong to the pre-combat reminder, which offers them without blocking the queue.
function PriorityList.IsUpkeep(spellID)
    if not spellID or spellID <= 0 then return false end
    local RF = LibStub("JustAC-RedundancyFilter", true)
    if RF and RF.IsUpkeepSpell then return RF.IsUpkeepSpell(spellID) end
    return false
end

--- Remove upkeep abilities from a stored list. Older lists were snapshotted from the
--- game's pool, which carries every poison the spec can use, and those entries stall the
--- queue (see IsUpkeep). Runs when the panel builds, so a list repairs itself once.
--- @return number how many were dropped
function PriorityList.PruneUpkeep(addon)
    local cq = CustomQueueFor(addon and addon:GetProfile())
    local list = cq and cq.spells
    if not list then return 0 end
    local kept, dropped = {}, 0
    for i = 1, #list do
        if PriorityList.IsUpkeep(list[i]) then dropped = dropped + 1 else kept[#kept + 1] = list[i] end
    end
    if dropped > 0 then cq.spells = kept end
    return dropped
end

--- How many abilities a source holds, without the per-row name and icon lookups Rows()
--- does. Cheap enough to ask for all three sources on every refresh.
function PriorityList.CountFor(addon)
    local cq = CustomQueueFor(addon and addon:GetProfile())
    return cq and cq.spells and #cq.spells or 0
end

--- Where an ability sits in the GAME's own order, by id. nil when the game does not list
--- it at all. Upkeep is excluded so the positions match what the panel actually shows.
--- Where the abilities BEING SHOWN would sit in the game's own order. Ranking the same
--- set both ways is the only comparison that means anything: measured against the whole
--- pool, a short list reads as "everything moved up" when nothing moved at all.
local function PositionsIn(shown, order)
    local ids = {}
    for i, id in ipairs(shown) do ids[i] = id end
    PriorityList.SortByPriority(ids, order)
    local out = {}
    for i, id in ipairs(ids) do
        if out[id] == nil then out[id] = i end
    end
    return out
end

--- The entries of one source: { id, name, icon, rank, cond, gameTimed, upkeep, move }.
function PriorityList.Rows(addon, source)
    local out = {}
    local profile = addon and addon:GetProfile()
    if not (profile and SpecKey()) then return out end
    local BlizzardAPI = LibStub("JustAC-BlizzardAPI", true)
    local SpellSearch = LibStub("JustAC-OptionsSpellSearch", true)
    local RI = LibStub("JustAC-RotationImport", true)
    if not BlizzardAPI then return out end

    local BAPI = BlizzardAPI
    --- The game's own list never includes what we inserted into the pool; the baseline has
    --- to mean the same thing whichever source happens to be live.
    local function poolFor(src)
        local out, have = {}, {}
        for _, id in ipairs((BAPI.GetRotationSpells and BAPI.GetRotationSpells(src == "blizzard")) or {}) do
            if not PriorityList.IsUpkeep(id) then
                out[#out + 1] = id
                have[id] = true
                local base = BAPI.ResolveSpellID and BAPI.ResolveSpellID(id)
                if base then have[base] = true end
            end
        end
        -- The theorycraft preview has to show what that ORDER would do, and part of what
        -- it does is offer abilities the game never recommends at all. Those only reach
        -- the live pool while theorycraft is the live source, so reading the pool alone
        -- made this tab change with a setting it exists to help you decide - and made it
        -- identical to the Blizzard tab whenever the game's own order was in use.
        if src ~= "blizzard" and RI and RI.GetInsertable then
            for _, raw in ipairs(RI.GetInsertable() or {}) do
                local id = (BAPI.ResolveKnownSpellID and BAPI.ResolveKnownSpellID(raw)) or raw
                if id and not have[id] and not PriorityList.IsUpkeep(id) then
                    out[#out + 1] = id
                    have[id] = true
                end
            end
        end
        return out
    end

    local ids = {}
    if source == "custom" then
        local cq = CustomQueueFor(profile)
        for i, id in ipairs((cq and cq.spells) or {}) do ids[i] = id end
    else
        ids = poolFor(source)
        -- "Use my order exactly" turns the engine's ranking off, so a preview that still
        -- showed a ranked order would describe something the queue is not doing.
        if not profile.orderExact then
            PriorityList.SortByPriority(ids, source)   -- a custom list is the player's own order
        end
    end

    -- Every source except the baseline itself is shown as movement against it. An id the
    -- game does not list at all has no baseline position, so it reads as added.
    local known = (source ~= "blizzard") and {} or nil
    if known then
        for _, id in ipairs(poolFor("blizzard")) do known[id] = true end
    end
    -- Theorycraft rank, counted over the rows on screen for the same reason.
    local rankOf = PositionsIn(ids, "simc")
    local shownKnown, shownAt = {}, {}
    for _, id in ipairs(ids) do
        if not known or known[id] then
            shownKnown[#shownKnown + 1] = id
            if shownAt[id] == nil then shownAt[id] = #shownKnown end
        end
    end
    local base = known and PositionsIn(shownKnown, "blizzard") or nil
    for i = 1, #ids do
        local id = ids[i]
        -- DisplayInfo owns the awkward cases: items arrive as NEGATIVE ids, and a
        -- transform form is labelled with the button it belongs to.
        local name, icon
        if SpellSearch and SpellSearch.DisplayInfo then name, icon = SpellSearch.DisplayInfo(id) end
        local rec = (id > 0) and RI and RI.GetEntry and RI.GetEntry(id, "st") or nil
        local upkeep = PriorityList.IsUpkeep(id)
        local move
        if base then
            move = base[id] and (base[id] - shownAt[id]) or "new"
        elseif rec and rec.rank then
            move = i - rankOf[id]   -- same subtraction, same sign, read from the baseline
        end
        out[i] = {
            id = id,
            name = name or tostring(id),
            icon = icon or 134400,
            rank = (rec and rec.rank) and rankOf[id] or nil,
            upkeep = upkeep,
            -- vs the game's own order: how far this source moves it, or that the game
            -- does not offer it at all. On the game's own tab, how far theorycraft would.
            move = move,
            cond = (id > 0) and (upkeep and L["Priority Cond Upkeep"]
                or PriorityList.Condition(rec)) or nil,
        }
    end
    return out
end


--- Plain words for ONE gate, or nil when there are none to give. Recursive, because a
--- group phrases its members exactly as the list does and joins them with or / and.
--- A resource condition in words. It used to print the raw comparison, tokens and all
--- ("combo_points >= 5"), which was both the longest line in the column and the only
--- one written in the data's language rather than the player's.
local RESOURCE_NAMES = {
    combo_points = "Combo Points", holy_power = "Holy Power", chi = "Chi",
    soul_shard = "Soul Shards", rune = "Runes", essence = "Essence",
    arcane_charges = "Arcane Charges", energy = "Energy", rage = "Rage",
    mana = "Mana", astral_power = "Astral Power", fury = "Fury",
    runic_power = "Runic Power", maelstrom = "Maelstrom", insanity = "Insanity",
    focus = "Focus", pain = "Pain",
}
local RESOURCE_OPS = {
    [">="] = "Cond Res Min", [">"] = "Cond Res Over", ["<"] = "Cond Res Under",
    ["<="] = "Cond Res Max", ["="] = "Cond Res Exact", ["!="] = "Cond Res Not",
}

local function ResourcePhrase(g)
    local key = RESOURCE_OPS[g.op]
    if not key then return nil end
    local name = RESOURCE_NAMES[g.res] or g.res or "?"
    -- `.deficit` asks about the room left, not the amount held, and there is no short
    -- way to say that: name it and let the tooltip carry the rest.
    if g.deficit then name = string.format(L["Priority Cond Res Room"], name) end
    return string.format(L["Priority " .. key], g.n, name)
end

local GatePhrase
GatePhrase = function(g)
    local SpellSearch = LibStub("JustAC-OptionsSpellSearch", true)
    local function nameOf(id)
        local nm = SpellSearch and SpellSearch.DisplayInfo and SpellSearch.DisplayInfo(id)
        return nm or tostring(id)
    end
    local piece
    if g.t == "any" or g.t == "all" then
        -- "during A or during B" says the same word twice. When every member of an OR
        -- is a plain buff, the shared word is lifted out: "during A or B".
        if g.t == "any" and #(g.g or {}) > 1 then
            local names, allBuffs = {}, true
            for i = 1, #g.g do
                local m = g.g[i]
                if m.t == "buff" and m.id and not m.neg then
                    names[#names + 1] = nameOf(m.id)
                else
                    allBuffs = false
                    break
                end
            end
            if allBuffs then
                return string.format(L["Priority Cond During"],
                    table.concat(names, L["Priority Cond Or"]))
            end
        end
        local sub = {}
        for i = 1, #(g.g or {}) do
            local m = g.g[i]
            local phrase = GatePhrase(m)
            -- Bracket a nested group: "a and b or c" reads three different ways.
            if phrase and (m.t == "any" or m.t == "all") and #(m.g or {}) > 1 then
                phrase = "(" .. phrase .. ")"
            end
            sub[#sub + 1] = phrase
        end
        if #sub == 0 then return nil end
        if #sub == 1 then return sub[1] end
        return table.concat(sub, g.t == "any" and L["Priority Cond Or"]
            or L["Priority Cond And"])
    elseif g.t == "buff" and g.id then
        piece = string.format(g.neg and L["Priority Cond Not During"]
            or L["Priority Cond During"], nameOf(g.id))
    elseif g.t == "cd" and g.id then
        -- `neg` means the entry wants that cooldown RUNNING, not ready.
        piece = string.format(g.neg and L["Priority Cond Cd Running"]
            or L["Priority Cond Cd Ready"], nameOf(g.id))
    elseif g.t == "stealth" then
        piece = g.neg and L["Priority Cond Unstealthed"] or L["Priority Cond Stealthed"]
    elseif (g.t == "resource" or g.t == "power") and g.op and g.n then
        piece = ResourcePhrase(g)
    elseif (g.t == "execute" or g.t == "health") and g.pct then
        -- Keyed off the OPERATOR, like the resource phrasing above. Assuming the
        -- common direction printed one condition as its own opposite: the data holds
        -- an execute gate that wants the target ABOVE its threshold.
        local over = (g.op == ">" or g.op == ">=")
        local key = g.t == "health"
            and (over and "Priority Cond Health Over" or "Priority Cond Health")
            or (over and "Priority Cond Execute Over" or "Priority Cond Execute")
        piece = string.format(L[key], g.pct)
    elseif g.t == "stack" and g.n and RESOURCE_OPS[g.op] then
        -- Same six phrasings the resources use, with a different noun.
        piece = string.format(L["Priority " .. RESOURCE_OPS[g.op]], g.n,
            L["Priority Cond Stacks"])
    elseif g.t == "dot" then
        piece = L["Priority Cond Dot"]
    elseif g.t == "prev" and g.id then
        piece = string.format(g.neg and L["Priority Cond Not After"]
            or L["Priority Cond After"], nameOf(g.id))
    end
    return piece
end

--- One line of plain words for an entry's conditions.
function PriorityList.Condition(rec)
    if not rec then return L["Priority Cond Unknown"] end
    local gates = rec.gates
    if not gates or #gates == 0 then return L["Priority Cond None"] end
    local parts = {}
    for i = 1, #gates do
        parts[#parts + 1] = GatePhrase(gates[i])
    end
    if #parts == 0 then return L["Priority Cond None"] end
    return table.concat(parts, " \194\183 ")   -- middle dot
end

--- The full story for one ability, as tooltip lines: { text, r, g, b } . The row shows
--- only its single-target condition, which is the common case and all that fits; a
--- different condition on two or more targets is exactly the kind of thing a player wants
--- to check before reordering, so it belongs here rather than nowhere.
--- Everything here is specific to the ability being pointed at. Which slots these
--- conditions are consulted for, and whether they can move an entry at all, are facts
--- about the whole LIST: the pinned first row says the one, the ordering option below
--- says the other, and repeating either on every row buries what is actually scarce.
function PriorityList.DetailLines(id)
    local out = {}
    if not id or id <= 0 then return out end
    if PriorityList.IsUpkeep(id) then
        out[#out + 1] = { L["Priority Tip Upkeep"], GOLD[1], GOLD[2], GOLD[3] }
        return out
    end
    local RI = LibStub("JustAC-RotationImport", true)
    if not (RI and RI.GetEntry) then return out end


    local contexts = {
        { "st", L["Priority Tip One"] },
        { "cleave", L["Priority Tip Two"] },
        { "aoe", L["Priority Tip Many"] },
    }
    local seen, any = {}, false
    for _, ctx in ipairs(contexts) do
        local rec = RI.GetEntry(id, ctx[1])
        local cond = rec and PriorityList.Condition(rec) or nil
        -- Only say it again when it actually differs: repeating one line three times
        -- reads as three facts.
        if cond and not seen[cond] then
            seen[cond] = true
            any = true
            out[#out + 1] = { string.format("%s: %s", ctx[2], cond), 0.82, 0.78, 0.70 }
        end
    end
    if not any then
        out[#out + 1] = { L["Priority Cond Unknown"], 0.66, 0.62, 0.55 }
    end


    -- Deliberately no rank number here: the theorycraft data ranks abilities this spec
    -- cannot currently cast, so its absolute number disagrees with the column, which counts
    -- only the rows on screen. Whether it is ranked AT ALL is the part the column cannot say.
    local rec = RI.GetEntry(id, "st")
    if not (rec and rec.rank) then
        out[#out + 1] = { L["Priority Tip Unranked"], 0.66, 0.62, 0.55 }
    end
    -- The padlock used to say this in the row itself; it repeated on nearly every line,
    -- so it moved here where it costs nothing to state properly.
    if (rec == nil) or (rec.delegated == true) then
        out[#out + 1] = { L["Priority Tip Game Timed"], GOLD[1], GOLD[2], GOLD[3] }
    else
        out[#out + 1] = { L["Priority Tip Self Timed"], GREEN[1], GREEN[2], GREEN[3] }
    end
    return out
end

-- UNDO. Every edit already routes through Changed, so rather than asking each control to
-- remember what it is about to do, the list is compared against the copy held here: the
-- copy IS the previous state, and pushing it is the whole of the bookkeeping. A control
-- added later is undoable without knowing this exists.
local UNDO_DEPTH = 10
local undoStack, undoSpec, undoProfile, undoLast = {}, nil, nil, nil

local function ListCopy(cq)
    local out = {}
    for i, id in ipairs((cq and cq.spells) or {}) do out[i] = id end
    out.live = (cq and cq.enabled) or nil   -- was the queue following it
    return out
end

local function SameList(a, b)
    if not (a and b) or #a ~= #b then return false end
    for i = 1, #a do
        if a[i] ~= b[i] then return false end
    end
    return true
end

local function NoteEdit(addon)
    local profile = addon and addon:GetProfile()
    local specKey = SpecKey()
    -- A list belongs to one spec on one profile. Carrying history across either would
    -- let an undo paste somebody else's list into this one.
    if specKey ~= undoSpec or profile ~= undoProfile then
        wipe(undoStack)
        undoSpec, undoProfile, undoLast = specKey, profile, nil
    end
    local now = ListCopy(CustomQueueFor(profile))
    if undoLast and not SameList(undoLast, now) then
        undoStack[#undoStack + 1] = undoLast
        if #undoStack > UNDO_DEPTH then table.remove(undoStack, 1) end
    end
    undoLast = now
end

function PriorityList.CanUndo()
    return #undoStack > 0
end

--- Put the list back as it was before the last change.
function PriorityList.Undo(addon)
    local prev = table.remove(undoStack)
    local cq = CustomQueueFor(addon and addon:GetProfile())
    if not (prev and cq) then return end
    local wasEmpty = not (cq.spells and #cq.spells > 0)
    local restored = {}
    for i, id in ipairs(prev) do restored[i] = id end
    cq.spells = restored
    -- Clear also handed the queue back to the game; bringing the list back brings that too.
    if wasEmpty and prev.live then cq.enabled = true end
    -- Set BEFORE the rebuild: Changed calls NoteEdit, which would otherwise see the
    -- restore as an edit and push the state we just undid back onto the stack.
    undoLast = ListCopy(cq)
    ListWidget.selected.custom = nil
    PriorityList.Changed(addon)
end

--- Anything that edits the list routes through here: one place that refreshes the queue
--- and the panel, so a new control cannot forget half of it.
function PriorityList.Changed(addon)
    NoteEdit(addon)
    local SpellQueue = LibStub("JustAC-SpellQueue", true)
    if SpellQueue and SpellQueue.InvalidateRotationCache then SpellQueue.InvalidateRotationCache(true) end
    local CustomQueue = LibStub("JustAC-OptionsCustomQueue", true)
    if CustomQueue and CustomQueue.UpdateCustomQueueOptions and addon then
        CustomQueue.UpdateCustomQueueOptions(addon)
    end
    if addon and addon.ForceUpdateAll then addon:ForceUpdateAll() end
    local AceConfigRegistry = LibStub("AceConfigRegistry-3.0", true)
    if AceConfigRegistry then AceConfigRegistry:NotifyChange("JustAssistedCombat") end
end

--------------------------------------------------------------------------------
-- The widget
--------------------------------------------------------------------------------

local Tooltip, MakeButton = ListWidget.Tooltip, ListWidget.MakeButton

--- One tab, in Blizzard's own options-tab art - the same three-slice the Ace tab container
--- uses, so the strip belongs to the panel instead of imitating it.
local TAB_PAD = 22

--- One tab: an opaque fill and a border on three sides. The open side faces the pane.
local function MakeTab(parent, label)
    local tab = CreateFrame("Button", nil, parent)
    tab:SetHeight(TAB_H)
    tab:SetNormalFontObject("GameFontNormalSmall")
    tab:SetHighlightFontObject("GameFontHighlightSmall")
    tab:SetText(label)

    tab.fill = tab:CreateTexture(nil, "BACKGROUND")
    tab.fill:SetAllPoints()

    local function edge(p1, p2, w, h)
        local t = tab:CreateTexture(nil, "BORDER")
        t:SetPoint(p1)
        t:SetPoint(p2)
        if w then t:SetWidth(w) end
        if h then t:SetHeight(h) end
        return t
    end
    tab.edges = {
        edge("TOPLEFT", "TOPRIGHT", nil, 1),
        edge("TOPLEFT", "BOTTOMLEFT", 1, nil),
        edge("TOPRIGHT", "BOTTOMRIGHT", 1, nil),
    }

    tab.liveDot = tab:CreateTexture(nil, "OVERLAY")
    tab.liveDot:SetSize(10, 10)
    tab.liveDot:SetPoint("RIGHT", tab:GetFontString(), "LEFT", -4, 0)
    tab.liveDot:SetTexture("Interface\\COMMON\\Indicator-Green")

    --- Label plus how many abilities that source holds. Re-measured because the count
    --- changes as a list is edited.
    function tab:SetLabel(text)
        self:SetText(text)
        local w = (self:GetFontString() and self:GetFontString():GetStringWidth() or 40) + TAB_PAD
        if self.liveDot:IsShown() then w = w + 12 end
        self:SetWidth(w)
    end

    function tab:SetSelected(on)
        -- Selected shares the pane's exact colour so the two read as one surface.
        self.fill:SetColorTexture(0.09, 0.085, 0.07, on and 1 or 0)
        if not on then self.fill:SetColorTexture(0.045, 0.043, 0.036, 1) end
        for _, e in ipairs(self.edges) do
            e:SetColorTexture(0.42, 0.40, 0.34, on and 1 or 0.55)
        end
        self:SetNormalFontObject(on and "GameFontNormalSmall" or "GameFontDisableSmall")
        self:GetFontString():SetPoint("CENTER", self.liveDot:IsShown() and 6 or 0, 0)
    end
    return tab
end

--- An entry's settings, for the strip under the open row. The same controls its Abilities
--- card shows; only the Proc Priority wording is this list's own, and it greys while the
--- ordering option it depends on is off.
local function RowControls(addon, id)
    local Abilities = LibStub("JustAC-OptionsAbilities", true)
    local SpellSearch = LibStub("JustAC-OptionsSpellSearch", true)
    local C = Abilities and Abilities.Controls
    if not C then return nil end
    local function changed() PriorityList.Changed(addon) end
    local proc = C.ProcPriority(addon, id, changed,
        L["Custom Queue Procs First"], L["Custom Queue Procs First desc"])
    proc.disabled = function()
        local profile = addon:GetProfile()
        return (profile and profile.orderProcsFirst == false) or false
    end
    local out = { C.AlwaysShow(addon, id, changed), proc }
    if SpellSearch and SpellSearch.HoldModeControl then
        out[#out + 1] = SpellSearch.HoldModeControl(addon, id, nil, changed)
    end
    return out
end

--- Re-share the free width between the name and condition columns. Called whenever the
--- pane resizes, not just on Refresh, because the width that Refresh measured is the one
--- from BEFORE Ace lays this widget out again.
local function ApplyColumns(self)
    local free = math.max(0, (self.frame:GetWidth() or 560) - ROW_FIXED)
    local nameW = math.floor(free * 0.33)
    for i = 1, #self.rows do
        self.rows[i].name:SetWidth(nameW)
        self.rows[i].cond:SetWidth(free - nameW)
    end
    self.head.cond:ClearAllPoints()
    self.head.cond:SetPoint("LEFT", self.head, "LEFT", 55 + nameW + 8, 0)
end



local methods = {}

function methods:OnAcquire()
    self.addon = Addon()
    self.disabled = false
    self:SetHeight(TAB_H + HEAD_H + PIN_H + 10)
    self:SetWidth(560)
    self:Refresh()
end

function methods:OnRelease()
    -- Widgets are pooled: anything left here is inherited by the next option that mounts
    -- this type.
    ListWidget.Reset(self)
    self.addon, self.disabled, self.refreshing = nil, false, nil
end

-- What the shared rows ask of this list (Options/ListWidget.lua).
function methods:Commit() PriorityList.Changed(self.addon) end
function methods:Reflow() PriorityList.Changed(self.addon) end
function methods:RowTooltip(row)
    for _, line in ipairs(PriorityList.DetailLines(row.id)) do
        GameTooltip:AddLine(line[1], line[2], line[3], line[4], true)
    end
end
--- The "when it is used" column, between the name and the comparison.
function methods:OnRowCreated(row)
    row.cond = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.cond:SetPoint("LEFT", row.name, "RIGHT", 8, 0)
    row.cond:SetJustifyH("LEFT")
    -- Never wrap: the row is a fixed 26px, and a second line silently broke the grid.
    row.cond:SetWordWrap(false)
    row.cond:SetTextColor(unpack(INK_DIM))
end

-- AceConfigDialog drives a description control with SetText/SetFontObject, and every
-- control with SetDisabled. The list draws itself, so the option's own text is unused.
function methods:SetText() end
function methods:SetFontObject() end
function methods:SetDisabled(disabled)
    self.disabled = disabled and true or false
    -- Ace sets the width (which refreshes) BEFORE disabled, so without this pass the
    -- buttons would keep the previous answer.
    self:Refresh()
end

function methods:OnWidthSet() self:Refresh() end

--- The editable array behind the current view, or nil when previewing a source the player
--- does not own.
function methods:List()
    if self:Source() ~= "custom" then return nil end
    local cq = CustomQueueFor(self.addon and self.addon:GetProfile())
    return cq and cq.spells or nil
end

function methods:Source()
    -- Module state, not instance state: editing anything rebuilds the options table, which
    -- releases and re-acquires this widget. Kept on the instance, the previewed tab was
    -- lost on every click and the panel jumped back to whichever source is live.
    return PriorityList.CurrentSource(self.addon and self.addon:GetProfile())
end

function methods:Refresh()
    if not self.addon or self.refreshing then return end
    self.refreshing = true
    -- Every redraw notes the list as seen. That makes the first edit after a reload
    -- undoable, and wipes the history the moment the spec or profile under it changes -
    -- before an Undo from the old one could paste its list over this one.
    NoteEdit(self.addon)
    local profile = self.addon:GetProfile()
    -- Forever: no game pick, so the game's own order is not a source. Its tab greys out
    -- and a remembered view of it falls back to the live source.
    local BAPI = LibStub("JustAC-BlizzardAPI", true)
    local noPick = BAPI and BAPI.HasGamePick and not BAPI.HasGamePick()
    if noPick and PriorityList.view == "blizzard" then PriorityList.view = nil end
    local source, live = self:Source(), PriorityList.LiveSource(profile)
    local cq = CustomQueueFor(profile)
    local haveList = cq and cq.spells and #cq.spells > 0
    local SQ = LibStub("JustAC-SpellQueue", true)
    local leadMode = (SQ and SQ.LeadMode and SQ.LeadMode(profile)) or "off"
    -- Only your own list contests the row; Safe Lead replaces the game's pick from
    -- whichever order is live, so it gets its own reading rather than borrowing one.
    local leads = source == "custom" and haveList and leadMode == "mylist"
    local editable = (source == "custom") and not self.disabled

    for key, tab in pairs(self.tabs) do
        tab:SetShown(key ~= "simc" or PriorityList.HasSimc())
        tab:SetLabel(key == "custom"
            and string.format("%s (%d)", tab.baseLabel, PriorityList.CountFor(self.addon))
            or tab.baseLabel)
        tab.liveDot:SetShown(key == live)   -- before SetSelected: it re-centres around the dot
        tab:SetSelected(key == source)
        local unused = noPick and key == "blizzard"
        tab:SetEnabled(not unused)
        tab:SetAlpha(unused and 0.4 or 1)
        Tooltip(tab, (unused and L["Not used in WoW Forever"])
            or (key == live and L["Priority Tab Live"]) or L["Priority Tab View"])
    end

    -- Position 1. The row the whole panel exists to explain, in the three states the lead
    -- setting can put it in: the game's outright, contested by your list, or the game's
    -- except while it waits.
    local pinTitle, pinNote, pinGold = L["Priority Pin Blizzard"], L["Priority Pin Blizzard Note"], false
    if leads then
        pinTitle, pinNote, pinGold = L["Priority Pin Contested"], L["Priority Pin Contested Note"], true
    elseif leadMode == "safe" then
        pinTitle, pinNote, pinGold = L["Priority Pin Safe"], L["Priority Pin Safe Note"], true
    end
    self.pin.lock:SetVertexColor(unpack(pinGold and GOLD or GREEN))
    self.pin.num:SetTextColor(unpack(pinGold and GOLD or GREEN))
    self.pin.title:SetText(pinTitle)
    self.pin.title:SetTextColor(unpack(pinGold and GOLD or GREEN))
    self.pin.note:SetText(pinNote)
    self.pin.bg:SetColorTexture(pinGold and 0.20 or 0.11, pinGold and 0.16 or 0.20, 0.09, 1)
    Tooltip(self.pin, pinTitle .. "|n|n" .. pinNote)

    local rows = PriorityList.Rows(self.addon, source)
    for i = 1, #rows do
        local id = rows[i].id
        rows[i].num = i + 1   -- position 1 is the pinned row above
        if id > 0 then rows[i].controls = function() return RowControls(self.addon, id) end end
    end
    local _, detailShown = ListWidget.PlaceRows(self, rows, -(TAB_H + HEAD_H + PIN_H + 4), editable,
        function(row, data)
            row.cond:SetText(data.cond or "")
            row.cond:SetTextColor(unpack(data.upkeep and GOLD or INK_DIM))
            if data.move ~= nil then
                if data.move == "new" then
                    row.right:SetText(L["Priority Move New"])
                    row.right:SetTextColor(unpack(BLUE))
                elseif data.move == 0 then
                    row.right:SetText("=")
                    row.right:SetTextColor(unpack(INK_DIM))
                else
                    row.right:SetText((data.move > 0 and "+" or "") .. data.move)
                    row.right:SetTextColor(unpack(data.move > 0 and GREEN or RED))
                end
            else
                row.right:SetText(data.rank and ("#" .. data.rank) or "")
                row.right:SetTextColor(unpack(BLUE))
            end
        end)

    -- Two ways to take one of the orders you did not write into a list of your own.
    -- Export replaces the whole thing and asks first; Merge only adds what is missing
    -- and never needs to. Both collapse to one wide Export before there is a list to
    -- protect, which is also where the long label fits and is most needed.
    -- An empty list is the one thing that cannot be used: the queue would fall back to the
    -- game's pool while every label claimed otherwise. That tab keeps its hint instead.
    self.use:SetShown(not self.disabled and source ~= live and (source ~= "custom" or haveList))
    local offer = (source ~= "custom") and not self.disabled
    self.merge:SetShown(offer and haveList)
    self.useThis:SetShown(offer)
    self.useThis:SetText(haveList and L["Priority Export Short"] or L["Priority Export"])
    self.useThis:SetWidth(haveList and 66 or 132)
    Tooltip(self.useThis, haveList and L["Priority Replace desc"] or L["Priority Export desc"])
    self.clear:SetShown(not self.disabled and source == "custom" and haveList)
    -- Only where there is a list to put back, and only once something has changed.
    self.undo:SetShown(not self.disabled and source == "custom"
        and PriorityList.CanUndo())

    self.emptyNote:SetShown(source == "custom" and not haveList)
    self.emptyNote:SetText(L["Priority Empty Hint"])


    self.head:SetShown(#rows > 0)
    ApplyColumns(self)
    if #rows > 0 then
        self.head.rank:ClearAllPoints()
        self.head.rank:SetPoint("RIGHT", self.head, "RIGHT", -56, 0)
        self.head.rank:SetText(source == "blizzard" and L["Priority Head Rank"] or L["Priority Head Move"])
    end

    -- +10: the pane's own top and bottom border insets.
    self:SetHeight(TAB_H + HEAD_H + PIN_H + 10 + (#rows * ROW_H)
        + (detailShown and DETAIL_H or 0) + ((#rows == 0) and 28 or 4))
    self.refreshing = nil
end

--------------------------------------------------------------------------------
local function Constructor()
    local frame = CreateFrame("Frame", nil, UIParent)
    frame:Hide()
    frame:SetScript("OnSizeChanged", function(f)
        if f.obj and f.obj.rows then ApplyColumns(f.obj) end
    end)

    local widget = { frame = frame, type = Type, tabs = {}, listKey = "custom" }
    for method, func in pairs(methods) do widget[method] = func end

    -- The list needs a pane for the tabs to sit ON, or they float over the panel with
    -- nothing joining them to the rows. Ace's own inline-group backdrop, so the pane
    -- matches every other bordered group around it; the tab strip then overlaps its top
    -- edge by two pixels, which is what reads as "joined".
    local body = ListWidget.Pane(frame, TAB_H - 2)
    widget.body = body

    local content = CreateFrame("Frame", nil, frame)
    content:SetAllPoints()
    -- Above the tabs, below the rows: the pane is what hides each tab's lower edge, and
    -- the rows must still draw on top of the pane.
    body:SetFrameLevel(frame:GetFrameLevel() + 2)
    content:SetFrameLevel(body:GetFrameLevel() + 1)
    -- Anything that draws ON the pane needs its level too; only the tabs go behind.
    local function onPane(f) f:SetFrameLevel(body:GetFrameLevel() + 1) end
    ListWidget.Attach(widget, content)

    -- Tab strip: the source the queue is using. Selecting a tab SWITCHES to it. There
    -- is no separate commit step: the player opened this to change what the queue
    -- does, and a preview that needed a second click made every edit look inert.
    local defs = {
        { "blizzard", L["Priority Tab Blizzard"] },
        { "simc", L["Priority Tab Simc"] },
        { "custom", L["Priority Tab Custom"] },
    }
    local prev
    for _, def in ipairs(defs) do
        local key, label = def[1], def[2]
        local tab = MakeTab(frame, label)
        tab:SetPoint("BOTTOMLEFT", prev or body, prev and "BOTTOMRIGHT" or "TOPLEFT",
            prev and 3 or 8, prev and 0 or -3)
        tab:SetFrameLevel(math.max(0, body:GetFrameLevel() - 1))
        -- A tab is a LOOK. Players open the game's order to read it, not to hand the
        -- queue back to it, so switching is its own button (Use This Order, below).
        tab:SetScript("OnClick", function()
            PriorityList.view = key
            local reg = LibStub("AceConfigRegistry-3.0", true)
            if reg then reg:NotifyChange("JustAssistedCombat") end
        end)
        tab.baseLabel = label
        widget.tabs[key] = tab
        prev = tab
    end

    -- Beside the tabs, so it reads as "the one I am looking at". Only there while that tab
    -- is not already what the queue follows.
    widget.use = MakeButton(frame, L["Priority Use"], L["Priority Use desc"], function()
        PriorityList.SetLiveSource(widget.addon, widget:Source())
    end, 104)
    onPane(widget.use)
    widget.use:SetHeight(TAB_H - 5)
    widget.use:SetPoint("LEFT", widget.tabs.custom, "RIGHT", 8, 0)

    widget.useThis = MakeButton(frame, "", "", function()
        local source = widget:Source()
        local cq = CustomQueueFor(widget.addon and widget.addon:GetProfile())
        if cq and cq.spells and #cq.spells > 0 then
            -- The source is captured NOW: the tabs stay clickable behind a popup, and
            -- reading it again on accept would replace the list from whichever tab the
            -- player wandered to while the question was on screen.
            if UIFrameFactory then
                UIFrameFactory.ShowPopupAbove("JUSTAC_REPLACE_PRIORITY_LIST",
                    { addon = widget.addon, src = source })
            end
        else
            PriorityList.StartFrom(widget.addon, source)
        end
    end, 132)
    onPane(widget.useThis)
    widget.useThis:SetHeight(TAB_H - 5)
    widget.useThis:SetPoint("RIGHT", frame, "TOPRIGHT", -6, -(TAB_H / 2 + 1))

    StaticPopupDialogs["JUSTAC_REPLACE_PRIORITY_LIST"] = StaticPopupDialogs["JUSTAC_REPLACE_PRIORITY_LIST"] or {
        text = L["Priority Replace Confirm"],
        button1 = YES,
        button2 = NO,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        OnAccept = function(self)
            local d = self.data
            if d and d.addon then PriorityList.StartFrom(d.addon, d.src) end
        end,
    }

    widget.merge = MakeButton(frame, L["Priority Merge Short"], L["Priority Merge desc"], function()
        PriorityList.MergeFrom(widget.addon, widget:Source())
    end, 66)
    onPane(widget.merge)
    widget.merge:SetHeight(TAB_H - 5)

    StaticPopupDialogs["JUSTAC_CLEAR_PRIORITY_LIST"] = StaticPopupDialogs["JUSTAC_CLEAR_PRIORITY_LIST"] or {
        text = L["Priority Clear Confirm"],
        button1 = YES,
        button2 = NO,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        OnAccept = function(self)
            local d = self.data
            if not (d and d.addon) then return end
            -- Stay on the emptied list: its Undo is right there.
            PriorityList.view = "custom"
            PriorityList.ClearList(d.addon)
        end,
    }
    widget.clear = MakeButton(frame, L["Priority Clear"], L["Priority Clear desc"], function()
        if UIFrameFactory then
            UIFrameFactory.ShowPopupAbove("JUSTAC_CLEAR_PRIORITY_LIST", { addon = widget.addon })
        end
    end, 56)
    onPane(widget.clear)
    widget.clear:SetHeight(TAB_H - 5)
    widget.clear:SetPoint("RIGHT", frame, "TOPRIGHT", -6, -(TAB_H / 2 + 1))

    widget.undo = MakeButton(frame, L["Priority Undo"], L["Priority Undo desc"], function()
        PriorityList.Undo(widget.addon)
    end, 56)
    onPane(widget.undo)
    widget.undo:SetHeight(TAB_H - 5)
    widget.undo:SetPoint("RIGHT", widget.clear, "LEFT", -4, 0)
    widget.merge:SetPoint("RIGHT", widget.useThis, "LEFT", -4, 0)

    -- Column header. Its moving labels are re-anchored in Refresh, so a name column that
    -- resizes with the panel cannot drift away from its heading.
    local head = CreateFrame("Frame", nil, frame)
    head:SetHeight(HEAD_H)
    head:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -(TAB_H + 4))
    head:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -5, -(TAB_H + 4))
    local function headLabel(text, justify)
        local fs = head:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        fs:SetText(text)
        fs:SetJustifyH(justify or "LEFT")
        return fs
    end
    head.slot = headLabel(L["Priority Head Slot"], "CENTER")
    head.slot:SetPoint("LEFT", head, "LEFT", 6, 0)
    head.slot:SetWidth(20)
    head.name = headLabel(L["Priority Head Ability"])
    head.name:SetPoint("LEFT", head, "LEFT", 55, 0)
    head.cond = headLabel(L["Priority Head When"])
    head.rank = headLabel(L["Priority Head Rank"], "RIGHT")
    head.rank:SetWidth(76)
    head.rule = head:CreateTexture(nil, "ARTWORK")
    head.rule:SetHeight(1)
    head.rule:SetPoint("BOTTOMLEFT", 4, 0)
    head.rule:SetPoint("BOTTOMRIGHT", -4, 0)
    head.rule:SetColorTexture(1, 1, 1, 0.08)
    onPane(head)
    widget.head = head

    -- Position-1 row, always present, never editable.
    local pin = CreateFrame("Frame", nil, frame)
    pin:SetHeight(PIN_H)
    pin:SetPoint("TOPLEFT", frame, "TOPLEFT", 5, -(TAB_H + HEAD_H + 4))
    pin:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -5, -(TAB_H + HEAD_H + 4))
    pin.bg = pin:CreateTexture(nil, "BACKGROUND")
    pin.bg:SetAllPoints()
    -- This row IS position 1, so it says so, on the same centre line every row number
    -- uses. The padlock rides the icon corner rather than sharing the number column,
    -- which is 20px wide and cannot hold both without pushing the number off that line.
    pin.num = pin:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    pin.num:SetPoint("LEFT", pin, "LEFT", 6, 0)
    pin.num:SetWidth(20)
    pin.num:SetJustifyH("CENTER")
    pin.num:SetText("1")
    -- The icon column, so the emblem lines up with every ability icon below it.
    pin.icon = pin:CreateTexture(nil, "ARTWORK")
    pin.icon:SetSize(16, 16)
    pin.icon:SetPoint("LEFT", pin, "LEFT", 32, 0)
    if HasAtlas(BUTTON_ATLAS) then pin.icon:SetAtlas(BUTTON_ATLAS) else pin.icon:Hide() end
    pin.frame = pin:CreateTexture(nil, "ARTWORK", nil, 1)
    pin.frame:SetSize(18, 18)
    pin.frame:SetPoint("CENTER", pin.icon, "CENTER")
    if HasAtlas(BUTTON_FRAME_ATLAS) then
        pin.frame:SetAtlas(BUTTON_FRAME_ATLAS)
    else
        pin.frame:Hide()
    end
    -- The ring the assist paints around an action button. Sized to the icon rather than
    -- to the atlas, which is drawn for a 36px button and sat proud of a 16px one, and
    -- softened so it reads as a mark on the icon instead of a sticker over it.
    pin.ring = pin:CreateTexture(nil, "OVERLAY", nil, 1)
    pin.ring:SetPoint("CENTER", pin.icon, "CENTER")
    pin.ring:SetSize(22, 22)
    pin.ring:SetAtlas(ASSIST_ATLAS)
    pin.ring:SetShown(HasAtlas(ASSIST_ATLAS) and HasAtlas(BUTTON_ATLAS))
    -- Above the ring, not merely after it: same layer, and draw order within a layer
    -- is the sublevel, so the lock was being painted under the arc it sits beside.
    pin.lock = pin:CreateTexture(nil, "OVERLAY", nil, 7)
    -- The padlock the game itself puts on a locked action button, cropped to the glyph.
    -- The old button texture was a 32px square with the lock in its middle third, so at
    -- any size that fits a 16px icon the lock came out a few pixels tall and sat inside
    -- the ring instead of on its corner.
    local lockInfo = C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(LOCK_ATLAS)
    if lockInfo and lockInfo.height and lockInfo.height > 0 then
        pin.lock:SetAtlas(LOCK_ATLAS)
        pin.lock:SetSize(LOCK_H * lockInfo.width / lockInfo.height, LOCK_H)
        -- Grey first, so the green / gold tint below reads the same as it did.
        pin.lock:SetDesaturated(true)
    else
        pin.lock:SetTexture(LOCK_TEXTURE)
        pin.lock:SetSize(12, 15)
    end
    -- Centred ON the icon's top-right corner: a badge on the button, not a mark inside
    -- it. Nudged in just enough to stay within the row.
    pin.lock:SetPoint("CENTER", pin.icon, "TOPRIGHT", -1, -2)
    pin.title = pin:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    pin.title:SetPoint("LEFT", pin, "LEFT", 55, 0)
    pin.note = pin:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    pin.note:SetPoint("LEFT", pin.title, "RIGHT", 8, 0)
    pin.note:SetPoint("RIGHT", -6, 0)
    pin.note:SetJustifyH("LEFT")
    pin.note:SetWordWrap(false)
    pin:EnableMouse(true)   -- the note is clipped by design; the tooltip carries the rest
    onPane(pin)
    widget.pin = pin

    widget.emptyNote = content:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    widget.emptyNote:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -(TAB_H + HEAD_H + PIN_H + 6))
    widget.emptyNote:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    widget.emptyNote:SetJustifyH("LEFT")

    return AceGUI:RegisterAsWidget(widget)
end

AceGUI:RegisterWidgetType(Type, Constructor, Version)
