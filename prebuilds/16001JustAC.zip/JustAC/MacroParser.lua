-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2026 wealdly
-- JustAC: Macro Parser Module - Resolves macro conditionals to find actionable spells
local MacroParser = LibStub:NewLibrary("JustAC-MacroParser", 25)
if not MacroParser then return end

local BlizzardAPI = LibStub("JustAC-BlizzardAPI", true)
local FormCache = LibStub("JustAC-FormCache", true)

-- Hot path cache
local tonumber = tonumber
local string_lower = string.lower
local string_match = string.match
local string_find = string.find
local string_gmatch = string.gmatch
local string_sub = string.sub
local table_insert = table.insert
local pairs = pairs
local pcall = pcall
local wipe = wipe

local GetTime = GetTime
local UnitAffectingCombat = UnitAffectingCombat
local IsStealthed = IsStealthed
local IsSpellKnown = IsSpellKnown
local IsPlayerSpell = IsPlayerSpell

local parsedMacroCache = {}
local spellOverrideCache = {}
local lastPrintTime = {}
local DEBUG_THROTTLE_INTERVAL = 5

local function GetLowercase(str)
    return str and string_lower(str) or ""
end

-- Extract the spell name from a macro clause, stripping any [condition] brackets.
-- Returns: spellPart (string), conditionGroups (table of strings, one per [...] group)
-- OR-cascade: "[spec:1][spec:2] Maul" → {"spec:1", "spec:2"}; "Maul" → {}
local function StripBracketConditions(entry)
    if not entry then return "", {} end
    local trimmed = entry:match("^%s*(.-)%s*$")
    if not trimmed or trimmed == "" then return "", {} end
    -- Find the last ']' efficiently using string.find with reverse search
    local lastBracketPos = 0
    local pos = 1
    while true do
        local found = string_find(trimmed, "]", pos, true)
        if not found then break end
        lastBracketPos = found
        pos = found + 1
    end
    if lastBracketPos > 0 and string_sub(trimmed, 1, 1) == "[" then
        local conditionPart = string_sub(trimmed, 1, lastBracketPos)
        local spellPart = string_match(string_sub(trimmed, lastBracketPos + 1), "^%s*(.-)%s*$") or ""
        -- Extract ALL bracket groups for OR-cascade evaluation
        local conditionGroups = {}
        for groupContent in string_gmatch(conditionPart, "%[([^%]]*)%]") do
            table_insert(conditionGroups, groupContent)
        end
        return spellPart, conditionGroups
    end
    return trimmed, {}
end

local function GetDebugMode()
    return BlizzardAPI and BlizzardAPI.GetDebugMode() or false
end

local function SafeGetOverrideSpell(spellID)
    if not spellID or not C_Spell or not C_Spell.GetOverrideSpell then return nil end
    local ok, result = pcall(C_Spell.GetOverrideSpell, spellID)
    if ok and result and result ~= 0 and result ~= spellID then
        return result
    end
    return nil
end

local function SafeGetSpecialization()
    if not C_SpecializationInfo.GetSpecialization then return 0 end
    local ok, result = pcall(C_SpecializationInfo.GetSpecialization)
    return ok and result or 0
end

local function SafeGetActionText(slot)
    if not slot or not GetActionText then return nil end
    local ok, result = pcall(GetActionText, slot)
    return ok and result or nil
end

local function IsInCombat()
    return UnitAffectingCombat and UnitAffectingCombat("player") or false
end

local function IsInStealth()
    return IsStealthed and IsStealthed() or false
end

local function IsSpellKnownByIdentifier(identifier)
    if not identifier or identifier == "" then return false end
    
    local spellID = tonumber(identifier)
    if spellID then
        if BlizzardAPI and BlizzardAPI.IsSpellAvailable then
            return BlizzardAPI.IsSpellAvailable(spellID)
        elseif IsSpellKnown then
            return IsSpellKnown(spellID) or (IsPlayerSpell and IsPlayerSpell(spellID)) or false
        end
    else
        if C_Spell and C_Spell.GetSpellInfo then
            local ok, spellInfo = pcall(C_Spell.GetSpellInfo, identifier)
            if ok and spellInfo and spellInfo.spellID then
                local sid = spellInfo.spellID
                if BlizzardAPI and BlizzardAPI.IsSpellAvailable then
                    return BlizzardAPI.IsSpellAvailable(sid)
                elseif IsSpellKnown then
                    return IsSpellKnown(sid) or (IsPlayerSpell and IsPlayerSpell(sid)) or false
                end
            end
        end
    end
    
    return false
end

local function SafeGetMacroInfo(macroName)
    if not macroName or not GetMacroInfo then return nil, nil, nil end
    local ok, name, icon, body = pcall(GetMacroInfo, macroName)
    if ok then
        return name, icon, body
    end
    return nil, nil, nil
end

function MacroParser.InvalidateMacroCache()
    wipe(parsedMacroCache)
    wipe(spellOverrideCache)
end

--- Drop cached parses for a single action slot (ACTIONBAR_SLOT_CHANGED).
--- Cache keys are "slot_spellID_spec". spellOverrideCache is untouched:
--- a slot change can't alter spell overrides.
function MacroParser.InvalidateMacroSlot(slot)
    local prefix = slot .. "_"
    local len = #prefix
    for key in pairs(parsedMacroCache) do
        if key:sub(1, len) == prefix then
            parsedMacroCache[key] = nil
        end
    end
end

-- Event-only invalidation: spellOverrideCache is cleared by InvalidateMacroCache(),
-- which fires on form, spell, spec, bar-page and vehicle/possess changes. (A single
-- ACTIONBAR_SLOT_CHANGED only drops that slot's parses - overrides are slot-independent.)
local function GetSpellAndOverride(spellID, spellName)
    if spellOverrideCache[spellID] then
        return spellOverrideCache[spellID]
    end

    local spells = {}
    if spellID and spellID > 0 then
        spells[spellID] = spellName
    end

    local overrideSpellID = SafeGetOverrideSpell(spellID)
    if overrideSpellID and BlizzardAPI then
        local overrideSpellInfo = BlizzardAPI.GetSpellInfo(overrideSpellID)
        if overrideSpellInfo and overrideSpellInfo.name then
            spells[overrideSpellID] = overrideSpellInfo.name
        end
    end
    -- And the BASE, the other way along the same chain: a spell that transforms while you
    -- use it (a channel's in-flight form) reaches here as the transformed id, but a macro
    -- names the base. Without it the keyed macro stopped matching mid-channel and a keyless
    -- slot holding the plain spell - which slot matching does resolve by base - won.
    local baseSpellID = FindBaseSpellByID and FindBaseSpellByID(spellID)
    if baseSpellID and baseSpellID ~= spellID and BlizzardAPI then
        local baseInfo = BlizzardAPI.GetSpellInfo(baseSpellID)
        if baseInfo and baseInfo.name then
            spells[baseSpellID] = baseInfo.name
        end
    end

    spellOverrideCache[spellID] = spells
    return spells
end

local function DoesSpellMatch(spellPart, targetSpells)
    if not spellPart or spellPart == "" then return false end
    
    local lowerSpellPart = GetLowercase(spellPart)
    
    -- Strip leading ! (repeat-cast toggle), target specifiers (@mouseover, @player, etc.) and trailing markers
    local cleanSpellPart = lowerSpellPart:gsub("^!", ""):gsub("%s*@[%w]+%s*$", ""):gsub("%s*%(@[%w]+%)%s*$", "")
    cleanSpellPart = cleanSpellPart:gsub("%s*%(.-%)%s*$", "")
    cleanSpellPart = cleanSpellPart:match("^%s*(.-)%s*$") or cleanSpellPart
    
    local checkOriginal = cleanSpellPart ~= lowerSpellPart
    for spellID, spellName in pairs(targetSpells) do
        local lowerSpellName = GetLowercase(spellName)
        if cleanSpellPart == lowerSpellName then
            return true, spellID, spellName
        end
        if checkOriginal and lowerSpellPart == lowerSpellName then
            return true, spellID, spellName
        end
    end
    
    return false
end

-- Shared macro-line walk for AnalyzeMacroExecutionFlow and ParseMacroForSpell.
-- Invokes callback once per /use, /cast, or /castsequence command line with the
-- line's clauses pre-split:
--   entries[i] = { entry = raw clause text, spellPart, conditionGroups }
-- /cast and /use clauses are semicolon-separated fallbacks with per-clause
-- [condition] brackets; /castsequence entries are comma-separated, only trimmed,
-- and all share the sequence-level condition groups (after the reset= clause is
-- stripped). Comment (#) lines are always skipped. skipInertLines additionally
-- skips blank and /stopcasting lines: execution-flow analysis skips them, keybind
-- parsing historically does not (behavior-identical either way, since neither
-- kind of line can match a command pattern, but the drift is kept explicit).
-- A non-nil callback return stops the walk and is returned.
-- "/startattack [conditions]" starts the Attack spell (6603) under those conditions, so it
-- reads as a cast of Attack, by its localized name.
local attackName
local function StartAttackCommand(lowerLine)
    local rest = string_match(lowerLine, "^%s*/startattack(.*)$")
    if not rest then return nil end
    -- Cached only once the client has the name: an early fallback must not stick for the
    -- session, or a non-English client never matches.
    local name = attackName
    if not name then
        local ok, info = pcall(C_Spell.GetSpellInfo, 6603)
        if ok and info and info.name then attackName = GetLowercase(info.name) end
        name = attackName or "attack"
    end
    local conds = ""
    for b in string_gmatch(rest, "%b[]") do conds = conds .. b end
    return conds .. " " .. name
end

local function ForEachCommandLine(macroBody, skipInertLines, callback)
    local commandIndex = 0

    for line in string_gmatch(macroBody, "[^\r\n]+") do
        local lowerLine = GetLowercase(line)

        local skipped = string_match(lowerLine, "^%s*#") ~= nil
        if not skipped and skipInertLines then
            skipped = string_match(lowerLine, "^%s*$") ~= nil
                or string_match(lowerLine, "^%s*/stopcasting") ~= nil
        end

        if not skipped then
            local command = string_match(lowerLine, "/use%s+(.+)") or
                            string_match(lowerLine, "/cast%s+(.+)")
            local isAttackLine = false
            if not command then
                command = StartAttackCommand(lowerLine)
                isAttackLine = command ~= nil
            end
            local castseqGroups  -- sequence-level condition groups for /castsequence

            if not command then
                local castseq = string_match(lowerLine, "/castsequence%s+(.+)")
                if castseq then
                    local seqSpellPart, seqGroups = StripBracketConditions(castseq)
                    castseqGroups = seqGroups
                    command = seqSpellPart:gsub("^reset=[^,]+,%s*", ""):gsub("^reset=[^%s]+%s*", "")
                end
            end

            if command then
                -- A /startattack line does not move the count: "/startattack" + "/cast X"
                -- keeps X as the macro's first command, as it always scored.
                local index = commandIndex + 1
                if not isAttackLine then commandIndex = index end
                local isCastseq = castseqGroups ~= nil
                local entries = {}
                local entryPattern = isCastseq and "[^,]+" or "[^;]+"

                for spellEntry in string_gmatch(command, entryPattern) do
                    local spellPart, conditionGroups
                    if isCastseq then
                        spellPart = spellEntry:match("^%s*(.-)%s*$") or ""
                        conditionGroups = castseqGroups
                    else
                        spellPart, conditionGroups = StripBracketConditions(spellEntry)
                    end
                    table_insert(entries, {
                        entry = spellEntry,
                        spellPart = spellPart,
                        conditionGroups = conditionGroups,
                    })
                end

                local result = callback(index, isCastseq, entries)
                if result ~= nil then return result end
            end
        end
    end

    return nil
end

local function AnalyzeMacroExecutionFlow(macroBody, targetSpells)
    return ForEachCommandLine(macroBody, true, function(commandIndex, isCastseq, entries)
        local totalInLine = 0
        local clauseEntries = {}
        local targetSpellFound = false
        local targetSpellPosition = 0

        for clausePosition, clause in ipairs(entries) do
            local spellPart = clause.spellPart
            if spellPart and spellPart ~= "" then
                totalInLine = totalInLine + 1
                table_insert(clauseEntries, clause.entry)

                if DoesSpellMatch(spellPart, targetSpells) then
                    targetSpellFound = true
                    targetSpellPosition = clausePosition
                end
            end
        end

        if targetSpellFound then
            -- Count [condition] brackets in the matching clause only
            local matchingEntry = clauseEntries[targetSpellPosition] or ""
            local lineConditions = 0
            for _ in string_gmatch(matchingEntry, "%[[^%]]*%]") do
                lineConditions = lineConditions + 1
            end
            return {
                order = commandIndex,
                positionInLine = targetSpellPosition,
                totalInLine = totalInLine,
                conditionCount = lineConditions,
                isFirstClause = targetSpellPosition == 1,
            }
        end
    end)
end

local function CalculateMacroSpecificityScore(macroName, macroBody, targetSpells, debugMode)
    local score = 500
    local lowerMacroName = GetLowercase(macroName)

    for spellID, spellName in pairs(targetSpells) do
        local lowerSpellName = GetLowercase(spellName)
        if lowerMacroName == lowerSpellName then
            score = score + 200
            break
        elseif #lowerSpellName >= 4 and string_find(lowerMacroName, string_sub(lowerSpellName, 1, 4), 1, true) then
            score = score + 150
            break
        end
    end
    
    local executionInfo = AnalyzeMacroExecutionFlow(macroBody, targetSpells)
    
    if executionInfo then
        local penalty = 0
        
        if executionInfo.order > 1 then
            penalty = penalty + (executionInfo.order - 1) * 150
        end
        
        if executionInfo.positionInLine > 1 then
            penalty = penalty + (executionInfo.positionInLine - 1) * 75
        end
        
        if executionInfo.totalInLine > 2 then
            penalty = penalty + (executionInfo.totalInLine - 2) * 25
        end
        
        -- Multi-spell line penalty: if target spell is not the first clause
        if executionInfo.totalInLine > 1 and not executionInfo.isFirstClause then
            penalty = penalty + 100
        end
        
        local conditionCount = executionInfo.conditionCount or 0
        if conditionCount > 0 then
            score = score + (conditionCount * 50)
        end
        
        score = score - penalty

        local now = GetTime()
        local throttleKey = "spec_" .. macroName
        if debugMode and (not lastPrintTime[throttleKey] or now - lastPrintTime[throttleKey] > DEBUG_THROTTLE_INTERVAL) then
            lastPrintTime[throttleKey] = now
            print("|JAC| Macro '" .. macroName .. "' specificity: score=" .. score .. ", penalty=" .. penalty .. ", conditions=" .. conditionCount)
        end
    end
    
    return score
end

-- ponytail: hand-rolled subset of Blizzard's macro-conditional grammar; unhandled
-- clauses (target/mounted/outdoors/...) fail-open. Drifts as Blizzard adds
-- conditionals - deliberately NOT SecureCmdOptionParse, which answers "what fires
-- right now" and would blank/churn a static keybind display.
local function EvaluateConditions(conditionString, currentSpec, currentForm)
    local modifiers = {}
    local allConditionsMet = true
    local formMatched = false
    local requiresModifier = false

    if not conditionString or conditionString == "" then
        return true, modifiers, false, false
    end

    for condition in conditionString:gmatch("[^,]+") do
        local trimmed = GetLowercase(condition:match("^%s*(.-)%s*$"))

        if trimmed:match("^mod") then
            local modType = trimmed:match("^mod:?(.*)") or "any"
            if modType == "" then modType = "any" end
            modifiers.mod = modType
            requiresModifier = true  -- Mark clause as modifier-dependent for keybind detection

        elseif trimmed:match("^nomod") then
            modifiers.nomod = true  -- No-modifier clause = what we want for default keybind

        elseif trimmed:match("^nospec") then
            local specList = trimmed:match("nospec:([%d/]+)")
            if specList then
                for specStr in specList:gmatch("([^/]+)") do
                    local reqSpec = tonumber(specStr)
                    if reqSpec and currentSpec == reqSpec then
                        allConditionsMet = false
                        break
                    end
                end
            end
            if not allConditionsMet then break end

        elseif trimmed:match("^spec") then
            local match = false
            local specList = trimmed:match("spec:([%d/]+)")
            if specList then
                for specStr in specList:gmatch("([^/]+)") do
                    local reqSpec = tonumber(specStr)
                    if reqSpec and currentSpec == reqSpec then
                        match = true
                        break
                    end
                end
            end
            if not match then allConditionsMet = false; break end

        -- [stance] and [form] are the same conditional under two names, and so are
        -- their negations. Two shapes, not four. The id list is read after the
        -- first colon rather than by name, which is what lets one arm serve both.
        elseif trimmed:match("^noform") or trimmed:match("^nostance") then
            local formList = trimmed:match(":([%d/]+)")
            if formList then
                for formStr in formList:gmatch("([^/]+)") do
                    if tonumber(formStr) == currentForm then
                        allConditionsMet = false
                        break
                    end
                end
            elseif currentForm ~= 0 then
                -- bare [noform] / [nostance] = only pass if not in any form
                allConditionsMet = false
            end
            if not allConditionsMet then break end

        elseif trimmed:match("^form") or trimmed:match("^stance") then
            local match = false
            local formList = trimmed:match(":([%d/]+)")
            if formList then
                for formStr in formList:gmatch("([^/]+)") do
                    if tonumber(formStr) == currentForm then
                        match = true
                        break
                    end
                end
            else
                -- bare [form] / [stance] = any form active
                match = (currentForm ~= 0)
            end
            if match then formMatched = true end
            if not match then allConditionsMet = false; break end

        elseif trimmed:match("^known") then
            local spellIdentifier = trimmed:match("known:(.+)")
            if spellIdentifier and not IsSpellKnownByIdentifier(spellIdentifier) then
                allConditionsMet = false
                break
            end

        elseif trimmed:match("^combat") then
            if not IsInCombat() then
                allConditionsMet = false
                break
            end

        elseif trimmed:match("^nocombat") then
            if IsInCombat() then
                allConditionsMet = false
                break
            end

        elseif trimmed:match("^stealth") then
            if not IsInStealth() then
                allConditionsMet = false
                break
            end

        elseif trimmed:match("^nostealth") then
            if IsInStealth() then
                allConditionsMet = false
                break
            end

        -- Target/mounted/outdoors conditions ignored - don't affect which key to press
        end
    end

    return allConditionsMet, modifiers, formMatched, requiresModifier
end

function MacroParser.ParseMacroForSpell(macroBody, targetSpellID, targetSpellName)
    if not macroBody or not targetSpellID or not targetSpellName or targetSpellName == "" then 
        return false, nil 
    end

    local targetSpells = GetSpellAndOverride(targetSpellID, targetSpellName)
    local currentSpec = SafeGetSpecialization()
    -- Use FormCache which returns form index (1-N), not GetShapeshiftFormID which returns constant IDs
    local currentForm = FormCache and FormCache.GetActiveForm() or 0
    local debugMode = GetDebugMode()

    local bestMatch = nil

    ForEachCommandLine(macroBody, false, function(commandIndex, isCastseq, entries)
        for _, clause in ipairs(entries) do
            local spellPart = clause.spellPart
            local conditionGroups = clause.conditionGroups

            local isMatch, matchedSpellID, matchedSpellName = DoesSpellMatch(spellPart, targetSpells)

            if isMatch then
                local now = GetTime()
                local throttleKey = "match_" .. matchedSpellID
                if debugMode and (not lastPrintTime[throttleKey] or now - lastPrintTime[throttleKey] > DEBUG_THROTTLE_INTERVAL) then
                    lastPrintTime[throttleKey] = now
                    print("|JAC| Found macro match: '" .. spellPart .. "' -> " .. matchedSpellName .. " (ID: " .. matchedSpellID .. ")")
                end

                local modifiers = {}
                local conditionsMet = true
                local requiresModifier = false

                if conditionGroups and #conditionGroups > 0 then
                    -- OR-cascade: first passing bracket group wins
                    conditionsMet = false
                    for _, conditionString in ipairs(conditionGroups) do
                        if conditionString == "" then
                            -- bare [] = unconditional fallback
                            conditionsMet = true
                            break
                        end
                        local groupMet, groupMods, _, groupReq = EvaluateConditions(conditionString, currentSpec, currentForm)
                        if groupMet then
                            conditionsMet = true
                            modifiers = groupMods
                            requiresModifier = groupReq
                            break
                        end
                    end
                end

                if conditionsMet then
                    -- Prefer no-modifier clause for default keybind detection
                    if not bestMatch or (not requiresModifier and bestMatch.requiresModifier) then
                        bestMatch = {modifiers = modifiers, requiresModifier = requiresModifier}
                    end
                end
            end
        end
    end)

    if bestMatch then
        return true, bestMatch.modifiers
    end
    return false, nil
end

function MacroParser.GetMacroSpellInfo(slot, targetSpellID, targetSpellName)
    if not slot or not targetSpellID or not targetSpellName or targetSpellName == "" then
        return nil
    end

    -- Cache by spec only - form/stealth/combat affect spell cast, not keybind
    local currentSpec = SafeGetSpecialization()
    local cacheKey = slot .. "_" .. targetSpellID .. "_" .. currentSpec

    -- false = cached negative: without it, every non-matching (slot, spell) pair
    -- re-parses the full macro body on every hotkey rebuild.
    local cached = parsedMacroCache[cacheKey]
    if cached ~= nil then
        return cached or nil
    end

    local actionText = SafeGetActionText(slot)
    if not actionText or actionText == "" then return nil end

    local name, _, body = SafeGetMacroInfo(actionText)
    if not name or not body or body == "" then
        parsedMacroCache[cacheKey] = false
        return nil
    end

    local found, modifiers = MacroParser.ParseMacroForSpell(body, targetSpellID, targetSpellName)
    if not found then
        parsedMacroCache[cacheKey] = false
        return nil
    end

    local targetSpells = GetSpellAndOverride(targetSpellID, targetSpellName)
    local qualityScore = CalculateMacroSpecificityScore(name, body, targetSpells, GetDebugMode())
    
    local entry = {
        found = true,
        modifiers = modifiers,
        qualityScore = qualityScore,
    }
    
    parsedMacroCache[cacheKey] = entry
    return entry
end