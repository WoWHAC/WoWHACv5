-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2026 wealdly
-- PrecombatEngine.lua - Out-of-combat buff checklist. Detects pre-combat buffs (flask,
-- food, augment rune, weapon enchant) the player is missing AND owns something to fix.
-- Detection is aura-based and runs only out of combat, so it never touches the 12.0
-- secret-value wall (auras and item counts are plain values out of combat).

local PrecombatEngine = LibStub:NewLibrary("JustAC-PrecombatEngine", 9)
if not PrecombatEngine then return end

local SpellDB = LibStub("JustAC-SpellDB", true)
local BlizzardAPI = LibStub("JustAC-BlizzardAPI", true)

local InCombatLockdown = InCombatLockdown
local GetWeaponEnchantInfo = GetWeaponEnchantInfo
local C_UnitAuras = C_UnitAuras
local ipairs = ipairs
local GetTime = GetTime
local type = type
local UnitClass = UnitClass
local UnitIsDeadOrGhost = UnitIsDeadOrGhost
local UnitCastingInfo = UnitCastingInfo
local UnitChannelInfo = UnitChannelInfo
local IsPlayerSpell = IsPlayerSpell or IsSpellKnown

-- Top-off "between pulls" reminder fires below this (exact read, OOC only) - toggle-gated.
local RECUPERATE_HEALTH_PCT = 90
-- Emergency floor: at/below this (the never-secret low-health vignette) the heal ALWAYS
-- shows, regardless of the top-off toggle - a critical-health survival cue.
local LOW_HEALTH_PCT = 35

-- How long an ARMED top-off offer survives without a fresh arming signal. The
-- signals that can arm it while health is secret (regen ticks, the post-combat
-- window, the ally-low key) are intermittent, and the offer must not blink out
-- between two of them. "Provably at full" cancels the hold immediately, so this
-- can only ever keep an offer alive a little longer, never resurrect a stale one.
local TOPOFF_HOLD_SECONDS = 3
local topoffHeldUntil = 0

-- Onset debounce: "not at full" must persist this long before the reminder
-- appears. Health can dip below full for a moment for uninteresting reasons (a
-- scratch that regen erases immediately, a passive's no-change snapshot), and a
-- reminder that pops for one frame each time is worse than no reminder.
-- Deliberately ASYMMETRIC: appearing is delayed, but reaching full clears it
-- instantly - being told to top off when you are already topped off is the one
-- state this feature must never show.
local TOPOFF_ONSET_SECONDS = 2
local notFullSince = 0

-- Re-offer a buff once it has this much time left, rather than waiting for it to lapse
-- outright. FLAT time remaining, not a fraction of the duration: what matters is whether
-- the buff outlasts the pull, and a 60-minute flask with 20 minutes on it needs nothing.
-- Wider in a group, where a recast covers everyone and wants to land while people are
-- still standing around rather than mid-pull. Applies to EVERY out-of-combat category -
-- flasks, food, runes, oils, poisons, imbues, raid buffs - so they all age out the same way.
local PRECOMBAT_REFRESH_SOLO  = 180   -- 3 minutes
local PRECOMBAT_REFRESH_GROUP = 300   -- 5 minutes

local function RefreshWindow()
    local inGroup = IsInGroup and IsInGroup()
    -- Group-membership probes can come back secret in instanced contexts; unreadable means
    -- we cannot establish a group, and the narrower window is the one that nags less.
    if issecretvalue and issecretvalue(inGroup) then return PRECOMBAT_REFRESH_SOLO end
    return inGroup and PRECOMBAT_REFRESH_GROUP or PRECOMBAT_REFRESH_SOLO
end

-- Exported because the redundancy filter has to agree with us: it decides when a buff that
-- IS up stops being reason enough to hide the recast, and that has to be the same moment we
-- start offering it. Two numbers here meant the queue nagged long before we did.
PrecombatEngine.RefreshWindow = RefreshWindow

-- Is this aura close enough to lapsing to be worth re-applying now?
-- A permanent aura (duration 0) never lapses. Unreadable timing answers "no": a buff we
-- cannot time is one we must not nag about, since the cost of a false cue is a wasted
-- flask. Same rule the class-buff path uses, so one window governs everything.
local function IsLapsing(aura)
    if not aura then return false end
    local dur, exp = aura.duration, aura.expirationTime
    if issecretvalue and (issecretvalue(dur) or issecretvalue(exp)) then return false end
    if type(dur) ~= "number" or type(exp) ~= "number" or dur <= 0 then return false end
    return (exp - GetTime()) <= RefreshWindow()
end

-- Main-hand temp enchant (weapon oil / shaman imbue) present AND not about to run out.
-- Its expiry comes back as milliseconds REMAINING, not a timestamp - the one place in this
-- file where the window is not compared against expirationTime.
local function MainHandEnchantHolds()
    if not GetWeaponEnchantInfo then return false end
    local has, expiryMs = GetWeaponEnchantInfo()
    if not has then return false end
    if issecretvalue and issecretvalue(expiryMs) then return true end
    if type(expiryMs) ~= "number" then return true end
    return (expiryMs / 1000) > RefreshWindow()
end

-- Off-hand twin of MainHandEnchantHolds - select() past the main-hand triplet+id.
-- Only consulted when an off-hand imbue is actually offerable (see OffHandImbue).
local function OffHandEnchantHolds()
    if not GetWeaponEnchantInfo then return false end
    local _, _, _, _, has, expiryMs = GetWeaponEnchantInfo()
    if not has then return false end
    if issecretvalue and issecretvalue(expiryMs) then return true end
    if type(expiryMs) ~= "number" then return true end
    return (expiryMs / 1000) > RefreshWindow()
end

-- The off-hand imbue to offer, or nil. Blizzard routes the hands in SPELL DATA:
-- Windfury's tooltip reads "main-hand", and Flametongue's is conditional on KNOWING
-- Windfury ($?s33757[off-hand][]) - so when both are known (Enhancement), Flametongue
-- IS the off-hand cast and a plain spell click applies to the right slot; no
-- slot-targeted macro needed. Offerable only when the off-hand holds a WEAPON
-- (classID 2): shields and frills can't take an imbue. GetItemInfoInstant is
-- cache-free, so this never waits on an item query.
local function OffHandImbue()
    if not (IsPlayerSpell(33757) and IsPlayerSpell(318038)) then return nil end
    local itemID = GetInventoryItemID and GetInventoryItemID("player", 17)
    if not itemID then return nil end
    local classID = select(6, C_Item.GetItemInfoInstant(itemID))
    if classID ~= 2 then return nil end
    return 318038
end

-- True if the player currently has any aura whose spellId is in the set AND it is not
-- already inside the refresh window. Iterates the player's helpful auras (usually < 40),
-- so cost is independent of how big the set is - which matters because the food set can
-- hold a few hundred Well Fed buff ids.
local function HasAnyAura(buffSet)
    if not buffSet or not BlizzardAPI or not BlizzardAPI.GetAuras then return false end
    local auras = BlizzardAPI.GetAuras("player", "HELPFUL")
    if not auras then return false end
    for i = 1, #auras do
        local spellId = auras[i].spellId
        -- 12.0.7: some aura spellIds are secret even out of combat; a secret table
        -- key throws, so skip those auras (their identity is unknowable here).
        -- Keep scanning past a lapsing match: a category can be satisfied by more than one
        -- buff, and a fresher one elsewhere in the list still counts.
        if spellId and not (issecretvalue and issecretvalue(spellId))
           and buffSet[spellId] and not IsLapsing(auras[i]) then return true end
    end
    return false
end

-- The weapon imbue the player knows (in preference order), or nil. Shaman only - IsPlayerSpell
-- gates and separates specs (Enhancement -> Windfury, Resto -> Earthliving). Imbues are weapon
-- ENCHANTS, so they're detected/suggested off the weapon (GetWeaponEnchantInfo), not auras.
local function KnownWeaponImbue()
    local list = SpellDB and SpellDB.WEAPON_IMBUE_SPELLS
    if not list then return nil end
    for i = 1, #list do
        if IsPlayerSpell(list[i]) then return list[i] end
    end
    return nil
end

-- Optimistic post-click suppression for weapon enhancements. Applying one is a server
-- round trip, so GetWeaponEnchantInfo keeps reporting "no enchant" for a beat after the
-- click - long enough that the suggestion lingers, still clickable, and a double-click
-- burns a second stone (the click applies in one go; it isn't a harmless cursor arm).
-- Treat the category as satisfied for a moment after a click so the icon clears at once.
-- Purely a display latch: if the application never landed, the window lapses and the
-- suggestion returns on the next rebuild.
local ENCHANT_APPLY_GRACE = 2
local enchantAppliedAt = -1e9

--- Called by the click overlay the instant a weapon enhancement is used.
function PrecombatEngine.NoteWeaponEnchantApplied()
    enchantAppliedAt = GetTime()
    PrecombatEngine.ClearCache()
end

--- Mid-application guard: is an application in progress right now? Every category here is
--- satisfied by an AURA (or a weapon enchant) that only lands when the cast/channel COMPLETES,
--- so while you are eating, applying a poison or imbue, or using an oil, the category still
--- reads "missing". One more click then cancels the channel (wasting the food) or burns a
--- second consumable - and ANY suggestion cancels it, not just the one being applied.
---
--- The suggestions STAY on screen through the wait (you are still out of combat, and the icon
--- is what tells you what you're waiting on); it's the CLICK that has to stop. The click
--- overlay disarms every layer while this is true - see UIPrecombatOverlay.
---
--- Eating counts even though it is aura-based (no cast bar, no UnitChannelInfo) - but only
--- for the ~10s it takes Well Fed to land, not the whole meal. The buff persists once you
--- stand up, so waiting out the rest of the food aura buys nothing.
--- OOC-only system, and we only test truthiness (never compare/concat), so this is secret-safe.
function PrecombatEngine.IsBusyApplying()
    if UnitCastingInfo and UnitCastingInfo("player") then return true end
    if UnitChannelInfo and UnitChannelInfo("player") then return true end
    if SpellDB and SpellDB.IsEatingForBuff then
        return SpellDB.IsEatingForBuff()
    end
    return false
end

--- Is the buff category already satisfied? Weapon enchant is read off the weapon (temp
--- enchant); every other category from the player's auras. Out of combat only.
function PrecombatEngine.IsCategorySatisfied(category)
    -- 12.0.7: in aura-restricted contexts (PvP instances - restriction is per-context,
    -- not per-combat) every aura reads as secret, so nothing can be verified. Report
    -- satisfied so we never nag someone to re-consume a buff they may already have.
    -- Live gate; false in normal content keeps this a no-op.
    if BlizzardAPI and BlizzardAPI.AreAurasSecret() then
        return true
    end
    if category == "weaponEnchant" then
        if GetTime() - enchantAppliedAt < ENCHANT_APPLY_GRACE then return true end
        return MainHandEnchantHolds()
    end
    local set = SpellDB and SpellDB.GetPrecombatBuffSet and SpellDB.GetPrecombatBuffSet(category)
    return HasAnyAura(set)
end

--- Pre-combat buffs the player is missing AND can fix right now:
--- { {category=, entry=}, ... } - the best owned entry per enabled, unsatisfied category.
--- Out of combat only (returns empty in combat; buffs can't be applied there anyway). A
--- category only appears if the player actually OWNS something that satisfies it.
--- `settings` (optional), keyed by category:
---   settings[category] = false             -> category disabled
---   settings[category] = "haste"/"crit"/…  -> stat preference for the best-owned pick
function PrecombatEngine.GetMissingBuffs(settings)
    local out = {}
    if InCombatLockdown() then return out end
    if not SpellDB or not SpellDB.GetPrecombatBuffCategories then return out end
    for _, category in ipairs(SpellDB.GetPrecombatBuffCategories()) do
        -- An imbue-using class (Enhancement shaman) fills the main-hand enchant slot with its
        -- weapon imbue, so never suggest a weapon oil for it - the imbue is offered instead by
        -- GetMissingClassBuffs (and an oil would just overwrite the imbue anyway).
        local skip = category == "weaponEnchant" and KnownWeaponImbue() ~= nil
        local pref = settings and settings[category]
        if not skip and pref ~= false and not PrecombatEngine.IsCategorySatisfied(category) then
            local entry = SpellDB.GetBestOwnedBuff(category,
                type(pref) == "string" and pref or nil)
            if entry then
                out[#out + 1] = { category = category, entry = entry }
            end
        end
    end
    return out
end

--- Just the bag-item IDs to insert at the front of the defensive queue, in category order
--- (bag items only; toys/spells are handled elsewhere). Out of combat only.
---
--- Cached for a short window: the defensive queue rebuilds up to ~10x/s, but this scans
--- every buff item (GetItemCount) + aura state, which only changes on bag/aura/gear events.
--- A 0.5s expiry caps the full scan at ~2x/s and still reflects changes within half a
--- second. (In combat the queue insertion is skipped entirely, so the cache is OOC-only.)
local cachedItems, cachedItemsAt = nil, -1
local cachedClassBuffs, cachedClassBuffsAt = nil, -1
function PrecombatEngine.GetMissingBuffItems(settings)
    local now = GetTime()
    if cachedItems and (now - cachedItemsAt) < 0.5 then
        return cachedItems
    end
    local out = {}
    for _, m in ipairs(PrecombatEngine.GetMissingBuffs(settings)) do
        if (m.entry.source or "item") == "item" then
            out[#out + 1] = m.entry.id
        end
    end
    if not (settings and settings.recovery == false) then PrecombatEngine.AddRecoveryItems(out) end
    cachedItems, cachedItemsAt = out, now
    return out
end

-- WoW Forever: recover between pulls. Out of combat with mana below RECOVERY_MANA_PCT, offer
-- the best drink; with health below RECOVERY_HEALTH_PCT, the best food, or a bandage when no
-- food is in the bags. Health and mana are secret there even out of combat; the engine-side
-- "below N%" checks answer (measured build 70245). Nothing while already eating or drinking,
-- mounted or dead. A no-op on retail, where no recovery items are registered.
-- ponytail: fixed thresholds; make them options if players want them tuned.
local RECOVERY_HEALTH_PCT, RECOVERY_MANA_PCT = 70, 50
local RECENTLY_BANDAGED = 11196
local NO_MANA = { WARRIOR = true, ROGUE = true }
function PrecombatEngine.AddRecoveryItems(out)
    if not (SpellDB and SpellDB.IsForever() and SpellDB.GetBestRecoveryItem and BlizzardAPI) then return end
    local dead = UnitIsDeadOrGhost("player")
    if InCombatLockdown() or (IsMounted and IsMounted())
       or (issecretvalue and issecretvalue(dead)) or dead
       or (SpellDB.GetActiveEatingAura and SpellDB.GetActiveEatingAura()) then
        return
    end
    local function add(id) if id then out[#out + 1] = id end end
    if not NO_MANA[select(2, UnitClass("player")) or ""] and BlizzardAPI.IsUnitPowerBelow
       and BlizzardAPI.IsUnitPowerBelow("player", RECOVERY_MANA_PCT, Enum.PowerType.Mana) == true then
        add(SpellDB.GetBestRecoveryItem("drink"))
    end
    if BlizzardAPI.IsUnitHealthBelow and BlizzardAPI.IsUnitHealthBelow("player", RECOVERY_HEALTH_PCT) == true then
        local food = SpellDB.GetBestRecoveryItem("food")
        if food then
            add(food)
        else
            local ok, bandaged = pcall(C_UnitAuras.GetPlayerAuraBySpellID, RECENTLY_BANDAGED)
            if not (ok and bandaged) then add(SpellDB.GetBestRecoveryItem("bandage")) end
        end
    end
end

--- Drop the cache so the next query recomputes immediately (call on options changes).
function PrecombatEngine.ClearCache()
    cachedItemsAt = -1
    cachedClassBuffsAt = -1
end

-- Class maintained buffs (poisons, imbues) that need (re)applying, as spell IDs. For each
-- group we find the option that's currently ACTIVE and re-suggest it once it is close enough
-- to lapsing to be worth a recast; if none is up we fall back to the group's default. Only
-- spells the player knows (IsPlayerSpell) surface, so it self-gates by class. Out of combat
-- only; cached. Shares the flat refresh window with the consumable categories (IsLapsing);
-- every buff in this table runs 30-60 minutes, so no short-duration floor is needed.
--
-- One override on all of that: when the assisted-combat rotation expresses its own pick
-- within a group (see ACPickInGroup), that pick WINS - over the default, over the queue
-- scan, and even over a different member that is already active and fresh.

-- Forever ranks: groups name rank 1, while casts, the queue and the bar carry the rank
-- pressed. Every match below goes through rank 1 (the id itself on retail).
local RotationImport = LibStub("JustAC-RotationImport", true)
local function R1(id) return RotationImport and RotationImport.RankBase(id) or id end

-- The member of `group` the assisted-combat rotation itself runs, or nil. Matching it is
-- mandatory, not cosmetic: the AC manager keeps recommending ITS member until that exact
-- one is applied - a different member of the same group never satisfies it - so offering
-- anything else sends the player in a circle (apply ours, AC still nags for the other).
-- Two sources, in authority order:
--   1. The live demand (GetAnyNextCastSpell / plain queue head) - the very spell slot 1
--      is frozen on. Plain and readable out of combat, which is the only place this runs.
--   2. GetRotationSpells - the spec's full AC spell list (also plain). Confirmed in game:
--      it carries EVERY member of a group the spec can use (Sub lists all three
--      non-lethal poisons), so it expresses a pick ONLY when exactly one member appears.
--      Several listed members = no opinion - return nil and let the demand chain (or,
--      with no demand pending, the caller's fallbacks) decide.
local function ACPickInGroup(nextCast, rotation, group)
    if nextCast then
        nextCast = R1(nextCast)
        for j = 1, #group do
            if nextCast == group[j] and IsPlayerSpell(group[j]) then return group[j] end
        end
    end
    if not rotation then return nil end
    local found
    for j = 1, #group do
        if IsPlayerSpell(group[j]) then
            for i = 1, #rotation do
                if R1(rotation[i]) == group[j] then
                    if found then return nil end   -- second member listed: ambiguous
                    found = group[j]
                    break
                end
            end
        end
    end
    return found
end

-- Highest-priority member of `group` that the current rotation/fixed queue wants, or nil.
-- Fallback pick when a maintained buff is missing entirely and the rotation list gave no
-- answer (ACPickInGroup above is the preferred source): offer the poison the fixed queue
-- is actually trying to apply instead of a blind default. Best-effort only - position 1
-- of the queue is Blizzard's 12.0 secret suggestion, which can't be compared (a raw `==`
-- throws), so secret entries are skipped. Returns the known group constant (never a queue
-- value) and only one the player knows, so it can NEVER suppress the reliable default
-- fallback at the call site.
local issecretvalue = issecretvalue
local function HighestQueuedInGroup(group)
    local SQ = LibStub("JustAC-SpellQueue", true)
    local queue = SQ and SQ.GetCurrentSpellQueue and SQ.GetCurrentSpellQueue()
    if type(queue) ~= "table" then return nil end
    for i = 1, #queue do
        local q = queue[i]
        if not (issecretvalue and issecretvalue(q)) then
            q = R1(q)
            for j = 1, #group do
                if q == group[j] and IsPlayerSpell(group[j]) then return group[j] end
            end
        end
    end
    return nil
end

local IsSecret = BlizzardAPI and BlizzardAPI.IsSecretValue or function() return false end

-- Unit-state probes (exists / connected / dead / in-range) can return a SECRET BOOLEAN even
-- out of combat: secrecy is per-CONTEXT, not per-combat, so an instanced context secrets them
-- while player auras still read fine - which is exactly why the `restricted` aura gate upstream
-- does NOT cover this. A bare `if UnitInRange(unit) then` on a secret boolean THROWS.
-- Resolve to a real boolean when readable, nil when secret; every caller treats nil as
-- "can't tell" and skips the member (fail-silent - never cue what we can't verify).
local function ReadableBool(v)
    if v == nil then return nil end
    if IsSecret(v) then return nil end
    return v and true or false
end

-- Does `unit` carry any of `auraIDs` as a HELPFUL aura? Reads the unit's aura list directly -
-- deliberately NOT BlizzardAPI.IsAuraActive, which serves the player-only RedundancyFilter
-- cache when it's warm and would report every party member as buffed.
-- `auraIDs` is a LIST because a buff need not apply its own cast id - some trigger a
-- per-class sub-aura instead, and matching only the cast id would report a fully buffed
-- player as missing forever.
-- Fail-SILENT: an unreadable (secret) spellId means we can't prove the buff is missing, so
-- we report "has it". Note this bails on the FIRST unreadable entry rather than skipping it:
-- skipping could walk past the buff itself and produce a false "missing" cue. The cost is
-- that the party check goes quiet wherever auras are secret - the right trade for a feature
-- whose only failure mode would otherwise be nagging about a buff that is already up.
local function UnitHasHelpfulAura(unit, auraIDs)
    if not auraIDs then return true end
    -- Point queries FIRST: the by-spellID probe is the only mechanism that yields
    -- an AUTHORITATIVE negative under 12.0 (presence/absence as plain table-or-nil;
    -- the rule the Midnight-native frames addons converged on). The bulk scan below
    -- stays as fallback, but its fail-silent rule reads any doubt as "has it", so
    -- routing through it first muted the feature wherever reads were partial. A
    -- throw here means a restricted read, not absence - fall through to the scan.
    local byId = C_UnitAuras and C_UnitAuras.GetUnitAuraBySpellID
    if byId then
        local sawThrow = false
        for j = 1, #auraIDs do
            local ok, data = pcall(byId, unit, auraIDs[j])
            if ok and data ~= nil then return true end
            if not ok then sawThrow = true end
        end
        if not sawThrow then return false end   -- every id answered plainly: true absence
    end
    if not BlizzardAPI or not BlizzardAPI.GetAuras then return true end
    local auras = BlizzardAPI.GetAuras(unit, "HELPFUL")
    if not auras then return true end
    for i = 1, #auras do
        local sid = auras[i].spellId
        if sid == nil or IsSecret(sid) then return true end
        for j = 1, #auraIDs do
            if sid == auraIDs[j] then return true end
        end
    end
    return false
end

-- True when a PARTY member who could actually receive the buff right now is missing it.
-- Party only (party1-4): raid scale would be up to 39 unit scans per refresh and would
-- cue constantly for people out of range or freshly resurrected, so raids are skipped
-- outright. Dead / disconnected / out-of-range members are excluded so every cue is one
-- the player can act on immediately. Note UnitInRange is ~40yd while these buffs reach
-- further - the mismatch errs toward silence, never toward a false cue.
local function PartyMemberMissingBuff(castID, auraIDs)
    -- Group-membership probes go through the same readable-boolean gate: anything we can't
    -- read plainly means we can't establish there's a party to check, so offer nothing.
    if ReadableBool(IsInGroup and IsInGroup()) ~= true then return false end
    if ReadableBool(IsInRaid and IsInRaid()) ~= false then return false end
    for i = 1, 4 do
        local unit = "party" .. i
        if ReadableBool(UnitExists(unit)) == true then
            -- Compare against explicit true/false, never a bare truthiness test: a secret
            -- probe resolves to nil here and the member is skipped, which is the only safe
            -- reading of "we cannot tell whether they are buffable".
            -- NPCs (dungeon followers, companions) never carry player raid buffs, so a
            -- follower party would nag forever - no recast can satisfy the check. And a
            -- cross-faction open-world member the buff cannot legally reach is noise, not
            -- a cue: UnitCanAssist filters those (plain reaction booleans, both).
            local isPlayer  = ReadableBool(UnitIsPlayer(unit))
            local canAssist = ReadableBool(UnitCanAssist("player", unit))
            local connected = ReadableBool(UnitIsConnected(unit))
            local dead      = ReadableBool(UnitIsDeadOrGhost(unit))
            -- Range via the BUFF's own spell-range query, which stays PLAIN for allies
            -- where the generic 40yd probe reads secret (measured 2026-08-10: UnitInRange
            -- returned a secret boolean for an open-world party member OUT of combat, so
            -- this gate silently skipped everyone and the recast nudge never fired). It
            -- is also the truer question - "can my recast reach them". The generic probe
            -- stays as fallback when the spell query has no answer.
            local inRange
            if castID and C_Spell and C_Spell.IsSpellInRange then
                local ok, sr = pcall(C_Spell.IsSpellInRange, castID, unit)
                if ok then inRange = ReadableBool(sr) end
            end
            if inRange == nil then
                inRange = ReadableBool(UnitInRange(unit))
            end
            if isPlayer == true and canAssist == true
               and connected == true and dead == false and inRange == true
               and not UnitHasHelpfulAura(unit, auraIDs) then
                return true
            end
        end
    end
    return false
end

-- Applied-latch for class-buff and imbue SPELL casts - the spell twin of
-- NoteWeaponEnchantApplied above, fed from UNIT_SPELLCAST_SUCCEEDED. The cast has
-- landed but the aura (or weapon enchant) takes a server beat to register; without
-- this the offer stays on screen with a live "click" hint for those seconds, and a
-- second click re-applies for nothing. Purely a display latch: if the application
-- somehow never lands, the grace lapses and the offer returns.
local CLASSBUFF_APPLY_GRACE = 3
local classBuffAppliedAt = {}
local function IsFreshlyApplied(spellID)
    local t = classBuffAppliedAt[R1(spellID)]
    return t ~= nil and (GetTime() - t) < CLASSBUFF_APPLY_GRACE
end
-- Exported for RedundancyFilter's sibling rule: a group with a freshly-applied member
-- keeps its siblings out of the queue for the same settle window.
PrecombatEngine.IsClassBuffFresh = IsFreshlyApplied

--- Called from the addon's UNIT_SPELLCAST_SUCCEEDED handler for player casts.
--- Latches only maintained members and imbues, so the table stays a handful of keys.
function PrecombatEngine.NoteClassBuffApplied(spellID)
    if not spellID then return end
    local members = SpellDB and SpellDB.MAINTAINED_BUFF_MEMBERS
    local enchants = SpellDB and SpellDB.WEAPON_ENCHANT_SPELLS
    if (members and members[spellID]) or (enchants and enchants[spellID]) then
        classBuffAppliedAt[R1(spellID)] = GetTime()
        PrecombatEngine.ClearCache()
    end
end

-- Is the player currently CASTING a maintained application (a poison's several-second
-- apply, a weapon imbue)? Read for the mid-cast hold below. OOC cast info is plain.
local function CastingMaintainedBuff()
    if not UnitCastingInfo then return false end
    local castID = select(9, UnitCastingInfo("player"))
    if not castID or (issecretvalue and issecretvalue(castID)) then return false end
    if SpellDB and SpellDB.WEAPON_ENCHANT_SPELLS and SpellDB.WEAPON_ENCHANT_SPELLS[castID] then
        return true
    end
    castID = R1(castID)
    local class = select(2, UnitClass("player"))
    local groups = class and SpellDB and SpellDB.CLASS_MAINTAINED_BUFFS
        and SpellDB.CLASS_MAINTAINED_BUFFS[class]
    if not groups then return false end
    for _, grp in ipairs(groups) do
        for _, id in ipairs(grp.group) do
            if castID == id then return true end
        end
    end
    return false
end

-- Cooldown-free stealths worth entering before a pull, per class. Vanish and Shadowmeld are
-- left out: they are escapes with real cooldowns, not an opener stance. Prowl is Feral
-- only - every druid knows it, and on by default it would nag the other three specs.
local STEALTH_REMINDER = {
    ROGUE = { spell = 1784 },            -- Stealth
    DRUID = { spell = 5215, spec = 2, tree = "feral" },  -- Prowl (Feral)
}

--- The entry's spec gate. WoW Forever has one spec per class, so Feral there is the
--- installed talent tree (RotationImport picks it from points spent), not spec index 2.
local function StealthSpecMatches(entry)
    if not entry.spec then return true end
    if SpellDB and SpellDB.IsForever and SpellDB.IsForever() then
        local RI = LibStub("JustAC-RotationImport", true)
        local tree = RI and RI.GetForeverTree and RI.GetForeverTree()
        return tree == entry.tree or tree == (entry.tree and entry.tree .. "_bear")
    end
    return C_SpecializationInfo.GetSpecialization() == entry.spec
end
PrecombatEngine.STEALTH_REMINDER = STEALTH_REMINDER

--- The player's stealth, when it is worth reminding about: known, not already stealthed, and
--- not in a state where stealthing makes no sense (mounted, flying, on a taxi, resting, in a
--- vehicle, dead). Deliberately NOT gated on the cooldown: the offer keeps its slot with the
--- cooldown swipe, and the renderer holds its glow until the spell is ready.
local function StealthReminderSpell()
    if (IsStealthed and IsStealthed()) or (IsMounted and IsMounted())
        or (IsFlying and IsFlying()) or (UnitOnTaxi and UnitOnTaxi("player"))
        or (IsResting and IsResting())
        or ReadableBool(UnitInVehicle and UnitInVehicle("player")) == true
        or ReadableBool(UnitIsDeadOrGhost("player")) ~= false then
        return nil
    end
    local entry = STEALTH_REMINDER[select(2, UnitClass("player"))]
    if not entry or not StealthSpecMatches(entry) then return nil end
    -- OverridesKnown: Subterfuge replaces Stealth (1784 -> 115191), and a replaced base
    -- spell can read as unknown to IsPlayerSpell. Casting the base id still casts the override.
    local known = IsPlayerSpell(entry.spell)
        or (IsSpellKnownOrOverridesKnown and IsSpellKnownOrOverridesKnown(entry.spell))
    return known and entry.spell or nil
end

--- @param offerTopoff boolean|nil  include the OOC top-off self-heal (gated by the
---   precombatBuffs.topoffHeal option; passed by the caller which owns the profile). Poisons
---   and imbues are unaffected - only the health top-off reminder honors this flag.
--- @param topoffPct number|nil  the player's top-off threshold percent. Passed in rather
---   than read here for the same reason as offerTopoff: this module never touches the
---   profile. nil falls back to "below full".
--- @param offerStealth boolean|nil  include the stealth reminder (precombatBuffs.stealth).
function PrecombatEngine.GetMissingClassBuffs(offerTopoff, topoffPct, offerStealth)
    local now = GetTime()
    if cachedClassBuffs and (now - cachedClassBuffsAt) < 0.5 then
        return cachedClassBuffs
    end
    -- Mid-application hold: the moment a poison/imbue CAST starts, AC's demand pointer
    -- moves on to its next reveal, but the state it left won't settle until the cast
    -- lands and the aura updates. Recomputing during the cast surfaces that transient -
    -- a third poison flashing while the second is still applying - so serve the answer
    -- from before the cast began and recompute when it resolves (lands OR is cancelled;
    -- either way UnitCastingInfo goes quiet and the next call falls through). Bounded by
    -- the cast itself, so a hold can never outlive the confusion it hides.
    if cachedClassBuffs and CastingMaintainedBuff() then
        cachedClassBuffsAt = now   -- keep the cache warm for the cast's duration
        return cachedClassBuffs
    end
    local out = {}
    -- Which spell (if any) this pass offered as the health top-off, so the renderer can tell it
    -- apart from the poisons/imbues alongside it and drive its alpha from the health curve.
    -- Cleared on RECOMPUTE only: an early return from the cache above must keep the value that
    -- produced that cache, or the cue would blink off for the rest of the cache window.
    PrecombatEngine.offeredTopoffHeal = nil
    local groups = (not InCombatLockdown()) and SpellDB and SpellDB.CLASS_MAINTAINED_BUFFS
    local class = groups and select(2, UnitClass("player"))
    groups = class and SpellDB.CLASS_MAINTAINED_BUFFS[class]
    local get = C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID
    -- 12.0.7: in aura-restricted contexts the by-ID probe returns nil for secret-flagged
    -- auras (RequiresNonSecretAura), so every class buff would look lapsed - offer nothing.
    local restricted = BlizzardAPI and BlizzardAPI.AreAurasSecret()
    if groups and get and not restricted then
        -- AC's live demand, from the strongest source available:
        --   1. GetAnyNextCastSpell - the include-hidden API read. The visible-only
        --      variants skip spells with no action-bar button, and poisons rarely
        --      have one, so they'd report the demand as "nothing" (observed on Sub).
        --   2. The queue's position 1, when plain (it is out of combat) - the very
        --      icon the player sees frozen, so deferring to it can never disagree
        --      with what's on screen.
        local nextCast = BlizzardAPI and BlizzardAPI.GetAnyNextCastSpell
            and BlizzardAPI.GetAnyNextCastSpell()
        if not nextCast then
            local SQ = LibStub("JustAC-SpellQueue", true)
            local queue = SQ and SQ.GetCurrentSpellQueue and SQ.GetCurrentSpellQueue()
            local head = type(queue) == "table" and queue[1] or nil
            if head and not (issecretvalue and issecretvalue(head)) then nextCast = head end
        end
        if nextCast then nextCast = R1(nextCast) end
        local rotation = BlizzardAPI and BlizzardAPI.GetRotationSpells
            and BlizzardAPI.GetRotationSpells()
        -- AC surfaces its maintained-buff demands ONE at a time through the demand
        -- probe, and the rotation list can't break the tie (it carries every member
        -- the spec can use, not a preference). So while AC is demanding a member of
        -- ANY group, the picks for the OTHER groups are still hidden behind that
        -- demand - and offering our own default in that window is a trap: apply it,
        -- and AC's next reveal freezes on a member we just displaced. Those groups
        -- HOLD instead; each applied demand reveals the next group's pick.
        local pendingDemand = false
        if nextCast then
            for _, grp in ipairs(groups) do
                for _, id in ipairs(grp.group) do
                    if nextCast == id then pendingDemand = true; break end
                end
                if pendingDemand then break end
            end
            -- A demanded weapon IMBUE must hold the group fallbacks exactly like a
            -- demanded group member. Imbues live outside the aura groups (weapon
            -- enchants), so without this the shield default could fire while AC's
            -- shield pick is still hidden behind the imbue demand - the same
            -- displacement trap the hold exists for. The imbue itself is offered
            -- by the enchant tail below, so holding here hides nothing.
            if not pendingDemand and SpellDB and SpellDB.WEAPON_ENCHANT_SPELLS
               and SpellDB.WEAPON_ENCHANT_SPELLS[nextCast] then
                pendingDemand = true
            end
        end
        for _, grp in ipairs(groups) do
            local active, aura, latchedActive
            for _, spellID in ipairs(grp.group) do
                if IsPlayerSpell(spellID) then
                    local a = get(spellID)
                    -- A buff that applies a per-class sub-aura instead of its own cast id
                    -- is invisible to the cast-id probe - fall back to its declared aura
                    -- family. `active` stays the CAST id (that's what gets suggested);
                    -- only the detection changes.
                    if not a and grp.auraIDs then
                        for _, auraID in ipairs(grp.auraIDs) do
                            a = get(auraID)
                            if a then break end
                        end
                    end
                    if a then active, aura = spellID, a; break end
                    -- Applied-latch: the cast landed a moment ago but the aura hasn't
                    -- registered yet. Treat as active with UNKNOWN timing (aura nil -
                    -- IsLapsing answers false), so the group goes quiet the instant the
                    -- cast completes instead of a clickable beat later.
                    if IsFreshlyApplied(spellID) then
                        active, latchedActive = spellID, true
                        break
                    end
                end
            end
            local acPick = ACPickInGroup(nextCast, rotation, grp.group)
            -- While the active member is FRESHLY APPLIED, a differing AC demand is stale
            -- by definition - the demand API settles a few seconds behind the cast we
            -- just watched land (and behind Blizzard's own visible slot), and offering
            -- its member in that window is the sibling flash again, from the other side.
            -- Ask the latch DIRECTLY, not just latchedActive: when the aura registers
            -- faster than the demand settles (the common order right after a reload),
            -- `active` comes from the aura probe and latchedActive stays unset - the
            -- gate must hold in both orders. If AC still demands a different member
            -- once the grace lapses, that is a genuine wrong-member and it fires.
            if active and acPick and acPick ~= active
               and not (latchedActive or IsFreshlyApplied(active)) then
                -- The WRONG member is up: the assisted rotation runs a different one, and
                -- the active buff doesn't satisfy it, so AC's queue slot stays frozen on
                -- its pick no matter how fresh the current buff is. Offer AC's member -
                -- applying it replaces the active one and unfreezes the recommendation.
                out[#out + 1] = acPick
            elseif active then
                local offered = IsLapsing(aura)
                if offered then out[#out + 1] = active end
                -- Group buff the player already has, but a party member is missing it
                -- (joined late, released, or was out of range when it went out). One
                -- re-cast covers everyone, so offer it even though the player's own
                -- copy is nowhere near lapsing.
                -- latchedActive also blocks the party recast: the cast that just landed
                -- covered the party too, and THEIR auras lag the same server beat.
                if not offered and grp.raidWide and not latchedActive
                   and PartyMemberMissingBuff(active, grp.auraIDs or grp.group) then
                    out[#out + 1] = active
                end
            else
                -- Missing entirely (lapsed/cancelled): defer to the assisted rotation's
                -- pick; the queue-scan/default fallbacks only run when NO AC demand is
                -- pending in another group (see pendingDemand above) - otherwise this
                -- group holds until the chain reveals its pick.
                local pick = acPick
                if not pick and not pendingDemand then
                    pick = HighestQueuedInGroup(grp.group) or grp.default
                end
                if pick and IsPlayerSpell(pick) then out[#out + 1] = pick end
            end
        end

    end

    -- ENGINE-KNOWN group buffs the curated table does not cover (12.1.0+).
    -- C_CooldownViewer.GetGroupBuffItems is Blizzard's own registry, so a class buff
    -- added or reworked in a patch appears here without a data update. Kept strictly
    -- ADDITIVE - the curated groups above run first and own anything they claim -
    -- because a GroupBuffItem names only its cast id and carries no aura FAMILY, so
    -- detection for it is the plain by-id probe and nothing more.
    -- Skips hideByDefault entries: Blizzard de-emphasises those deliberately.
    --
    -- OUTSIDE the `groups` block on purpose. A class with NO curated entry is exactly
    -- the case this registry exists to cover, and nesting it under `groups` would
    -- have skipped precisely those classes - the gap it was added to close.
    -- `get`/`restricted` are still required: without a readable aura probe every buff
    -- reads as missing and we would nag for buffs already up.
    local engineBuffs = (not InCombatLockdown()) and get and not restricted
        and BlizzardAPI and BlizzardAPI.GetGroupBuffItems and BlizzardAPI.GetGroupBuffItems()
    if engineBuffs then
        local covered = {}
        for _, grp in ipairs(groups or {}) do
            for _, id in ipairs(grp.group) do covered[id] = true end
            for _, id in ipairs(grp.auraIDs or {}) do covered[id] = true end
        end
        -- Blizzard's registry is broader than "maintainable buff" (user-confirmed live on
        -- a Holy Priest, which got its whole registry offered at full health): it also
        -- carries group SAVE cooldowns (a raid heal channel, an external) and even known
        -- PASSIVES - isKnown answers true for those, and so does IsPlayerSpell. Neither
        -- is a precombat offer. The registry item carries no discriminating field, so:
        --   * passives are refused outright;
        --   * anything with a real cooldown is refused - a buff you keep up between
        --     pulls has none, a group save has minutes. GetSpellBaseCooldown is plain
        --     out of combat, which is the only place this block runs.
        for i = 1, #engineBuffs do
            local it = engineBuffs[i]
            if it.isKnown and not it.hideByDefault and not covered[it.spellID]
               and IsPlayerSpell(it.spellID) and not get(it.spellID)
               and not (BlizzardAPI and BlizzardAPI.IsPassiveSpell and BlizzardAPI.IsPassiveSpell(it.spellID)) then
                local cdMs = GetSpellBaseCooldown and GetSpellBaseCooldown(it.spellID)
                if not (cdMs and not (issecretvalue and issecretvalue(cdMs)) and cdMs > 60000) then
                    out[#out + 1] = it.spellID
                end
            end
        end
    end
    -- Weapon imbue (Enhancement shaman): a temp weapon ENCHANT, not a player aura, so it can't
    -- ride the group loop above. Suggest the known imbue while the main hand is bare or the
    -- enchant is inside the refresh window - the same read IsCategorySatisfied uses for oils.
    if not InCombatLockdown() then
        local imbue = KnownWeaponImbue()
        if imbue and not MainHandEnchantHolds() and not IsFreshlyApplied(imbue) then
            out[#out + 1] = imbue
        end
        -- Off-hand imbue (dual-imbue specs, i.e. Enhancement). Never collides with the
        -- main-hand offer: that one is Windfury whenever Windfury is known, which is
        -- exactly the condition that makes Flametongue an off-hand cast (see OffHandImbue).
        local ohImbue = OffHandImbue()
        if ohImbue and not OffHandEnchantHolds() and not IsFreshlyApplied(ohImbue) then
            out[#out + 1] = ohImbue
        end
    end
    -- Recuperate (cross-class OOC self-heal): a maintained buff whose "missing"
    -- condition is health-based instead of aura-expiry - offer it while the player
    -- is below the comfortable threshold and its heal-over-time isn't running.
    -- (1231411 also applies its own 30s active aura, hence the second probe.)
    -- A procced heal (free instant Regrowth and the like) is the better way to
    -- top up after combat and already surfaces with its proc glow - step aside.
    local function HasProccedHeal()
        local ABS = LibStub("JustAC-ActionBarScanner", true)
        local procs = ABS and ABS.GetDefensiveProccedSpells and ABS.GetDefensiveProccedSpells()
        if not procs or not SpellDB.IsHealingSpell then return false end
        for i = 1, #procs do
            if SpellDB.IsHealingSpell(procs[i]) then return true end
        end
        return false
    end
    -- Known-check: general "All Classes" skill-line spells can fail IsPlayerSpell
    -- even when learned, so fall back to IsSpellKnown/IsSpellKnownOrOverridesKnown.
    local recupKnown = SpellDB and SpellDB.RECUPERATE and (
        IsPlayerSpell(SpellDB.RECUPERATE)
        or (IsSpellKnown and IsSpellKnown(SpellDB.RECUPERATE))
        or (IsSpellKnownOrOverridesKnown and IsSpellKnownOrOverridesKnown(SpellDB.RECUPERATE)))
    -- Gate on the HoT (1231418) ONLY - deliberately not the 30s active aura
    -- (1231411): a damage tick interrupts the heal but leaves the active aura
    -- (and its animation) running, and that is exactly when a re-cast must be
    -- offered. The click layer cancels the stale aura before re-casting.
    -- Two tiers, so a critical-health cue can never be accidentally disabled:
    --   * EMERGENCY (<= ~35%): ALWAYS on, even with the top-off toggle OFF. The low-health
    --     vignette is never secret (and a low exact read counts too), so a critical-health
    --     player is always shown the heal.
    --   * TOP-OFF (35-100%): the opt-in "top off between pulls" reminder, gated by the toggle
    --     (offerTopoff). Health is secret out of combat in the open world, so detect below-full
    --     from never-secret signals: the exact read where available (rested/cities); in a
    --     party, the party health alert's PLAIN per-unit key for "player" (the keys persist
    --     out of combat - a nuisance for the group-heal feature, exactly right here: between
    --     pulls it still says "below the alert threshold"); else sustained regen ticks
    --     (health only regenerates BELOW full - airtight, and it goes false the moment you
    --     hit full) plus a short post-combat window to bridge the regen-start delay. The
    --     alert key is a POSITIVE signal only: its absence means "above the ALERT threshold",
    --     which says nothing about the user's own topoffThreshold, so it must never suppress
    --     the regen heuristic.
    if not InCombatLockdown() and not restricted and get and recupKnown
        and not get(SpellDB.RECUPERATE_AURA) then
        local hurt = false
        if BlizzardAPI and BlizzardAPI.GetPlayerHealthPercentSafe then
            local pct, estimated = BlizzardAPI.GetPlayerHealthPercentSafe()
            if pct and pct <= LOW_HEALTH_PCT then
                hurt = true                                  -- emergency floor: always on
                notFullSince = 0                             -- onset timer is the gate path's alone
            elseif offerTopoff then
                if pct and not estimated then
                    hurt = pct < RECUPERATE_HEALTH_PCT       -- exact 35-90%
                    notFullSince = 0
                else
                    -- ONE QUESTION: are you below your top-off threshold? The
                    -- ENGINE answers it - IsUnitHealthBelow encodes the threshold
                    -- as a curve, so the comparison happens where secrets are
                    -- allowed and only a plain yes/no comes back. Two fallbacks,
                    -- in descending precision: the exact full/not-full bit, then
                    -- the old arming heuristics.
                    local below
                    if topoffPct and BlizzardAPI.IsUnitHealthBelow then
                        below = BlizzardAPI.IsUnitHealthBelow("player", topoffPct)
                    end
                    if below == nil and BlizzardAPI.IsUnitFullHealth then
                        local atFull = BlizzardAPI.IsUnitFullHealth("player")
                        if atFull ~= nil then below = (atFull == false) end
                    end
                    if below ~= nil then
                        if below then
                            if notFullSince == 0 then notFullSince = now end
                            hurt = (now - notFullSince) >= TOPOFF_ONSET_SECONDS
                        else
                            notFullSince = 0        -- above the line: clear at once
                        end
                        topoffHeldUntil = 0
                    else
                        -- No zero-gate on this client: fall back to the old arming
                        -- signals, which can only ever prove "below full" anyway.
                        -- They arrive in bursts (regen ticks), so hold the offer
                        -- briefly once armed or the icon blinks between them.
                        local armed = (BlizzardAPI.IsPartyLowAvailable and BlizzardAPI.IsPartyLowAvailable()
                                and BlizzardAPI.IsUnitLow and BlizzardAPI.IsUnitLow("player"))
                            or (BlizzardAPI.HasSustainedPlayerHealthActivity and BlizzardAPI.HasSustainedPlayerHealthActivity())
                            or (BlizzardAPI.IsInPostCombatDowntime and BlizzardAPI.IsInPostCombatDowntime())
                        if armed then
                            topoffHeldUntil = now + TOPOFF_HOLD_SECONDS
                        end
                        hurt = armed or (now < topoffHeldUntil)
                    end
                end
            end
        end
        -- Same secret-boolean hazard as the party probes above: UnitIsDeadOrGhost can come
        -- back secret, and a bare truthiness test on it throws. "Not KNOWN to be dead" is
        -- the right fail direction here - a secret must not swallow a critical-health cue.
        if hurt and ReadableBool(UnitIsDeadOrGhost and UnitIsDeadOrGhost("player")) ~= true
            and not HasProccedHeal() then
            -- Prefer the class's own cheap heal (spammable; resource regens OOC).
            -- Ready-check via IsSpellReady (engine cooldown state); usability
            -- fails OPEN because resource state can be secret even out of combat -
            -- worst case an out-of-mana click errors and mana is back in seconds.
            local heal = SpellDB.GetKnownTopoffHeal and SpellDB.GetKnownTopoffHeal()
            if heal and get(heal) then
                -- The chosen heal's own HoT is still ticking: the player IS being
                -- healed - suggest nothing (mirrors the Recuperate aura gate, and
                -- prevents the HoT's own no-change snapshots at full health from
                -- keeping the suggestion alive).
            elseif heal and BlizzardAPI
                and (not BlizzardAPI.IsSpellUsable or BlizzardAPI.IsSpellUsable(heal, true))
                and (not BlizzardAPI.IsSpellReady or BlizzardAPI.IsSpellReady(heal)) then
                out[#out + 1] = heal
                PrecombatEngine.offeredTopoffHeal = heal
            else
                -- Recuperate (1231411) is a universal all-class heal, castable in
                -- any form; druids see it DISPLAYED as Frenzied Regeneration in
                -- bear, but the base carries no form requirement, so it is always
                -- a valid recovery offer. (Do NOT gate on the display override's
                -- legacy bear requirement - that hides a castable heal.)
                out[#out + 1] = SpellDB.RECUPERATE
                PrecombatEngine.offeredTopoffHeal = SpellDB.RECUPERATE
            end
        end
    end
    -- Stealth reminder, last: entering stealth is the final step before a pull.
    local stealth = offerStealth and not InCombatLockdown() and StealthReminderSpell()
    if stealth then out[#out + 1] = stealth end
    cachedClassBuffs, cachedClassBuffsAt = out, now
    return out
end

-- Are out-of-combat buff offers live right now? The defensive queue builds under exactly
-- this gate, and the DPS queue asks the same question so it can drop an ability that is
-- already sitting one cluster over as a clickable buff icon. One gate, two surfaces - they
-- cannot disagree about whether the offer exists.
function PrecombatEngine.IsOfferingNow(profile)
    if not profile or InCombatLockdown() then return false end
    local def, pre = profile.defensives, profile.precombatBuffs
    return (def and def.enabled and pre and pre.enabled ~= false) and true or false
end

local function DefensiveIcons()
    local addon = BlizzardAPI and BlizzardAPI.GetAddon and BlizzardAPI.GetAddon()
    return addon and addon.defensiveIcons
end

-- Is this spell being offered on screen, right now, as a pre-combat buff? Asked of the
-- rendered icons rather than of the checklist, because only the icons know whether the
-- offer is actually VISIBLE - the cluster can be hidden with the rest of the panel, and the
-- queue is capped at maxIcons, so "we would like to offer this" is not the same claim. An
-- icon carries isPrecombatBuff only while shown out of combat by the pre-combat path (the
-- renderer clears it on hide), and IsVisible answers false when an ancestor is hidden.
-- Only spells are asked about: the consumable offers are items, which never reach the DPS
-- queue. Reads one frame behind the DPS build, which is the safe direction - a buff that
-- has just lapsed is listed in both for one pass, never dropped from both.
function PrecombatEngine.IsOfferedNow(spellID, profile)
    if not spellID or not PrecombatEngine.IsOfferingNow(profile) then return false end
    local icons = DefensiveIcons()
    if not icons then return false end
    for i = 1, #icons do
        local icon = icons[i]
        if icon and icon.isPrecombatBuff and icon.spellID
           and R1(icon.spellID) == R1(spellID) and icon:IsVisible() then
            return true
        end
    end
    return false
end
