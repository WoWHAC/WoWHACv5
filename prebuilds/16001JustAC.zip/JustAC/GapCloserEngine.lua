-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2026 wealdly
-- GapCloserEngine.lua - Gap-closer system: melee range detection, spell prioritization
-- Suggests movement spells when target is out of melee range.
-- Extracted from DefensiveEngine.lua for clarity (gap closers inject into the offensive queue).

local GapCloserEngine = LibStub:NewLibrary("JustAC-GapCloserEngine", 7)
if not GapCloserEngine then return end

-- Hot path cache
local GetTime = GetTime
local UnitExists = UnitExists
local UnitIsDead = UnitIsDead
local UnitCanAttack = UnitCanAttack
local IsStealthed = IsStealthed
local IsSpellKnown = IsSpellKnown
local ipairs = ipairs

-- Module references (resolved at load time)
local BlizzardAPI       = LibStub("JustAC-BlizzardAPI", true)
local SpellDB           = LibStub("JustAC-SpellDB", true)
local SpellQueue        = LibStub("JustAC-SpellQueue", true)

--------------------------------------------------------------------------------
-- Constants
--------------------------------------------------------------------------------

-- Hide debounce: after target returns to melee range, hold the gap-closer icon
-- briefly so it doesn't vanish on a single in-range frame.  No show debounce -
-- showing the gap closer instantly is correct because the slot would otherwise
-- fill with a rotation spell, and the subsequent debounce expiry would cause a
-- visible blink.
local GAP_CLOSER_HIDE_DEBOUNCE = 0.4   -- seconds to hold the icon after returning to range.
                                       -- Larger than the old event-driven value because we
                                       -- now POLL IsSpellInRange each build; the longer hold
                                       -- bridges boundary jitter so the icon doesn't flicker
                                       -- as the player crosses in/out of melee.
local lastOutOfRangeTime = 0

-- Post-fire debounce: after a gap closer is CONFIRMED cast (UNIT_SPELLCAST_SUCCEEDED),
-- the charge/leap is still in flight and the melee probe hasn't caught up - without
-- this the engine offers the NEXT gap closer during the travel window. Long enough
-- to cover any charge/leap travel plus the range probe settling; short enough that a
-- genuinely failed close (target blinked away) re-offers promptly.
local GAP_CLOSER_FIRED_DEBOUNCE = 3    -- seconds
local lastFiredTime = -1e9

-- Near-band gate: barely out of melee is walking distance, not a cooldown's job -
-- only offer when the target is PROVEN beyond this (or unprovable: probe coverage
-- varies by spec, and unknown fails OPEN so thin toolboxes keep their gap closers).
local GAP_CLOSER_NEAR_YARDS = 10
-- Probe-hole fallback for the near band. Only ONE 10yd probe exists in all of
-- Data/RangeReferences.lua, so for most melee the 5-10yd question is UNANSWERABLE:
-- a rogue's ladder is 5yd melee probes then Blind at 15, which proves "within 15"
-- but never "within 10" - so one step outside melee read as unknown, failed open,
-- and offered Shadowstep (user-reported). When 10 is unanswerable, a proven
-- "within 15" is accepted as near instead. Specs that CAN answer 10 keep the
-- tighter band; specs with no mid probe at all still fail open (both nil).
-- ponytail: one flat pair; per-spell max-range bands if a spec ever needs them.
local GAP_CLOSER_NEAR_FALLBACK_YARDS = 15

--------------------------------------------------------------------------------
-- Internal helpers
--------------------------------------------------------------------------------

--- Evaluate a single gap-closer candidate: resolve → dedup → known → not passive →
--- not blacklisted → ready → in range.  Returns resolvedID, baseID on success,
--- or nil if the spell doesn't pass all gates.
--- The gap-closer list is curated (user-configured or SpellDB defaults), so
--- the only availability gate is "does the player know this spell" - filtering
--- out default entries the player hasn't talented into.  No usability check
--- (fail-closed rejects valid spells in combat due to secret values; fail-open
--- adds no value for a curated list).  Cooldown check remains to avoid
--- suggesting spells that are on CD.
--- @param spellID      number       Base spell ID from the gap-closer list
--- @param addedSpellIDs table|nil   Set of already-queued spell IDs to skip
local function TryGapCloserCandidate(spellID, addedSpellIDs)
    if not spellID or spellID <= 0 then return nil end
    local resolvedID = BlizzardAPI.ResolveSpellID(spellID)

    -- Dedup: skip if already shown in the queue
    if addedSpellIDs and (addedSpellIDs[resolvedID] or addedSpellIDs[spellID]) then
        return nil
    end

    -- Known check: filter out spells the player doesn't have (untalented defaults). Use
    -- IsSpellKnown (form-independent), NOT IsSpellAvailable (castability) - the latter wrongly
    -- rejects a known gap-closer that isn't instantly castable (e.g. a Druid's form-gated
    -- Wild Charge). Cooldown is handled separately below; range by the checkRange gate.
    if IsSpellKnown and not (IsSpellKnown(spellID) or IsSpellKnown(resolvedID)) then return nil end

    -- Passive backstop. This gate deliberately uses IsSpellKnown rather than
    -- IsSpellAvailable (see above) - but that also skips IsSpellAvailable's built-in
    -- passive refusal, and IsSpellKnown answers true for a known passive. Every other
    -- suggestion path has that refusal somewhere; this was the one that did not, so a
    -- passive id added to the gap-closer list would have rendered an unpressable icon.
    if BlizzardAPI.IsPassiveSpell and BlizzardAPI.IsPassiveSpell(resolvedID) then return nil end

    -- Blacklist: suppress entries the user has hidden from all positions.
    -- Check both the curated base ID and the talent-resolved ID - the user may
    -- have blacklisted either form (IsSpellBlacklisted expands each via display override).
    if not SpellQueue then SpellQueue = LibStub("JustAC-SpellQueue", true) end
    if SpellQueue and SpellQueue.IsSpellBlacklisted
       and (SpellQueue.IsSpellBlacklisted(spellID)
            or (resolvedID ~= spellID and SpellQueue.IsSpellBlacklisted(resolvedID))) then
        return nil
    end

    -- Cooldown check: don't suggest spells on CD
    if not BlizzardAPI.IsSpellReady(resolvedID) then return nil end

    -- Range check: reject only if the ability is confirmed OUT of reach (e.g. target beyond
    -- Wild Charge's max range). AbilityInRange rather than the bare spell read: that one tests
    -- the BASE range, so it rejected a stealth teleport (5yd by spell, 25yd in stealth) at
    -- every distance a gap closer is for, and the stealth path below never returned it.
    -- Self-targeted spells (Sprint) and unknowns read nil -> pass; only a confirmed false rejects.
    if BlizzardAPI.AbilityInRange(spellID) == false then
        return nil
    end

    return resolvedID, spellID
end


--- Resolve the gap-closer spell list for the current class+spec.
--- Reads from profile (user-configured) with SpellDB defaults as fallback.
--- Returns an array of spell IDs, or nil if no gap-closers for this spec.
local function ResolveGapCloserSpells(addon)
    -- Direct read, no cache: it returned a reference to the profile's own table, so
    -- caching saved nothing and went stale across a profile switch (the old profile's
    -- list served until a form change happened by).
    local specKey = SpellDB and SpellDB.GetSpecKey and SpellDB.GetSpecKey()
    if not specKey then return nil end
    local profile = addon:GetProfile()
    local gc = profile and profile.gapClosers
    local list = gc and gc.classSpells and gc.classSpells[specKey]
    if list and #list > 0 then return list end
    return SpellDB and SpellDB.CLASS_GAPCLOSER_DEFAULTS and SpellDB.CLASS_GAPCLOSER_DEFAULTS[specKey] or nil
end

--------------------------------------------------------------------------------
-- Public API
--------------------------------------------------------------------------------

--- Copy this spec's stock gap-closer list into the profile. Shared by first-time
--- setup and the Restore Defaults button; `clearWhenNone` is the only difference
--- between them - setup leaves an unlisted spec alone, Restore wipes it.
--- @return boolean changed
local function SeedDefaults(profile, specKey, clearWhenNone)
    local defaults = SpellDB and SpellDB.CLASS_GAPCLOSER_DEFAULTS
        and SpellDB.CLASS_GAPCLOSER_DEFAULTS[specKey]
    if not defaults then
        if clearWhenNone then profile.gapClosers.classSpells[specKey] = nil end
        return clearWhenNone or false
    end
    local list = {}
    for i, spellID in ipairs(defaults) do list[i] = spellID end
    profile.gapClosers.classSpells[specKey] = list
    return true
end

--- Initialize gap-closer defaults for the current spec if not yet populated
function GapCloserEngine.InitializeGapClosers(addon)
    local profile = addon:GetProfile()
    if not profile then return end

    if not profile.gapClosers then
        profile.gapClosers = { enabled = false, classSpells = {} }
    end
    if not profile.gapClosers.classSpells then
        profile.gapClosers.classSpells = {}
    end

    local specKey = SpellDB and SpellDB.GetSpecKey and SpellDB.GetSpecKey()
    if not specKey then return end

    local existing = profile.gapClosers.classSpells[specKey]
    if not existing or #existing == 0 then
        SeedDefaults(profile, specKey, false)
    end
end

--- Reset range state on target change and form change: clears the hide-debounce timestamp so
--- a new target doesn't inherit the previous target's "recently out of range" hold.
--- The post-fire debounce is deliberately NOT cleared here: switching targets mid-flight
--- is exactly when offering a second gap closer wastes it, and 3s self-expires anyway.
function GapCloserEngine.ClearRangeState()
    lastOutOfRangeTime = 0
end

--- Called from the player's UNIT_SPELLCAST_SUCCEEDED: arm the post-fire debounce when
--- the cast was one of this spec's gap closers (user list or defaults, either ID form).
function GapCloserEngine.NoteSpellcastSucceeded(addon, spellID)
    local profile = addon and addon.db and addon.db.profile
    if not (profile and profile.gapClosers and profile.gapClosers.enabled) then return end
    if GapCloserEngine.IsGapCloserSpell(addon, spellID) then
        lastFiredTime = GetTime()
    end
end

--- Returns the first usable gap-closer spell ID for the current spec, or nil.
--- "Usable" = known (IsSpellKnown), not blacklisted, not on a real cooldown
--- (IsSpellReady), and - for the melee-range gate - in range (IsSpellInRange).
--- No castability/usability check: fail-closed rejects valid spells in combat
--- (secret values), fail-open adds nothing for a curated list.
--- Returns: resolvedID, baseID  (resolvedID is the talent-overridden form;
---   baseID is the original list entry, e.g. Roll vs Chi Torpedo).
--- @param addon table              The JustAC addon object
--- @param addedSpellIDs table|nil  Set of already-queued spell IDs to skip (prevent duplicates)
function GapCloserEngine.GetGapCloserSpell(addon, addedSpellIDs)
    if not addon or not addon.db or not addon.db.profile then return nil end
    local gc = addon.db.profile.gapClosers
    if not gc or not gc.enabled then return nil end

    -- Must have a hostile target that is alive
    if not UnitExists("target") or UnitIsDead("target") or not UnitCanAttack("player", "target") then
        return nil
    end

    -- IsStealthed() is NeverSecret and covers Stealth, Vanish, Shadow Dance, etc.
    local stealthed = IsStealthed and IsStealthed() or false
    local spellList = ResolveGapCloserSpells(addon)
    if not spellList then return nil end

    -- Post-fire debounce: a gap closer just landed a cast; while it travels, offer
    -- nothing from the whole category (the fired spell itself is on CD, but the
    -- NEXT list entry would otherwise fill the slot mid-flight). Ahead of the
    -- stealth loop too: Shadowstrike has no cooldown and was offered mid-Shadowstep.
    local now = GetTime()
    if (now - lastFiredTime) < GAP_CLOSER_FIRED_DEBOUNCE then return nil end

    ----------------------------------------------------------------------------
    -- STEALTH GAP CLOSERS - evaluate before the melee range gate. Stealth gap
    -- closers like Shadowstrike teleport TO the target, so their own castable
    -- range (SpellInRange on the spell itself) IS the gap-closer range - no melee
    -- probe needed. Dedup via addedSpellIDs prevents showing them when Blizzard's
    -- assisted combat already suggests them at position 1.
    ----------------------------------------------------------------------------
    -- Not while PROVEN in melee: there the spell is ordinary rotation, and offering it as a
    -- gap closer (with that glow) would be wrong. Deliberately ahead of the near-band
    -- suppression below - that exists to save a cooldown on a short gap, and a stealth
    -- teleport costs none.
    if stealthed and not (SpellDB.IsTargetWithin and SpellDB.IsTargetWithin(5) == true) then
        for _, spellID in ipairs(spellList) do
            if spellID and spellID > 0 and SpellDB.GAP_CLOSER_REQUIRES_STEALTH
                and SpellDB.GAP_CLOSER_REQUIRES_STEALTH[spellID] then
                local resolved, base = TryGapCloserCandidate(spellID, addedSpellIDs)
                if resolved then return resolved, base end
            end
        end
    end

    -- Melee detection via the shared range-reference system (SpellDB.IsTargetWithin), so the
    -- gap closer and ContextRank use ONE melee check - all melee specs covered bar-free
    -- (5yd probes in Data/RangeReferences.lua). IsTargetWithin polls every melee ability the
    -- player actually knows, so no per-spec reference or user override is needed.
    -- nil (no probe known / can't tell) → false → not out of melee (fail-safe).
    local outOfRange = (SpellDB.IsTargetWithin and SpellDB.IsTargetWithin(5) == false) or false

    -- Near-band suppression (gapClosers.farOnly, default ON via ~= false): proven
    -- within GAP_CLOSER_NEAR_YARDS means the gap isn't worth a cooldown - treat it
    -- like melee range (same hide-debounce smoothing). Only a positive proof
    -- suppresses; nil (out of probe coverage) falls through and the offer stands,
    -- so this can only ever REMOVE wasted offers, never valid ones.
    if outOfRange and gc.farOnly ~= false and SpellDB.IsTargetWithin then
        local near = SpellDB.IsTargetWithin(GAP_CLOSER_NEAR_YARDS)
        if near == nil then
            -- 10 unanswerable (probe hole - see GAP_CLOSER_NEAR_FALLBACK_YARDS).
            near = SpellDB.IsTargetWithin(GAP_CLOSER_NEAR_FALLBACK_YARDS)
        end
        if near == true then outOfRange = false end
    end

    if outOfRange then
        -- Hide-debounce timestamp (this poll and ClearRangeState are its only writers).
        lastOutOfRangeTime = now
        -- No show debounce: display gap closer immediately when out of range.
        -- A show debounce would cause slot 2 to blink (rotation spell fills it
        -- during the debounce window, then gets displaced by the gap closer).
    else
        -- Hide debounce: hold the icon briefly after returning to range
        if lastOutOfRangeTime == 0 or (now - lastOutOfRangeTime) > GAP_CLOSER_HIDE_DEBOUNCE then
            return nil
        end
    end

    for _, spellID in ipairs(spellList) do
        if spellID and spellID > 0 then
            -- Skip stealth-only gap closers in the normal loop.
            -- When stealthed: already evaluated in the dedicated stealth path above.
            -- When not stealthed: gap-closer component is inactive (no teleport).
            local resolvedID = BlizzardAPI.ResolveSpellID(spellID)
            local isStealth = SpellDB.GAP_CLOSER_REQUIRES_STEALTH
                and (SpellDB.GAP_CLOSER_REQUIRES_STEALTH[spellID] or SpellDB.GAP_CLOSER_REQUIRES_STEALTH[resolvedID])
            if not isStealth then
                local resolved, base = TryGapCloserCandidate(spellID, addedSpellIDs)
                if resolved then return resolved, base end
            end
        end
    end

    return nil
end

--- Returns true if the given spellID is ANY known gap-closer for the current spec.
--- Checks both the user's configured list AND the SpellDB defaults, plus their
--- active talent overrides.  This ensures that even if a user removes a spell
--- from their personal list, Blizzard suggesting it at position 1 still suppresses
--- our gap-closer injection at position 2.
-- Scan a spell list for a match (base ID or talent override). Module-level:
-- defining it inside IsGapCloserSpell allocated a closure per call, and SpellQueue
-- calls that up to twice per build.
local function ListContains(list, spellID)
    if not list then return false end
    for _, gcSpellID in ipairs(list) do
        if gcSpellID == spellID then return true end
        if BlizzardAPI.ResolveSpellID(gcSpellID) == spellID then return true end
    end
    return false
end

function GapCloserEngine.IsGapCloserSpell(addon, spellID)
    if not spellID or spellID == 0 then return false end

    -- Check user-configured list
    if addon then
        local userList = ResolveGapCloserSpells(addon)
        if ListContains(userList, spellID) then return true end
    end

    -- Check SpellDB defaults (catches spells the user removed from their list)
    local defaults = SpellDB and SpellDB.GetGapCloserDefaults and SpellDB.GetGapCloserDefaults()
    if defaults and ListContains(defaults, spellID) then return true end

    return false
end

--- Mark all gap-closer spell IDs (base + talent-resolved forms) into a set.
--- Called by SpellQueue to suppress gap-closer spells from the rotation list
--- when the gap-closer system is enabled - our insertion controls when they appear.
--- With the feature DISABLED this marks nothing: the spells are then ordinary
--- rotation abilities and must flow through the queue like any other.
function GapCloserEngine.MarkGapCloserSpellIDs(addon, spellIDSet)
    if not addon or not spellIDSet then return end
    local profile = addon.db and addon.db.profile
    if not (profile and profile.gapClosers and profile.gapClosers.enabled) then return end
    BlizzardAPI.MarkResolvedIDs(ResolveGapCloserSpells(addon), spellIDSet)
end

--- Restore gap-closer defaults for the current spec
function GapCloserEngine.RestoreGapCloserDefaults(addon)
    local profile = addon:GetProfile()
    if not profile or not profile.gapClosers then return end

    local specKey = SpellDB and SpellDB.GetSpecKey and SpellDB.GetSpecKey()
    if not specKey then return end

    if not profile.gapClosers.classSpells then
        profile.gapClosers.classSpells = {}
    end

    SeedDefaults(profile, specKey, true)
end
