-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2026 wealdly
-- JustAC: Blizzard API Module - entry point, version detection and LibStub registration.
-- Public functions are defined in the BlizzardAPI\ submodules, loaded immediately
-- after this file in JustAC.toc: CooldownTracking, SecretValues, SpellQuery, StateHelpers.
--
-- Key functions added by each submodule:
--   SpellQuery.lua        → GetAddon, GetProfile, GetDebugMode, GetSpellInfo, IsSpellUsable
--   CooldownTracking.lua  → IsSpellReady, IsSpellOnCooldown, IsBuffWindowActive
--   SecretValues.lua      → GetAuras, RefreshFeatureAvailability, IsProcFeatureAvailable
-- (IsSecretValue, Unsecret, AreCooldownsSecret, AreAurasSecret are defined here in the root.)
--   StateHelpers.lua      → GetPlayerHealthPercent, CheckDefensiveItemState, IsTargetCCImmune
local BlizzardAPI = LibStub:NewLibrary("JustAC-BlizzardAPI", 36)
if not BlizzardAPI then return end

-- 12.x only (JustAC.toc pins Interface 120100): no version conditionals anywhere in
-- the addon. A client API that is missing is a bug to fix, not a branch to keep.

--------------------------------------------------------------------------------
-- Secret Value Primitives
--------------------------------------------------------------------------------
-- Defined here (root) so every submodule can upvalue them at load time.

--- Returns true if the value is a secret (cannot be compared or used in arithmetic).
--- Try the direct API call first; guard the result with this before any comparison.
--- @param value any
--- @return boolean
function BlizzardAPI.IsSecretValue(value)
    return issecretvalue(value)
end

--- Extract a readable value - returns fallback when secret or nil.
--- Optimistic: assumes the value IS readable (Blizzard may loosen restrictions
--- over time), only falls back when it provably isn't.
---
---   local dur = BlizzardAPI.Unsecret(cd.duration)          -- nil if secret
---   local hp  = BlizzardAPI.Unsecret(health, 100)          -- 100 if secret
---
--- @param value    any          The potentially-secret value
--- @param fallback any|nil      Returned when value is nil or secret (default nil)
--- @return any                  value if readable, fallback otherwise
function BlizzardAPI.Unsecret(value, fallback)
    if value == nil then return fallback end
    if issecretvalue(value) then return fallback end
    return value
end

--------------------------------------------------------------------------------
-- Live Secrecy Gates (12.0.7+)
--------------------------------------------------------------------------------
-- C_Secrets predicates are plain booleans that flip exactly at combat edges in
-- every context (validated in-game 12.0.7: open world, dungeon, delve). Prefer
-- these over InCombatLockdown() as the "is this data readable" signal - they
-- stay correct if Blizzard changes which contexts are restricted.

local C_Secrets_ShouldCooldownsBeSecret = C_Secrets and C_Secrets.ShouldCooldownsBeSecret
local C_Secrets_ShouldAurasBeSecret     = C_Secrets and C_Secrets.ShouldAurasBeSecret

--- Are spell/action cooldown values secret right now?
--- @return boolean
function BlizzardAPI.AreCooldownsSecret()
    return C_Secrets_ShouldCooldownsBeSecret()
end

--- Are unit aura contents secret right now? (Per-spell NeverSecret exemptions
--- override this - see RedundancyFilter's exemption handling.)
--- @return boolean
function BlizzardAPI.AreAurasSecret()
    return C_Secrets_ShouldAurasBeSecret()
end

--------------------------------------------------------------------------------
-- Action Bar Usability Helper (IsSpellUsable's fallback when the spell read is secret)
--------------------------------------------------------------------------------
-- Event-driven usability cache, populated by ACTION_USABLE_CHANGED.
-- Keyed by absolute action slot number → {usable, noMana}.
-- Macro modifier effects are handled by the C engine: when a modifier changes
-- the effective spell on a slot, ACTION_USABLE_CHANGED re-fires for that slot
-- with updated usability reflecting the newly-resolved spell.
local slotUsabilityCache = {}
local wipe = wipe

--- Process ACTION_USABLE_CHANGED batched payload.
--- @param changes table Array of {slot=luaIndex, usable=bool, noMana=bool}
function BlizzardAPI.OnActionUsableChanged(changes)
    for _, change in ipairs(changes) do
        slotUsabilityCache[change.slot] = change
    end
    -- Deliberately NOT a cooldown or charge signal: a slot flips usable on energy ticks,
    -- target swaps and "not enough mana", none of which mean a charge came back.
end

--- Wipe slot usability cache (call when slot content changes, e.g. bar page
--- switch, ACTIONBAR_SLOT_CHANGED, vehicle enter/exit).
function BlizzardAPI.InvalidateSlotUsabilityCache()
    wipe(slotUsabilityCache)
    if BlizzardAPI.InvalidateBarSpells then BlizzardAPI.InvalidateBarSpells() end
end

--- Returns the action bar usability state for a spell, or nil if unavailable.
--- NeverSecret API - safe in combat. Uses ActionBarScanner to find the slot.
--- Falls back to assisted combat slot when spell isn't on the player's bars.
--- Checks the event-driven cache first; falls back to live API.
--- @param spellID number
--- @return boolean|nil usable, boolean|nil notEnoughMana
function BlizzardAPI.GetActionBarUsability(spellID)
    local ABS = LibStub("JustAC-ActionBarScanner", true)
    if not ABS or not ABS.GetSlotForSpell then return nil, nil end
    local slot = ABS.GetSlotForSpell(spellID)

    -- Assisted combat slot fallback: if the spell isn't on any bar but matches
    -- the current assistant recommendation, use that slot for usability checks.
    if not slot and ABS.GetAssistedCombatSlot and BlizzardAPI.GetHighlightCastSpell then
        -- GetHighlightCastSpell pcalls the API and returns a plain number or nil,
        -- so the comparisons below never see a secret or non-number value.
        local nextCast = BlizzardAPI.GetHighlightCastSpell()
        local displayID = BlizzardAPI.GetDisplaySpellID(spellID)
        if nextCast and (nextCast == spellID or nextCast == displayID) then
            slot = ABS.GetAssistedCombatSlot()
        end
    end

    if not slot then return nil, nil end

    -- Prefer event-driven cache (ACTION_USABLE_CHANGED)
    local cached = slotUsabilityCache[slot]
    if cached then
        return cached.usable, cached.noMana
    end

    -- Fallback to live API (cache not yet populated for this slot)
    if not C_ActionBar or not C_ActionBar.IsUsableAction then return nil, nil end
    local usable, noMana = C_ActionBar.IsUsableAction(slot)
    if BlizzardAPI.IsSecretValue(usable) or BlizzardAPI.IsSecretValue(noMana) then return nil, nil end
    return usable, noMana
end
