-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2026 wealdly
-- JustAC: Form Cache Module - Tracks current shapeshift form and available forms
local FormCache = LibStub:NewLibrary("JustAC-FormCache", 11)
if not FormCache then return end

local BlizzardAPI = LibStub("JustAC-BlizzardAPI", true)

-- Hot path cache
local GetTime = GetTime
local pairs = pairs

local cachedFormData = {
    -- Stance bar position (1-N) matching macro [form:X] conditionals (0 = caster/no form)
    currentStanceIndex = 0,
    currentFormName = "",
    availableForms = {},
    spellToFormMap = {},
    lastUpdate = 0,
    lastFullScan = 0,
}

local function ScanSpellbookForFormSpells()
    local formSpells = {}

    -- Build a set of form spell IDs first (O(numForms)), avoiding O(numSpells×numForms) inner loop
    local formSpellSet = {}
    local numForms = BlizzardAPI.GetNumShapeshiftForms()
    for i = 1, numForms do
        local _, _, _, formSpellID = BlizzardAPI.GetShapeshiftFormInfo(i)
        if formSpellID then
            formSpellSet[formSpellID] = true
        end
    end

    if not next(formSpellSet) then return formSpells end

    local numTabs = C_SpellBook.GetNumSpellBookSkillLines()
    for tabIndex = 1, numTabs do
        local skillLine = C_SpellBook.GetSpellBookSkillLineInfo(tabIndex)

        if skillLine and skillLine.itemIndexOffset and skillLine.numSpellBookItems then
            for spellIndex = skillLine.itemIndexOffset + 1, skillLine.itemIndexOffset + skillLine.numSpellBookItems do
                local itemType, actionID, spellID = C_SpellBook.GetSpellBookItemType(spellIndex, Enum.SpellBookSpellBank.Player)
                local id = (itemType == Enum.SpellBookItemType.Spell) and (spellID or actionID) or nil

                if id and formSpellSet[id] then
                    local spellInfo = BlizzardAPI and BlizzardAPI.GetSpellInfo(id)
                    if spellInfo and spellInfo.name then
                        formSpells[id] = spellInfo.name
                    end
                end
            end
        end
    end

    return formSpells
end

local function DetermineSpellFormTarget(spellID)
    local numForms = BlizzardAPI.GetNumShapeshiftForms()
    for i = 1, numForms do
        local icon, active, castable, formSpellID = BlizzardAPI.GetShapeshiftFormInfo(i)
        if formSpellID and formSpellID == spellID then
            return i
        end
    end
    
    return nil
end

local function BuildSpellToFormMapping()
    local currentTime = GetTime()
    
    if cachedFormData.lastFullScan > 0 and (currentTime - cachedFormData.lastFullScan) < 30 then
        return cachedFormData.spellToFormMap
    end
    
    local mapping = {}
    local formSpells = ScanSpellbookForFormSpells()
    
    for spellID in pairs(formSpells) do
        local targetForm = DetermineSpellFormTarget(spellID)
        if targetForm then
            mapping[spellID] = targetForm
        end
    end
    
    cachedFormData.spellToFormMap = mapping
    cachedFormData.lastFullScan = currentTime
    
    return mapping
end

-- GetShapeshiftForm() returns nil during loading; iteration is always reliable
local function FindActiveStanceIndex(numForms)
    for i = 1, numForms do
        local icon, active, castable, spellID = BlizzardAPI.GetShapeshiftFormInfo(i)
        if active and active ~= 0 then
            return i
        end
    end
    return 0  -- No active form = caster form
end

local function UpdateFormCache()
    local currentTime = GetTime()
    
    if (currentTime - cachedFormData.lastUpdate) < 0.1 then
        return
    end
    
    local numForms = BlizzardAPI.GetNumShapeshiftForms()
    
    local stanceIndex = FindActiveStanceIndex(numForms)
    
    -- Caster/no-form has no spell, so the name stays "" - the only consumers compare
    -- form names against spell names, which "" can never match.
    local formName = ""
    if stanceIndex > 0 and stanceIndex <= numForms then
        local icon, active, castable, spellID = BlizzardAPI.GetShapeshiftFormInfo(stanceIndex)
        local spellInfo = spellID and BlizzardAPI.GetSpellInfo(spellID)
        if spellInfo and spellInfo.name then
            formName = spellInfo.name
        end
    end

    -- Only name/spellID are consumed (GetFormIDBySpellID match loops)
    local availableForms = {}
    for i = 1, numForms do
        local icon, active, castable, spellID = BlizzardAPI.GetShapeshiftFormInfo(i)
        if icon and spellID then
            local spellInfo = BlizzardAPI and BlizzardAPI.GetSpellInfo(spellID)
            availableForms[i] = {
                name = spellInfo and spellInfo.name,
                spellID = spellID,
            }
        end
    end
    
    local formChanged = cachedFormData.currentStanceIndex ~= stanceIndex
    cachedFormData.currentStanceIndex = stanceIndex
    cachedFormData.currentFormName = formName
    cachedFormData.availableForms = availableForms
    cachedFormData.lastUpdate = currentTime
    
    if formChanged or (currentTime - cachedFormData.lastFullScan) > 30 then
        BuildSpellToFormMapping()
    end
end

function FormCache.GetActiveForm()
    UpdateFormCache()
    return cachedFormData.currentStanceIndex
end

function FormCache.GetActiveFormName()
    UpdateFormCache()
    return cachedFormData.currentFormName
end

function FormCache.InvalidateCache()
    cachedFormData.lastUpdate = 0
end

function FormCache.InvalidateSpellMapping()
    cachedFormData.lastFullScan = 0
    wipe(cachedFormData.spellToFormMap)
end

function FormCache.OnPlayerLogin()
    FormCache.InvalidateCache()
    FormCache.InvalidateSpellMapping()
    
    local addon = LibStub("AceAddon-3.0"):GetAddon("JustAssistedCombat", true)
    if addon and addon.ScheduleTimer then
        addon:ScheduleTimer(function()
            UpdateFormCache()
        end, 1.0)
    else
        UpdateFormCache()
    end
end

function FormCache.GetFormIDBySpellID(spellID)
    if not spellID then return nil end

    UpdateFormCache()

    local mapping = cachedFormData.spellToFormMap
    local cached = mapping[spellID]
    if cached then return cached end
    if cached == false then return nil end  -- negative cache hit
    
    for formID, formData in pairs(cachedFormData.availableForms) do
        if formData.spellID and formData.spellID == spellID then
            return formID
        end
    end
    
    -- Rotation may return base ID while stance bar uses override spell
    if C_Spell and C_Spell.GetOverrideSpell then
        local overrideID = C_Spell.GetOverrideSpell(spellID)
        if overrideID and overrideID ~= spellID then
            if mapping[overrideID] then
                mapping[spellID] = mapping[overrideID]
                return mapping[overrideID]
            end
            for formID, formData in pairs(cachedFormData.availableForms) do
                if formData.spellID and formData.spellID == overrideID then
                    mapping[spellID] = formID
                    return formID
                end
            end
        end
    end
    
    -- Fallback: match by name when rotation uses different spell ID for same form
    local spellInfo = BlizzardAPI and BlizzardAPI.GetSpellInfo(spellID)
    if spellInfo and spellInfo.name then
        local spellName = spellInfo.name
        for formID, formData in pairs(cachedFormData.availableForms) do
            if formData.name and formData.name == spellName then
                mapping[spellID] = formID
                return formID
            end
        end
    end
    
    BuildSpellToFormMapping()
    mapping = cachedFormData.spellToFormMap
    local result = mapping[spellID]
    if not result then
        mapping[spellID] = false  -- negative cache: not a form spell
    end
    return result
end

