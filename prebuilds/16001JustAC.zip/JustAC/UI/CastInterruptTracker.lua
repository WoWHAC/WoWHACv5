-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2026 wealdly
-- JustAC: Cast Interrupt Tracker Module
-- Centralises all interrupt-detection state, cast-bar discovery, and sound playback.
-- UIRenderer and UINameplateOverlay both delegate to the public functions here
-- so there is exactly one debounce timer for the whole addon.
local CastInterruptTracker = LibStub:NewLibrary("JustAC-CastInterruptTracker", 2)
if not CastInterruptTracker then return end

local BlizzardAPI = LibStub("JustAC-BlizzardAPI", true)
local SpellDB     = LibStub("JustAC-SpellDB", true)

-- Hot path cache
local GetTime = GetTime
local pcall   = pcall
local pairs   = pairs

local C_NamePlate           = C_NamePlate
local UnitCastingInfo       = UnitCastingInfo
local UnitChannelInfo       = UnitChannelInfo

-- Cast bar lingers after interrupt lands; suppress to avoid re-suggesting.
local INTERRUPT_DEBOUNCE    = 1.0
local lastInterruptUsedTime = 0
local lastInterruptShownID  = nil
-- 2s covers state-registration lag; short enough for back-to-back CCs to still work.
local CC_APPLIED_SUPPRESS = 2.0
local lastCCAppliedTime   = 0

-- LibSharedMedia integration for user-expandable interrupt sounds.
local LSM = LibStub("LibSharedMedia-3.0", true)

-- Register built-in interrupt alert sounds with LSM.
-- Curated for alert utility - short, distinctive, attention-grabbing.
if LSM then
    local BUILTIN_SOUNDS = {
        -- Iconic WoW alerts
        ["JAC: Night Elf Bell"]    = 566558,  -- clear bell toll
        ["JAC: Raid Emote"]        = 876098,  -- Blizzard raid warning chime
        ["JAC: Algalon Black Hole"]= 543587,  -- deep warning swell
        ["JAC: PvP Flag"]          = 569200,  -- PVP flag taken
        -- Crisp alert tones
        ["JAC: Shing!"]            = 566240,  -- sharp metallic bling
        ["JAC: Wham!"]             = 566946,  -- heavy thud
        ["JAC: Simon Chime"]       = 566076,  -- classic alert chime
        ["JAC: Short Circuit"]     = 568975,  -- electric snap
        -- Dramatic stings
        ["JAC: Worgen Transform"]  = 552035,  -- dramatic sting
        ["JAC: Loatheb Aggro"]     = 554236,  -- eerie piercing
        ["JAC: Horseman Laugh"]    = 551703,  -- unmistakable
        -- Horns & blasts
        ["JAC: Dwarf Horn"]        = 566064,  -- short brass horn
        ["JAC: Grimrail Horn"]     = 1023633, -- train horn blast
        ["JAC: Fel Nova"]          = 568582,  -- arcane pulse
    }
    for name, fileDataID in pairs(BUILTIN_SOUNDS) do
        LSM:Register(LSM.MediaType.SOUND, name, fileDataID)
    end
end

local PlaySoundFile = PlaySoundFile
local lastInterruptSoundTime    = 0
local INTERRUPT_SOUND_DEBOUNCE  = 0.5

-- Shared between both renderers so interrupt debounce is unified.
local lastInterruptEvalTime = -1
local cachedIntResult = { shouldShow = false, spellID = nil, castBar = nil, interruptMode = nil }

-- ─────────────────────────────────────────────────────────────────────────────
-- Cast bar discovery. Source-verified frame paths (2026-03-01) covering the Blizzard
-- default and the common third-party cast-bar / nameplate addons:
--   "blizzard"     : nameplate.UnitFrame.CastBarsContainer.castBar  (12.x nesting)
--   "lowercaseUF"  : nameplate.unitFrame.castBar  (lowercase u)
--   "childCastbar" : a nameplate child's .Castbar  (unit-frame-library element)
-- ─────────────────────────────────────────────────────────────────────────────
-- Scratch buffer for child enumeration (see the childCastbar branch below).
local childScratch = {}
local function FillChildScratch(...)
    local n = select("#", ...)
    for i = 1, n do childScratch[i] = select(i, ...) end
    return n
end

local function FindVisibleCastBar(nameplate)
    if not nameplate then return nil, nil end

    local uf = nameplate.UnitFrame
    if uf then
        -- 12.x nests the cast bar inside CastBarsContainer; there is NO uf.castBar alias any
        -- more (every Blizzard reference goes through the container). Missing it costs the ONE
        -- readable interruptibility signal there is, so CC substitution silently stops and the
        -- kick is offered on shielded casts instead - reported in game as a ding with no icon,
        -- because the secret alpha sink then correctly hides that kick.
        local container = uf.CastBarsContainer
        local bar = container and container.castBar
        if bar and bar.IsVisible and bar:IsVisible() then
            return bar, "blizzard"
        end
    end

    -- lowercase .unitFrame (used by some cast-bar frameworks)
    local puf = nameplate.unitFrame
    if puf and puf ~= uf then
        local bar = puf.castBar
        if bar and bar.IsShown and bar:IsShown() then
            return bar, "lowercaseUF"
        end
    end

    -- child-element .Castbar is not a named field, must enumerate children.
    if nameplate.GetNumChildren then
        -- Scratch-filled, not `{ GetChildren() }`: this path is the COMMON
        -- "target not casting" state and ran per evaluation, so the vararg pack
        -- was a steady multi-element allocation all combat. Stale tail entries
        -- beyond n are never read (the loop is bounded by n).
        local numKids = FillChildScratch(nameplate:GetChildren())
        for i = 1, numKids do
            local child = childScratch[i]
            if child then
                local cb = child.Castbar
                if cb and cb.IsShown and cb:IsShown() then
                    return cb, "childCastbar"
                end
            end
        end
    end

    return nil, nil
end

--- The bar the tracker would actually use, exposed for /jac inspect castdiag.
--- Diagnostics must probe the SAME frame production picked, not a lookalike - the
--- whole question is what happens on a replaced bar, and re-deriving it in the
--- probe would answer it for a different frame.
function CastInterruptTracker.DebugFindCastBar(nameplate)
    return FindVisibleCastBar(nameplate)
end

-- ═════════════════════════════════════════════════════════════════════════════
-- INTERRUPT DETECTION - what's secret, what works (verified 2026-06-28 via
-- /jac inspect castdiag; READ THIS before concluding interruptibility is "sealed").
-- In 12.0 an enemy cast's interruptibility is a secret value in combat. It is handled
-- in two layers:
--
-- 1. VISUAL suppression (universal) - in UIRenderer / UINameplateOverlay via
--    BlizzardAPI.ApplyInterruptIconAlpha. We forward UnitCastingInfo's secret
--    notInterruptible straight into the icon's SetAlphaFromBoolean - a secret-aware sink
--    (SecretArguments = AllowedWhenTainted) - so the engine sets the kick icon's alpha to 0
--    on a non-interruptible cast WITHOUT us ever reading the value. No cast-bar dependency,
--    so the kick is correctly hidden regardless of any cast-bar / nameplate / unit-frame
--    addon. (This is the same display mechanism Blizzard's own cast bars use for the shield.)
--
-- 2. LOGIC (kick-vs-CC substitution) - this function. Substituting a CC for a kick on a
--    non-interruptible cast requires BRANCHING on interruptibility, which a secret can't do.
--    The only readable signal is the "icon-hidden" check below: Blizzard hides the cast bar's
--    spell Icon on a non-interruptible cast, and bar.Icon:IsShown() is a CONCRETE, non-secret
--    boolean - but only when that bar's update ran in Blizzard's UNTAINTED, privileged stack.
--    A cast-bar addon that replaces or reskins (taints) the bar removes this signal.
--
-- WHAT IS SECRET / DOES NOT WORK (red herrings - do NOT re-derive "sealed" from these):
--   • bar.notInterruptible field    - never assigned by Blizzard's mixin (local/param only)
--   • bar:IsInterruptable()/barType  - `barType ~= CastingBarType.Uninterruptable`; comparing
--                                      those secret-wrapped enums errors under our taint
--   • BorderShield:IsShown()         - secret, but NOT via SetShown(notInterruptible): it is
--                                      driven by `showShield and not IsInterruptable()`, so the
--                                      secrecy comes from that same barType comparison
--   • cast bar fill atlas / color    - secret;  the cast spellID - secret
--   • UNIT_SPELLCAST_(NOT_)INTERRUPTIBLE events - do NOT fire for these casts (any unit token)
--   • a private CastingBarFrame we create - runs in OUR taint → IsInterruptable() coerces wrong
--   • setting HideIconWhenNotInterruptible on a tainted bar - makes it THROW; do not do it
--
-- NET: the kick is correctly hidden everywhere (layer 1). Only the CC-substitution LOGIC
-- (layer 2) degrades when a cast-bar addon replaces/reskins the bar - there you get no
-- suggestion instead of a CC, never a wrongly-shown kick.
--
-- Returns (isCasting, isInterruptible, castBar, known). Cascade: event tracker (no-op for these
-- casts) → cast bar fields (icon-hidden is the one that works, on an untainted Blizzard bar)
-- → API fallback → fail-open.
-- ═════════════════════════════════════════════════════════════════════════════
local function IsTargetCastInterruptible(nameplate)
    local evtActive, evtInterruptible, evtKnown = BlizzardAPI.GetTargetCastInterruptState()
    local bar, barSource = FindVisibleCastBar(nameplate)

    -- Confirm the cast via API (unless event tracker already says "no cast") - bar or no
    -- bar. A visible bar is not proof: the frame stays shown through its fade-out after
    -- the cast stopped or was kicked, and the slot kept offering a stun on a mob that was
    -- no longer casting.
    local spell
    if evtActive or not evtKnown then
        spell = UnitCastingInfo("target")
        -- Spell name is secret in 12.0 combat; a secret value IS non-nil → cast exists.
        if not BlizzardAPI.IsSecretValue(spell) and not spell then
            spell = UnitChannelInfo("target")
        end
    end
    if not BlizzardAPI.IsSecretValue(spell) and not spell then
        return false, false, nil, true
    end
    if not bar then barSource = "api" end

    -- Event tracker is definitive (real boolean, never secret).
    if evtKnown then
        return true, evtInterruptible, bar, true
    end

    if bar then
        -- Every cast bar field/widget may propagate secret booleans in 12.0 combat.
        -- Blizzard's CastingBarMixin does BorderShield:SetShown(self.notInterruptible),
        -- so IsShown()/GetAlpha() on sub-widgets inherit the secrecy and crash on
        -- boolean tests. Wrap each check in pcall; crash = skip to next check.

        -- Direct field: notInterruptible. Blizzard's own mixin NEVER assigns this - it exists
        -- there only as a local/parameter - so on a stock bar this is always nil and falls
        -- through. Kept for a replacement bar that does expose it as a field.
        local niOk, ni = pcall(function() return bar.notInterruptible and true or false end)
        if niOk and ni then return true, false, bar, true end

        -- Icon hidden when not interruptible. CastingBarMixin:ShouldIconBeShown returns false
        -- from TWO guards BEFORE it ever tests interruptibility: `showIcon` (false when the
        -- player turns the cast-bar spell icon off) and a `look` other than "UNITFRAME" (set
        -- by a bar that reskins it). Without checking those first, a hidden icon reads as
        -- "uninterruptible" for EVERY cast, silently suppressing every kick suggestion for
        -- that player, permanently. Compare against false, not truthiness: a replacement bar
        -- may not carry these fields at all, and nil must keep the signal rather than kill it.
        local iconOk, iconHidden = pcall(function()
            return bar.Icon and bar.HideIconWhenNotInterruptible
                and bar.showIcon ~= false
                and (bar.look == nil or bar.look == "UNITFRAME")
                and not bar.Icon:IsShown()
        end)
        if iconOk and iconHidden then return true, false, bar, true end

        -- BorderShield visible = not interruptible (IsShown/GetAlpha inherit secret)
        local shieldOk, shieldShown = pcall(function()
            return bar.BorderShield and bar.BorderShield:IsShown() and (bar.BorderShield:GetAlpha() or 0) > 0.5
        end)
        if shieldOk and shieldShown then return true, false, bar, true end

        -- child-element cast bars use .Shield instead of .BorderShield
        if barSource == "childCastbar" then
            local altOk, altShown = pcall(function()
                return bar.Shield and bar.Shield:IsShown() and (bar.Shield:GetAlpha() or 0) > 0.5
            end)
            if altOk and altShown then return true, false, bar, true end
        end
    end

    -- API fallback when no cast bar frame is available (nameplates off + addon target frame).
    if barSource == "api" then
        local castName, notInt
        castName, _, _, _, _, _, _, notInt = UnitCastingInfo("target")
        -- Cast name is secret in 12.0 combat; secret non-nil = cast exists.
        if not BlizzardAPI.IsSecretValue(castName) and not castName then
            _, _, _, _, _, _, notInt = UnitChannelInfo("target")
        end
        -- notInterruptible is a secret boolean in 12.0 - check before comparing.
        if BlizzardAPI.IsSecretValue(notInt) then
            return true, true, nil, false  -- secret → fail-open, NOT authoritative
        end
        if notInt ~= nil then
            return true, not notInt, nil, true
        end
    end

    -- Fail-open: no negative signal → assume interruptible. NOT authoritative: we did not
    -- learn the cast is interruptible, we merely failed to prove otherwise.
    return true, true, bar, false
end

-- Diagnostic hook (/jac inspect castdiag): the live verdict the addon actually computes for
-- the current target, plus WHICH cascade check flagged "not interruptible" - so we read the
-- decision and its source instead of guessing from raw fields.
function CastInterruptTracker.DebugInterruptState()
    local nameplate = C_NamePlate and C_NamePlate.GetNamePlateForUnit and C_NamePlate.GetNamePlateForUnit("target")
    local isCasting, interruptible = IsTargetCastInterruptible(nameplate)
    local _, _, evtKnown = BlizzardAPI.GetTargetCastInterruptState()
    local src
    if evtKnown then
        src = "event-tracker"
    else
        local b = FindVisibleCastBar(nameplate)
        if not b then src = "no-bar/api" else
            local niOk, ni = pcall(function() return b.notInterruptible and true or false end)
            local icOk, icHid = pcall(function() return b.Icon and b.HideIconWhenNotInterruptible
                and b.showIcon ~= false and (b.look == nil or b.look == "UNITFRAME")
                and not b.Icon:IsShown() end)
            local shOk, shShown = pcall(function() return b.BorderShield and b.BorderShield:IsShown() and (b.BorderShield:GetAlpha() or 0) > 0.5 end)
            if niOk and ni then src = "notInterruptible-field"
            elseif icOk and icHid then src = "icon-hidden"
            elseif shOk and shShown then src = "borderShield"
            else src = "fail-open(checks-passed)" end
        end
    end
    return isCasting, interruptible, src
end

--- Why the slot may be deliberately silent right now, for /jac inspect interrupts.
--- These two suppressors and the already-CC'd test are all CORRECT behaviour, and from
--- outside they are indistinguishable from detection having failed - which is exactly how
--- "it works but it is inconsistent" gets reported. The probe has to be able to see them.
--- @return number sinceInterrupt, number interruptWindow, number sinceCC, number ccWindow
function CastInterruptTracker.DebugSuppression()
    local now = GetTime()
    return now - lastInterruptUsedTime, INTERRUPT_DEBOUNCE,
           now - lastCCAppliedTime, CC_APPLIED_SUPPRESS
end

--- Can the suggested ability actually hit the current target right now?
--- Ranged CCs/kicks: exact via IsSpellInRange, fail-OPEN on unknown - pressing a
--- targeted spell out of range is a harmless "Out of range" error, nothing is spent.
--- Player-centered AoE (reach="pbaoe") fails CLOSED - proven within radius or not
--- shown - because the waste asymmetry is reversed: the cast fires on the spot
--- regardless, burning the cooldown while the enemy cast continues, and the icon
--- trains exactly that impulse press. Better to miss a reminder than to bait one.
--- The gap-closer system owns the approach; the moment a charge lands, the melee
--- probes prove "within" and the suggestion appears.
--- Three-state: true reachable, false proven out of reach, NIL unanswerable. Nil only
--- happens for a self-centered CC this character can never prove (the probes short enough
--- to answer an 8yd radius are melee attacks, so every caster reads nil forever - which
--- silently hid War Stomp, Psychic Scream, Howl of Terror and Arcane Torrent from them).
--- The caller keeps a nil as a dimmed last resort instead of dropping it.
local function IsReachable(entry)
    if entry.reach == "pbaoe" then
        -- Self-centered AoE: reach = radius, and IsSpellInRange is nil for it. Use the
        -- range-probe bracket instead (baseline taunt probes in Data/RangeReferences
        -- give Druid/Monk their mid-range beyond-proof).
        local radius = entry.radius or 8
        local within = SpellDB.IsTargetWithin and SpellDB.IsTargetWithin(radius)
        if within ~= nil then return within end
        -- Unproven: "too far" (keep failing closed) vs "no probe can ever say".
        if SpellDB.CanProveWithin and SpellDB.CanProveWithin(radius) then return false end
        return nil
    end
    -- Tri-state read (BlizzardAPI.SpellInRange owns the required-unit-arg finding that
    -- was first measured here). Fail OPEN: nil (unknown) → assume reachable.
    local r = BlizzardAPI.SpellInRange and BlizzardAPI.SpellInRange(entry.spellID)
    return r ~= false
end

--- Cached per-frame (≤0.015 s); both renderers share the same answer and debounce timer.
---
--- @param resolvedInts  table?   ordered {spellID, type} array from SpellDB.ResolveInterruptSpells
--- @param interruptMode string   "kickOnly" | "ccPrefer"
--- @param currentTime   number   GetTime() value from the caller
--- @return table  { shouldShow, spellID, castBar } - reused each call; do NOT hold across frames
function CastInterruptTracker.EvaluateInterrupt(resolvedInts, interruptMode, currentTime)
    -- Keyed on time AND interruptMode so different renderer modes don't share stale results.
    if (currentTime - lastInterruptEvalTime) < 0.015
        and cachedIntResult.interruptMode == interruptMode then
        return cachedIntResult
    end
    lastInterruptEvalTime = currentTime
    cachedIntResult.interruptMode = interruptMode

    local shouldShow = false
    local intSpellID = nil
    local castBar    = nil
    -- Reset every evaluation: these are cached on a shared table, and a stale "we knew it was
    -- interruptible" from a previous cast would let the alert fire for an icon the sink hides.
    cachedIntResult.interruptible      = nil
    cachedIntResult.interruptibleKnown = false
    cachedIntResult.unreachable        = false

    -- Fears scatter packs and break on damage; excluded from suggestions by default.
    -- nil profile → exclude (fail-safe to the default-off behavior).
    local profile = BlizzardAPI.GetProfile()
    local includeFears = profile and profile.includeFears

    local debounceActive = (currentTime - lastInterruptUsedTime) < INTERRUPT_DEBOUNCE
                        or (currentTime - lastCCAppliedTime)    < CC_APPLIED_SUPPRESS

    if not debounceActive and resolvedInts and BlizzardAPI.IsTargetInterruptWorthy() then
        local nameplate = C_NamePlate and C_NamePlate.GetNamePlateForUnit and C_NamePlate.GetNamePlateForUnit("target", false)

        -- Unified interruptibility check: event tracker → cast bar fields → API fallback.
        local isCasting, interruptible, bar, interruptibleKnown = IsTargetCastInterruptible(nameplate)
        cachedIntResult.interruptible      = interruptible
        cachedIntResult.interruptibleKnown = interruptibleKnown and true or false

        if isCasting then
            -- Blanket only (bosses, minions); per-mechanic immunity is checked per entry below.
            local targetCCImmune  = BlizzardAPI.IsTargetCCImmune()
            -- Is the target ALREADY crowd-controlled? In combat: unanswerable, and this
            -- reads false there. GetUnitAuraInstanceIDs carries RequiresUnitAuraAccess as
            -- of 12.1.0, so IsUnitCrowdControlled's pcall fails and it fails open by
            -- design. A speculative `UnitIsCrowdControlled` global used to be OR'd in
            -- ahead of it; it does not exist in any client build and never has, so it
            -- only made a dead check look like two.
            -- Fail-open is still the right direction - suppressing every CC suggestion in
            -- combat is worse than occasionally offering one onto a CC'd target - but it
            -- IS a live cost: we can burn a diminishing-returns window. Out of combat the
            -- check works normally.
            local targetAlreadyCC = (BlizzardAPI.IsUnitCrowdControlled
                and BlizzardAPI.IsUnitCrowdControlled("target")) or false
            local canCC = not targetCCImmune and not targetAlreadyCC
            -- kickPrefer / ccPrefer: when cast is shielded, only CC spells can stop it.
            local ccOnly = not interruptible and canCC
                and (interruptMode == "kickPrefer" or interruptMode == "ccPrefer")
            local preferCC = interruptMode == "ccPrefer" and canCC

            -- Uninterruptible + kickOnly → nothing useful to suggest.
            if not interruptible and not ccOnly then
                -- fall through to no-show
            else
                -- Single-pass spell selection: prefer CC when configured, otherwise first usable.
                local fallbackID = nil
                local silenceFallbackID = nil   -- ccOnly: silence-class CC, used only if no stun-class CC found
                local outOfRangeFallbackID = nil -- usable but can't reach target; last resort (renderer flags out-of-range)
                for _, entry in ipairs(resolvedInts) do
                    local sid, stype = entry.spellID, entry.type
                    -- In ccOnly mode, skip non-CC spells (kicks can't stop shielded casts).
                    -- In kickOnly mode, skip CC spells entirely.
                    if ccOnly and stype ~= "cc" then
                        -- skip
                    elseif interruptMode == "kickOnly" and stype == "cc" then
                        -- skip
                    elseif (stype == "cc" and (targetCCImmune or BlizzardAPI.IsTargetCCImmune(entry.mech)))
                        or targetAlreadyCC then
                        -- CC spells unusable on immune / already CC'd targets - skip. Immunity
                        -- is per mechanic: a stun-immune mob still gets offered an incapacitate.
                    elseif stype == "cc" and not BlizzardAPI.IsCCSpellTypeValid(sid) then
                        -- Type-restricted CC (e.g. Repentance) on an incompatible creature type - skip.
                    elseif stype == "cc" and not includeFears and entry.mech == 5 then
                        -- Fear-class CC: scatters packs / breaks on damage - skip unless opted in.
                    -- failOpen=true for kicks (short CD, always useful to remind);
                    -- failOpen=false for CCs so we never recommend one we can't confirm is castable.
                    elseif BlizzardAPI.IsSpellUsable(sid, stype ~= "cc") and not SpellDB.IsInterruptOnCooldown(sid) then
                        local reach = IsReachable(entry)
                        if not reach then
                            -- Usable but can't hit the target now (e.g. a ranged CC out of range).
                            -- TARGETED spells stay as a dimmed last resort - an out-of-range
                            -- press costs nothing. A self-centered CC does NOT: it would fire
                            -- in place and burn the cooldown, so it drops out entirely rather
                            -- than baiting the impulse press - UNLESS its radius is unprovable
                            -- for this character (reach == nil), where dropping it means the
                            -- cue never exists at all. Then it takes the dimmed slot too.
                            if (entry.reach ~= "pbaoe" or reach == nil) and not outOfRangeFallbackID then
                                outOfRangeFallbackID = sid
                            end
                        elseif (preferCC or ccOnly) and stype == "cc" then
                            if ccOnly and entry.mech == 9 then
                                -- A silence only stops magic casts; an uninterruptible cast
                                -- may be physical. Defer it and keep looking for a stun-class
                                -- CC that stops anything; use it only if nothing else turns up.
                                if not silenceFallbackID then silenceFallbackID = sid end
                            else
                                intSpellID = sid; shouldShow = true; break
                            end
                        elseif not fallbackID then
                            fallbackID = sid
                            if not preferCC and not ccOnly then break end
                        end
                    end
                end
                if not shouldShow then
                    intSpellID = silenceFallbackID or fallbackID or outOfRangeFallbackID
                    if intSpellID then shouldShow = true end
                    -- The last resort cannot be shown to reach: the renderer dims it.
                    cachedIntResult.unreachable = intSpellID ~= nil and intSpellID == outOfRangeFallbackID
                end
            end
            -- castBar is nil for API fallback; callers gracefully hide cast aura.
            if shouldShow then castBar = bar end
        end
    end

    -- Runs every frame: detects when suggested spell goes on CD (≈ was cast).
    if lastInterruptShownID then
        if SpellDB.IsInterruptOnCooldown(lastInterruptShownID) then
            lastInterruptUsedTime = currentTime
            lastInterruptShownID  = nil
        elseif not shouldShow then
            lastInterruptShownID = nil
        end
    end
    if shouldShow and intSpellID then
        lastInterruptShownID = intSpellID
    end

    cachedIntResult.shouldShow = shouldShow
    cachedIntResult.spellID    = intSpellID
    cachedIntResult.castBar    = castBar
    return cachedIntResult
end

function CastInterruptTracker.PlayInterruptAlertSound(profile)
    local alertSound = profile.interruptAlertSound
    if not alertSound or alertSound == "None" then return end
    if not LSM then return end
    local soundFile = LSM:Fetch(LSM.MediaType.SOUND, alertSound, true)
    if not soundFile then return end
    local now = GetTime()
    if (now - lastInterruptSoundTime) < INTERRUPT_SOUND_DEBOUNCE then return end
    lastInterruptSoundTime = now
    PlaySoundFile(soundFile, "Master")
end

-- Suppresses CC suggestions until the game registers the CC state on the target.
function CastInterruptTracker.NotifyCCApplied()
    lastCCAppliedTime = GetTime()
end
