-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2025 wealdly
-- JustAC: Redundancy Filter Module - Hides active buffs and forms from queue
local RedundancyFilter = LibStub:NewLibrary("JustAC-RedundancyFilter", 42)
if not RedundancyFilter then return end

local BlizzardAPI = LibStub("JustAC-BlizzardAPI", true)
local FormCache = LibStub("JustAC-FormCache", true)

-- Hot path cache
local GetTime = GetTime
local pcall = pcall
local wipe = wipe
local pairs = pairs
local ipairs = ipairs
local UnitAffectingCombat = UnitAffectingCombat
local table_remove = table.remove
local C_Secrets = C_Secrets


-- Spell classification tables (manual, covers essential spells)

-- Raid buffs (includes alternate IDs from 12.0 Midnight Exclusion Whitelist)
local RAID_BUFF_SPELLS = {
    [1126] = true,    -- Mark of the Wild (Druid)
    [264778] = true,  -- Mark of the Wild (alternate)
    [21562] = true,   -- Power Word: Fortitude (Priest)
    [264764] = true,  -- Power Word: Fortitude (alternate)
    [6673] = true,    -- Battle Shout (Warrior)
    [264761] = true,  -- Battle Shout (alternate)
    [1459] = true,    -- Arcane Intellect (Mage)
    [264760] = true,  -- Arcane Intellect (alternate)
    [381732] = true,  -- Blessing of the Bronze (Evoker)
}

-- Pet summon spells
local PET_SUMMON_SPELLS = {
    -- Hunter
    [883] = true,     -- Call Pet 1
    [83242] = true,   -- Call Pet 2
    [83243] = true,   -- Call Pet 3
    [83244] = true,   -- Call Pet 4
    [83245] = true,   -- Call Pet 5
    -- Warlock
    [688] = true,     -- Summon Imp
    [697] = true,     -- Summon Voidwalker
    [712] = true,     -- Summon Succubus
    [691] = true,     -- Summon Felhunter
    [30146] = true,   -- Summon Felguard
    -- Death Knight
    [46584] = true,   -- Raise Dead (permanent ghoul)
    [46585] = true,   -- Raise Dead (temporary)
    [42650] = true,   -- Army of the Dead
    [49206] = true,   -- Summon Gargoyle
    -- Mage
    [31687] = true,   -- Summon Water Elemental
    -- Shaman
    [51533] = true,   -- Feral Spirit
    [198103] = true,  -- Earth Elemental
    [198067] = true,  -- Fire Elemental
    [192249] = true,  -- Storm Elemental
}

-- Unique Aura Spells: Buffs that can only have one instance active
-- These should be filtered when already active (outside pandemic window)
local UNIQUE_AURA_SPELLS = {
    -- Druid Forms
    [768] = true,     -- Cat Form
    [5487] = true,    -- Bear Form
    [783] = true,     -- Travel Form
    [24858] = true,   -- Moonkin Form
    [197625] = true,  -- Moonkin Form (affinity)
    [114282] = true,  -- Tree of Life
    -- Warrior Stances
    [386164] = true,  -- Battle Stance
    [386208] = true,  -- Defensive Stance
    -- Paladin Auras
    [465] = true,     -- Devotion Aura
    [183435] = true,  -- Retribution Aura
    [32223] = true,   -- Crusader Aura
    -- Rogue Stealth
    [1784] = true,    -- Stealth
    [115191] = true,  -- Stealth (Subterfuge)
    -- Hunter Aspects
    [5118] = true,    -- Aspect of the Cheetah
    [186257] = true,  -- Aspect of the Cheetah
    [186265] = true,  -- Aspect of the Turtle
    [186289] = true,  -- Aspect of the Eagle
}

-- Raid buffs are also unique auras (can only have one active)
for spellID in pairs(RAID_BUFF_SPELLS) do
    UNIQUE_AURA_SPELLS[spellID] = true
end

--------------------------------------------------------------------------------
-- NeverSecret Aura Whitelist (12.0+)
-- Source: Meorawr (Blizzard) hotfix + NoSelph/ShadowedUnitFrames research.
-- These spells return non-secret AuraData (spellId, name, icon, duration, etc.)
-- even in combat on player/party/raid units. When the aura API reports a field
-- as "secret" for one of these spells, we can safely pcall-access it — the data
-- is guaranteed readable and the pcall verifies that guarantee holds.
-- This allows resolution of NEW auras gained during combat (no instance-map entry)
-- without waiting for the next out-of-combat refresh.
--------------------------------------------------------------------------------
local NEVER_SECRET_AURA_SPELLS = {
    -- Raid Buffs (already in RAID_BUFF_SPELLS, but listed explicitly for whitelist)
    [1126]   = true,  -- Mark of the Wild
    [1459]   = true,  -- Arcane Intellect
    [6673]   = true,  -- Battle Shout
    [21562]  = true,  -- Power Word: Fortitude
    [369459] = true,  -- Source of Magic (Evoker)
    [462854] = true,  -- Skyfury
    [381732] = true,  -- Blessing of the Bronze
    [381741] = true,  -- Blessing of the Bronze (DH)
    [381746] = true,  -- Blessing of the Bronze (DK)
    [381748] = true,  -- Blessing of the Bronze (Druid)
    [381750] = true,  -- Blessing of the Bronze (Hunter)
    [381751] = true,  -- Blessing of the Bronze (Mage)
    [381752] = true,  -- Blessing of the Bronze (Monk)
    [381753] = true,  -- Blessing of the Bronze (Paladin)
    [381754] = true,  -- Blessing of the Bronze (Priest)
    [381756] = true,  -- Blessing of the Bronze (Rogue)
    [381757] = true,  -- Blessing of the Bronze (Shaman)
    [381758] = true,  -- Blessing of the Bronze (Warlock)
    [474754] = true,  -- Symbiotic Relationship
    -- Rogue Poisons (aura buff IDs)
    [2823]   = true,  -- Deadly Poison
    [8679]   = true,  -- Wound Poison
    [3408]   = true,  -- Crippling Poison
    [5761]   = true,  -- Numbing Poison
    [315584] = true,  -- Instant Poison
    [381637] = true,  -- Atrophic Poison
    [381664] = true,  -- Amplifying Poison
    -- Shaman Imbuements
    [319773] = true,  -- Windfury Weapon (aura)
    [319778] = true,  -- Flametongue Weapon (aura)
    [382021] = true,  -- Earthliving Weapon (aura, cast)
    [382022] = true,  -- Earthliving Weapon (buff)
    [457496] = true,  -- Tidecaller Guard (aura)
    [457481] = true,  -- Tidecaller Guard (buff)
    [462757] = true,  -- Thunderstrike Ward (aura)
    [462742] = true,  -- Thunderstrike Ward (buff)
    -- Resources / Class Mechanics
    [205473] = true,  -- Icicles (Mage)
    [260286] = true,  -- Tip of the Spear (Hunter)
    -- Rites (Self Buffs)
    [433568] = true,  -- Rite of Sanctification
    [433583] = true,  -- Rite of Adjuration
    -- Cooldowns
    [8690]   = true,  -- Hearthstone
    [20608]  = true,  -- Reincarnation
    -- Debuffs / Exhaustion
    [57723]  = true,  -- Exhaustion (Heroism)
    [390435] = true,  -- Exhaustion (alternate)
    [57724]  = true,  -- Sated (Bloodlust)
    [80354]  = true,  -- Temporal Displacement (Time Warp)
    [95809]  = true,  -- Insanity (Ancient Hysteria)
    [160455] = true,  -- Fatigued
    [264689] = true,  -- Fatigued (alternate)
    [26013]  = true,  -- Deserter
    [71041]  = true,  -- Dungeon Deserter
    -- Skyriding
    [427490] = true,  -- Ride Along Available
    [447959] = true,  -- Ride Along Active
    [447960] = true,  -- Ride Along Inactive
}

-- Pandemic window: allow recast when aura has less than 30% duration remaining
-- This matches WoW's pandemic mechanic where refreshing extends duration
local PANDEMIC_THRESHOLD = 0.30
-- Absolute minimum time-remaining threshold for long-duration buffs (poisons, raid buffs, etc).
-- When less than this many seconds remain, stop filtering — show the recast suggestion so
-- the player can reapply before or immediately after entering combat.
-- expirationTime is cached out of combat as a plain Lua number (GetTime() timestamp),
-- so remaining = expirationTime - GetTime() is valid arithmetic even in combat.
-- auraInstanceID → expirationTime mapping (instanceToTimingMap) carries this into combat.
local PRE_COMBAT_REFRESH_THRESHOLD = 600  -- 10 minutes in seconds
local LONG_BUFF_DURATION_CUTOFF    = 600  -- Only apply absolute threshold to buffs >= 10 min

-- Cache auras to avoid repeated API calls (refreshed on UNIT_AURA event)
-- UNIT_AURA events invalidate the cache, so 0.5s is safe and reduces API calls by 60%
local cachedAuras = {}
local lastAuraCheck = 0
local AURA_CACHE_DURATION = 0.5

-- Out-of-combat trusted cache (persists into combat to handle long-duration buffs)
-- When we check auras out of combat and they're valid, cache them longer
-- Trust them in combat even if aura API returns secrets (handles 50min poisons, etc)
-- Invalidated by UNIT_AURA events, so safe to keep for extended duration
local trustedOutOfCombatCache = {}
local lastTrustedCacheTime = 0
local TRUSTED_CACHE_DURATION = 600  -- Trust out-of-combat checks for 10 minutes (invalidated by events)
local TRUSTED_CACHE_RECENT_THRESHOLD = 300  -- Cache younger than 5 min uses exact expiration; older uses 80% threshold
local nextExpirationCheck = 0  -- Throttle expiration checking to once per 5 seconds
local EXPIRATION_CHECK_INTERVAL = 5

--------------------------------------------------------------------------------
-- Aura Instance ID Mapping (12.0 Combat-Safe Aura Detection)
-- auraInstanceID is NeverSecret in 12.0 — it's always readable even in combat.
-- We build a map of instanceID → spellID out of combat (when spellId is readable),
-- then use it in combat to resolve secret spellId fields back to real values.
-- UNIT_AURA addedAuras/removedAuraInstanceIDs keep the map current during combat.
--------------------------------------------------------------------------------
local instanceToSpellMap = {}   -- auraInstanceID → spellID
local instanceToNameMap = {}    -- auraInstanceID → spell name
local instanceToIconMap = {}    -- auraInstanceID → icon texture
local instanceToTimingMap = {}  -- auraInstanceID → {duration, expirationTime, count, halfwayThreshold}

-- Track spellIDs explicitly removed during combat (via UNIT_AURA removedAuraInstanceIDs)
-- Prevents trustedOutOfCombatCache from re-adding auras the player manually cancelled
-- Cleared on leaving combat (ClearActivationTracking)
local combatRemovedSpellIDs = {}

-- Pending activation queue: bridges UNIT_SPELLCAST_SUCCEEDED → UNIT_AURA addedAuras
-- When a spell is cast in combat, we know the spellID but not the new auraInstanceID.
-- When addedAuras fires with a secret spellId, we match by timing to map the instance.
-- This enables proper removal tracking on subsequent remove/reapply cycles.
local PENDING_ACTIVATION_WINDOW = 2.0  -- Max seconds between cast and UNIT_AURA addedAuras
local pendingActivations = {}  -- Array of {spellID, timestamp}

-- In-combat activation tracking (mirrors proc detection system)
-- When player casts a spell in combat, record it so we know they have the buff/form
-- Clear activation state on leaving combat to reset for next pull
local inCombatActivations = {}

-- Throttle debug prints (per-message-type timestamps)
local lastPrintTime = {}

-- Forward declaration for RefreshAuraCache (defined in Dynamic Aura Detection section)
-- Required because PruneExpiredActivations uses it before the full definition
local RefreshAuraCache

-- Debug mode (BlizzardAPI caches this, only checked once per second)
local function GetDebugMode()
    return BlizzardAPI and BlizzardAPI.GetDebugMode() or false
end

-- Hot-path alias for BlizzardAPI.GetCachedSpellInfo (avoids repeated nil guards)
local GetCachedSpellInfo = BlizzardAPI and BlizzardAPI.GetCachedSpellInfo or function() return nil end

-- Invalidate aura cache on UNIT_AURA; keep inCombatActivations until combat ends
-- Preserve trusted out-of-combat snapshot while in combat to avoid gaps caused by secret values
-- Preserve instanceToSpellMap always — it's our combat-safe aura identity resolution
function RedundancyFilter.InvalidateCache()
    wipe(cachedAuras)
    lastAuraCheck = 0

    -- Only invalidate trusted cache and instance maps when out of combat
    -- In combat, keep the pre-combat snapshot and instance maps intact
    if not UnitAffectingCombat("player") then
        wipe(trustedOutOfCombatCache)
        lastTrustedCacheTime = 0
        nextExpirationCheck = 0
        -- Instance maps are rebuilt on next RefreshAuraCache out of combat
        -- Don't wipe them here — they may still be valid and are cheap to rebuild
    end

    -- Prune expired activations (handles toggleable auras being turned off)
    RedundancyFilter.PruneExpiredActivations()
end

-- Clear activation tracking (called only on leaving combat)
function RedundancyFilter.ClearActivationTracking()
    wipe(inCombatActivations)
    wipe(combatRemovedSpellIDs)
    wipe(pendingActivations)
end

--------------------------------------------------------------------------------
-- UNIT_AURA Incremental Update (12.0 Instance Map Maintenance)
-- Called from JustAC:OnUnitAura with the updateInfo payload.
-- Processes addedAuras (new auras with possibly non-secret data even in combat)
-- and removedAuraInstanceIDs (clean removal from instance maps).
--------------------------------------------------------------------------------
function RedundancyFilter.OnUnitAuraUpdate(updateInfo)
    if not updateInfo then return end
    
    if updateInfo.removedAuraInstanceIDs then
        for _, instanceID in ipairs(updateInfo.removedAuraInstanceIDs) do
            -- Record the spellID before removing, so trusted cache merge doesn't re-add it
            local removedSpellID = instanceToSpellMap[instanceID]
            if removedSpellID then
                combatRemovedSpellIDs[removedSpellID] = true
                -- Also clear from inCombatActivations (player may have cast then cancelled)
                inCombatActivations[removedSpellID] = nil
            end
            instanceToSpellMap[instanceID] = nil
            instanceToNameMap[instanceID] = nil
            instanceToIconMap[instanceID] = nil
            instanceToTimingMap[instanceID] = nil
        end
    end
    
    -- Process added auras: populate instance maps for new auras
    -- In 12.0, addedAuras is an array of AuraData tables for newly applied auras.
    -- The spellId/name may be secret in combat, but we try anyway — if readable,
    -- we get immediate mapping; if secret, match against pendingActivations by timing.
    if updateInfo.addedAuras then
        local now = GetTime()
        
        for i = #pendingActivations, 1, -1 do
            if now - pendingActivations[i].time > PENDING_ACTIVATION_WINDOW then
                table_remove(pendingActivations, i)
            end
        end
        
        for _, auraData in ipairs(updateInfo.addedAuras) do
            local instanceID = auraData.auraInstanceID
            if instanceID then
                local spellIdIsSecret = BlizzardAPI.IsSecretValue(auraData.spellId)
                local nameIsSecret = BlizzardAPI.IsSecretValue(auraData.name)
                local resolvedSpellID = nil
                
                -- Determine if this is a beneficial aura (everything we track is helpful)
                -- isHelpful/isHarmful may or may not be secret; fail-open if unreadable
                local isHelpful = auraData.isHelpful
                local isHarmful = auraData.isHarmful
                if BlizzardAPI.IsSecretValue(isHelpful) then isHelpful = nil end
                if BlizzardAPI.IsSecretValue(isHarmful) then isHarmful = nil end
                -- Skip harmful auras entirely — we only track beneficial spells
                local isDefinitelyHarmful = (isHarmful == true) or (isHelpful == false)
                
                if not isDefinitelyHarmful then
                    if not spellIdIsSecret and auraData.spellId then
                        resolvedSpellID = auraData.spellId
                    elseif spellIdIsSecret and #pendingActivations > 0 then
                        -- Secret spellId: match against pending activations by timing.
                        -- Only safe when exactly one pending activation exists —
                        -- with multiple pending, we can't reliably determine which
                        -- cast produced this aura, so skip and fail-open (show spell).
                        -- Only matches helpful auras (harmful ones skipped above).
                        if #pendingActivations == 1 then
                            local pending = pendingActivations[1]
                            if now - pending.time <= PENDING_ACTIVATION_WINDOW then
                                resolvedSpellID = pending.spellID
                                table_remove(pendingActivations, 1)
                            end
                        end
                    end
                end
                
                if resolvedSpellID then
                    instanceToSpellMap[instanceID] = resolvedSpellID
                    combatRemovedSpellIDs[resolvedSpellID] = nil
                    
                    local dur = auraData.duration
                    local exp = auraData.expirationTime
                    local durIsSecret = BlizzardAPI.IsSecretValue(dur)
                    local expIsSecret = BlizzardAPI.IsSecretValue(exp)
                    if not durIsSecret and not expIsSecret and dur and exp then
                        local halfwayThreshold = nil
                        if dur > 0 and exp > 0 then
                            halfwayThreshold = exp - (dur * 0.2)
                        end
                        instanceToTimingMap[instanceID] = {
                            duration = dur,
                            expirationTime = exp,
                            count = auraData.applications or 1,
                            halfwayThreshold = halfwayThreshold,
                        }
                    end
                    
                    -- Copy name/icon from previous mapping if we have them
                    local prevName = instanceToNameMap[instanceID]
                    if not prevName then
                        -- Try to get from spell info cache (non-secret out of combat)
                        local spellInfo = BlizzardAPI.GetCachedSpellInfo and BlizzardAPI.GetCachedSpellInfo(resolvedSpellID)
                        if spellInfo and spellInfo.name and not BlizzardAPI.IsSecretValue(spellInfo.name) then
                            instanceToNameMap[instanceID] = spellInfo.name
                        end
                    end
                end
                if not nameIsSecret and auraData.name then
                    instanceToNameMap[instanceID] = auraData.name
                end
                if auraData.icon and not BlizzardAPI.IsSecretValue(auraData.icon) then
                    instanceToIconMap[instanceID] = auraData.icon
                end
            end
        end
    end
    
    -- updatedAuraInstanceIDs: auras that changed (e.g., stack count change)
    -- We don't need to do anything special here — the cache invalidation will
    -- cause RefreshAuraCache to re-read the current aura state on next access.
    -- The instance map entries remain valid (same instanceID = same aura).
end

--------------------------------------------------------------------------------
-- Safe API Wrappers
--------------------------------------------------------------------------------

-- Generic safe call wrapper: returns fallback on error or if func doesn't exist
local function SafeCall(func, fallback, ...)
    if not func then return fallback end
    local ok, result = pcall(func, ...)
    return ok and result or fallback
end

local function SafeUnitExists(unit) return SafeCall(UnitExists, false, unit) end
local function SafeHasPetUI() return SafeCall(HasPetUI, false) end
local function SafeIsMounted() return SafeCall(IsMounted, false) end
local function SafeIsStealthed() return SafeCall(IsStealthed, false) end

-- Spell ID sets used by multiple functions below -- defined here so all
-- dependent functions can reference them regardless of declaration order.
-- Uses spell IDs instead of English name patterns for locale safety.

local PET_REVIVE_SPELL_IDS = {
    [982]   = true,  -- Revive Pet
    [55709] = true,  -- Heart of the Phoenix
}
local function IsPetReviveSpell(spellID)
    return PET_REVIVE_SPELL_IDS[spellID] ~= nil
end

local STEALTH_SPELL_IDS = {
    [1784]  = true,  -- Stealth (Rogue)
    [1856]  = true,  -- Vanish (Rogue)
    [5215]  = true,  -- Prowl (Druid)
    [58984] = true,  -- Shadowmeld (Night Elf)
}
local function IsStealthSpell(spellID)
    return STEALTH_SPELL_IDS[spellID] ~= nil
end

local function IsMountSpell(spellID)
    return C_MountJournal and C_MountJournal.GetMountFromSpell
        and C_MountJournal.GetMountFromSpell(spellID) ~= nil
end

-- Prune expired activations only when aura API is reliable; otherwise retain activations conservatively
-- Also checks non-aura detection methods (forms, stealth, pets) which work in combat
function RedundancyFilter.PruneExpiredActivations()
    if not next(inCombatActivations) then return end
    
    -- Check each tracked activation
    for spellID, timestamp in pairs(inCombatActivations) do
        local shouldKeep = false
        
        -- Method 1: Form/stance detection (always works - not secret)
        if FormCache then
            local targetFormID = FormCache.GetFormIDBySpellID(spellID)
            if targetFormID then
                local currentFormID = FormCache.GetActiveForm()
                if targetFormID == currentFormID then
                    shouldKeep = true  -- Still in this form
                end
            end
        end
        
        -- Method 2: Stealth detection (always works - not secret)
        if not shouldKeep then
            if IsStealthSpell(spellID) and SafeIsStealthed() then
                shouldKeep = true  -- Still stealthed
            end
        end

        -- Method 3: Pet detection (always works - not secret)
        if not shouldKeep and PET_SUMMON_SPELLS[spellID] then
            if SafeHasPetUI() then
                shouldKeep = true  -- Pet still exists
            end
        end

        -- Method 4: Mount detection (always works - not secret)
        if not shouldKeep then
            if IsMountSpell(spellID) and SafeIsMounted() then
                shouldKeep = true  -- Still mounted
            end
        end
        
        -- Method 5: Aura API (only when accessible, not blocked by secrets)
        if not shouldKeep then
            local auraAPIAvailable = BlizzardAPI and BlizzardAPI.IsRedundancyFilterAvailable and BlizzardAPI.IsRedundancyFilterAvailable()
            if auraAPIAvailable and RefreshAuraCache then
                local auras = RefreshAuraCache()
                if auras and auras.byID and not auras.hasSecrets then
                    -- Aura data is reliable - check if buff still active
                    if auras.byID[spellID] then
                        shouldKeep = true  -- Aura still present
                    end
                else
                    -- Aura data unreliable - keep activation (conservative)
                    shouldKeep = true
                end
            else
                -- Aura API blocked - keep activation (conservative)
                shouldKeep = true
            end
        end
        
        -- Remove if no detection method confirms it's still active
        if not shouldKeep then
            inCombatActivations[spellID] = nil
        end
    end
end

-- Record spell activation during combat (called from UNIT_SPELLCAST_SUCCEEDED)
-- Mirrors proc detection system - reliable even with combat log restrictions
-- Also queues a pending activation so addedAuras can map the auraInstanceID
function RedundancyFilter.RecordSpellActivation(spellID)
    if not spellID then return end
    local now = GetTime()
    inCombatActivations[spellID] = now
    
    -- Queue for instance mapping: addedAuras will match by timing
    -- Only queue known aura spells to avoid noise from damage abilities
    if UNIQUE_AURA_SPELLS[spellID] or RAID_BUFF_SPELLS[spellID] then
        pendingActivations[#pendingActivations + 1] = { spellID = spellID, time = now }
    end
end

--------------------------------------------------------------------------------
-- Dynamic Aura Detection
--------------------------------------------------------------------------------

--- Prune expired entries from the trusted out-of-combat cache.
--- Throttled to once every EXPIRATION_CHECK_INTERVAL seconds.
--- Uses conservative 80% threshold for old caches, exact expiration for recent ones.
local function PruneTrustedCacheExpiration(now)
    if now < nextExpirationCheck then return end
    nextExpirationCheck = now + EXPIRATION_CHECK_INTERVAL

    local auraInfo = trustedOutOfCombatCache.auraInfo
    if not auraInfo then return end

    local cacheAge = now - lastTrustedCacheTime
    local useConservativeThreshold = cacheAge > TRUSTED_CACHE_RECENT_THRESHOLD

    for spellID, info in pairs(auraInfo) do
        local shouldInvalidate = false
        if useConservativeThreshold then
            if info.halfwayThreshold and now >= info.halfwayThreshold then
                shouldInvalidate = true
            end
        else
            if info.expirationTime and info.expirationTime > 0 and now >= info.expirationTime then
                shouldInvalidate = true
            end
        end
        if shouldInvalidate then
            trustedOutOfCombatCache.byID[spellID] = nil
            auraInfo[spellID] = nil
        end
    end
end

--- Merge trusted out-of-combat cache as fallback when in-combat aura resolution
--- has unresolved secrets. Skips spellIDs that were explicitly removed in combat,
--- and auras whose cached expiration shows they'll expire within the threshold.
local function MergeTrustedCacheFallback(now)
    for spellID, v in pairs(trustedOutOfCombatCache.byID) do
        if not cachedAuras.byID[spellID] and not combatRemovedSpellIDs[spellID] then
            local info = trustedOutOfCombatCache.auraInfo and trustedOutOfCombatCache.auraInfo[spellID]
            local skipExpiring = info
                and info.expirationTime and info.expirationTime > 0
                and info.duration and info.duration >= LONG_BUFF_DURATION_CUTOFF
                and (info.expirationTime - now) < PRE_COMBAT_REFRESH_THRESHOLD
            if not skipExpiring then
                cachedAuras.byID[spellID] = v
            end
        end
    end
    for name, v in pairs(trustedOutOfCombatCache.byName or {}) do
        if not cachedAuras.byName[name] then
            local nameSpellID = (type(v) == "number") and v
            if not nameSpellID or not combatRemovedSpellIDs[nameSpellID] then
                cachedAuras.byName[name] = v
            end
        end
    end
    for spellID, info in pairs(trustedOutOfCombatCache.auraInfo or {}) do
        if not cachedAuras.auraInfo[spellID] and not combatRemovedSpellIDs[spellID] then
            cachedAuras.auraInfo[spellID] = info
        end
    end
end

-- Build cache of current player auras (by spellID, name, and icon)
-- Now also stores duration and expiration time for pandemic window checks
-- 12.0: Uses auraInstanceID mapping to resolve secret values in combat
RefreshAuraCache = function()
    local now = GetTime()
    local inCombat = UnitAffectingCombat("player")
    
    -- If in combat and we have a recent trusted out-of-combat cache, use it as FALLBACK
    -- The instance map resolution below may produce better results, but if it can't
    -- resolve everything, we still have trustedOutOfCombatCache as a safety net.
    -- CRITICAL: Only compare timestamps in combat - no arithmetic with cached values (may be secrets)
    if inCombat and trustedOutOfCombatCache.byID and (now - lastTrustedCacheTime) < TRUSTED_CACHE_DURATION then
        PruneTrustedCacheExpiration(now)
    end
    
    if cachedAuras.byID and (now - lastAuraCheck) < AURA_CACHE_DURATION then
        return cachedAuras
    end
    
    wipe(cachedAuras)
    cachedAuras.byID = {}
    cachedAuras.byName = {}
    cachedAuras.byIcon = {}
    cachedAuras.auraInfo = {}  -- Stores {duration, expirationTime, count} by spellID
    
    local unresolvedSecrets = 0  -- Track how many auras we couldn't resolve
    
    -- 12.0+ fast pre-check: skip the full aura scan when all fields are known secret.
    -- C_Secrets.ShouldAurasBeSecret() is a NeverSecret boolean — safe to branch on.
    -- When true (combat), the loop below would just hit secret values on every aura,
    -- so we skip it entirely and rely on trustedOutOfCombatCache + instance maps.
    local aurasAreSecret = C_Secrets and C_Secrets.ShouldAurasBeSecret
        and C_Secrets.ShouldAurasBeSecret()
    
    if aurasAreSecret then
        -- Populate from instance maps maintained by OnUnitAuraUpdate (addedAuras/removedAuraInstanceIDs).
        -- This avoids 40 pcall(GetAuraDataByIndex) calls that would all return secret fields.
        for instanceID, spellID in pairs(instanceToSpellMap) do
            cachedAuras.byID[spellID] = true
            local timing = instanceToTimingMap[instanceID]
            if timing then cachedAuras.auraInfo[spellID] = timing end
            local name = instanceToNameMap[instanceID]
            if name then cachedAuras.byName[name] = spellID end
            local icon = instanceToIconMap[instanceID]
            if icon then cachedAuras.byIcon[icon] = name or true end
        end
        -- Flag for trusted cache merge (covers auras not in instance maps)
        cachedAuras.hasSecrets = true
    -- Modern API (11.0+)
    elseif C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        for i = 1, 40 do
            -- pcall protection: GetAuraDataByIndex may throw on compound unit tokens
            -- or unexpected 12.0.x hotfix changes. On failure, break the loop and use
            -- whatever auras we've already resolved + trustedOutOfCombatCache as fallback.
            local ok, auraData = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
            if not ok or not auraData then break end
            
            -- auraInstanceID is NeverSecret in 12.0 — always readable
            local instanceID = auraData.auraInstanceID
            local spellIdIsSecret = BlizzardAPI.IsSecretValue(auraData.spellId)
            local nameIsSecret = BlizzardAPI.IsSecretValue(auraData.name)
            
            if spellIdIsSecret or nameIsSecret then
                -- 12.0 NeverSecret whitelist: Some auras are guaranteed non-secret
                -- even in combat. For these, pcall-access the fields directly —
                -- if readable, skip the instance-map resolution path entirely.
                -- This handles auras gained during combat that have no instance map entry.
                local whitelistResolved = false
                if spellIdIsSecret then
                    local ok, realSpellId = pcall(function() return auraData.spellId + 0 end)
                    if ok and realSpellId and NEVER_SECRET_AURA_SPELLS[realSpellId] then
                        -- spellId was readable (NeverSecret) despite IsSecretValue returning true.
                        -- Process as a normal non-secret aura.
                        -- IMPORTANT: Don't use BlizzardAPI.GetAuraTiming here — it calls
                        -- Unsecret() which trusts issecretvalue(). For NeverSecret fields,
                        -- issecretvalue() still returns true (generic marking), but the
                        -- actual values ARE readable via forced evaluation. Use the same
                        -- pcall bypass used for spellId to extract duration/expirationTime.
                        cachedAuras.byID[realSpellId] = true
                        local durOk, dur = pcall(function() return auraData.duration + 0 end)
                        local expOk, exp = pcall(function() return auraData.expirationTime + 0 end)
                        if not durOk then dur = nil end
                        if not expOk then exp = nil end
                        local halfwayThreshold = nil
                        if dur and dur > 0 and exp and exp > 0 then
                            halfwayThreshold = exp - (dur * 0.2)
                        end
                        local timingInfo = {
                            duration = dur or 0,
                            expirationTime = exp or 0,
                            count = auraData.applications or 1,
                            halfwayThreshold = halfwayThreshold,
                        }
                        cachedAuras.auraInfo[realSpellId] = timingInfo
                        if instanceID then
                            instanceToSpellMap[instanceID] = realSpellId
                            instanceToTimingMap[instanceID] = timingInfo
                        end
                        -- Try reading name/icon too (also NeverSecret for whitelisted)
                        local nameOk, realName = pcall(function() return auraData.name .. "" end)
                        if nameOk and realName then
                            cachedAuras.byName[realName] = realSpellId
                            if instanceID then instanceToNameMap[instanceID] = realName end
                        end
                        if auraData.icon then
                            cachedAuras.byIcon[auraData.icon] = realName or true
                            if instanceID then instanceToIconMap[instanceID] = auraData.icon end
                        end
                        whitelistResolved = true
                    end
                end

                if not whitelistResolved then
                -- 12.0 Instance Map Resolution: Use instanceID to look up known spellID
                local mappedSpellID = instanceID and instanceToSpellMap[instanceID]
                local mappedName = instanceID and instanceToNameMap[instanceID]
                local mappedIcon = instanceID and instanceToIconMap[instanceID]
                
                if mappedSpellID then
                    cachedAuras.byID[mappedSpellID] = true
                    -- Use pre-cached timing from instance map (timing values are secret in combat)
                    local mappedTiming = instanceToTimingMap[instanceID]
                    if mappedTiming then
                        cachedAuras.auraInfo[mappedSpellID] = mappedTiming
                    end
                    if mappedName then
                        cachedAuras.byName[mappedName] = mappedSpellID
                    end
                    if mappedIcon then
                        cachedAuras.byIcon[mappedIcon] = mappedName or true
                    end
                else
                    -- Instance ID not in our map (new aura gained during combat)
                    unresolvedSecrets = unresolvedSecrets + 1
                end
                end  -- not whitelistResolved
            else
                -- Not secret — process normally and update instance maps
                if auraData.spellId then
                    cachedAuras.byID[auraData.spellId] = true
                    -- Store aura timing info for pandemic check (use API-specific helper)
                    local dur, exp = BlizzardAPI.GetAuraTiming("player", i, "HELPFUL")
                    -- Pre-calculate 80% duration threshold (absolute timestamp)
                    -- CRITICAL: Do arithmetic NOW (out of combat) not later when values may be secret
                    local halfwayThreshold = nil
                    if dur and dur > 0 and exp and exp > 0 then
                        halfwayThreshold = exp - (dur * 0.2)  -- Timestamp when aura reaches 20% remaining (80% consumed)
                    end
                    local timingInfo = {
                        duration = dur or 0,
                        expirationTime = exp or 0,
                        count = auraData.applications or 1,  -- Stack count
                        halfwayThreshold = halfwayThreshold,  -- Pre-calculated for in-combat comparison
                    }
                    cachedAuras.auraInfo[auraData.spellId] = timingInfo
                    
                    -- Update instance maps (always, so they're current for combat)
                    if instanceID then
                        instanceToSpellMap[instanceID] = auraData.spellId
                        instanceToTimingMap[instanceID] = timingInfo
                        if auraData.name then
                            instanceToNameMap[instanceID] = auraData.name
                        end
                        if auraData.icon then
                            instanceToIconMap[instanceID] = auraData.icon
                        end
                    end
                end
                if auraData.name then
                    cachedAuras.byName[auraData.name] = auraData.spellId or true
                end
                if auraData.icon then
                    cachedAuras.byIcon[auraData.icon] = auraData.name or true
                end
            end
        end
    -- Fallback for older clients (no instance ID support)
    elseif UnitAura then
        for i = 1, 40 do
            local ok, name, icon, count, _, duration, expirationTime, _, _, _, spellId = pcall(UnitAura, "player", i, "HELPFUL")
            if not ok or not name then break end
            
            -- Best-effort: skip secret auras but continue processing others
            local spellIdIsSecret = BlizzardAPI.IsSecretValue(spellId)
            local nameIsSecret = BlizzardAPI.IsSecretValue(name)
            
            if spellIdIsSecret or nameIsSecret then
                unresolvedSecrets = unresolvedSecrets + 1
            else
                if spellId then
                    cachedAuras.byID[spellId] = true
                    local durIsSecret = BlizzardAPI.IsSecretValue(duration)
                    local expIsSecret = BlizzardAPI.IsSecretValue(expirationTime)
                    local dur = (not durIsSecret and duration) or 0
                    local exp = (not expIsSecret and expirationTime) or 0
                    -- Pre-calculate 80% duration threshold (absolute timestamp)
                    -- CRITICAL: Do arithmetic NOW (out of combat) not later when values may be secret
                    local halfwayThreshold = nil
                    if dur > 0 and exp > 0 then
                        halfwayThreshold = exp - (dur * 0.2)  -- Timestamp when aura reaches 20% remaining (80% consumed)
                    end
                    cachedAuras.auraInfo[spellId] = {
                        duration = dur,
                        expirationTime = exp,
                        count = count or 1,
                        halfwayThreshold = halfwayThreshold,  -- Pre-calculated for in-combat comparison
                    }
                end
                if name then
                    cachedAuras.byName[name] = spellId or true
                end
                if icon then
                    cachedAuras.byIcon[icon] = name or true
                end
            end
        end
    end
    
    -- Mark hasSecrets only when there are UNRESOLVED secrets
    -- If all secret auras were resolved via instance map, we have complete data
    if unresolvedSecrets > 0 then
        cachedAuras.hasSecrets = true
    end
    
    lastAuraCheck = now
    
    -- If out of combat and we got clean data (no secrets), save as trusted cache
    if not inCombat and not cachedAuras.hasSecrets then
        wipe(trustedOutOfCombatCache)
        trustedOutOfCombatCache.byID = {}
        trustedOutOfCombatCache.byName = {}
        trustedOutOfCombatCache.byIcon = {}
        trustedOutOfCombatCache.auraInfo = {}
        for k, v in pairs(cachedAuras.byID) do trustedOutOfCombatCache.byID[k] = v end
        for k, v in pairs(cachedAuras.byName) do trustedOutOfCombatCache.byName[k] = v end
        for k, v in pairs(cachedAuras.byIcon) do trustedOutOfCombatCache.byIcon[k] = v end
        for k, v in pairs(cachedAuras.auraInfo) do 
            trustedOutOfCombatCache.auraInfo[k] = {
                duration = v.duration,
                expirationTime = v.expirationTime,
                count = v.count,
                halfwayThreshold = v.halfwayThreshold  -- Pre-calculated threshold (safe for in-combat comparison)
            }
        end
        lastTrustedCacheTime = now
        
        -- Out of combat, we have authoritative data — prune stale entries
        local activeInstances = {}
        if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
            for i = 1, 40 do
                local auraData = C_UnitAuras.GetAuraDataByIndex("player", i, "HELPFUL")
                if not auraData then break end
                if auraData.auraInstanceID then
                    activeInstances[auraData.auraInstanceID] = true
                end
            end
        end
        for instanceID in pairs(instanceToSpellMap) do
            if not activeInstances[instanceID] then
                instanceToSpellMap[instanceID] = nil
                instanceToNameMap[instanceID] = nil
                instanceToIconMap[instanceID] = nil
                instanceToTimingMap[instanceID] = nil
            end
        end
    end
    
    -- In combat with unresolved secrets: merge trustedOutOfCombatCache as fallback
    if inCombat and cachedAuras.hasSecrets and trustedOutOfCombatCache.byID then
        MergeTrustedCacheFallback(GetTime())
    end
    
    return cachedAuras
end

-- Check if player has a buff by spell ID
local function HasBuffBySpellID(spellID)
    if not spellID then return false end
    
    if inCombatActivations[spellID] then return true end
    
    local auras = RefreshAuraCache()
    return auras.byID and auras.byID[spellID]
end

-- Get aura info (duration, expiration, count) by spell ID
local function GetAuraInfo(spellID)
    if not spellID then return nil end
    local auras = RefreshAuraCache()
    return auras.auraInfo and auras.auraInfo[spellID]
end

-- Check if aura is within pandemic window (last 30% of duration)
-- Returns true if aura should be allowed to refresh
local function IsInPandemicWindow(spellID)
    local info = GetAuraInfo(spellID)
    if not info then
        -- No timing info available. Two scenarios:
        -- 1) Buff is gone → allow recast (return true)
        -- 2) Buff exists via inCombatActivations but timing data is secret → just cast, full duration
        -- Check inCombatActivations to distinguish: if we KNOW it's active, don't allow refresh
        if inCombatActivations[spellID] then
            return false  -- Just cast in combat, assume full duration remaining
        end
        return true  -- No aura info and not tracked → allow
    end
    
    local duration = info.duration
    local expirationTime = info.expirationTime
    
    -- Auras with 0 duration are permanent/passive - don't consider them for refresh
    if duration <= 0 then return false end
    
    local now = GetTime()
    local remaining = expirationTime - now

    -- Allow refresh if remaining time is less than pandemic threshold
    local pandemicTime = duration * PANDEMIC_THRESHOLD

    -- For long-duration buffs (>= 10 min, e.g. poisons, Mark of the Wild), apply an
    -- absolute minimum window so the addon suggests reapplication with time to spare.
    -- expirationTime is a plain Lua number cached out of combat — arithmetic is safe in combat.
    -- The auraInstanceID → timing mapping (instanceToTimingMap) carries this value into combat
    -- even when the aura API returns secret values for expirationTime directly.
    if duration >= LONG_BUFF_DURATION_CUTOFF then
        pandemicTime = math.max(pandemicTime, PRE_COMBAT_REFRESH_THRESHOLD)
    end

    return remaining <= pandemicTime
end

-- Check if player has a buff by exact name
local function HasBuffByName(buffName)
    if not buffName then return false end
    local auras = RefreshAuraCache()
    return auras.byName and auras.byName[buffName]
end

--------------------------------------------------------------------------------
-- Native Spell Classification Functions (12.0 Compliant)
--------------------------------------------------------------------------------

-- Check if spell applies an aura (using native tables + name pattern fallback)
-- Returns: isAura, isUniqueAura
local function IsAuraSpell(spellID)
    if not spellID then return false, false end
    
    -- Check our known unique aura table first (fast path)
    if UNIQUE_AURA_SPELLS[spellID] then
        return true, true
    end
    
    -- Fallback: FormCache ID-based detection for unknown spells
    -- GetFormIDBySpellID returns non-nil for any known shapeshift form spell
    if FormCache and FormCache.GetFormIDBySpellID
            and FormCache.GetFormIDBySpellID(spellID) ~= nil then
        return true, true  -- Treat as unique personal aura
    end

    return false, false
end

-- Check if spell is a pet-related ability (native table + name pattern)
local function IsPetSpell(spellID)
    if not spellID then return false end
    
    -- Check known pet summon table
    if PET_SUMMON_SPELLS[spellID] then
        return true
    end
    
    -- Name pattern fallback removed; unknown pet summon spells fail-open
    return false
end

-- Check if spell is DPS-relevant for rotation queue
-- When aura detection is blocked, only show spells that are clearly offensive/rotational
-- Uses name-based heuristics since we don't have LibPlayerSpells flags
local function IsDPSRelevant(spellID)
    if not spellID then return false end
    
    -- Known raid buffs: Always hide when can't check if active
    if RAID_BUFF_SPELLS[spellID] then
        return false
    end
    
    -- Known pet summons: Hide when can't check if pet exists
    if PET_SUMMON_SPELLS[spellID] then
        return false
    end
    
    -- Known unique auras (forms/stances): Hide when can't check if active
    if UNIQUE_AURA_SPELLS[spellID] then
        return false
    end
    
    -- Form/stance spells not already in UNIQUE_AURA_SPELLS: check FormCache
    if FormCache and FormCache.GetFormIDBySpellID
            and FormCache.GetFormIDBySpellID(spellID) ~= nil then
        return false
    end

    -- Pet revive (ID-based)
    if IsPetReviveSpell(spellID) then
        return false
    end

    -- Default: Include in queue (fail-open for combat relevance)
    return true
end

--------------------------------------------------------------------------------
-- Pet Detection
--------------------------------------------------------------------------------

-- Check if pet is alive (exists AND not dead)
-- 12.0: UnitIsDead result may be secret for non-player units
local function IsPetAlive()
    if not SafeUnitExists("pet") then return false end
    -- UnitIsDead returns true if unit is dead, false if alive
    local ok, isDead = pcall(UnitIsDead, "pet")
    if not ok then return true end  -- Fail-safe: assume alive
    
    -- 12.0: Check if result is secret - fail-open (assume alive if can't determine)
    if BlizzardAPI.IsSecretValue(isDead) then
        return true  -- Fail-open: assume pet is alive
    end
    
    return not isDead
end

--------------------------------------------------------------------------------
-- Form/Stance Detection
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Spell Category Detection (dynamic, no hardcoded spell lists)
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Rogue Poison Detection (cast-based inference)
-- Poisons are hour-long buffs; once observed via cast tracking assume active until combat ends
-- This avoids querying aura state which may return secret values
--------------------------------------------------------------------------------

-- Poison CAST spell IDs (what C_AssistedCombat recommends)
-- These are tracked via UNIT_SPELLCAST_SUCCEEDED -> inCombatActivations
-- Duration: 1 HOUR - safe to assume active once cast observed
-- Source: 12.0 Midnight Exclusion Whitelist
local ROGUE_POISON_CAST_IDS = {
    [2823] = true,   -- Deadly Poison (Lethal)
    [8679] = true,   -- Wound Poison (Lethal)
    [315584] = true, -- Instant Poison (Lethal)
    [381664] = true, -- Atrophic Poison (Lethal) - C_AssistedCombat uses this
    [381637] = true, -- Atrophic Poison (Lethal) - alternate cast ID
    [3408] = true,   -- Crippling Poison (Non-Lethal)
    [5761] = true,   -- Numbing Poison (Non-Lethal)
}

-- Poison AURA spell IDs (what appears in the player's buff list)
-- Source: 12.0 Midnight Exclusion Whitelist
-- Primary detection uses cast tracking (inCombatActivations) for reliability
local ROGUE_POISON_BUFF_IDS = {
    -- Lethal Poisons (aura IDs from whitelist)
    [2823] = true,   -- Deadly Poison
    [8679] = true,   -- Wound Poison
    [315584] = true, -- Instant Poison
    [381637] = true, -- Atrophic Poison
    -- Non-Lethal Poisons (aura IDs from whitelist)
    [3408] = true,   -- Crippling Poison
    [5761] = true,   -- Numbing Poison
}

-- Poison buff names (fallback detection)
local ROGUE_POISON_NAMES = {
    ["Deadly Poison"] = true,
    ["Wound Poison"] = true,
    ["Instant Poison"] = true,
    ["Atrophic Poison"] = true,
    ["Crippling Poison"] = true,
    ["Numbing Poison"] = true,
}

-- Check if a spell is a Rogue poison application spell
local function IsRoguePoisonSpell(spellID)
    return spellID and ROGUE_POISON_CAST_IDS[spellID]
end

-- Count how many poison buffs are currently active on the player
-- Count active poison buffs using cast-based inference (12.0 compatible)
-- Priority: Cast tracking > Aura cache by ID > Aura cache by name
-- Poisons are 1-hour buffs, safe to assume active once cast is observed
local function CountActivePoisonBuffs()
    local auras = RefreshAuraCache()
    local count = 0
    local foundNames = {}  -- Track poison names to avoid double-counting

    -- PRIMARY: Cast-based inference via UNIT_SPELLCAST_SUCCEEDED
    -- Most reliable in combat - doesn't depend on aura API (may return secrets)
    -- Poisons are hour-long buffs, safe to assume active until combat ends
    for spellID in pairs(ROGUE_POISON_CAST_IDS) do
        if inCombatActivations[spellID] then
            count = count + 1
            local spellInfo = GetCachedSpellInfo(spellID)
            if spellInfo and spellInfo.name then
                foundNames[spellInfo.name] = true
            end
        end
    end

    -- FALLBACK 1: Aura cache by buff spell ID (works out of combat, pre-combat buffs)
    -- Also checks cached expirationTime: if <= PRE_COMBAT_REFRESH_THRESHOLD seconds remain,
    -- don't count the poison as "active" — the player should reapply before or at combat start.
    -- expirationTime is a plain Lua number from the out-of-combat snapshot (or instanceToTimingMap),
    -- so the arithmetic is valid even when the aura API returns secret values in combat.
    if auras.byID then
        local now_poison = GetTime()
        for spellID in pairs(ROGUE_POISON_BUFF_IDS) do
            if auras.byID[spellID] then
                local auraInfo = auras.auraInfo and auras.auraInfo[spellID]
                local expiringSoon = auraInfo
                    and auraInfo.expirationTime and auraInfo.expirationTime > 0
                    and (auraInfo.expirationTime - now_poison) < PRE_COMBAT_REFRESH_THRESHOLD
                if not expiringSoon then
                    local spellInfo = GetCachedSpellInfo(spellID)
                    local name = spellInfo and spellInfo.name
                    if name and not foundNames[name] then
                        count = count + 1
                        foundNames[name] = true
                    end
                else
                    -- Still record the name so FALLBACK 2 doesn't re-count this expiring poison
                    local spellInfo = GetCachedSpellInfo(spellID)
                    if spellInfo and spellInfo.name then
                        foundNames[spellInfo.name] = true
                    end
                end
            end
        end
    end

    -- FALLBACK 2: Aura cache by name (catches unknown buff IDs)
    if auras.byName then
        for poisonName in pairs(ROGUE_POISON_NAMES) do
            if auras.byName[poisonName] and not foundNames[poisonName] then
                count = count + 1
                foundNames[poisonName] = true
            end
        end
    end

    return count
end

--------------------------------------------------------------------------------
-- Weapon Enchant Detection (for Shaman Imbues)
--------------------------------------------------------------------------------

-- Minimum time remaining to consider weapon enchant "active" (in milliseconds)
-- 10 seconds = 10000 ms - if less than this, allow refresh
local WEAPON_ENCHANT_REFRESH_THRESHOLD = 10000

-- Shaman weapon imbue spell IDs (1 hour duration)
-- Source: 12.0 Midnight Exclusion Whitelist
-- Maps the spell you cast to apply the weapon enchant
local WEAPON_ENCHANT_SPELLS = {
    [33757] = true,   -- Windfury Weapon
    [318038] = true,  -- Flametongue Weapon
    [196834] = true,  -- Frostbrand Weapon
    [382021] = true,  -- Earthliving Weapon
}

-- Check if a spell is a weapon enchant application spell (Shaman imbue)
local function IsWeaponEnchantSpell(spellID)
    return spellID and WEAPON_ENCHANT_SPELLS[spellID]
end

-- Check if main-hand weapon has enchant with sufficient time remaining
-- Returns true if main-hand has active enchant, false otherwise
local function HasActiveWeaponEnchant()
    if not GetWeaponEnchantInfo then return false end
    
    local hasMainHand, mainHandExpiration = GetWeaponEnchantInfo()
    
    -- Main-hand enchant required
    -- If missing or expiring soon, allow refresh
    if not hasMainHand then return false end
    if mainHandExpiration and mainHandExpiration < WEAPON_ENCHANT_REFRESH_THRESHOLD then return false end
    
    return true
end

--------------------------------------------------------------------------------
-- Main Redundancy Check
-- isDefensiveCheck: optional flag to skip DPS-relevance filter (for defensive spell selection)
--------------------------------------------------------------------------------

function RedundancyFilter.IsSpellRedundant(spellID, profile, isDefensiveCheck)
    if not spellID then return false end

    local debugMode = GetDebugMode()

    -- 1. FORM/STANCE REDUNDANCY (check FIRST - unaffected by 12.0 secrets)
    -- Stance bar APIs are client-side UI state, always accessible
    -- If this is a form spell and we're already in that form, skip it
    if FormCache then
        local targetFormID = FormCache.GetFormIDBySpellID(spellID)
        if targetFormID then
            local currentFormID = FormCache.GetActiveForm()
            if targetFormID == currentFormID then
                -- Throttle debug output (once per spell per 5 seconds)
                local now = GetTime()
                local throttleKey = "form_" .. spellID
                if debugMode and (not lastPrintTime[throttleKey] or now - lastPrintTime[throttleKey] > 5) then
                    lastPrintTime[throttleKey] = now
                    local spellInfo = GetCachedSpellInfo(spellID)
                    local spellName = spellInfo and spellInfo.name or tostring(spellID)
                    print("|cff66ccffJAC|r |cffff6666REDUNDANT|r: " .. spellName .. " - already in form " .. targetFormID)
                end
                return true
            end
        else
            -- Fallback: spell not in FormCache mapping - compare localized spell name
            -- directly against the active form name (both strings are from the game,
            -- so this comparison is locale-safe regardless of client language).
            local spellInfo = GetCachedSpellInfo(spellID)
            if spellInfo and spellInfo.name then
                local name = spellInfo.name
                local currentFormName = FormCache.GetActiveFormName()
                if currentFormName and currentFormName == name then
                    local now = GetTime()
                    local throttleKey = "form_name_" .. name
                    if debugMode and (not lastPrintTime[throttleKey] or now - lastPrintTime[throttleKey] > 5) then
                        lastPrintTime[throttleKey] = now
                        print("|cff66ccffJAC|r |cffff6666REDUNDANT|r: " .. name .. " - already active (name match)")
                    end
                    return true
                end
            end
        end
    end
    
    -- 2. MAINTENANCE BUFF COMBAT SUPPRESSION
    -- Long-duration maintenance buffs (poisons, imbues, raid buffs, rites) should never
    -- take priority over DPS mid-combat. Filter them out — they can wait until combat ends.
    -- Covers aura IDs (NEVER_SECRET_AURA_SPELLS) and cast IDs (poison/imbue cast tables).
    if UnitAffectingCombat("player") then
        if NEVER_SECRET_AURA_SPELLS[spellID] or IsRoguePoisonSpell(spellID) or IsWeaponEnchantSpell(spellID) then
            return true
        end
    end

    -- NOTE: Cooldown filtering moved to SpellQueue.IsSpellUsable() which uses a 2s threshold
    -- Position 1 doesn't get usability filtering (shows what Blizzard recommends)
    -- Positions 2+ get filtered by SpellQueue before reaching RedundancyFilter
    
    -- Check if we have incomplete aura data (unresolved secrets after instance map resolution)
    -- Instance maps make the raw auraAPIBlocked check redundant — hasSecrets is the
    -- authoritative indicator of whether our aura cache is complete
    local auras = RefreshAuraCache()
    local auraDataIncomplete = auras and auras.hasSecrets
    
    -- If cache has UNRESOLVED secrets, filter non-DPS spells as safety measure
    -- EXCEPTION 1: Defensive checks bypass this filter (heals are not "DPS-relevant" but are valid defensives)
    -- EXCEPTION 2: If we have no trusted cache (logged in during combat), fail-open to avoid hiding valid spells
    -- EXCEPTION 3: Skip if we have definitive knowledge about this spell's state:
    --   - cachedAuras.byID[spellID]: resolved present via instance map → let unique aura check handle it
    --   - combatRemovedSpellIDs[spellID]: explicitly removed during combat → let unique aura check handle it
    -- IMPORTANT: Continue to remaining checks (pet/stealth/mount/etc) even when aura data incomplete
    if auraDataIncomplete then
        -- Skip non-DPS gate if we know this specific spell's state (present or removed)
        local spellStateKnown = (auras.byID and auras.byID[spellID]) or combatRemovedSpellIDs[spellID]
        
        if not spellStateKnown then
            -- Check if we have any trusted pre-combat data to validate against
            local hasTrustedData = trustedOutOfCombatCache.byID and next(trustedOutOfCombatCache.byID)
            
            -- Only filter non-DPS spells if we have trusted data OR are doing defensive checks
            -- If no trusted data and not defensive, fail-open (allow spell through) to avoid false negatives
            if not isDefensiveCheck and not IsDPSRelevant(spellID) then
                if hasTrustedData then
                    -- Have pre-combat snapshot - safe to filter non-DPS spells
                    local now = GetTime()
                    local throttleKey = "nondps_" .. spellID
                    if GetDebugMode() and (not lastPrintTime[throttleKey] or now - lastPrintTime[throttleKey] > 5) then
                        lastPrintTime[throttleKey] = now
                        local reason = "unresolved secrets in cache"
                        local spellInfo = GetCachedSpellInfo(spellID)
                        local spellName = spellInfo and spellInfo.name or "Unknown"
                        print("|cff66ccffJAC|r |cffff6666FILTERED|r: " .. spellName .. " (ID: " .. spellID .. ") - Non-DPS spell (" .. reason .. ", have trusted cache)")
                    end
                    return true  -- Hide non-DPS spells
                else
                    -- No trusted cache - fail-open for safety (avoid hiding valid spells)
                    if GetDebugMode() then
                        local spellInfo = GetCachedSpellInfo(spellID)
                        local spellName = spellInfo and spellInfo.name or "Unknown"
                        print("|cff66ccffJAC|r |cffffff00ALLOWED|r: " .. spellName .. " (ID: " .. spellID .. ") - No trusted cache, fail-open")
                    end
                end
            end
        end
        -- Fall through for both defensive checks AND DPS-relevant spells
        -- Continue to pet/stealth/mount checks even when aura checks are blocked
    end
    
    local spellInfo = GetCachedSpellInfo(spellID)
    if not spellInfo or not spellInfo.name then return false end
    
    local spellName = spellInfo.name
    local isKnownAuraSpell, isUniqueAura = IsAuraSpell(spellID)
    
    -- Removed noisy "Checking redundancy" debug logs to reduce spam
    -- Use /jac test or /jac find for diagnostics instead
    
    -- 3. AURA SPELL REDUNDANCY
    -- IMPORTANT: Only filter auras that are UNIQUE (can't stack) and not in pandemic window
    -- Many abilities can stack (Immolation Aura, etc.) - trust Assisted Combat's judgment
    if isKnownAuraSpell then
        -- Only UNIQUE_AURA spells should be filtered when active
        -- Non-unique auras may stack or have other reasons to recast
        if isUniqueAura then
            -- Check if buff is active
            local hasBuff = HasBuffBySpellID(spellID) or HasBuffByName(spellName)
            
            if hasBuff then
                -- Check pandemic window - allow refresh if aura is about to expire
                if IsInPandemicWindow(spellID) then
                    if debugMode then
                        print("|cff66ccffJAC|r |cff00ff00ALLOWED|r: Unique aura in pandemic window - refresh allowed")
                    end
                    return false  -- Allow the cast
                end
                
                if debugMode then
                    print("|cff66ccffJAC|r |cffff6666REDUNDANT|r: Unique aura already active (not in pandemic window)")
                end
                return true
            end
        else
            -- Non-unique aura spells: trust Assisted Combat
            -- These may stack, refresh for damage, or have other valid reasons
            if debugMode and (HasBuffBySpellID(spellID) or HasBuffByName(spellName)) then
                print("|cff66ccffJAC|r |cff00ff00ALLOWED|r: Non-unique aura - may stack or have refresh benefit")
            end
        end
    end
    
    -- 4. PET SPELL REDUNDANCY
    -- Revive Pet: redundant if pet is ALIVE (can't revive alive pet)
    -- Summon Pet: redundant if pet EXISTS (alive or dead - already have a pet)
    if IsPetReviveSpell(spellID) then
        -- Revive is redundant only if pet is alive
        if IsPetAlive() then
            if debugMode then
                print("|cff66ccffJAC|r |cffff6666REDUNDANT|r: Revive Pet but pet is alive")
            end
            return true
        end
    else
        -- Pet summon spells: redundant if any pet exists
        if IsPetSpell(spellID) and SafeHasPetUI() then
            if debugMode then
                print("|cff66ccffJAC|r |cffff6666REDUNDANT|r: Pet summon but pet already exists")
            end
            return true
        end
    end
    
    -- 5. STEALTH REDUNDANCY
    -- Use IsStealthed() API - more reliable than buff checking
    if IsStealthSpell(spellID) then
        if SafeIsStealthed() then
            if debugMode then
                print("|cff66ccffJAC|r |cffff6666REDUNDANT|r: Stealth spell but already stealthed")
            end
            return true
        end
    end
    
    -- 6. MOUNT REDUNDANCY
    -- Use IsMounted() API
    if SafeIsMounted() then
        -- Check if this is a mount spell (avoid false positives)
        if IsMountSpell(spellID) then
            if debugMode then
                print("|cff66ccffJAC|r |cffff6666REDUNDANT|r: Mount spell but already mounted")
            end
            return true
        end
    end
    
    -- 7. ROGUE POISON REDUNDANCY
    -- Out of combat: Rogues can have max 2 poisons active (1 lethal + 1 non-lethal)
    -- If both slots are filled, all poison suggestions are redundant
    -- (In-combat suppression handled by step 2 above)
    if IsRoguePoisonSpell(spellID) then
        local activePoisons = CountActivePoisonBuffs()
        if activePoisons >= 2 then
            return true
        end
    end
    
    -- 8. WEAPON ENCHANT REDUNDANCY (Shaman Imbues)
    -- Out of combat: if weapon already has active enchant with sufficient time, skip it
    -- (In-combat suppression handled by step 2 above)
    if IsWeaponEnchantSpell(spellID) then
        if HasActiveWeaponEnchant() then
            if debugMode then
                print("|cff66ccffJAC|r |cffff6666REDUNDANT|r: Weapon enchant already active with time remaining")
            end
            return true
        else
            if debugMode then
                print("|cff66ccffJAC|r |cff00ff00ALLOWED|r: Weapon enchant needed (missing or expiring)")
            end
        end
    end
    
    -- Removed noisy "NOT REDUNDANT" debug logs to reduce spam
    return false
end

--------------------------------------------------------------------------------
-- Aura Query API
--------------------------------------------------------------------------------

--- Returns true if the player currently has a buff matching the given spellID.
--- Combat-safe: uses instanceToSpellMap (maintained by UNIT_AURA events).
function RedundancyFilter.IsAuraActiveBySpellID(spellID)
    if not spellID then return false end
    for _, mapSpellID in pairs(instanceToSpellMap) do
        if mapSpellID == spellID then return true end
    end
    return false
end

--- Returns true if ANY spellID in the given set is active as a player aura.
--- Efficient single-pass scan for checking multiple trigger auras at once.
function RedundancyFilter.IsAnyAuraActive(spellIDSet)
    if not spellIDSet then return false end
    for _, mapSpellID in pairs(instanceToSpellMap) do
        if spellIDSet[mapSpellID] then return true end
    end
    return false
end

--------------------------------------------------------------------------------
-- Debug / Diagnostic Functions
--------------------------------------------------------------------------------



-- Expose aura cache for diagnostics
function RedundancyFilter.GetAuraCache()
    return RefreshAuraCache()
end