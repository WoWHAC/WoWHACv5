-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2025 wealdly
-- JustAC: Action Bar Scanner Module - Caches action bar slots and keybind mappings
local ActionBarScanner = LibStub:NewLibrary("JustAC-ActionBarScanner", 37)
if not ActionBarScanner then return end
ActionBarScanner.lastKeybindChangeTime = 0

local BlizzardAPI = LibStub("JustAC-BlizzardAPI", true)
local MacroParser = LibStub("JustAC-MacroParser", true)
local FormCache = LibStub("JustAC-FormCache", true)

-- Hot path cache
local GetTime = GetTime
local HasAction = HasAction
local GetBindingKey = GetBindingKey
local GetActionCooldown = GetActionCooldown
local GetItemSpell = GetItemSpell
local C_Spell_GetOverrideSpell = C_Spell and C_Spell.GetOverrideSpell
local C_Spell_GetSpellInfo = C_Spell and C_Spell.GetSpellInfo
local FindBaseSpellByID = FindBaseSpellByID
local FindSpellOverrideByID = FindSpellOverrideByID
local C_GamePad = C_GamePad
local pairs = pairs
local ipairs = ipairs
local wipe = wipe
local string_find = string.find
local math_max = math.max

-- Gamepad face button atlas mappings by style (using _64 atlas with outline for better visibility)
-- Format: {PAD1, PAD2, PAD3, PAD4, PAD5, PAD6}
-- Atlas format: |A:name:height:width|a
-- Normal size (14:14) for single buttons, small size (10:10) for modifier combos
local GAMEPAD_FACE_BUTTONS = {
    generic = {
        normal = {
            "|A:Gamepad_Gen_1_64:14:14|a",
            "|A:Gamepad_Gen_2_64:14:14|a",
            "|A:Gamepad_Gen_3_64:14:14|a",
            "|A:Gamepad_Gen_4_64:14:14|a",
            "|A:Gamepad_Gen_5_64:14:14|a",
            "|A:Gamepad_Gen_6_64:14:14|a",
        },
        small = {
            "|A:Gamepad_Gen_1_64:10:10|a",
            "|A:Gamepad_Gen_2_64:10:10|a",
            "|A:Gamepad_Gen_3_64:10:10|a",
            "|A:Gamepad_Gen_4_64:10:10|a",
            "|A:Gamepad_Gen_5_64:10:10|a",
            "|A:Gamepad_Gen_6_64:10:10|a",
        },
    },
    xbox = {
        normal = {
            "|A:Gamepad_Ltr_A_64:14:14|a",
            "|A:Gamepad_Ltr_B_64:14:14|a",
            "|A:Gamepad_Ltr_X_64:14:14|a",
            "|A:Gamepad_Ltr_Y_64:14:14|a",
            "|A:Gamepad_Gen_5_64:14:14|a",
            "|A:Gamepad_Gen_6_64:14:14|a",
        },
        small = {
            "|A:Gamepad_Ltr_A_64:10:10|a",
            "|A:Gamepad_Ltr_B_64:10:10|a",
            "|A:Gamepad_Ltr_X_64:10:10|a",
            "|A:Gamepad_Ltr_Y_64:10:10|a",
            "|A:Gamepad_Gen_5_64:10:10|a",
            "|A:Gamepad_Gen_6_64:10:10|a",
        },
    },
    playstation = {
        normal = {
            "|A:Gamepad_Shp_Cross_64:14:14|a",
            "|A:Gamepad_Shp_Circle_64:14:14|a",
            "|A:Gamepad_Shp_Square_64:14:14|a",
            "|A:Gamepad_Shp_Triangle_64:14:14|a",
            "|A:Gamepad_Shp_MicMute_64:14:14|a",
            "|A:Gamepad_Shp_TouchpadR_64:14:14|a",
        },
        small = {
            "|A:Gamepad_Shp_Cross_64:10:10|a",
            "|A:Gamepad_Shp_Circle_64:10:10|a",
            "|A:Gamepad_Shp_Square_64:10:10|a",
            "|A:Gamepad_Shp_Triangle_64:10:10|a",
            "|A:Gamepad_Shp_MicMute_64:10:10|a",
            "|A:Gamepad_Shp_TouchpadR_64:10:10|a",
        },
    },
}

local string_gsub = string.gsub

-- Reuse BlizzardAPI's cached addon lookup
local GetCachedAddon = BlizzardAPI.GetAddon

-- Helper to get face button atlas based on current setting
-- size: "normal" (14:14) or "small" (10:10) for modifier combos
local function GetGamepadFaceButton(buttonNum, size)
    local addon = GetCachedAddon()
    local style = (addon and addon.db and addon.db.profile.gamepadIconStyle) or "xbox"
    local styleButtons = GAMEPAD_FACE_BUTTONS[style] or GAMEPAD_FACE_BUTTONS.xbox
    local sizeButtons = styleButtons[size or "normal"] or styleButtons.normal
    return sizeButtons[buttonNum] or sizeButtons[1]
end

local NUM_ACTIONBAR_BUTTONS = 12
local MAX_ACTION_SLOTS = 200

-- Three-level cache to avoid repeated API calls: action slots → keybinds → hotkeys
local bindingKeyCache = {}
local bindingCacheValid = false
local slotMappingCache = {}
local slotMappingCacheKey = 0
local keybindCache = {}
local keybindCacheValid = false
local lastValidatedStateHash = 0
local isRebuildingBindings = false

local spellHotkeyCache = {}
local spellHotkeyCacheValid = false

-- Cache slot mappings so hotkey lookups don't fail when spell changes mid-GCD
local spellSlotCache = {}
-- Parallel cache: true when slot directly represents the spell (safe for
-- C_ActionBar slot-based queries), false when behind a macro modifier.
local slotDirectCache = {}
-- Item → action slot cache (items are always direct matches on the bar).
local itemSlotCache = {}

-- PERFORMANCE: Cache abbreviated keybinds (50+ gsub calls per abbreviation is expensive)
-- Key: raw binding string, Value: abbreviated string
-- Self-limits to the number of unique keybinds (~30-60 typical). Cleared by ClearAllCaches().
local abbreviatedKeyCache = {}

-- PERFORMANCE: Rate-limit full hotkey lookups (FindSpellInActions is VERY expensive)
-- When cache is invalid, we return stale value immediately and only refresh periodically
local lastHotkeyRefreshTime = 0
local HOTKEY_REFRESH_INTERVAL = 0.25  -- Refresh stale entries max 4x/sec (enough for responsiveness)

-- Track page, form, and override state to detect when keybinds need refresh
local cachedStateData = {
    page = 1,
    bonusOffset = 0,
    form = 0,
    hasOverride = false,
    hasVehicle = false,
    hasTemp = false,
    hash = 0,
    valid = false,
}

-- Hash multipliers for action bar state change detection.
-- Each field occupies a non-overlapping range so the composite hash
-- uniquely identifies the combination of page + bonus + form + flags.
local HASH_BONUS_OFFSET   = 100
local HASH_FORM           = 10000
local HASH_OVERRIDE       = 1000000
local HASH_VEHICLE        = 2000000
local HASH_TEMP_SHAPESHIFT = 4000000

local function UpdateCachedState()
    cachedStateData.page = GetActionBarPage and GetActionBarPage() or 1
    cachedStateData.bonusOffset = GetBonusBarOffset and GetBonusBarOffset() or 0
    -- FormCache uses reliable iteration; fallback to 0 (caster form) if unavailable
    cachedStateData.form = FormCache and FormCache.GetActiveForm() or 0
    cachedStateData.hasOverride = HasOverrideActionBar and HasOverrideActionBar() or false
    cachedStateData.hasVehicle = HasVehicleActionBar and HasVehicleActionBar() or false
    cachedStateData.hasTemp = HasTempShapeshiftActionBar and HasTempShapeshiftActionBar() or false
    
    cachedStateData.hash = cachedStateData.page
        + cachedStateData.bonusOffset * HASH_BONUS_OFFSET
        + cachedStateData.form * HASH_FORM
    if cachedStateData.hasOverride then cachedStateData.hash = cachedStateData.hash + HASH_OVERRIDE end
    if cachedStateData.hasVehicle then cachedStateData.hash = cachedStateData.hash + HASH_VEHICLE end
    if cachedStateData.hasTemp then cachedStateData.hash = cachedStateData.hash + HASH_TEMP_SHAPESHIFT end
    
    cachedStateData.valid = true
end

local function GetCachedStateHash()
    if not cachedStateData.valid then
        UpdateCachedState()
    end
    return cachedStateData.hash
end

-- Binding version counter — incremented on each RebuildBindingCache to detect changes
local bindingVersion = 0

-- Select the appropriate binding key based on input preference (auto/keyboard/gamepad).
-- GetBindingKey() returns multiple values: key1, key2, ... (keyboard + controller).
-- This function picks the one matching the user's inputPreference setting.
local function IsPadKey(key)
    if not key then return false end
    local pos = string_find(key, "PAD")
    if not pos then return false end
    -- Exclude NUMPAD keys
    return not (pos >= 4 and key:sub(pos - 3, pos - 1) == "NUM")
end

local function SelectBinding(...)
    local n = select("#", ...)
    if n == 0 then return nil end
    if n == 1 then return ... end  -- Single binding, no choice to make

    local addon = GetCachedAddon()
    local pref = (addon and addon.db and addon.db.profile.inputPreference) or "auto"
    local wantPad
    if pref == "keyboard" then
        wantPad = false
    elseif pref == "gamepad" then
        wantPad = true
    else -- "auto"
        wantPad = C_GamePad and C_GamePad.IsEnabled and C_GamePad.IsEnabled() or false
    end

    -- First pass: find preferred binding type
    local fallback = select(1, ...)
    for i = 1, n do
        local key = select(i, ...)
        if key and IsPadKey(key) == wantPad then
            return key
        end
    end
    return fallback
end

local function RebuildBindingCache()
    wipe(bindingKeyCache)
    local patterns = {
        "ACTIONBUTTON", "MULTIACTIONBAR1BUTTON", "MULTIACTIONBAR2BUTTON",
        "MULTIACTIONBAR3BUTTON", "MULTIACTIONBAR4BUTTON", "MULTIACTIONBAR5BUTTON",
        "MULTIACTIONBAR6BUTTON", "MULTIACTIONBAR7BUTTON",
    }
    
    for i, pattern in ipairs(patterns) do
        for j = 1, NUM_ACTIONBAR_BUTTONS do
            local bindingKey = pattern .. j
            bindingKeyCache[bindingKey] = SelectBinding(GetBindingKey(bindingKey)) or ""
        end
    end
    
    bindingVersion = bindingVersion + 1
    
    bindingCacheValid = true
end

local function GetCachedBindingKey(bindingKey)
    if not bindingCacheValid then
        RebuildBindingCache()
    end
    return bindingKeyCache[bindingKey] or ""
end

-- Return current binding version (incremented on each rebuild)
local function CalculateKeybindHash()
    if not bindingCacheValid then
        RebuildBindingCache()
    end
    return bindingVersion
end

local function CalculateActionSlot(buttonID, barType)
    if not cachedStateData.valid then
        UpdateCachedState()
    end
    
    local page = 1
    
    if barType == "main" then
        page = cachedStateData.page
        if cachedStateData.bonusOffset > 0 then
            page = 6 + cachedStateData.bonusOffset
        end
    elseif barType == "multibar1" then
        page = 6
    elseif barType == "multibar2" then
        page = 5
    elseif barType == "multibar3" then
        page = 3
    elseif barType == "multibar4" then
        page = 4
    elseif barType == "multibar5" then
        page = 13
    elseif barType == "multibar6" then
        page = 14
    elseif barType == "multibar7" then
        page = 15
    end
    
    local safePage = math_max(1, page)
    local safeButtonID = math_max(1, math.min(buttonID, NUM_ACTIONBAR_BUTTONS))
    
    return safeButtonID + ((safePage - 1) * NUM_ACTIONBAR_BUTTONS)
end

local function GetCachedSlotMapping()
    local currentHash = GetCachedStateHash()
    
    if slotMappingCacheKey == currentHash and next(slotMappingCache) then
        return slotMappingCache
    end
    
    local mapping = {}
    
    for buttonID = 1, NUM_ACTIONBAR_BUTTONS do
        local slot = CalculateActionSlot(buttonID, "main")
        mapping[slot] = "ACTIONBUTTON" .. buttonID
    end
    
    for buttonID = 1, NUM_ACTIONBAR_BUTTONS do
        mapping[buttonID] = "ACTIONBUTTON" .. buttonID
    end
    
    local barMappings = {
        {barType = "multibar1", pattern = "MULTIACTIONBAR1BUTTON"},
        {barType = "multibar2", pattern = "MULTIACTIONBAR2BUTTON"},
        {barType = "multibar3", pattern = "MULTIACTIONBAR3BUTTON"},
        {barType = "multibar4", pattern = "MULTIACTIONBAR4BUTTON"},
        {barType = "multibar5", pattern = "MULTIACTIONBAR5BUTTON"},
        {barType = "multibar6", pattern = "MULTIACTIONBAR6BUTTON"},
        {barType = "multibar7", pattern = "MULTIACTIONBAR7BUTTON"},
    }
    
    for _, barData in ipairs(barMappings) do
        for buttonID = 1, NUM_ACTIONBAR_BUTTONS do
            local slot = CalculateActionSlot(buttonID, barData.barType)
            mapping[slot] = barData.pattern .. buttonID
        end
    end
    
    slotMappingCache = mapping
    slotMappingCacheKey = currentHash
    
    return mapping
end

local function ValidateAndBuildKeybindCache()
    local newKeybindHash = CalculateKeybindHash()
    local stateHash = GetCachedStateHash()
    local combinedHash = newKeybindHash * 10000000 + stateHash  -- Form changes trigger rebuild

    if keybindCacheValid and lastValidatedStateHash == combinedHash then
        return
    end

    lastValidatedStateHash = combinedHash

    wipe(keybindCache)
    local slotMapping = GetCachedSlotMapping()

    for slot, keybindPattern in pairs(slotMapping) do
        local key = GetCachedBindingKey(keybindPattern)
        if key and key ~= "" then
            keybindCache[slot] = key
        end
    end

    keybindCacheValid = true
end

local function InvalidateKeybindCache()
    keybindCacheValid = false
    lastValidatedStateHash = 0
    wipe(keybindCache)
    spellHotkeyCacheValid = false
    wipe(spellHotkeyCache)
    wipe(spellSlotCache)
    wipe(slotDirectCache)
    wipe(itemSlotCache)
end

local function InvalidateBindingCache()
    bindingCacheValid = false
    wipe(bindingKeyCache)
    -- NOTE: Do NOT clear abbreviatedKeyCache here - it's keyed by raw keybind strings
    -- (like "SHIFT-PAD1") and the abbreviation only depends on gamepad icon style,
    -- not on which spells are bound. Clearing it on every binding change defeats caching.
    InvalidateKeybindCache()
end

local function InvalidateStateCache()
    cachedStateData.valid = false
    slotMappingCacheKey = 0
    wipe(slotMappingCache)
    spellHotkeyCacheValid = false
    wipe(spellHotkeyCache)
end

local function GetOptimizedKeybind(slot)
    if not slot or slot < 1 or slot > MAX_ACTION_SLOTS then
        return nil
    end
    
    ValidateAndBuildKeybindCache()
    return keybindCache[slot]
end

local function SearchSlots(slotSet, priority, spellID, spellName, debugMode)
    local candidates = {}
    
    for slot in pairs(slotSet) do
        if not HasAction(slot) then
            -- empty slot
        else
            local actionType, id, subType, macroSpellID = BlizzardAPI.GetActionInfo(slot)

            if not actionType then
                -- invalid
            elseif actionType == "spell" and type(id) == "string" and id == "assistedcombat" then
                -- Assisted Combat placeholder
            elseif C_ActionBar and C_ActionBar.IsAssistedCombatAction and C_ActionBar.IsAssistedCombatAction(slot) then
                -- Assisted Combat slot
            else
                local slotKeybind = GetOptimizedKeybind(slot)
                local hasHotkey = slotKeybind ~= nil and slotKeybind ~= ""
                
                if actionType == "spell" then
                    local isMatch = (id == spellID)

                    -- Slot's base transforms to our target (e.g., Pyroblast → Hot Streak)
                    -- onlyKnown=false catches dynamic combat transforms (Templar Strike → Templar Slash)
                    if not isMatch and id and id ~= spellID then
                        local slotSpellOverride = C_Spell_GetOverrideSpell and C_Spell_GetOverrideSpell(id, 0, false)
                        if slotSpellOverride and slotSpellOverride ~= id and slotSpellOverride == spellID then
                            isMatch = true
                        end
                    end

                    -- Our target transforms to slot's spell (reverse)
                    if not isMatch then
                        local targetOverride = C_Spell_GetOverrideSpell and C_Spell_GetOverrideSpell(spellID, 0, false)
                        if targetOverride and targetOverride ~= 0 and targetOverride ~= spellID and id == targetOverride then
                            isMatch = true
                        end
                    end

                    -- FindSpellOverrideByID fallback — separate native API for talent/aura overrides
                    -- that C_Spell.GetOverrideSpell may miss (different internal lookup path)
                    if not isMatch and FindSpellOverrideByID then
                        local slotOverride = FindSpellOverrideByID(id)
                        if slotOverride and slotOverride ~= id and slotOverride == spellID then
                            isMatch = true
                        end
                        if not isMatch then
                            local targetOverride = FindSpellOverrideByID(spellID)
                            if targetOverride and targetOverride ~= spellID and targetOverride == id then
                                isMatch = true
                            end
                        end
                    end

                    -- Target is override, slot has base
                    if not isMatch and FindBaseSpellByID then
                        local baseSpellID = FindBaseSpellByID(spellID)
                        if baseSpellID and baseSpellID ~= spellID and baseSpellID == id then
                            isMatch = true
                        end
                    end

                    -- Slot has override, we want base
                    if not isMatch and FindBaseSpellByID and id then
                        local slotBaseSpellID = FindBaseSpellByID(id)
                        if slotBaseSpellID and slotBaseSpellID ~= id and slotBaseSpellID == spellID then
                            isMatch = true
                        end
                    end
                    
                    if isMatch then
                        candidates[#candidates + 1] = {
                            slot = slot,
                            type = "direct",
                            modifiers = {},
                            priority = priority,
                            score = hasHotkey and 1000 or -500
                        }
                    end
                elseif actionType == "item" then
                    -- Match items by cast spell so slot-based APIs work for items too.
                    if GetItemSpell then
                        local _, itemCastSpellID = GetItemSpell(id)
                        if itemCastSpellID and itemCastSpellID == spellID then
                            itemSlotCache[id] = slot
                            candidates[#candidates + 1] = {
                                slot = slot,
                                type = "direct",
                                modifiers = {},
                                priority = priority,
                                score = hasHotkey and 1000 or -500
                            }
                        end
                    end
                elseif actionType == "macro" then
                    if subType == "spell" and macroSpellID and macroSpellID > 0 then
                        local macroIconSpellInfo = C_Spell_GetSpellInfo and C_Spell_GetSpellInfo(macroSpellID)
                        if macroIconSpellInfo and macroIconSpellInfo.name == spellName then
                            candidates[#candidates + 1] = {
                                slot = slot,
                                type = "macro_visible",
                                modifiers = {},
                                priority = priority,
                                score = hasHotkey and 900 or -600
                            }
                        end
                    end

                    if MacroParser and MacroParser.GetMacroSpellInfo then
                        local parsedEntry = MacroParser.GetMacroSpellInfo(slot, spellID, spellName)
                        if parsedEntry and parsedEntry.found then
                            local baseScore = parsedEntry.qualityScore or 500
                            candidates[#candidates + 1] = {
                                slot = slot,
                                type = "macro_conditional",
                                modifiers = parsedEntry.modifiers or {},
                                priority = priority,
                                score = hasHotkey and baseScore or (baseScore - 1000)
                            }
                        end
                    end
                end
            end
        end
    end
    
    -- Early exit if no candidates found
    if #candidates == 0 then
        return nil, nil
    end
    
    table.sort(candidates, function(a, b)
        if a.score ~= b.score then
            return a.score > b.score
        end
        return a.slot < b.slot
    end)
    
    local bestCandidate = candidates[1]
    
    if debugMode then
        print("|JAC| Selected slot " .. bestCandidate.slot .. " with score " .. bestCandidate.score)
    end
    
    return bestCandidate.slot, bestCandidate
end

local function FindSpellInActions(spellID, spellName)
    if not spellID or spellID == 0 or not spellName or spellName == "" then 
        return nil, nil 
    end
    
    local slotMapping = GetCachedSlotMapping()
    
    if not cachedStateData.valid then
        UpdateCachedState()
    end
    local bonusOffset = cachedStateData.bonusOffset
    
    -- Form bars replace main bar visually; keybinds follow what's currently shown
    local currentBarSlots = {}
    local fallbackSlots = {}

    if bonusOffset > 0 then
        -- Form bar active: use form slots, keep base slots as fallback
        local formBarStart = 1 + (6 + bonusOffset - 1) * NUM_ACTIONBAR_BUTTONS
        for i = formBarStart, formBarStart + 11 do
            if slotMapping[i] then
                currentBarSlots[i] = true
            end
        end
        for i = 1, NUM_ACTIONBAR_BUTTONS do
            if slotMapping[i] then
                fallbackSlots[i] = true
            end
        end
    else
        for i = 1, NUM_ACTIONBAR_BUTTONS do
            if slotMapping[i] then
                currentBarSlots[i] = true
            end
        end
    end

    -- Multi-bar slots (always visible)
    for slot in pairs(slotMapping) do
        if slot > NUM_ACTIONBAR_BUTTONS then
            local isFormBarSlot = false
            if bonusOffset > 0 then
                local formBarStart = 1 + (6 + bonusOffset - 1) * NUM_ACTIONBAR_BUTTONS
                if slot >= formBarStart and slot <= formBarStart + 11 then
                    isFormBarSlot = true
                end
            end
            if not isFormBarSlot then
                currentBarSlots[slot] = true
            end
        end
    end

    local foundSlot, slotInfo = SearchSlots(currentBarSlots, 1, spellID, spellName, false)

    if not foundSlot and next(fallbackSlots) then
        foundSlot, slotInfo = SearchSlots(fallbackSlots, 2, spellID, spellName, false)
    end
    
    if foundSlot then
        return foundSlot, slotInfo.modifiers
    end
    
    return nil, nil
end

local function AbbreviateKeybind(key)
    if not key or key == "" then return "" end

    -- PERFORMANCE: Check cache first (50+ gsub calls is very expensive)
    local cached = abbreviatedKeyCache[key]
    if cached then
        return cached
    end

    local result = key

    -- Check if this is a gamepad combo (modifier + PAD button)
    -- WoW maps gamepad triggers to keyboard modifiers: LT→SHIFT, RT→CTRL
    -- Quick pre-check: skip keys that don't contain "PAD" or only contain it as part of "NUMPAD"
    local hasGamepadButton = false
    local padPos = string_find(key, "PAD")
    if padPos then
        -- Exclude NUMPAD keys: "PAD" at pos 4+ preceded by "NUM" is a numpad key, not gamepad
        local isNumpad = padPos >= 4 and string.sub(key, padPos - 3, padPos - 1) == "NUM"
        if not isNumpad then
            hasGamepadButton = string_find(key, "PAD%d") or string_find(key, "PADD") or
                               string_find(key, "PADLSTICK") or string_find(key, "PADRSTICK") or
                               string_find(key, "PAD[LR]SHOULDER") or string_find(key, "PAD[LR]TRIGGER") or
                               string_find(key, "PADPADDLE") or string_find(key, "PADFORWARD") or
                               string_find(key, "PADBACK") or string_find(key, "PADSYSTEM") or string_find(key, "PADSOCIAL")
        end
    end
    local isGamepadModifierCombo = hasGamepadButton and (string_find(key, "^SHIFT%-") or string_find(key, "^CTRL%-"))
    local iconSize = isGamepadModifierCombo and "10:10" or "14:14"
    
    -- Convert keyboard modifiers to gamepad trigger icons when combined with PAD buttons
    -- LT = SHIFT, RT = CTRL (WoW's internal gamepad→keyboard mapping)
    if isGamepadModifierCombo then
        result = string_gsub(result, "^SHIFT%-", "|A:Gamepad_Gen_LTrigger_64:" .. iconSize .. "|a")
        result = string_gsub(result, "^CTRL%-", "|A:Gamepad_Gen_RTrigger_64:" .. iconSize .. "|a")
    else
        -- Regular keyboard modifiers (no gamepad button involved)
        result = string_gsub(result, "SHIFT%-", "S")
        result = string_gsub(result, "CTRL%-", "C")
    end
    result = string_gsub(result, "ALT%-", "A")

    -- PERFORMANCE: Skip all gamepad button replacements for keyboard-only binds
    -- This avoids ~40 unnecessary string.gsub calls when hasGamepadButton is false
    if hasGamepadButton then
        -- Gamepad modifier buttons as prefixes (native PADLTRIGGER- format, if WoW ever uses it)
        result = string_gsub(result, "PADLSHOULDER%-", "|A:Gamepad_Gen_LShoulder_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADRSHOULDER%-", "|A:Gamepad_Gen_RShoulder_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADLTRIGGER%-", "|A:Gamepad_Gen_LTrigger_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADRTRIGGER%-", "|A:Gamepad_Gen_RTrigger_64:" .. iconSize .. "|a")
        -- Stick directions (must come before stick click abbreviations)
        result = string_gsub(result, "PADLSTICKUP", "|A:Gamepad_Gen_LStickUp_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADLSTICKDOWN", "|A:Gamepad_Gen_LStickDown_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADLSTICKLEFT", "|A:Gamepad_Gen_LStickLeft_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADLSTICKRIGHT", "|A:Gamepad_Gen_LStickRight_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADRSTICKUP", "|A:Gamepad_Gen_RStickUp_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADRSTICKDOWN", "|A:Gamepad_Gen_RStickDown_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADRSTICKLEFT", "|A:Gamepad_Gen_RStickLeft_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADRSTICKRIGHT", "|A:Gamepad_Gen_RStickRight_64:" .. iconSize .. "|a")
        -- Stick clicks
        result = string_gsub(result, "PADLSTICK", "|A:Gamepad_Gen_LStickIn_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADRSTICK", "|A:Gamepad_Gen_RStickIn_64:" .. iconSize .. "|a")
        -- D-pad (must come before arrow key abbreviations - PADDDOWN contains DOWN)
        result = string_gsub(result, "PADDUP", "|A:Gamepad_Gen_Up_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADDDOWN", "|A:Gamepad_Gen_Down_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADDLEFT", "|A:Gamepad_Gen_Left_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADDRIGHT", "|A:Gamepad_Gen_Right_64:" .. iconSize .. "|a")
        -- Shoulders and triggers (standalone, not as modifiers)
        result = string_gsub(result, "PADLSHOULDER", "|A:Gamepad_Gen_LShoulder_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADRSHOULDER", "|A:Gamepad_Gen_RShoulder_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADLTRIGGER", "|A:Gamepad_Gen_LTrigger_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADRTRIGGER", "|A:Gamepad_Gen_RTrigger_64:" .. iconSize .. "|a")
        -- Paddles (must come before face buttons - PADPADDLE1 contains PAD substring)
        result = string_gsub(result, "PADPADDLE1", "|A:Gamepad_Gen_Paddle1_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADPADDLE2", "|A:Gamepad_Gen_Paddle2_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADPADDLE3", "|A:Gamepad_Gen_Paddle3_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADPADDLE4", "|A:Gamepad_Gen_Paddle4_64:" .. iconSize .. "|a")
        -- System buttons (must come before face buttons)
        result = string_gsub(result, "PADFORWARD", "|A:Gamepad_Gen_Forward_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADBACK", "|A:Gamepad_Gen_Back_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADSYSTEM", "|A:Gamepad_Gen_System_64:" .. iconSize .. "|a")
        result = string_gsub(result, "PADSOCIAL", "|A:Gamepad_Gen_Share_64:" .. iconSize .. "|a")
        -- Face buttons (style-dependent: Generic/Xbox/PlayStation)
        local faceSize = isGamepadModifierCombo and "small" or "normal"
        result = string_gsub(result, "PAD1", GetGamepadFaceButton(1, faceSize))
        result = string_gsub(result, "PAD2", GetGamepadFaceButton(2, faceSize))
        result = string_gsub(result, "PAD3", GetGamepadFaceButton(3, faceSize))
        result = string_gsub(result, "PAD4", GetGamepadFaceButton(4, faceSize))
        result = string_gsub(result, "PAD5", GetGamepadFaceButton(5, faceSize))
        result = string_gsub(result, "PAD6", GetGamepadFaceButton(6, faceSize))
    end

    -- Mouse buttons
    result = string_gsub(result, "BUTTON(%d+)", "M%1")
    result = string_gsub(result, "MOUSEWHEELUP", "MwU")
    result = string_gsub(result, "MOUSEWHEELDOWN", "MwD")
    
    -- Numpad special keys (must come before generic NUMPAD replacement)
    result = string_gsub(result, "NUMPADDIVIDE", "N/")
    result = string_gsub(result, "NUMPADMULTIPLY", "N*")
    result = string_gsub(result, "NUMPADMINUS", "N%-")
    result = string_gsub(result, "NUMPADPLUS", "N+")
    result = string_gsub(result, "NUMPADDECIMAL", "N%.")
    result = string_gsub(result, "NUMPADENTER", "NE")
    result = string_gsub(result, "NUMLOCK", "NLk")
    result = string_gsub(result, "NUMPAD", "N")  -- NUMPAD0-9 -> N0-N9

    -- Navigation keys
    result = string_gsub(result, "PAGEUP", "PU")
    result = string_gsub(result, "PAGEDOWN", "PD")
    result = string_gsub(result, "INSERT", "Ins")
    result = string_gsub(result, "DELETE", "Del")
    result = string_gsub(result, "HOME", "Hm")
    result = string_gsub(result, "END", "End")
    
    -- Arrow keys (only abbreviate if they get too long with modifiers)
    result = string_gsub(result, "UP", "Up")
    result = string_gsub(result, "DOWN", "Dn")
    result = string_gsub(result, "LEFT", "Lt")
    result = string_gsub(result, "RIGHT", "Rt")
    
    -- Function/special keys
    result = string_gsub(result, "BACKSPACE", "BS")
    result = string_gsub(result, "CAPSLOCK", "CL")
    result = string_gsub(result, "ESCAPE", "Esc")
    result = string_gsub(result, "PRINTSCREEN", "PS")
    result = string_gsub(result, "SCROLLLOCK", "SL")
    result = string_gsub(result, "PAUSE", "Pa")
    result = string_gsub(result, "SPACE", "Spc")
    result = string_gsub(result, "TAB", "Tab")
    result = string_gsub(result, "ENTER", "Ent")
    
    -- Punctuation/symbol keys (tilde, brackets, etc. - keep short)
    result = string_gsub(result, "BACKQUOTE", "`")  -- ` or ~ key
    result = string_gsub(result, "TILDE", "~")
    result = string_gsub(result, "MINUS", "%-")
    result = string_gsub(result, "EQUALS", "=")
    result = string_gsub(result, "LEFTBRACKET", "%[")
    result = string_gsub(result, "RIGHTBRACKET", "%]")
    result = string_gsub(result, "BACKSLASH", "\\")
    result = string_gsub(result, "SEMICOLON", ";")
    result = string_gsub(result, "QUOTE", "'")
    result = string_gsub(result, "COMMA", ",")
    result = string_gsub(result, "PERIOD", "%.")
    result = string_gsub(result, "SLASH", "/")

    -- PERFORMANCE: Cache the result (50+ gsub calls avoided on subsequent lookups)
    abbreviatedKeyCache[key] = result

    return result
end

local function FormatHotkeyWithModifiers(baseKey, macroModifiers)
    if not baseKey or baseKey == "" then
        return ""
    end

    if not macroModifiers or not macroModifiers.mod then
        return baseKey
    end

    -- Don't prefix modifiers when key already contains gamepad icon markup;
    -- AbbreviateKeybind() already converted SHIFT/CTRL to trigger icons.
    if baseKey:find("|A:") then
        return baseKey
    end

    local modType = macroModifiers.mod
    if modType == "any" or modType == "" then
        return "+" .. baseKey
    elseif modType:match("shift") then
        return "S" .. baseKey
    elseif modType:match("ctrl") then
        return "C" .. baseKey
    elseif modType:match("alt") then
        return "A" .. baseKey
    else
        return "+" .. baseKey
    end
end

function ActionBarScanner.GetSpellHotkey(spellID)
    if not spellID or spellID == 0 then
        return ""
    end

    -- User override takes priority
    local addon = GetCachedAddon()
    if addon and addon.GetHotkeyOverride then
        local override = addon:GetHotkeyOverride(spellID)
        if override and override ~= "" then
            return override
        end
    end

    -- FAST PATH: Valid cache hit - return immediately
    -- Skip fast path for empty results so dynamic transforms (Templar Strike → Slash)
    -- self-correct via the stale-refresh logic below instead of returning "" forever
    if spellHotkeyCacheValid and spellHotkeyCache[spellID] ~= nil and spellHotkeyCache[spellID] ~= "" then
        return spellHotkeyCache[spellID]
    end

    -- PERFORMANCE: If we have a cached value (even stale), return it immediately
    -- and only do expensive lookup if refresh interval has passed
    local previousValue = spellHotkeyCache[spellID]
    local now = GetTime()

    if previousValue ~= nil then
        -- We have a cached value - check if we should refresh
        if (now - lastHotkeyRefreshTime) < HOTKEY_REFRESH_INTERVAL then
            -- Too soon to refresh - return stale value (usually correct anyway)
            return previousValue
        end
        -- Mark this refresh time
        lastHotkeyRefreshTime = now
    end

    local spellInfo = C_Spell.GetSpellInfo(spellID)
    if not spellInfo or not spellInfo.name or spellInfo.name == "" then
        spellHotkeyCache[spellID] = ""
        slotDirectCache[spellID] = false
        return previousValue or ""
    end

    local function CacheHotkey(slot, modifiers, cacheID, extraCacheID)
        local baseKey = GetOptimizedKeybind(slot)
        if not baseKey then return nil end
        local finalHotkey = FormatHotkeyWithModifiers(AbbreviateKeybind(baseKey), modifiers)
        spellHotkeyCache[cacheID] = finalHotkey
        spellSlotCache[cacheID] = slot
        local isDirect = not modifiers or not next(modifiers)
        slotDirectCache[cacheID] = isDirect
        if extraCacheID then
            spellHotkeyCache[extraCacheID] = finalHotkey
            spellSlotCache[extraCacheID] = slot
            slotDirectCache[extraCacheID] = isDirect
        end
        spellHotkeyCacheValid = true
        return finalHotkey
    end

    local foundSlot, macroModifiers = FindSpellInActions(spellID, spellInfo.name)
    if foundSlot then
        local result = CacheHotkey(foundSlot, macroModifiers, spellID)
        if result then return result end
    end

    -- Transform fast path: slot doesn't change, only displayed spell
    if FindBaseSpellByID then
        local baseSpellID = FindBaseSpellByID(spellID)
        if baseSpellID and baseSpellID ~= spellID then
            local cachedSlot = spellSlotCache[baseSpellID]
            if cachedSlot then
                local result = CacheHotkey(cachedSlot, nil, spellID)
                if result then return result end
            end

            local baseSpellInfo = C_Spell.GetSpellInfo(baseSpellID)
            if baseSpellInfo and baseSpellInfo.name then
                local baseFoundSlot, baseMacroModifiers = FindSpellInActions(baseSpellID, baseSpellInfo.name)
                if baseFoundSlot then
                    local result = CacheHotkey(baseFoundSlot, baseMacroModifiers, spellID, baseSpellID)
                    if result then return result end
                end
            end
        end
    end

    -- Forward override scan: check if any cached slot's current override matches
    -- our target. Catches dynamic combat transforms (e.g. Templar Strike → Slash)
    -- where FindBaseSpellByID returns nil (aura-driven, not talent-driven).
    if C_Spell_GetOverrideSpell then
        for cachedID, slot in pairs(spellSlotCache) do
            if cachedID ~= spellID then
                local currentOverride = C_Spell_GetOverrideSpell(cachedID, 0, false)
                if currentOverride and currentOverride == spellID then
                    local result = CacheHotkey(slot, nil, spellID)
                    if result then return result end
                end
            end
        end
    end

    spellHotkeyCache[spellID] = ""
    slotDirectCache[spellID] = false
    spellHotkeyCacheValid = true
    return previousValue or ""
end

function ActionBarScanner.FindSpellInActions(spellID, spellName)
    return FindSpellInActions(spellID, spellName)
end

-- Item hotkey lookup: override → direct bar scan → cast-spell fallback.
-- Uses GetOptimizedKeybind + AbbreviateKeybind for consistent formatting.
function ActionBarScanner.GetItemHotkey(itemID, castSpellID)
    if not itemID or itemID == 0 then return "" end

    -- User override takes priority (stored as negative item ID)
    local addon = GetCachedAddon()
    if addon and addon.GetHotkeyOverride then
        local override = addon:GetHotkeyOverride(-itemID)
        if override and override ~= "" then return override end
    end

    -- Scan action bars for direct item placement
    local slotMapping = GetCachedSlotMapping()
    for slot in pairs(slotMapping) do
        if HasAction(slot) then
            local actionType, actionID = BlizzardAPI.GetActionInfo(slot)
            if actionType == "item" and actionID == itemID then
                itemSlotCache[itemID] = slot
                -- Cross-populate spell caches for unified slot-based lookups.
                if castSpellID and castSpellID > 0 then
                    spellSlotCache[castSpellID] = slot
                    slotDirectCache[castSpellID] = true
                end
                local baseKey = GetOptimizedKeybind(slot)
                if baseKey and baseKey ~= "" then
                    return AbbreviateKeybind(baseKey)
                end
            end
        end
    end

    -- Fall back to cast spell lookup (handles macros with the item's "use" spell)
    if castSpellID and castSpellID > 0 then
        local result = ActionBarScanner.GetSpellHotkey(castSpellID)
        if result and result ~= "" then return result end
    end

    return ""
end

-- Exported helper: apply input preference to a GetBindingKey() call.
function ActionBarScanner.SelectBindingKey(bindingName)
    return SelectBinding(GetBindingKey(bindingName)) or ""
end

function ActionBarScanner.InvalidateKeybindCache()
    InvalidateKeybindCache()
end

-- Soft invalidation: mark invalid but keep values to prevent flicker
function ActionBarScanner.InvalidateHotkeyCache()
    spellHotkeyCacheValid = false
    if next(spellHotkeyCache) then
        local count = 0
        for _ in pairs(spellHotkeyCache) do
            count = count + 1
            if count > 50 then
                wipe(spellHotkeyCache)
                break
            end
        end
    end
end

function ActionBarScanner.RebuildKeybindCache()
    InvalidateKeybindCache()
    ValidateAndBuildKeybindCache()
end

function ActionBarScanner.OnSpecialBarChanged()
    InvalidateStateCache()
end

function ActionBarScanner.OnKeybindsChanged()
    local now = GetTime()

    if isRebuildingBindings then
        return
    end

    if (now - ActionBarScanner.lastKeybindChangeTime) < 0.2 then
        return
    end

    ActionBarScanner.lastKeybindChangeTime = now
    isRebuildingBindings = true
    -- Soft invalidation only: clear the raw binding-key cache so that the eventual
    -- fresh lookup re-reads from WoW, but do NOT wipe spellHotkeyCache yet.
    -- Gamepad bindings are often not committed when UPDATE_BINDINGS first fires;
    -- wiping spellHotkeyCache immediately causes the next render to call GetBindingKey
    -- before PAD keys are registered, returning keyboard text that then gets
    -- fast-path cached as glyphs permanently.  The 0.3s delayed refresh below
    -- does the full hard wipe once bindings have settled.
    bindingCacheValid = false
    wipe(bindingKeyCache)
    isRebuildingBindings = false

    -- Gamepad bindings may not be committed when UPDATE_BINDINGS fires.
    -- Full hard invalidation deferred to here so GetSpellHotkey fast-path
    -- continues returning cached glyphs during the settling window.
    C_Timer.After(0.3, function()
        InvalidateBindingCache()
        InvalidateKeybindCache()
        -- Also invalidate UIRenderer's per-icon caches
        local UIRenderer = LibStub("JustAC-UIRenderer", true)
        if UIRenderer and UIRenderer.InvalidateHotkeyCache then
            UIRenderer.InvalidateHotkeyCache()
        end
    end)
end

function ActionBarScanner.OnUIChanged()
    InvalidateStateCache()
end

--------------------------------------------------------------------------------
-- Event-Driven Proc Tracking (SPELL_ACTIVATION_OVERLAY_GLOW_SHOW/HIDE)
--------------------------------------------------------------------------------

local activeProcs = {}
local activeProcsList = {}
local procListDirty = true
local defensiveProcsListDirty = true

function ActionBarScanner.OnProcShow(spellID)
    if spellID and spellID > 0 and not activeProcs[spellID] then
        activeProcs[spellID] = true
        procListDirty = true
        defensiveProcsListDirty = true

        -- Track override spell too
        local displayID = BlizzardAPI and BlizzardAPI.GetDisplaySpellID and BlizzardAPI.GetDisplaySpellID(spellID)
        if displayID and displayID ~= spellID and displayID > 0 then
            activeProcs[displayID] = true
        end
    end
end

function ActionBarScanner.OnProcHide(spellID)
    if spellID and spellID > 0 then
        local displayID = BlizzardAPI and BlizzardAPI.GetDisplaySpellID and BlizzardAPI.GetDisplaySpellID(spellID)
        
        if activeProcs[spellID] then
            activeProcs[spellID] = nil
            procListDirty = true
            defensiveProcsListDirty = true
        end
        
        if displayID and displayID ~= spellID and activeProcs[displayID] then
            activeProcs[displayID] = nil
            procListDirty = true
            defensiveProcsListDirty = true
        end
    end
end

local function RebuildProcList()
    if not procListDirty then return end
    wipe(activeProcsList)
    for spellID in pairs(activeProcs) do
        activeProcsList[#activeProcsList + 1] = spellID
    end
    procListDirty = false
end

function ActionBarScanner.GetSpellbookProccedSpells()
    RebuildProcList()
    return activeProcsList
end

function ActionBarScanner.IsSpellProcced(spellID)
    if not spellID or spellID == 0 then return false end
    if activeProcs[spellID] then return true end
    -- Proc events may fire with different ID than display ID
    if BlizzardAPI and BlizzardAPI.GetDisplaySpellID then
        local displayID = BlizzardAPI.GetDisplaySpellID(spellID)
        if displayID and displayID ~= spellID and activeProcs[displayID] then
            return true
        end
    end
    return false
end

function ActionBarScanner.HasKeybind(spellID)
    if not spellID then return false end
    local hotkey = ActionBarScanner.GetSpellHotkey(spellID)
    return hotkey and hotkey ~= ""
end

function ActionBarScanner.ClearAllCaches()
    wipe(spellHotkeyCache)
    wipe(spellSlotCache)
    wipe(slotDirectCache)
    wipe(itemSlotCache)
    wipe(abbreviatedKeyCache)
    spellHotkeyCacheValid = false
    if BlizzardAPI and BlizzardAPI.InvalidateSlotUsabilityCache then
        BlizzardAPI.InvalidateSlotUsabilityCache()
    end
end

function ActionBarScanner.GetSlotForSpell(spellID)
    if not spellID then return nil end

    local cachedSlot = spellSlotCache[spellID]
    if cachedSlot then
        return cachedSlot
    end

    -- Trigger hotkey lookup to populate cache
    local _ = ActionBarScanner.GetSpellHotkey(spellID)
    return spellSlotCache[spellID]
end

-- Returns slot only when it directly represents the spell/item (not behind
-- a macro modifier). Safe for C_ActionBar slot-based queries.
function ActionBarScanner.GetDirectSlotForSpell(spellID)
    if not spellID then return nil end

    -- Populate cache if needed
    if slotDirectCache[spellID] == nil then
        ActionBarScanner.GetSpellHotkey(spellID)
    end

    if slotDirectCache[spellID] then
        return spellSlotCache[spellID]
    end
    return nil
end

-- Returns action slot for an item placed directly on the bar.
function ActionBarScanner.GetDirectSlotForItem(itemID)
    if not itemID then return nil end

    local cached = itemSlotCache[itemID]
    if cached ~= nil then
        return cached or nil
    end

    -- Trigger scan via GetItemHotkey to populate cache
    ActionBarScanner.GetItemHotkey(itemID)
    local result = itemSlotCache[itemID]
    if not result then
        itemSlotCache[itemID] = false
    end
    return result
end

-- Returns action bar cooldown (Blizzard's ground truth for GCD vs spell CD)
function ActionBarScanner.GetActionBarCooldown(spellID)
    if not spellID then return nil, nil end

    local slot = ActionBarScanner.GetSlotForSpell(spellID)
    if not slot then return nil, nil end

    if GetActionCooldown then
        return GetActionCooldown(slot)
    end

    return nil, nil
end

--------------------------------------------------------------------------------
-- Defensive Proc Tracking (HELPFUL/SURVIVAL spells only)
--------------------------------------------------------------------------------

local defensiveProcsList = {}

-- Validates procs via API to catch stale event cache
local function RebuildDefensiveProcList()
    if not defensiveProcsListDirty then return end

    wipe(defensiveProcsList)
    local toRemove = {}

    for spellID in pairs(activeProcs) do
        local stillProcced = BlizzardAPI.IsSpellProcced and BlizzardAPI.IsSpellProcced(spellID)

        if not stillProcced then
            toRemove[#toRemove + 1] = spellID
        else
            local actualID = BlizzardAPI.GetDisplaySpellID(spellID)
            if BlizzardAPI.IsDefensiveSpell(actualID) or BlizzardAPI.IsDefensiveSpell(spellID) then
                defensiveProcsList[#defensiveProcsList + 1] = actualID
            end
        end
    end

    for _, staleID in ipairs(toRemove) do
        activeProcs[staleID] = nil
        procListDirty = true
    end

    defensiveProcsListDirty = false
end

-- Force revalidation: stale procs cause visible glow color issues
function ActionBarScanner.GetDefensiveProccedSpells()
    defensiveProcsListDirty = true
    RebuildDefensiveProcList()
    return defensiveProcsList
end

--------------------------------------------------------------------------------
-- Assisted Combat Slot Lookup
--------------------------------------------------------------------------------

local cachedAssistedSlot = nil
local assistedSlotDirty = true

--- Invalidate the cached assisted combat slot.
--- Called on ACTIONBAR_SLOT_CHANGED / bar page changes.
function ActionBarScanner.InvalidateAssistedSlot()
    assistedSlotDirty = true
end

--- Returns the first action bar slot containing the Assisted Combat button,
--- or nil if the player hasn't placed it on any bar.
function ActionBarScanner.GetAssistedCombatSlot()
    if not assistedSlotDirty then return cachedAssistedSlot end
    assistedSlotDirty = false
    cachedAssistedSlot = nil
    if not C_ActionBar or not C_ActionBar.FindAssistedCombatActionButtons then return nil end
    local slots = C_ActionBar.FindAssistedCombatActionButtons()
    if slots and slots[1] then
        cachedAssistedSlot = slots[1]
    end
    return cachedAssistedSlot
end
