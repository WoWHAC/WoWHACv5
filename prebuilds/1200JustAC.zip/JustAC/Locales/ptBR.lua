-- SPDX-License-Identifier: GPL-3.0-or-later
-- Copyright (C) 2024-2025 wealdly
-- JustAC: Portuguese - Brazil (ptBR) - ~8-10% of player base

local L = LibStub("AceLocale-3.0"):NewLocale("JustAssistedCombat", "ptBR")
if not L then return end

-- General UI
L["JustAssistedCombat"] = "JustAssistedCombat"
L["General"] = "Geral"
L["Settings"] = "Configurações"
L["Offensive"] = "Ofensivos"
L["Defensives"] = "Defensivos"
L["Blacklist"] = "Lista negra"
L["Hotkey Overrides"] = "Atalhos"
L["Add"] = "Adicionar"
L["Clear All"] = "Limpar tudo"
L["Clear All Blacklist desc"] = "Remover todas as magias da lista negra"
L["Clear All Hotkeys desc"] = "Remover todos os atalhos personalizados"

-- General Options
L["Max Icons"] = "Ícones máx"
L["Icon Size"] = "Tamanho do ícone"
L["Spacing"] = "Espaçamento"
L["Primary Spell Scale"] = "Escala da magia principal"
L["Queue Orientation"] = "Layout da fila"
L["Gamepad Icon Style"] = "Estilo de ícone do controle"
L["Gamepad Icon Style desc"] = "Escolher o estilo de ícones dos botões para controles/gamepads."
L["Input Preference"] = "Preferência de entrada"
L["Input Preference desc"] = "Escolher qual tipo de atalho exibir. Auto-Detectar mostra atalhos de controle quando conectado, ou atalhos de teclado caso contrário."
L["Auto-Detect"] = "Auto-Detectar"
L["Keyboard"] = "Teclado"
L["Gamepad"] = "Controle"
L["Generic"] = "Genérico (1/2/3/4)"
L["Xbox"] = "Xbox (A/B/X/Y)"
L["PlayStation"] = "PlayStation (Cruz/Círculo/Quadrado/Triângulo)"
L["Insert Procced Defensives"] = "Inserir defensivos ativados"
L["Insert Procced Defensives desc"] = "Mostrar habilidades defensivas ativadas (Investida Vitoriosa, curas gratuitas) em qualquer nível de vida."
L["Frame Opacity"] = "Opacidade do quadro"
L["Queue Icon Fade"] = "Esmaecimento do ícone da fila"
L["Insert Procced Abilities"] = "Mostrar todas as habilidades ativadas"
L["Include All Available Abilities"] = "Incluir habilidades ocultas"
L["Highlight Mode"] = "Modo de destaque"
L["All Glows"] = "Todos os brilhos"
L["Primary Only"] = "Apenas principal"
L["Proc Only"] = "Apenas proc"
L["No Glows"] = "Sem brilhos"
L["Show Key Press Flash"] = "Flash de tecla"
L["Show Key Press Flash desc"] = "Piscar o ícone ao pressionar o atalho correspondente."
L["Grey Out While Casting"] = "Esmaecer ao conjurar"
L["Grey Out While Casting desc"] = "Dessaturar os ícones da fila enquanto conjura. A magia sendo conjurada mantém a cor."
L["Grey Out While Channeling"] = "Esmaecer ao canalizar"
L["Grey Out While Channeling desc"] = "Dessaturar os ícones da fila enquanto canaliza. A magia canalizada mantém a cor com uma animação de preenchimento."

-- Blacklist
L["Remove"] = "Remover"
L["No spells currently blacklisted"] = "Nenhuma magia na lista negra. Shift+Clique direito em uma magia na fila para adicionar."
L["Blacklisted Spells"] = "Magias na lista negra"
L["Add Spell to Blacklist"] = "Adicionar magia à lista negra"

-- Hotkey Overrides
L["Custom Hotkey"] = "Atalho personalizado"
L["No custom hotkeys set"] = "Nenhum atalho personalizado definido. Clique direito em uma magia para definir um atalho."
L["Add Hotkey Override"] = "Adicionar atalho personalizado"
L["Hotkey"] = "Atalho"
L["Enter the hotkey text to display (e.g. 1, F1, S-2)"] = "Inserir o texto do atalho a exibir (ex: 1, F1, S-2, Ctrl+Q)"
L["Custom Hotkeys"] = "Atalhos personalizados"

-- Defensives
L["Show Defensive Icons"] = "Mostrar ícones defensivos"
L["Add to %s"] = "Adicionar a %s"

-- Orientation values
L["Up"] = "Cima"
L["Dn"] = "Baixo"

-- Descriptions
L["General description"] = "Configurações compartilhadas entre a fila padrão e a sobreposição."
L["Shared Behavior"] = "Comportamento compartilhado"
L["Icon Layout"] = "Layout dos ícones"
L["Visibility"] = "Visibilidade"
L["Appearance"] = "Aparência"
L["Offensive Display"] = "Exibição ofensiva"
L["Defensive Display"] = "Exibição defensiva"

-- Tooltip mode dropdown
L["Tooltips"] = "Dicas"
L["Tooltips desc"] = "Quando mostrar dicas de magias ao passar o cursor"
L["Never"] = "Nunca"
L["Out of Combat Only"] = "Apenas fora de combate"
L["Always"] = "Sempre"

-- Defensive display mode dropdown
L["Defensive Display Mode"] = "Visibilidade defensiva"
L["Defensive Display Mode desc"] = "Vida baixa: Mostrar apenas quando a vida cai abaixo dos limites\nApenas em combate: Sempre mostrar em combate\nSempre: Mostrar o tempo todo"
L["When Health Low"] = "Vida baixa"
L["In Combat Only"] = "Apenas em combate"

-- Detailed descriptions
L["Max Icons desc"] = "Ícones máximos a exibir (1 = principal, 2+ = fila)"
L["Icon Size desc"] = "Tamanho base dos ícones em pixels"
L["Spacing desc"] = "Espaço entre ícones em pixels"
L["Primary Spell Scale desc"] = "Escala para ícones principais e defensivos"
L["Queue Orientation desc"] = "Direção da fila e posição da barra lateral (defensivos + barra de vida)"
L["Highlight Mode desc"] = "Quais efeitos de brilho mostrar nos ícones"
L["Frame Opacity desc"] = "Transparência global do quadro"
L["Queue Icon Fade desc"] = "Dessaturação de ícones na fila (0 = cor, 1 = escala de cinza)"
L["Hide When Mounted"] = "Ocultar em montaria"
L["Hide When Mounted desc"] = "Ocultar enquanto em montaria"
L["Require Hostile Target"] = "Requer alvo hostil"
L["Allow Item Abilities"] = "Permitir habilidades de itens"
L["Allow Item Abilities desc"] = "Mostrar habilidades de berloques e itens usáveis na fila ofensiva"
L["Insert Procced Abilities desc"] = "Adicionar habilidades com proc brilhante à fila"
L["Include All Available Abilities desc"] = "Incluir habilidades ocultas de macros nas recomendações"
L["Panel Interaction"] = "Interação do painel"
L["Panel Interaction desc"] = "Como o painel responde à entrada do mouse.\n\nTransparente oculta a aba e deixa todos os cliques passarem para o jogo. Segure Alt e arraste qualquer ícone para reposicionar."
L["Unlocked"] = "Desbloqueado"
L["Locked"] = "Bloqueado"
L["Click Through"] = "Clique transparente"
L["Enable Defensive Suggestions desc"] = "Mostrar defensivos quando a vida está baixa"
L["Custom Hotkey desc"] = "Texto personalizado (ex: F1, Ctrl+Q)"
L["Move up desc"] = "Subir prioridade"
L["Move down desc"] = "Descer prioridade"
L["Restore Defensive Defaults desc"] = "Redefinir a lista defensiva para os padrões da classe"

-- Additional sections
L["Defensive Priority List"] = "Lista de prioridade defensiva"
L["Defensive Priority desc"] = "Ordem de prioridade unificada — autocuras e recargas em uma lista. Reordene para definir a prioridade."
L["Restore Class Defaults"] = "Restaurar padrões da classe"

-- Defensive thresholds

-- Defensive display options
L["Show Health Bars"] = "Mostrar barras de vida"
L["Show Health Bars desc"] = "Barras de vida compactas do jogador e pet junto à fila"
L["Defensive Icon Scale"] = "Escala do ícone defensivo"
L["Defensive Icon Scale desc"] = "Escala de ícones defensivos"
L["Defensive Max Icons"] = "Ícones máximos"
L["Defensive Max Icons desc"] = "Ícones defensivos a mostrar"
L["Profiles"] = "Perfis"
L["Profiles desc"] = "Gerenciamento de perfis"
-- Per-spec profile switching
L["Spec-Based Switching"] = "Troca por especialização"
L["Auto-switch profile by spec"] = "Trocar perfil automaticamente por especialização"
L["(No change)"] = "(Sem mudança)"
L["(Disabled)"] = "(Desativado)"
-- New character default profile
L["New Character Defaults"] = "Padrões para novos personagens"
L["Use Default profile for new characters"] = "Usar perfil padrão para novos personagens"
L["Use Default profile for new characters desc"] = "Quando ativado, novos personagens começam no perfil padrão compartilhado em vez de receber o próprio. Afeta apenas personagens que nunca carregaram o JustAC antes."
-- Compound layout labels (queue direction + sidebar placement)
L["Left, Sidebar Above"] = "Esquerda, barra lateral acima"
L["Left, Sidebar Below"] = "Esquerda, barra lateral abaixo"
L["Right, Sidebar Above"] = "Direita, barra lateral acima"
L["Right, Sidebar Below"] = "Direita, barra lateral abaixo"
L["Up, Sidebar Left"] = "Cima, barra lateral esquerda"
L["Up, Sidebar Right"] = "Cima, barra lateral direita"
L["Down, Sidebar Left"] = "Baixo, barra lateral esquerda"
L["Down, Sidebar Right"] = "Baixo, barra lateral direita"

-- Target frame anchor
L["Target Frame Anchor"] = "Ancoragem ao quadro de alvo"
L["Target Frame Anchor desc"] = "Ancorar a fila no quadro de alvo padrão em vez de uma posição fixa na tela"
L["Target Frame Replaced"] = "Quadro de alvo padrão não detectado (substituído por outro addon)"
L["Disabled"] = "Desativado"
L["Top"] = "Cima"
L["Bottom"] = "Baixo"
L["Left"] = "Esquerda"
L["Right"] = "Direita"

-- Additional UI strings
L["Hotkey Overrides Info"] = "Atalhos personalizados para magias.\n|cff00ff00Clique direito|r para definir."
L["Blacklist Info"] = "Ocultar magias da fila.\n|cffff6666Shift+Clique direito|r para alternar."
L["Restore Class Defaults name"] = "Restaurar padrões da classe"

-- Spell search UI
L["Search spell name or ID"] = "Buscar nome ou ID de magia"
L["Search spell desc"] = "Digitar nome ou ID de magia (2+ caracteres para buscar)"
L["Select spell to add"] = "Selecionar uma magia dos resultados para adicionar"
L["Select spell to blacklist"] = "Selecionar uma magia dos resultados para a lista negra"
L["Add spell manual desc"] = "Adicionar magia por ID ou nome exato"
L["Add spell dropdown desc"] = "Adicionar magia por ID ou nome exato (para magias fora da lista)"
L["Select spell for hotkey"] = "Selecionar uma magia ou item dos resultados"
L["Add hotkey desc"] = "Adicionar atalho personalizado para a magia ou item selecionado"
L["No matches"] = "Sem resultados - tente outra busca"
L["Please search and select a spell first"] = "Primeiro busque e selecione uma magia ou item"
L["Please enter a hotkey value"] = "Insira um valor de atalho"
L["Select Spell..."] = "Selecionar magia/item..."
L["No spell selected"] = "Nenhuma magia ou item selecionado"
L["Set Override..."] = "Definir substituição..."

-- Display Mode (Standard Queue / Nameplate Overlay / Both / Disabled)
L["Display Mode"] = "Modo de exibição"
L["Display Mode desc"] = "Fila padrão mostra o painel principal, Overlay de placa anexa ícones à placa de nome, Ambos ativa todos os modos, Desativado oculta tudo."
L["Standard Queue"] = "Fila padrão"
L["Both"] = "Ambos"
L["Queue Visibility"] = "Visibilidade da fila"
L["Queue Visibility desc"] = "Sempre: exibir a qualquer momento.\nApenas em combate: ocultar fora de combate.\nRequer alvo hostil: exibir apenas ao mirar em um inimigo atacável."


-- Pet Rez/Summon and Pet Heal lists (pet classes only)
L["Pet Rez/Summon Priority List"] = "Ressurreição/Invocação de pet (prioridade)"
L["Pet Rez/Summon Priority desc"] = "Exibido quando o pet está morto ou ausente. Alta prioridade — confiável em combate."
L["Restore Pet Rez Defaults desc"] = "Redefinir magias de ressurreição de pet para os padrões da classe"
L["Pet Heal Priority List"] = "Cura de pet (prioridade)"
L["Pet Heal Priority desc"] = "Exibido quando a vida do pet está baixa. A vida do pet pode estar oculta em combate."
L["Restore Pet Heal Defaults desc"] = "Redefinir magias de cura de pet para os padrões da classe"
L["Show Pet Health Bar"] = "Mostrar barra de vida do pet"
L["Show Pet Health Bar desc"] = "Barra de vida compacta do pet (apenas classes com pet). Oculta-se sem pet ativo."

-- Item settings (per-item aura link / combat hide)
L["Link Aura..."] = "Vincular aura..."
L["Link Aura desc"] = "Vincule uma aura de buff (comida, frasco, poção, etc.) a este item. O item é ocultado enquanto o buff estiver ativo."
L["Hide in Combat"] = "Ocultar em combate"
L["Hide in Combat desc"] = "Ocultar este item da fila durante o combate. Recomendado para buffs de longa duração (comida, frascos) pois suas auras não podem ser detectadas em combate."
L["Linked: %s"] = "Vinculado: %s"
L["Clear Link"] = "Limpar"
L["Clear Link desc"] = "Remover a aura vinculada"
L["Search auras desc"] = "Mostra os buffs ativos do jogador. Digite para filtrar ou insira um ID de feitiço diretamente."

-- Nameplate Overlay (16 keys)
L["Nameplate Overlay"] = "Overlay"
L["Offensive Queue"] = "Fila ofensiva"
L["Defensive Queue"] = "Fila defensiva"
L["Reverse Anchor"] = "Inverter âncora"
L["Reverse Anchor desc"] = "Por padrão os ícones DPS aparecem à direita da placa. Ative para colocá-los à esquerda. Os ícones defensivos sempre aparecem no lado oposto."
L["Nameplate Show Defensives desc"] = "Mostrar ícones defensivos no lado oposto da placa."
L["Interrupt Mode"] = "Lembrete de interrupção"
L["Interrupt Mode desc"] = "Controla quando o ícone de lembrete de interrupção aparece e qual habilidade sugerir."
L["Sounds"] = "Sons"
L["Interrupt Alert"] = "Alerta de interrupção"
L["Interrupt Alert Sound desc"] = "Tocar um som quando o ícone de interrupção aparece pela primeira vez."
L["Interrupt Mode Disabled"] = "Desativado"
L["Interrupt Mode Kick Only"] = "Apenas Kick — Só interrupções, sem CC"
L["Interrupt Mode Kick Prefer"] = "Prioridade Kick — Kick primeiro, CC como reserva"
L["Interrupt Mode CC Prefer"] = "Prioridade CC — CC sobre kicks (gasta CC em conjurações kickáveis)"
L["Nameplate Show Health Bars desc"] = "Barras de vida compactas acima dos ícones defensivos. Oculta-se automaticamente sem defensivos visíveis."

-- Reset buttons (5 keys)
L["Reset to Defaults"] = "Redefinir padrões"
L["Reset General desc"] = "Redefinir todos os ajustes gerais para os valores padrão."
L["Reset Layout desc"] = "Redefinir ajustes de layout para os padrões."
L["Reset Offensive Display desc"] = "Redefinir ajustes de exibição ofensiva para os padrões."
L["Reset Defensive Display desc"] = "Redefinir ajustes de exibição defensiva para os padrões."

-- Icon Labels (21 keys)
L["Icon Labels"] = "Rótulos dos ícones"
L["Hotkey Text"] = "Texto de atalho"
L["Cooldown Text"] = "Contagem regressiva"
L["Charge Count"] = "Contagem (Cargas / Qtd.)"
L["Show"] = "Mostrar"
L["Font Scale"] = "Escala de fonte"
L["Font Scale desc"] = "Multiplicador aplicado ao tamanho de fonte base (1.0 = tamanho padrão)."
L["Text Color"] = "Cor"
L["Text Color desc"] = "Cor e opacidade deste elemento de texto."
L["Text Anchor"] = "Posição"
L["Hotkey Anchor desc"] = "Onde no ícone o rótulo de atalho aparece."
L["Charge Anchor desc"] = "Onde no ícone a quantidade de cargas ou de itens aparece."
L["Top Right"] = "Superior direito"
L["Top Left"] = "Superior esquerdo"
L["Top Center"] = "Superior centro"
L["Center"] = "Centro"
L["Bottom Right"] = "Inferior direito"
L["Bottom Left"] = "Inferior esquerdo"
L["Bottom Center"] = "Inferior centro"
L["Reset Icon Labels desc"] = "Redefinir todas as configurações de rótulos de ícone para os valores padrão."

-- Expansion Direction / positioning (5 keys)
L["Expansion Direction"] = "Direção de expansão"
L["Expansion Direction desc"] = "Direção de empilhamento dos ícones. Horizontal se expande a partir da placa."
L["Horizontal (Out)"] = "Horizontal (para fora)"
L["Vertical - Up"] = "Vertical - Cima"
L["Vertical - Down"] = "Vertical - Baixo"

-- Gap-Closers
L["Gap-Closers"] = "Aproximação"
L["Enable Gap-Closer Suggestions"] = "Ativar sugestões de aproximação"
L["Enable Gap-Closer Suggestions desc"] = "Sugere habilidades de aproximação quando o alvo está fora do alcance corpo a corpo. Mostrado na posição 2, antes dos procs."
L["Gap-Closer Priority List"] = "Lista de prioridade de aproximação"
L["Gap-Closer Priority desc"] = "O primeiro feitiço utilizável é mostrado. Reordenar para definir prioridade."
L["Restore Gap-Closer Defaults desc"] = "Redefinir a lista de aproximação para os feitiços padrão da classe e especialização"
L["No Gap-Closer Spells"] = "Nenhum feitiço de aproximação configurado. Adicione um abaixo ou clique em Restaurar padrões da classe."
L["Reset Gap-Closers desc"] = "Redefinir configurações de aproximação. A lista de magias não é afetada."
L["Show Gap-Closer Glow"] = "Brilho de aproximação"
L["Show Gap-Closer Glow desc"] = "Exibe um brilho dourado nos ícones de aproximação para destacar que estão disponíveis."
L["Gap-Closer Behavior Note"] = "Habilidades de aproximação substituem a posição 1 quando o alvo está fora de alcance."
L["Gap-Closer Ranged Spec Note"] = "Sem habilidades de aproximação padrão para esta especialização. Você pode adicionar magias manualmente abaixo se necessário."
L["Melee Range Reference"] = "Referência de alcance corpo a corpo"
L["Melee Range Spell desc"] = "Habilidades de aproximação são ativadas quando esta habilidade está fora de alcance. Deve estar na sua barra de ação."
L["Melee Range Spell Override desc"] = "Substituição do ID de magia (vazio = automático)"
L["Default"] = "Padrão"
L["Override"] = "Personalizar"
L["Clear Override"] = "Limpar personalização"
L["Search Spell"] = "Buscar magia"
L["Unknown"] = "Desconhecido"
L["None"] = "Nenhum"

-- Blacklist Position 1
L["Blacklist Position 1"] = "Aplicar à posição 1"
L["Blacklist Position 1 desc"] = "Aplicar a lista negra também à posição 1 (sugestão principal da Blizzard). Aviso: ocultar a magia principal pode travar a rotação — o sistema da Blizzard espera que ela seja lançada."

-- Performance
L["Performance"] = "Desempenho"
L["Disable Blizzard Highlight"] = "Desativar destaque da barra de ação da Blizzard"
L["Disable Blizzard Highlight desc"] = "Desativar o brilho da Blizzard na barra de ação (redundante com JustAC). Melhora o desempenho e previne erros de 'limite de tempo de execução' sob carga pesada de addons."

