local RH        = RotationHelper
RH.EventBus     = {}
local EventBus  = RH.EventBus

-- One hidden frame handles all WoW frame event registrations.
local frame     = CreateFrame("Frame", "RotationHelperEventFrame")
-- listeners[event][owner] = callback
local listeners = {}

-- Register `callback` for a WoW frame event.
-- `owner` is an arbitrary key used to identify and remove the listener later.
-- Callbacks are called as: callback(event, ...)
function EventBus:On(event, callback, owner)
    if not listeners[event] then
        listeners[event] = {}
        frame:RegisterEvent(event)
    end
    listeners[event][owner] = callback
end

-- Unregister all callbacks registered under `owner`.
function EventBus:Off(owner)
    for _, owners in pairs(listeners) do
        owners[owner] = nil
    end
end

frame:SetScript("OnEvent", function(_, event, ...)
    if not listeners[event] then return end
    local args = { ... }
    for _, cb in pairs(listeners[event]) do
        cb(event, unpack(args))
    end
end)
