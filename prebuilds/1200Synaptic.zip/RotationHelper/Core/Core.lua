local ADDON_NAME = "RotationHelper"
local RH         = RotationHelper

RH.VERSION  = "0.2.7"
RH.modules  = {}

-- Modules init in this explicit order so SpellSuggestion always runs first
-- (GCDIndicator parents to the icon frame SpellSuggestion creates).
-- PriorityItems has no UI and is queried at runtime, so order is flexible.
local MODULE_ORDER = { "PriorityItems", "SpellSuggestion", "GCDIndicator", "TrinketCooldowns", "OptionsPanel", "ManualRotation" }

-- Account-wide settings — shared across all characters
local GLOBAL_DEFAULTS = {
    position        = { x = 0, y = -150 },
    scale           = 1.0,
    locked          = false,
    visible         = true,
    showTrinkets    = true,
    showGCD         = true,
    showSpellGlow   = true,
    showBg          = true,
    hideOutOfCombat = false,
    bgOpacity       = 0.95,
    bgColor         = { r = 0.04, g = 0.04, b = 0.07 },
    hotkeyOpacity   = 0.6,
    hotkeySize      = 16,
    hotkeyOffsetX   = 0,
    hotkeyOffsetY   = 0,
    soundAlert      = false,
    soundVolume     = 0.7,
    soundKey        = "RAID_WARNING",  -- SOUNDKIT key string for the selected alert sound
    showControls    = true,
    showSpellName   = true,
    minimapAngle    = 215,   -- degrees; 0=right, 90=top, 180=left, 270=bottom
}

-- Per-character settings — class/spec/rotation data
local CHAR_DEFAULTS = {
    trinket1Priority    = true,   -- slot 13 (first trinket)
    trinket2Priority    = true,   -- slot 14 (second trinket)
    potionPriority      = false,
    spellPriority       = false,
    prioritySpells      = {},
    priorityPotions     = {},
    manualMode            = false,
    activeManualProfile   = nil,
    manualProfiles        = {},
    ignoreBarValidation   = false,
    specs               = {},
}

-- ── Module registry ────────────────────────────────────────────────────────

function RH:RegisterModule(name, module)
    self.modules[name] = module
end

-- ── SavedVariables ─────────────────────────────────────────────────────────

function RH:InitDB()
    RotationHelperGlobalDB = RH.Utils.DeepMerge(GLOBAL_DEFAULTS, RotationHelperGlobalDB)
    RotationHelperDB       = RH.Utils.DeepMerge(CHAR_DEFAULTS,   RotationHelperDB)
    self.gdb = RotationHelperGlobalDB  -- account-wide display/general settings
    self.db  = RotationHelperDB        -- per-character class/spec/rotation settings
end

-- ── Main frame ─────────────────────────────────────────────────────────────

function RH:CreateMainFrame()
    local f = CreateFrame("Frame", "RotationHelperFrame", UIParent, "BackdropTemplate")
    f:SetSize(240, 108)
    f:SetFrameStrata("MEDIUM")
    f:SetClampedToScreen(true)
    f:SetScale(self.gdb.scale)
    f:SetPoint("CENTER", UIParent, "CENTER", self.gdb.position.x, self.gdb.position.y)

    -- Solid dark background with a thin 1 px border
    f:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = false, tileSize = 0, edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    local c = self.gdb.bgColor
    if self.gdb.showBg then
        f:SetBackdropColor(c.r, c.g, c.b, self.gdb.bgOpacity)
        f:SetBackdropBorderColor(0.20, 0.20, 0.26, 0.9)
    else
        f:SetBackdropColor(0, 0, 0, 0)
        f:SetBackdropBorderColor(0, 0, 0, 0)
        -- title and divider are hidden after CreateMainFrame assigns the refs
    end

    -- Title
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    title:SetPoint("TOP", f, "TOP", 0, -6)
    title:SetText("Synaptic - Rotation Assistant")
    title:SetTextColor(0.85, 0.75, 0.40)
    self.titleText = title

    -- Thin divider below title
    local div = f:CreateTexture(nil, "ARTWORK")
    div:SetHeight(1)
    div:SetPoint("TOPLEFT",  f, "TOPLEFT",  8, -18)
    div:SetPoint("TOPRIGHT", f, "TOPRIGHT", -8, -18)
    div:SetColorTexture(0.20, 0.20, 0.26, 0.8)
    self.titleDiv = div

    -- Main frame is click-through — only the header drag strip captures mouse.
    f:SetMovable(true)
    f:EnableMouse(false)

    -- Header drag strip: covers the title bar (top 20 px). Everything below is click-through.
    local dragHandle = CreateFrame("Frame", nil, f)
    dragHandle:SetPoint("TOPLEFT",  f, "TOPLEFT",  0, 0)
    dragHandle:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
    dragHandle:SetHeight(20)
    dragHandle:SetFrameLevel(f:GetFrameLevel() + 1)
    dragHandle:EnableMouse(true)
    dragHandle:RegisterForDrag("LeftButton")
    dragHandle:SetScript("OnDragStart", function()
        if not RH.gdb.locked then f:StartMoving() end
    end)
    dragHandle:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        local _, _, _, x, y = f:GetPoint()
        RH.gdb.position.x = x
        RH.gdb.position.y = y
    end)
    self.dragHandle = dragHandle

    if not self.gdb.showBg then
        title:Hide()
        div:Hide()
    end

    if not self.gdb.visible then f:Hide() end
    self.frame = f
end

function RH:Toggle()
    if self.frame:IsShown() then
        self.frame:Hide()
        self.gdb.visible = false
    else
        self.frame:Show()
        self.gdb.visible = true
    end
end

-- ── Per-spec profiles ──────────────────────────────────────────────────────
-- prioritySpells, trinket1Priority, trinket2Priority, potionPriority, spellPriority are per-spec.
-- All display/sound/position settings remain global.
--
-- Design: flat db fields are the "live" values.  On spec switch we flush the
-- leaving spec's booleans back into its profile slot, then swap in the new
-- spec's data.  prioritySpells is shared by reference so table mutations
-- (insert/remove) automatically persist into the profile without extra work.

local activeSpecID = nil   -- spec loaded at last profile swap

function RH:GetSpecID()
    local idx = GetSpecialization()
    if not idx then return nil end
    local id = GetSpecializationInfo(idx)
    return id
end

function RH:LoadSpecProfile()
    local specID = self:GetSpecID()
    if not specID then return end

    -- Flush leaving spec's boolean fields back into its profile
    if activeSpecID and self.db.specs and self.db.specs[activeSpecID] then
        local prev = self.db.specs[activeSpecID]
        prev.trinket1Priority = self.db.trinket1Priority
        prev.trinket2Priority = self.db.trinket2Priority
        prev.potionPriority   = self.db.potionPriority
        prev.spellPriority    = self.db.spellPriority
    end

    activeSpecID = specID

    if not self.db.specs then self.db.specs = {} end

    if not self.db.specs[specID] then
        -- First time seeing this spec: seed from current live data so nothing is lost
        self.db.specs[specID] = {
            prioritySpells   = self.db.prioritySpells  or {},
            priorityPotions  = self.db.priorityPotions or {},
            trinket1Priority = self.db.trinket1Priority,
            trinket2Priority = self.db.trinket2Priority,
            potionPriority   = self.db.potionPriority,
            spellPriority    = self.db.spellPriority,
        }
    end

    local p = self.db.specs[specID]
    -- Back-fill fields that may be absent in profiles saved before they were added
    if not p.priorityPotions  then p.priorityPotions  = {} end
    -- Migrate old single trinketPriority flag to per-slot flags
    if p.trinket1Priority == nil then
        p.trinket1Priority = (p.trinketPriority ~= nil) and p.trinketPriority or true
    end
    if p.trinket2Priority == nil then
        p.trinket2Priority = (p.trinketPriority ~= nil) and p.trinketPriority or true
    end
    self.db.prioritySpells   = p.prioritySpells   -- shared ref; mutations persist automatically
    self.db.priorityPotions  = p.priorityPotions  -- shared ref; mutations persist automatically
    self.db.trinket1Priority = p.trinket1Priority
    self.db.trinket2Priority = p.trinket2Priority
    self.db.potionPriority   = p.potionPriority
    self.db.spellPriority    = p.spellPriority
end

-- ── Module lifecycle ───────────────────────────────────────────────────────

function RH:InitModules()
    for _, name in ipairs(MODULE_ORDER) do
        local mod = self.modules[name]
        if mod and mod.Init then
            local ok, err = pcall(function() mod:Init() end)
            if not ok then
                print("|cffff4444[Synaptic]|r Module '" .. name .. "' error: " .. tostring(err))
            end
        end
    end
end

-- ── Events ─────────────────────────────────────────────────────────────────

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")

eventFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        RH:InitDB()
        RH:CreateMainFrame()
        print(string.format(RotationHelperL.ADDON_LOADED, RH.VERSION))
    elseif event == "PLAYER_LOGIN" then
        -- Register spec-switch handler BEFORE InitModules so it fires first,
        -- ensuring the new spec's data is live before any module refreshes.
        RH.EventBus:On("PLAYER_SPECIALIZATION_CHANGED", function()
            RH:LoadSpecProfile()
            local pi = RH.modules.PriorityItems
            if pi then pi:RefreshData() end
            local ss = RH.modules.SpellSuggestion
            if ss then ss:UpdateSpell() end
            local tc = RH.modules.TrinketCooldowns
            if tc then tc:Refresh() end
            local op = RH.modules.OptionsPanel
            if op then op:OnSpecChanged() end
        end, "RHCore")

        RH:InitModules()
        RH:LoadSpecProfile()
    end
end)

-- ── Slash commands ─────────────────────────────────────────────────────────

SLASH_ROTATIONHELPER1 = "/sy"
SLASH_ROTATIONHELPER2 = "/synaptic"

SlashCmdList["ROTATIONHELPER"] = function(msg)
    local L   = RotationHelperL
    local cmd, arg = strsplit(" ", (msg or ""):lower():trim(), 2)

    if cmd == "" or cmd == "help" then
        print(L.CMD_HELP)

    elseif cmd == "toggle" then
        RH:Toggle()

    elseif cmd == "lock" then
        RH.gdb.locked = not RH.gdb.locked
        print(RH.gdb.locked and L.CMD_LOCK or L.CMD_UNLOCK)
        local op = RH.modules.OptionsPanel
        if op and op.lockIcon then
            local tex = RH.gdb.locked and "Interface\\Buttons\\LockButton-Locked-Up"
                                       or "Interface\\Buttons\\LockButton-Unlocked-Up"
            op.lockIcon:SetTexture(tex)
        end
        if RH.dragHandle then RH.dragHandle:EnableMouse(not RH.gdb.locked) end

    elseif cmd == "reset" then
        RH.frame:ClearAllPoints()
        RH.frame:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
        RH.gdb.position = { x = 0, y = -150 }
        print(L.CMD_RESET)

    elseif cmd == "scale" then
        local s = tonumber(arg)
        if s and s >= 0.5 and s <= 2.0 then
            RH.gdb.scale = s
            RH.frame:SetScale(s)
            print(string.format(L.CMD_SCALE, s))
        else
            print(L.CMD_SCALE_INVALID)
        end

    elseif cmd == "trinkets" then
        RH.gdb.showTrinkets = not RH.gdb.showTrinkets
        local mod = RH.modules.TrinketCooldowns
        if mod then mod:SetVisible(RH.gdb.showTrinkets) end
        print(RH.gdb.showTrinkets and L.CMD_TRINKETS_ON or L.CMD_TRINKETS_OFF)

    elseif cmd == "trinketpriority" then
        -- Toggle both trinket slots together (off if either is on, on if both are off)
        local newVal = not (RH.db.trinket1Priority or RH.db.trinket2Priority)
        RH.db.trinket1Priority = newVal
        RH.db.trinket2Priority = newVal
        print(newVal and L.CMD_TRINKET_PRIORITY_ON or L.CMD_TRINKET_PRIORITY_OFF)
        local mod = RH.modules.SpellSuggestion
        if mod then mod:UpdateSpell() end
        local op = RH.modules.OptionsPanel
        if op then op:SyncPriorityCbs() end

    elseif cmd == "potionpriority" then
        RH.db.potionPriority = not RH.db.potionPriority
        print(RH.db.potionPriority and L.CMD_POTION_PRIORITY_ON or L.CMD_POTION_PRIORITY_OFF)
        local mod = RH.modules.SpellSuggestion
        if mod then mod:UpdateSpell() end
        local op = RH.modules.OptionsPanel
        if op then op:SyncPriorityCbs() end

    elseif cmd == "spellspriority" then
        RH.db.spellPriority = not RH.db.spellPriority
        print(RH.db.spellPriority and L.CMD_SPELL_PRIORITY_ON or L.CMD_SPELL_PRIORITY_OFF)
        local mod = RH.modules.SpellSuggestion
        if mod then mod:UpdateSpell() end
        local op = RH.modules.OptionsPanel
        if op then op:SyncPriorityCbs() end

    elseif cmd == "gcd" then
        RH.gdb.showGCD = not RH.gdb.showGCD
        local mod = RH.modules.GCDIndicator
        if mod then mod:SetVisible(RH.gdb.showGCD) end
        print(RH.gdb.showGCD and L.CMD_GCD_ON or L.CMD_GCD_OFF)

    elseif cmd == "controls" then
        RH.gdb.showControls = not RH.gdb.showControls
        local op = RH.modules.OptionsPanel
        if op then op:SetControlsVisible(RH.gdb.showControls) end
        print(RH.gdb.showControls and L.CMD_CONTROLS_ON or L.CMD_CONTROLS_OFF)

    elseif cmd == "debugbars" then
        RH.Utils.DebugBars()

    elseif cmd == "debugallhotkeys" then
        RH.Utils.DebugAllHotkeys()

    elseif cmd == "debugspell" then
        RH.Utils.DebugSpell(arg)

    elseif cmd == "debugbind" then
        RH.Utils.DebugTrinketBind()

    elseif cmd == "debugitems" then
        RH.Utils.DebugActionBarItems()

    elseif cmd == "debugpotion" then
        RH.Utils.DebugPotionCheck()

    elseif cmd == "debugbuffs" then
        print(string.format("|cff00ccff[Sy Buffs]|r inCombat=%s", tostring(InCombatLockdown())))
        local found = 0
        for i = 1, 60 do
            local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
            if not ok or not aura then break end
            local name    = tostring(aura.name)
            local spellId = tostring(aura.spellId)
            print(string.format("  [%d] %s  id=%s", i, name, spellId))
            found = found + 1
        end
        if found == 0 then print("  (none — fields may be restricted if in an instance or in combat)") end

    elseif cmd == "debugvalidate" then
        -- Phase 1: dump the full macro book so we can see every macro and its index.
        local generalCount, charCount = GetNumMacros()
        print(string.format("|cff00ccff[Sy DebugValidate]|r Macro book: %d general, %d character", generalCount, charCount))
        for i = 1, generalCount do
            local mName = GetMacroInfo(i)
            local body = GetMacroBody(i) or ""
            print(string.format("  GEN[%d] %q  body=%q", i, mName or "?", body:sub(1, 60)))
        end
        for i = 1, charCount do
            local idx = 120 + i
            local mName = GetMacroInfo(idx)
            local body = GetMacroBody(idx) or ""
            print(string.format("  CHAR[%d/idx=%d] %q  body=%q", i, idx, mName or "?", body:sub(1, 60)))
        end
        -- Phase 2: scan slots 1-200 and print EVERY macro/spell slot found.
        print("|cff00ccff[Sy DebugValidate]|r Scanning slots 1-200:")
        for slot = 1, 200 do
            local aType, id = GetActionInfo(slot)
            if aType == "spell" and id then
                local sn = C_Spell.GetSpellName(id) or "?"
                print(string.format("  slot %d: SPELL id=%d %s", slot, id, sn))
            elseif aType == "macro" and id then
                local msID; pcall(function() msID = GetMacroSpell(id) end)
                local body = GetMacroBody(id) or ""
                print(string.format("  slot %d: MACRO id=%d spell=%s body=%q", slot, id, tostring(msID), body:sub(1, 60)))
            end
        end

    else
        print(L.CMD_HELP)
    end
end

-- ── Keybinding handlers ────────────────────────────────────────────────────
-- Called by Bindings.xml entries; appear in WoW keybinding UI under our header.

local function SyncOptionsPanel()
    local op = RH.modules.OptionsPanel
    if op then op:SyncPriorityCbs() end
end

function RH_Binding_ToggleTrinketPriority()
    if not RH.db or not RH.gdb then return end
    -- Toggle both slots together (same logic as /sy trinketpriority)
    local newVal = not (RH.db.trinket1Priority or RH.db.trinket2Priority)
    RH.db.trinket1Priority = newVal
    RH.db.trinket2Priority = newVal
    local mod = RH.modules.SpellSuggestion
    if mod then mod:UpdateSpell() end
    SyncOptionsPanel()
    local L = RotationHelperL
    print(newVal and L.CMD_TRINKET_PRIORITY_ON or L.CMD_TRINKET_PRIORITY_OFF)
end

function RH_Binding_TogglePotionPriority()
    if not RH.db or not RH.gdb then return end
    RH.db.potionPriority = not RH.db.potionPriority
    local mod = RH.modules.SpellSuggestion
    if mod then mod:UpdateSpell() end
    SyncOptionsPanel()
    local L = RotationHelperL
    print(RH.db.potionPriority and L.CMD_POTION_PRIORITY_ON or L.CMD_POTION_PRIORITY_OFF)
end

function RH_Binding_ToggleSpellPriority()
    if not RH.db or not RH.gdb then return end
    RH.db.spellPriority = not RH.db.spellPriority
    local mod = RH.modules.SpellSuggestion
    if mod then mod:UpdateSpell() end
    SyncOptionsPanel()
    local L = RotationHelperL
    print(RH.db.spellPriority and L.CMD_SPELL_PRIORITY_ON or L.CMD_SPELL_PRIORITY_OFF)
end
