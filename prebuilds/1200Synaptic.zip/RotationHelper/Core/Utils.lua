-- Initialise the addon table early so all modules can reference it.
RotationHelper = RotationHelper or {}

local RH    = RotationHelper
RH.Utils    = {}
local Utils = RH.Utils

-- Minimum cooldown duration (seconds) that counts as a real cooldown vs the GCD.
-- The GCD is at most 1.5s; 1.6 gives a small buffer above that.
-- Shared here so all modules use the same threshold without local copies.
RH.GCD_THRESHOLD = 1.6

-- Deep-merge `defaults` into `saved`, filling any keys missing from a prior
-- version without wiping existing user settings.
function Utils.DeepMerge(defaults, saved)
    saved = saved or {}
    for k, v in pairs(defaults) do
        if type(v) == "table" then
            saved[k] = Utils.DeepMerge(v, saved[k])
        elseif saved[k] == nil then
            saved[k] = v
        end
    end
    return saved
end

-- Format a remaining-seconds value as a compact string.
function Utils.FormatCooldown(remaining)
    if remaining >= 60 then
        return string.format("%dm", math.ceil(remaining / 60))
    elseif remaining >= 10 then
        return string.format("%ds", math.ceil(remaining))
    else
        return string.format("%.1fs", remaining)
    end
end

-- ── Health potion detection ─────────────────────────────────────────────────

-- Spell-description keywords that indicate health restoration.
-- Covers major WoW locales so detection works without a hardcoded item ID list.
local HEALTH_RESTORE_PATTERNS = {
    "restores", "restore", "heals", "heal",  -- enUS
    "heilt",    "stellt wieder her",          -- deDE
    "soigne",   "restaure",                   -- frFR
    "cura",     "restaura",                   -- esES / itIT / ptBR
    "восстанавливает",                        -- ruRU
}

-- Returns true if itemID is a health-restoring potion rather than a combat/stat
-- potion. Uses the item's attached spell description — works across patches
-- without maintaining a hardcoded list, and works for all locales.
function Utils.IsHealthPotion(itemID)
    local _, spellID = C_Item.GetItemSpell(itemID)
    if not spellID then return false end
    local desc = (C_Spell.GetSpellDescription(spellID) or ""):lower()
    for _, pat in ipairs(HEALTH_RESTORE_PATTERNS) do
        if desc:find(pat, 1, true) then return true end
    end
    return false
end

-- ── Action bar keybind lookup ───────────────────────────────────────────────

-- Fixed mapping: GetActionInfo slot-range start → WoW binding command prefix.
-- Confirmed against Blizzard's action bar code and cross-referenced with
-- established addons (Ovale, Bartender4) for correctness.
--
-- Slots 13-24 (bar 2) share ACTIONBUTTON bindings with bar 1 — bars 2-6 are
-- "pages" of bar 1 in WoW's binding system; there are no separate ACTIONBAR2BUTTON
-- etc. commands.
--
-- Slots 73-84 and 85-96 are additional pages of bar 1 used for shapeshift form
-- bars (Druid Cat/Bear, Rogue Stealth, etc.). When bar 1 is paged to these, the
-- physical buttons are still ACTIONBUTTON1-12, so bindings are the same.
--
-- GetActionInfo slot layout:
--    1-12  Bar 1 (main bar)             → ACTIONBUTTON
--   13-24  Bar 2 (page of bar 1)        → ACTIONBUTTON  (same keys as bar 1)
--   25-36  MultiBarBottomLeft           → MULTIACTIONBAR3BUTTON
--   37-48  MultiBarBottomRight          → MULTIACTIONBAR4BUTTON
--   49-60  MultiBarRight               → MULTIACTIONBAR2BUTTON
--   61-72  MultiBarLeft                → MULTIACTIONBAR1BUTTON
--   97-108 Extra bar 5 (Dragonflight+)  → MULTIACTIONBAR5BUTTON
--  109-120 Extra bar 6 (Dragonflight+)  → MULTIACTIONBAR6BUTTON
--  73-84  Shapeshift/stance page 1   → ACTIONBUTTON  (Druid Cat Form, Rogue Stealth, etc.)
--  85-96  Shapeshift/stance page 2   → ACTIONBUTTON  (Druid Bear Form, etc.)
--  97-108 MultiActionBar5 (Dragonflight+ extra bar) → MULTIACTIONBAR5BUTTON
-- 109-120 MultiActionBar6 (Dragonflight+ extra bar) → MULTIACTIONBAR6BUTTON
local BAR_CMD = {
    [1]   = "ACTIONBUTTON",
    [13]  = "ACTIONBUTTON",
    [25]  = "MULTIACTIONBAR3BUTTON",
    [37]  = "MULTIACTIONBAR4BUTTON",
    [49]  = "MULTIACTIONBAR2BUTTON",
    [61]  = "MULTIACTIONBAR1BUTTON",
    [73]  = "ACTIONBUTTON",            -- shapeshift page 1 (Druid Cat Form, Rogue Stealth, etc.)
    [85]  = "ACTIONBUTTON",            -- shapeshift page 2 (Druid Bear Form, etc.)
    [97]  = "MULTIACTIONBAR5BUTTON",   -- extra bar 5 (Dragonflight+)
    [109] = "MULTIACTIONBAR6BUTTON",   -- extra bar 6 (Dragonflight+)
}

-- Formats a raw GetBindingKey result into the compact style shown on action buttons.
--   "SHIFT-1"        → "S1"
--   "CTRL--"         → "C-"  (the key IS the dash)
--   "ALT-F"          → "AF"
--   "CTRL-SHIFT-1"   → "CS1"
--   "NUMPAD1"        → "N1"
--   "ALT-NUMPAD1"    → "AN1"
local function FormatBindingKey(raw)
    if not raw then return nil end
    local mod = ""
    local key = raw
    key = key:gsub("CTRL%-",  function() mod = mod .. "C"; return "" end)
    key = key:gsub("ALT%-",   function() mod = mod .. "A"; return "" end)
    key = key:gsub("SHIFT%-", function() mod = mod .. "S"; return "" end)
    -- Numpad keys: NUMPAD0-9, NUMPADDECIMAL, NUMPADMINUS, NUMPADPLUS, NUMPADSLASH, NUMPADMULTIPLY
    key = key:gsub("^NUMPAD(.+)$", function(suffix)
        -- Map named keys to symbols, digits stay as-is
        local map = { DECIMAL=".", MINUS="-", PLUS="+", SLASH="/", MULTIPLY="*" }
        return "N" .. (map[suffix] or suffix)
    end)
    if #key > 3 then key = key:sub(1, 3) end
    return mod .. key
end

-- Cache for ConsolePort icon lookups — avoids transient nil returns from
-- db.Gamepad.Active flickering during combat events.
-- false = confirmed no CP icon for this cmd; nil = not yet looked up.
local cpIconCache = {}

-- Cache for addon action-bar CLICK bindings (Bartender4, Dominos, etc.).
-- Keyed by action slot (1–120); value is the formatted binding string.
-- Populated by RebuildAddonBarCache(); nil = not yet built.
local addonSlotBindingCache = {}

-- Scans all frames via EnumerateFrames for action button objects and resolves the
-- exact WoW binding command for each slot.  Two addon styles are handled:
--
--   LibActionButton-1.0 (Bartender4, etc.)
--     button.action  = action slot (Lua field)
--     button:GetBindingAction()  = "ACTIONBUTTON1" for bar 1, or
--                                   "CLICK BT4Button13:Keybind" for unmapped bars
--
--   Dominos
--     frame:GetAttribute("action")       = action slot (secure attribute)
--     frame:GetAttribute("commandName")  = "ACTIONBUTTON1" for bar 1, or
--                                          "CLICK DominosActionButton13:HOTKEY" for bar 2
--
-- GetBindingKey(cmd) then returns whatever key the player bound to that specific
-- button, which is correct even when different keys are set on different bars.
local function RebuildAddonBarCache()
    wipe(addonSlotBindingCache)
    local frame = EnumerateFrames()
    while frame do
        -- Read action slot.  Try secure attribute first (Dominos), then Lua field (LAB-1.0).
        local action
        local ok, val = pcall(function() return frame:GetAttribute("action") end)
        if ok and type(val) == "number" and val >= 1 and val <= 120 then
            action = val
        else
            ok, val = pcall(function() return frame.action end)
            if ok and type(val) == "number" and val >= 1 and val <= 120 then
                action = val
            end
        end

        if action and not addonSlotBindingCache[action] then
            -- Try LibActionButton-1.0 (Bartender4): GetBindingAction() returns the
            -- exact command, e.g. "CLICK BT4Button13:Keybind" for bar 2 buttons.
            local cmd
            ok, cmd = pcall(function() return frame:GetBindingAction() end)
            if not (ok and type(cmd) == "string" and cmd ~= "") then
                -- Fallback: Dominos stores the command in a "commandName" attribute.
                ok, cmd = pcall(function() return frame:GetAttribute("commandName") end)
            end

            if ok and type(cmd) == "string" and cmd ~= "" then
                local raw = GetBindingKey(cmd)
                if raw then
                    addonSlotBindingCache[action] = FormatBindingKey(raw)
                end
            end
        end
        frame = EnumerateFrames(frame)
    end
end

-- Wipes both caches so GetSlotKey re-queries on the next call.
-- Called on UPDATE_BINDINGS and PLAYER_ENTERING_WORLD.
function Utils.InvalidateHotkeyMap()
    wipe(cpIconCache)
    RebuildAddonBarCache()
end

-- Diagnostic: scans ALL global names containing "HotKey" to find action button
-- hotkey frames we may not be covering in BAR_SLOTS.
function Utils.DebugAllHotkeys()
    print("|cff00ccff[Sy DebugAllHotkeys]|r Scanning _G for *HotKey* frames with text:")
    local found = 0
    for name, obj in pairs(_G) do
        if type(name) == "string" and name:find("HotKey") then
            local ok, text = pcall(function() return obj:GetText() end)
            if ok and text and text ~= "" then
                found = found + 1
                print(string.format("  %-50s = %s", name, text))
            end
        end
    end
    if found == 0 then print("  None found.") end
end

-- Diagnostic: prints the first bound key for each bar (via GetBindingKey).
function Utils.DebugBars()
    print("|cff00ccff[Sy DebugBars]|r Bar → command → sample key:")
    for startSlot, cmdPfx in pairs(BAR_CMD) do
        local sample = nil
        for btn = 1, 12 do
            local raw = GetBindingKey(cmdPfx .. btn)
            if raw then
                sample = string.format("btn%d=%s", btn, FormatBindingKey(raw))
                break
            end
        end
        print(string.format("  slots %2d-%-2d  cmd=%-26s  %s",
            startSlot, startSlot + 11, cmdPfx, sample or "(no bindings)"))
    end
end

-- Returns the keybind display string for an action bar slot, or nil if unbound.
-- If ConsolePort is loaded, returns its icon markup (e.g. |A:atlas:14:14|a)
-- for controller buttons. Falls back to the standard text format otherwise.
local function GetSlotKey(slot)
    -- Addon action-bar addons (Bartender4, Dominos, etc.) bind their buttons via a
    -- commandName attribute (e.g. "CLICK DominosActionButton13:HOTKEY") rather than
    -- the standard ACTIONBUTTON/MULTIACTIONBAR* commands.  The cache holds the
    -- correct per-slot key so we don't fall through to ACTIONBUTTON (bar 1's key).
    local addonKey = addonSlotBindingCache[slot]
    if addonKey then return addonKey end

    local barStart = slot - ((slot - 1) % 12)
    local cmdPfx = BAR_CMD[barStart]
    if not cmdPfx then return nil end
    local btnPos = ((slot - 1) % 12) + 1
    local bindingCmd = cmdPfx .. btnPos

    -- ConsolePort integration: show controller button icon when active.
    -- Results are cached to prevent flicker from transient nil returns
    -- (db.Gamepad.Active can be nil briefly during combat events).
    -- Cache is wiped on UPDATE_BINDINGS via Utils.InvalidateHotkeyMap().
    if C_AddOns.IsAddOnLoaded("ConsolePort")
    and ConsolePort and ConsolePort.GetFormattedBindingOwner then
        local cached = cpIconCache[bindingCmd]
        if cached then
            return cached  -- confirmed icon, return immediately
        elseif cached == nil then
            local icon = ConsolePort:GetFormattedBindingOwner(bindingCmd)
            if icon and icon ~= "" then
                cpIconCache[bindingCmd] = icon
                return icon
            else
                cpIconCache[bindingCmd] = false  -- no CP icon for this slot
            end
        end
        -- cached == false: fall through to text path below
    end

    return FormatBindingKey(GetBindingKey(bindingCmd))
end

-- Returns a short display string for the keybind of a spell on any action bar,
-- or nil if the spell is not found / has no binding.
-- Scans all 120 slots (10 bars × 12) and checks both direct spell slots and
-- macro slots whose body contains a /cast for the spell (handles [@unit]
-- conditionals that GetMacroSpell can't resolve when the target isn't present).
function Utils.GetSpellKeybind(spellID)
    local spellInfo = C_Spell.GetSpellInfo(spellID)
    local spellLower = spellInfo and spellInfo.name and spellInfo.name:lower()

    local function MacroBodyHasSpell(macroID)
        -- Fast path: GetMacroSpell (fails for [@unit] conditionals)
        local msID
        pcall(function() msID = GetMacroSpell(macroID) end)
        if msID == spellID then return true end
        -- Fallback: parse /cast lines from body text
        if not spellLower then return false end
        local body = GetMacroBody(macroID) or ""
        for line in body:gmatch("[^\n]+") do
            local castPart = line:match("^%s*/?cast%s+(.+)$")
            if castPart then
                local stripped = castPart:gsub("%[.-%]", "")
                for part in stripped:gmatch("[^;]+") do
                    local trimmed = part:match("^%s*(.-)%s*$")
                    if trimmed and trimmed:lower() == spellLower then
                        return true
                    end
                end
            end
        end
        return false
    end

    -- When the player is in a shapeshift/stance form (Druid Bear/Cat, Rogue
    -- Stealth, etc.) bar 1's physical buttons (ACTIONBUTTON1-12) display the
    -- active bonus bar, NOT bar 1 page 1.  GetActionInfo(1-12) still returns
    -- bar 1 page 1, so a spell that lives at different positions on the two
    -- bars would yield the wrong binding if we found it on bar 1 first.
    -- Fix: scan the active bonus-bar slots (73-96) before the full scan so
    -- the shapeshift position wins when the spell appears on both bars.
    local bonusIdx = GetBonusBarIndex()
    if bonusIdx and bonusIdx > 0 then
        local baseSlot = 72 + (bonusIdx - 1) * 12 + 1
        if BAR_CMD[baseSlot] then  -- guard: only valid shapeshift ranges (73-96)
            for slot = baseSlot, baseSlot + 11 do
                local actionType, id = GetActionInfo(slot)
                if actionType == "spell" and id == spellID then
                    local key = GetSlotKey(slot)
                    if key then return key end
                elseif actionType == "macro" and id then
                    if id == spellID then
                        local key = GetSlotKey(slot)
                        if key then return key end
                    end
                    if MacroBodyHasSpell(id) then
                        local key = GetSlotKey(slot)
                        if key then return key end
                    end
                end
            end
        end
    end

    for slot = 1, 120 do
        local actionType, id = GetActionInfo(slot)
        if actionType == "spell" and id == spellID then
            local key = GetSlotKey(slot)
            if key then return key end
        elseif actionType == "macro" and id then
            -- In Midnight, GetActionInfo returns the resolved spellID as `id`
            -- for spell-casting macros. Check it directly first.
            if id == spellID then
                local key = GetSlotKey(slot)
                if key then return key end
            end
            -- Legacy fallback: body parsing for older API behaviour.
            if MacroBodyHasSpell(id) then
                local key = GetSlotKey(slot)
                if key then return key end
            end
        end
    end
    return nil
end

-- Same as above but for an item placed on an action bar (e.g. trinkets/potions).
-- Also checks macro slots whose body references the item by name or by
-- equipment slot number (/use 13 / /use 14) since many players use macros
-- rather than dragging the item directly to the bar.
function Utils.GetItemKeybind(itemID)
    local itemName = GetItemInfo(itemID)
    local nameLower = itemName and itemName:lower()

    for slot = 1, 96 do
        local actionType, id = GetActionInfo(slot)

        if actionType == "item" and id == itemID then
            local key = GetSlotKey(slot)
            if key then return key end
        end

        if actionType == "macro" then
            local body = (GetMacroBody(id) or ""):lower()
            local match = (body:find("/use%s+13") or body:find("/use%s+14"))
                       or (nameLower and body:find(nameLower, 1, true))
            if match then
                local key = GetSlotKey(slot)
                if key then return key end
            end
        end
    end
    return nil
end

-- Diagnostic: finds a spell by name on the action bar and prints slot/cmd/key info.
function Utils.DebugSpell(spellName)
    if not spellName or spellName == "" then
        print("|cff00ccff[Sy DebugSpell]|r Usage: /sy debugspell <spell name>")
        return
    end
    local nameLower = spellName:lower()
    print("|cff00ccff[Sy DebugSpell]|r Searching for: " .. spellName)
    local found = 0
    for slot = 1, 96 do
        local aType, id = GetActionInfo(slot)
        if aType == "spell" and id then
            local name = C_Spell.GetSpellName(id) or ""
            if name:lower():find(nameLower, 1, true) then
                found = found + 1
                local barStart = slot - ((slot - 1) % 12)
                local cmdPfx = BAR_CMD[barStart] or "?"
                local btnPos = ((slot - 1) % 12) + 1
                local raw = GetBindingKey(cmdPfx .. btnPos)
                local key = FormatBindingKey(raw)
                print(string.format("  slot=%-3d  spellID=%-7d  cmd=%s%d  rawKey=%s  key=%s",
                    slot, id, cmdPfx, btnPos, tostring(raw), tostring(key)))
            end
        end
    end
    if found == 0 then
        print("  Spell not found on any action bar slot.")
    end
end

-- Diagnostic: prints every "item" type action bar slot and its item data.
function Utils.DebugActionBarItems()
    print("|cff00ccff[Sy DebugItems]|r Scanning action bar slots 1-96:")
    local found = 0
    for slot = 1, 96 do
        local aType, itemID = GetActionInfo(slot)
        if aType == "item" and itemID then
            found = found + 1
            local name, _, _, _, _, _, _, _, _, _, _, classID, subclassID =
                GetItemInfoInstant(itemID)
            local hasSpell = C_Item.GetItemSpell(itemID) ~= nil
            print(string.format("  slot=%-3d  itemID=%-8d  class=%-4s  sub=%-4s  spell=%-5s  %s",
                slot,
                itemID,
                tostring(classID),
                tostring(subclassID),
                tostring(hasSpell),
                tostring(name) or "?"))
        end
    end
    if found == 0 then
        print("  No 'item' type slots found on bars 1-96.")
    end
end

-- Diagnostic: prints action-bar info for all equipped trinkets to chat.
-- Usage: /sy debugbind
function Utils.DebugTrinketBind()
    local TRINKET_SLOTS = { 13, 14 }
    for _, equipSlot in ipairs(TRINKET_SLOTS) do
        local itemID = GetInventoryItemID("player", equipSlot)
        if itemID then
            local name = GetItemInfo(itemID) or "?"
            print(string.format("[Sy] Trinket equip-slot %d  itemID=%d  %s", equipSlot, itemID, name))
            local found = false
            for s = 1, 96 do
                local aType, aID = GetActionInfo(s)
                if aType and aType ~= "empty" then
                    local isMatch = (aType == "item" and aID == itemID)
                    if not isMatch and aType == "macro" then
                        local body = (GetMacroBody(aID) or ""):lower()
                        local n = name:lower()
                        isMatch = body:find("/use%s+13") or body:find("/use%s+14")
                              or body:find(n, 1, true)
                    end
                    if isMatch then
                        found = true
                        local mappedCmd = ACTION_BINDING[s] or "?"
                        local mappedKey = ACTION_BINDING[s] and GetBindingKey(ACTION_BINDING[s])
                        print(string.format("  action slot %d  type=%-6s  mapped_cmd=%s  mapped_key=%s",
                            s, aType, mappedCmd, tostring(mappedKey)))
                        -- Scan all multibar names for this button position to find the real binding
                        local btnPos = ((s - 1) % 12) + 1
                        print("  Scanning all MULTIACTIONBAR*BUTTON" .. btnPos .. " for a key:")
                        for bar = 1, 10 do
                            local cmd2 = "MULTIACTIONBAR" .. bar .. "BUTTON" .. btnPos
                            local key2 = GetBindingKey(cmd2)
                            if key2 then
                                print(string.format("    %s = %s", cmd2, key2))
                            end
                        end
                    end
                end
            end
            if not found then
                print("  NOT found on any action bar slot (not dragged / no matching macro)")
            end
        end
    end
end

-- Diagnostic: prints full potion detection data for every "item" action bar slot.
-- Usage: /sy debugpotion
function Utils.DebugPotionCheck()
    print("|cff00ccff[Sy DebugPotion]|r Scanning action bar slots 1-96:")
    local found = 0
    for slot = 1, 96 do
        local aType, itemID = GetActionInfo(slot)
        if aType == "item" and itemID then
            found = found + 1
            local name, _, _, _, _, _, _, _, _, texture, _, classID, subclassID = GetItemInfo(itemID)
            local hasSpell = C_Item.GetItemSpell(itemID) ~= nil
            local start, duration, enable = GetActionCooldown(slot)
            local iStart, iDur, iEnable = GetItemCooldown(itemID)
            print(string.format(
                "  slot=%-3d  itemID=%-8d  class=%-4s  sub=%-4s  spell=%-5s  ac_enable=%-5s  ac_dur=%-6s  ic_enable=%-5s  ic_dur=%-6s  %s",
                slot, itemID,
                tostring(classID), tostring(subclassID),
                tostring(hasSpell),
                tostring(enable), string.format("%.2f", duration or 0),
                tostring(iEnable), string.format("%.2f", iDur or 0),
                tostring(name) or "?"))
        end
    end
    if found == 0 then print("  No 'item' type slots found.") end
    print(string.format("|cff00ccff[Sy]|r potionPriority=%s", tostring(RotationHelper.db.potionPriority)))
end

-- Query the GCD state via the dummy spell 61304.
-- Returns: isOnGCD (bool), durationObject (DurationObject|nil)
-- isOnGCD is NeverSecret; DurationObject is passed directly to SetCooldownFromDurationObject.
function Utils.IsGCDActive()
    local info = C_Spell.GetSpellCooldown(61304)
    if not info then return false, nil end
    local dur = C_Spell.GetSpellCooldownDuration(61304)
    return info.isOnGCD, dur
end
