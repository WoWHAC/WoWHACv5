-- Keybinding UI strings — must be bare globals, not inside the L table
BINDING_HEADER_ROTATIONHELPER                              = "Synaptic"
BINDING_NAME_ROTATIONHELPER_TOGGLE_TRINKET_PRIORITY        = "Toggle Trinket Priority"
BINDING_NAME_ROTATIONHELPER_TOGGLE_POTION_PRIORITY         = "Toggle Potion Priority"
BINDING_NAME_ROTATIONHELPER_TOGGLE_SPELL_PRIORITY          = "Toggle Spell Priority"

RotationHelperL = {
    ADDON_LOADED              = "|cff00ccff[Synaptic]|r v%s loaded. Type /sy for options.",
    CMD_HELP                  = "|cff00ccff[Synaptic]|r commands:\n  /sy toggle            - show/hide the addon\n  /sy lock              - lock/unlock frame position\n  /sy reset             - reset frame to default position\n  /sy scale |cffaaaaaa<0.5-2.0>|r      - resize the frame\n  /sy gcd               - toggle GCD indicator\n  /sy trinkets          - toggle cooldown strip\n  /sy trinketpriority   - toggle trinket use reminder\n  /sy potionpriority    - toggle potion use reminder\n  /sy spellspriority    - toggle custom spell list priority\n  /sy controls          - show/hide cog & lock buttons",
    CMD_LOCK                  = "|cff00ccff[Synaptic]|r Frame locked.",
    CMD_UNLOCK                = "|cff00ccff[Synaptic]|r Frame unlocked.",
    CMD_RESET                 = "|cff00ccff[Synaptic]|r Position reset.",
    CMD_SCALE                 = "|cff00ccff[Synaptic]|r Scale set to %.1f.",
    CMD_SCALE_INVALID         = "|cff00ccff[Synaptic]|r Scale must be between 0.5 and 2.0.",
    CMD_TRINKETS_ON           = "|cff00ccff[Synaptic]|r Trinket cooldown panel enabled.",
    CMD_TRINKETS_OFF          = "|cff00ccff[Synaptic]|r Trinket cooldown panel disabled.",
    CMD_TRINKET_PRIORITY_ON   = "|cff00ccff[Synaptic]|r Trinket rotation priority |cff00ff00ON|r — ready trinkets show before spells.",
    CMD_TRINKET_PRIORITY_OFF  = "|cff00ccff[Synaptic]|r Trinket rotation priority |cffff4444OFF|r.",
    CMD_POTION_PRIORITY_ON    = "|cff00ccff[Synaptic]|r Potion rotation priority |cff00ff00ON|r — ready potions show before spells.",
    CMD_POTION_PRIORITY_OFF   = "|cff00ccff[Synaptic]|r Potion rotation priority |cffff4444OFF|r.",
    CMD_SPELL_PRIORITY_ON    = "|cff00ccff[Synaptic]|r Spell priority |cff00ff00ON|r — custom spells show before rotation.",
    CMD_SPELL_PRIORITY_OFF   = "|cff00ccff[Synaptic]|r Spell priority |cffff4444OFF|r.",
    CMD_GCD_ON                = "|cff00ccff[Synaptic]|r GCD indicator enabled.",
    CMD_GCD_OFF               = "|cff00ccff[Synaptic]|r GCD indicator disabled.",
    SYSTEM_UNAVAILABLE        = "Enable Assisted Combat\nin Interface > Combat",
    TRINKET_READY             = "Ready",
    NOT_ENOUGH_POWER          = "Not enough resources",
    NO_TARGET                 = "Select a target",
    OUT_OF_RANGE              = "Out of range",
    NO_CHARGES                = "No charges!",
    PRIORITY_TRINKET          = "Use Trinket!",
    PRIORITY_POTION           = "Use Potion!",
    PRIORITY_SPELL            = "Use Cooldown!",
    CMD_CONTROLS_ON           = "|cff00ccff[Synaptic]|r UI buttons |cff00ff00shown|r.",
    CMD_CONTROLS_OFF          = "|cff00ccff[Synaptic]|r UI buttons |cffff4444hidden|r. Use /sy controls to restore.",
}
