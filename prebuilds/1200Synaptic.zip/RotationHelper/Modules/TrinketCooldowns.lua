local RH = RotationHelper

local TrinketCooldowns = {}
RH:RegisterModule("TrinketCooldowns", TrinketCooldowns)

local SLOT_SIZE         = 28
local MIN_SLOT_SIZE     = 16
local SLOT_GAP          = 3
local MAX_SLOTS         = 12
local STRIP_AVAILABLE_W = 156   -- strip width in px (frame 240 - margins - 56px icon)
local GCD_THRESHOLD     = RH.GCD_THRESHOLD
local TRINKET_EQUIP     = { 13, 14 }

-- Max slots that fit at minimum size: floor((156+3) / (16+3)) = 8
local MAX_DISPLAYABLE = math.floor((STRIP_AVAILABLE_W + SLOT_GAP) / (MIN_SLOT_SIZE + SLOT_GAP))

-- ── UI creation ────────────────────────────────────────────────────────────

function TrinketCooldowns:CreateUI()
    local spellSection = RH.modules.SpellSuggestion.section
    local iconFrame    = RH.modules.SpellSuggestion.iconFrame

    local strip = CreateFrame("Frame", nil, spellSection)
    strip:SetHeight(SLOT_SIZE + 2)
    strip:SetPoint("BOTTOMLEFT",  iconFrame,    "BOTTOMRIGHT", 8,  -8)
    strip:SetPoint("BOTTOMRIGHT", spellSection, "BOTTOMRIGHT", 0,  -8)
    self.strip = strip

    self.slots = {}
    for i = 1, MAX_SLOTS do
        local slotFrame = CreateFrame("Frame", nil, strip)
        slotFrame:SetSize(SLOT_SIZE, SLOT_SIZE)
        slotFrame:SetPoint("TOPLEFT", strip, "TOPLEFT", 0, -1)  -- Refresh repositions
        slotFrame:Hide()

        local tex = slotFrame:CreateTexture(nil, "ARTWORK")
        tex:SetPoint("TOPLEFT",     slotFrame, "TOPLEFT",     1, -1)
        tex:SetPoint("BOTTOMRIGHT", slotFrame, "BOTTOMRIGHT", -1,  1)
        tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)

        local sweep = CreateFrame("Cooldown", nil, slotFrame, "CooldownFrameTemplate")
        sweep:SetPoint("TOPLEFT",     slotFrame, "TOPLEFT",     1, -1)
        sweep:SetPoint("BOTTOMRIGHT", slotFrame, "BOTTOMRIGHT", -1,  1)
        sweep:SetDrawEdge(false)
        sweep:SetSwipeColor(0, 0, 0, 0.82)
        sweep:SetHideCountdownNumbers(false)

        -- 1px border on a frame above the sweep
        local border = CreateFrame("Frame", nil, slotFrame)
        border:SetAllPoints()
        border:SetFrameLevel(sweep:GetFrameLevel() + 1)
        local R, G, B, A = 0.65, 0.65, 0.65, 0.9

        local bT = border:CreateTexture(nil, "OVERLAY")
        bT:SetColorTexture(R, G, B, A); bT:SetHeight(1)
        bT:SetPoint("TOPLEFT", border, "TOPLEFT", 0, 0)
        bT:SetPoint("TOPRIGHT", border, "TOPRIGHT", 0, 0)

        local bB = border:CreateTexture(nil, "OVERLAY")
        bB:SetColorTexture(R, G, B, A); bB:SetHeight(1)
        bB:SetPoint("BOTTOMLEFT",  border, "BOTTOMLEFT",  0, 0)
        bB:SetPoint("BOTTOMRIGHT", border, "BOTTOMRIGHT", 0, 0)

        local bL = border:CreateTexture(nil, "OVERLAY")
        bL:SetColorTexture(R, G, B, A); bL:SetWidth(1)
        bL:SetPoint("TOPLEFT",    border, "TOPLEFT",    0,  0)
        bL:SetPoint("BOTTOMLEFT", border, "BOTTOMLEFT", 0,  0)

        local bR = border:CreateTexture(nil, "OVERLAY")
        bR:SetColorTexture(R, G, B, A); bR:SetWidth(1)
        bR:SetPoint("TOPRIGHT",    border, "TOPRIGHT",    0, 0)
        bR:SetPoint("BOTTOMRIGHT", border, "BOTTOMRIGHT", 0, 0)

        -- Tooltip on hover
        slotFrame:EnableMouse(true)
        slotFrame:SetScript("OnEnter", function(frame)
            local slot = TrinketCooldowns.slots[i]
            if not slot then return end
            GameTooltip:SetOwner(frame, "ANCHOR_RIGHT")
            if slot.isSpell and slot.spellID then
                GameTooltip:SetSpellByID(slot.spellID)
            elseif slot.itemID then
                if slot.isEquip then
                    GameTooltip:SetInventoryItem("player", slot.equipSlot)
                else
                    GameTooltip:SetItemByID(slot.itemID)
                end
            else
                return
            end
            GameTooltip:Show()
        end)
        slotFrame:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)

        self.slots[i] = {
            frame      = slotFrame,
            tex        = tex,
            sweep      = sweep,
            itemID     = nil,
            isSpell    = false,
            spellID    = nil,
            isEquip    = false,
            equipSlot  = nil,
            barSlot    = nil,
            cdStart    = nil,
            cdDuration = nil,
        }
    end

    if not RH.gdb.showTrinkets then strip:Hide() end
end

-- ── Item discovery ─────────────────────────────────────────────────────────

function TrinketCooldowns:GatherItems()
    local items = {}
    local seen  = {}

    -- Equipped on-use trinkets
    for _, equipSlot in ipairs(TRINKET_EQUIP) do
        local itemID = GetInventoryItemID("player", equipSlot)
        if itemID and C_Item.GetItemSpell(itemID) then
            seen[itemID] = true
            items[#items + 1] = {
                itemID    = itemID,
                isEquip   = true,
                equipSlot = equipSlot,
                icon      = GetInventoryItemTexture("player", equipSlot),
            }
        end
    end

    -- Priority potions whitelist (mirrors PriorityItems.GetReadyPotion logic)
    for _, entry in ipairs(RH.db.priorityPotions or {}) do
        local itemID = entry.itemID
        if itemID and not seen[itemID] then
            local _, _, _, _, _, _, _, _, _, texture = GetItemInfo(itemID)
            seen[itemID] = true
            items[#items + 1] = {
                itemID  = itemID,
                isEquip = false,
                icon    = texture or C_Item.GetItemIconByID(itemID),
            }
        end
    end

    -- Priority spells — show in strip whenever the list has entries,
    -- regardless of the spellPriority suggestion toggle
    local prioritySpells = RH.db.prioritySpells or {}
    if #prioritySpells > 0 then
        local pi = RH.modules.PriorityItems
        if pi and pi.GetPrioritySpellStripData then
            for _, spellData in ipairs(pi:GetPrioritySpellStripData()) do
                if not seen[spellData.spellID] then
                    seen[spellData.spellID] = true
                    items[#items + 1] = spellData
                end
            end
        end
    end

    return items
end

-- ── Refresh ────────────────────────────────────────────────────────────────

function TrinketCooldowns:Refresh()
    local items        = self:GatherItems()
    local displayCount = math.min(#items, MAX_DISPLAYABLE)

    -- Shrink slots proportionally to fit; clamp to [MIN_SLOT_SIZE, SLOT_SIZE]
    local slotSize = SLOT_SIZE
    if displayCount > 0 then
        local computed = math.floor((STRIP_AVAILABLE_W + SLOT_GAP) / displayCount) - SLOT_GAP
        slotSize = math.max(MIN_SLOT_SIZE, math.min(SLOT_SIZE, computed))
    end

    -- Hide countdown numbers when slots are too small to be legible
    local hideNums = slotSize < 20

    for i = 1, MAX_SLOTS do
        local s    = self.slots[i]
        local item = items[i]

        if not item or i > MAX_DISPLAYABLE then
            s.frame:Hide()
            s.itemID     = nil
            s.isSpell    = false
            s.spellID    = nil
            s.isEquip    = false
            s.equipSlot  = nil
            s.barSlot    = nil
            s.cdStart    = nil
            s.cdDuration = nil
        else
            s.itemID     = item.itemID
            s.isSpell    = item.isSpell    or false
            s.spellID    = item.spellID
            s.isEquip    = item.isEquip    or false
            s.equipSlot  = item.equipSlot
            s.barSlot    = item.barSlot
            s.cdStart    = item.cdStart
            s.cdDuration = item.cdDuration
            s.tex:SetTexture(item.icon)
            s.sweep:SetHideCountdownNumbers(hideNums)

            local xOff = (i - 1) * (slotSize + SLOT_GAP)
            s.frame:ClearAllPoints()
            s.frame:SetSize(slotSize, slotSize)
            s.frame:SetPoint("TOPLEFT", self.strip, "TOPLEFT", xOff, -1)
            s.frame:Show()
            self:UpdateCooldown(i)
        end
    end
end

-- ── Cooldown update ────────────────────────────────────────────────────────

function TrinketCooldowns:UpdateCooldown(i)
    local s = self.slots[i]

    if s.isSpell and s.spellID then
        -- Use DurationObject API (Patch 12.0) — SetCooldown no longer accepts
        -- secret numbers returned by C_Spell.GetSpellCooldown in tainted contexts.
        local ok, dur = pcall(C_Spell.GetSpellCooldownDuration, s.spellID)
        if ok and dur then
            pcall(function() s.sweep:SetCooldownFromDurationObject(dur) end)
        else
            s.sweep:SetCooldown(0, 0)
        end
        return
    end

    if not s.itemID then return end

    local start, duration
    if s.isEquip then
        start, duration = GetInventoryItemCooldown("player", s.equipSlot)
    else
        start, duration = GetItemCooldown(s.itemID)
    end
    if duration ~= nil and duration > GCD_THRESHOLD then
        s.sweep:SetCooldown(start, duration)
    else
        s.sweep:SetCooldown(0, 0)
    end
end

-- ── Visibility ─────────────────────────────────────────────────────────────

function TrinketCooldowns:SetVisible(visible)
    if visible then self.strip:Show() else self.strip:Hide() end
end

-- ── Module init ────────────────────────────────────────────────────────────

function TrinketCooldowns:Init()
    self:CreateUI()
    self:Refresh()

    -- Item cooldowns (bag/equip)
    RH.EventBus:On("BAG_UPDATE_COOLDOWN", function()
        for i = 1, MAX_SLOTS do
            if not self.slots[i].isSpell then
                self:UpdateCooldown(i)
            end
        end
    end, self)

    -- Spell cooldowns start when a cast succeeds; re-seed from PriorityItems
    RH.EventBus:On("UNIT_SPELLCAST_SUCCEEDED", function(_, unit)
        if unit == "player" then self:Refresh() end
    end, self)

    RH.EventBus:On("PLAYER_EQUIPMENT_CHANGED", function() self:Refresh() end, self)
    RH.EventBus:On("ACTIONBAR_SLOT_CHANGED",   function() self:Refresh() end, self)
    RH.EventBus:On("PLAYER_ENTERING_WORLD",    function() self:Refresh() end, self)
    RH.EventBus:On("GET_ITEM_INFO_RECEIVED",   function() self:Refresh() end, self)
end
