-- ManualRotationUI.lua — Builder / picker / share / import dialogs
-- Depends on ManualRotation.lua being loaded first (engine + module registration).

local RH            = RotationHelper
local ManualRotation = RH.modules.ManualRotation
local MAX_STEPS     = ManualRotation.MAX_STEPS
local MAX_COUNT     = ManualRotation.MAX_COUNT

-- ── UI-only constants ─────────────────────────────────────────────────────────

local SLOT_W    = 68
local ARROW_W   = 24
local BUILDER_W = 580
local BUILDER_H = 270
local PICKER_W  = 220
local PICKER_H  = 424

-- ── Spellbook helper ──────────────────────────────────────────────────────────

local function GetKnownSpells()
    local spells = {}
    local seen   = {}
    local numLines
    pcall(function() numLines = C_SpellBook.GetNumSpellBookSkillLines() end)
    if not numLines then return spells end

    for lineIdx = 1, numLines do
        local lineInfo
        pcall(function() lineInfo = C_SpellBook.GetSpellBookSkillLineInfo(lineIdx) end)
        if lineInfo and (not lineInfo.offSpecID or lineInfo.offSpecID == 0) then
            local offset = lineInfo.itemIndexOffset or 0
            local count  = lineInfo.numSpellBookItems or 0
            for j = offset + 1, offset + count do
                local ok, itemInfo = pcall(
                    C_SpellBook.GetSpellBookItemInfo, j, Enum.SpellBookSpellBank.Player)
                if ok and itemInfo and itemInfo.spellID and not itemInfo.isPassive then
                    local spellID = itemInfo.spellID
                    if not seen[spellID] then
                        seen[spellID] = true
                        local spellInfo = C_Spell.GetSpellInfo(spellID)
                        if spellInfo and spellInfo.name then
                            spells[#spells+1] = {
                                spellID = spellID,
                                name    = spellInfo.name,
                                iconID  = spellInfo.iconID,
                            }
                        end
                    end
                end
            end
        end
    end
    table.sort(spells, function(a, b) return a.name < b.name end)
    return spells
end

-- ── Builder state ─────────────────────────────────────────────────────────────

local builderWin      = nil
local pickerWin       = nil
local builderSteps    = {}   -- { spellID, name, iconID, count } while editing
local builderEditName = nil  -- nil = new profile, string = editing this profile

-- Pre-allocated pool — created once inside CreateBuilderWindow
local stepFrames  = {}   -- [i] = { frame, iconFrame, iconTex, badge, nameLabel, countLabel, minusBtn, plusBtn, removeBtn }
local arrowLabels = {}   -- [i] = FontString ">>>" between slot i and i+1
local addSlotFrame = nil -- the trailing [ + ] button

-- Forward declarations (assigned inside CreateBuilderWindow)
local RebuildTimeline
local OpenSpellPicker
local CloseSpellPicker

-- ── Builder window ────────────────────────────────────────────────────────────

function ManualRotation:CreateBuilderWindow()
    if builderWin then return end

    -- ── Main window ──────────────────────────────────────────────────────────
    local win = CreateFrame("Frame", "RHProfileBuilder", UIParent, "BackdropTemplate")
    win:SetSize(BUILDER_W, BUILDER_H)
    win:SetFrameStrata("DIALOG")
    win:SetClampedToScreen(true)
    win:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    win:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = false, tileSize = 0, edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    win:SetBackdropColor(0.04, 0.04, 0.07, 0.97)
    win:SetBackdropBorderColor(0.20, 0.20, 0.26, 0.9)
    win:SetMovable(true)
    win:EnableMouse(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", function(self) self:StartMoving() end)
    win:SetScript("OnDragStop",  function(self) self:StopMovingOrSizing() end)
    win:Hide()
    builderWin = win

    -- Title
    local titleLabel = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    titleLabel:SetPoint("TOP", win, "TOP", 0, -10)
    titleLabel:SetTextColor(0.85, 0.75, 0.40)
    self.builderTitle = titleLabel

    -- Close button
    local closeBtn = CreateFrame("Button", nil, win)
    closeBtn:SetSize(16, 16)
    closeBtn:SetPoint("TOPRIGHT", win, "TOPRIGHT", -8, -7)
    local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    closeLbl:SetAllPoints()
    closeLbl:SetText("×")
    closeLbl:SetTextColor(0.6, 0.6, 0.6)
    closeBtn:SetScript("OnEnter", function() closeLbl:SetTextColor(1, 0.3, 0.3) end)
    closeBtn:SetScript("OnLeave", function() closeLbl:SetTextColor(0.6, 0.6, 0.6) end)
    closeBtn:SetScript("OnClick", function()
        win:Hide()
        CloseSpellPicker()
    end)

    -- Divider below title
    local div1 = win:CreateTexture(nil, "ARTWORK")
    div1:SetHeight(1)
    div1:SetPoint("TOPLEFT",  win, "TOPLEFT",  8, -26)
    div1:SetPoint("TOPRIGHT", win, "TOPRIGHT", -8, -26)
    div1:SetColorTexture(0.20, 0.20, 0.26, 0.8)

    -- Instruction hint
    local hintLabel = win:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    hintLabel:SetPoint("TOPLEFT", win, "TOPLEFT", 14, -32)
    hintLabel:SetText("Click [ + ] to add spells. Click an icon to change it. Mouse-wheel or scrollbar to scroll.")
    hintLabel:SetTextColor(0.45, 0.45, 0.50)

    -- ── Timeline scroll area ──────────────────────────────────────────────────
    local TIMELINE_H = 140
    local SCROLL_PAD = 22
    local scrollW    = BUILDER_W - SCROLL_PAD * 2

    local sf = CreateFrame("ScrollFrame", nil, win)
    sf:SetSize(scrollW, TIMELINE_H)
    sf:SetPoint("TOPLEFT", win, "TOPLEFT", SCROLL_PAD, -46)
    self.builderScrollFrame = sf

    local content = CreateFrame("Frame", nil, sf)
    content:SetHeight(TIMELINE_H)
    content:SetWidth(scrollW)
    sf:SetScrollChild(content)
    self.builderContent = content

    -- Horizontal scrollbar below the timeline
    local scrollBar = CreateFrame("Slider", nil, win)
    scrollBar:SetOrientation("HORIZONTAL")
    scrollBar:SetSize(scrollW, 10)
    scrollBar:SetPoint("TOP", sf, "BOTTOM", 0, -5)
    scrollBar:SetMinMaxValues(0, 0)
    scrollBar:SetValue(0)
    scrollBar:SetObeyStepOnDrag(true)

    local sbTrack = scrollBar:CreateTexture(nil, "BACKGROUND")
    sbTrack:SetAllPoints()
    sbTrack:SetColorTexture(0.07, 0.07, 0.10, 1)

    local sbThumb = scrollBar:CreateTexture(nil, "ARTWORK")
    sbThumb:SetSize(36, 8)
    sbThumb:SetColorTexture(0.35, 0.35, 0.46, 0.9)
    scrollBar:SetThumbTexture(sbThumb)

    self.builderScrollBar = scrollBar

    local sbUpdating = false
    scrollBar:SetScript("OnValueChanged", function(self, value)
        if sbUpdating then return end
        sf:SetHorizontalScroll(value)
    end)

    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", function(self, delta)
        local cur = self:GetHorizontalScroll()
        local max = self:GetHorizontalScrollRange()
        local newVal = math.max(0, math.min(max, cur - delta * 92))
        self:SetHorizontalScroll(newVal)
        sbUpdating = true
        scrollBar:SetValue(newVal)
        sbUpdating = false
    end)

    -- ── Pre-allocate step slot frames ─────────────────────────────────────────
    -- Each "column" is SLOT_W (68px) wide; arrow FontString follows each filled slot.
    -- Layout per step: [6px pad][56x56 icon][6px pad] → arrow(24px) → next slot
    for i = 1, MAX_STEPS do
        local col = CreateFrame("Frame", nil, content)
        col:SetSize(SLOT_W, TIMELINE_H)
        col:Hide()

        -- Spell icon button (56×56, centered in 68px column)
        local iconFrame = CreateFrame("Button", nil, col)
        iconFrame:SetSize(56, 56)
        iconFrame:SetPoint("TOP", col, "TOP", 0, -4)

        local iconTex = iconFrame:CreateTexture(nil, "ARTWORK")
        iconTex:SetAllPoints()
        iconTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        iconFrame.iconTex = iconTex

        -- Hover darkening overlay
        local hoverTex = iconFrame:CreateTexture(nil, "OVERLAY")
        hoverTex:SetAllPoints()
        hoverTex:SetColorTexture(0, 0, 0, 0)
        iconFrame:SetScript("OnEnter", function()
            hoverTex:SetColorTexture(0, 0, 0, 0.35)
        end)
        iconFrame:SetScript("OnLeave", function()
            hoverTex:SetColorTexture(0, 0, 0, 0)
        end)

        -- Count badge (bottom-right corner of icon)
        local badge = iconFrame:CreateFontString(nil, "OVERLAY")
        badge:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
        badge:SetPoint("BOTTOMRIGHT", iconFrame, "BOTTOMRIGHT", -2, 2)
        badge:SetTextColor(1, 0.82, 0)
        iconFrame.badge = badge

        -- Remove button (top-right of icon, slightly outside)
        local removeBtn = CreateFrame("Button", nil, col)
        removeBtn:SetSize(22, 22)
        removeBtn:SetPoint("TOPRIGHT", iconFrame, "TOPRIGHT", 6, 6)
        removeBtn:SetFrameLevel(col:GetFrameLevel() + 4)
        local remLbl = removeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        remLbl:SetAllPoints()
        remLbl:SetText("×")
        remLbl:SetTextColor(0.8, 0.2, 0.2)
        removeBtn:SetScript("OnEnter", function() remLbl:SetTextColor(1, 0.1, 0.1) end)
        removeBtn:SetScript("OnLeave", function() remLbl:SetTextColor(0.8, 0.2, 0.2) end)

        -- Spell name label (below icon)
        local nameLabel = col:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
        nameLabel:SetPoint("TOPLEFT",  col, "TOPLEFT",  1, -65)
        nameLabel:SetPoint("TOPRIGHT", col, "TOPRIGHT", -1, -65)
        nameLabel:SetJustifyH("CENTER")
        nameLabel:SetWordWrap(false)
        nameLabel:SetTextColor(0.80, 0.80, 0.80)

        -- Count area: [-] N [+] centered in 68px column
        local minusBtn = CreateFrame("Button", nil, col)
        minusBtn:SetSize(18, 16)
        minusBtn:SetPoint("TOPLEFT", col, "TOPLEFT", 3, -86)
        local minusLbl = minusBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        minusLbl:SetAllPoints()
        minusLbl:SetText("-")
        minusLbl:SetTextColor(0.65, 0.65, 0.72)
        minusBtn:SetScript("OnEnter", function() minusLbl:SetTextColor(1, 1, 1) end)
        minusBtn:SetScript("OnLeave", function() minusLbl:SetTextColor(0.65, 0.65, 0.72) end)

        local countLabel = col:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        countLabel:SetSize(26, 16)
        countLabel:SetPoint("TOPLEFT", col, "TOPLEFT", 21, -86)
        countLabel:SetJustifyH("CENTER")
        countLabel:SetTextColor(1, 1, 1)

        local plusBtn = CreateFrame("Button", nil, col)
        plusBtn:SetSize(18, 16)
        plusBtn:SetPoint("TOPLEFT", col, "TOPLEFT", 47, -86)
        local plusLbl = plusBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        plusLbl:SetAllPoints()
        plusLbl:SetText("+")
        plusLbl:SetTextColor(0.65, 0.65, 0.72)
        plusBtn:SetScript("OnEnter", function() plusLbl:SetTextColor(1, 1, 1) end)
        plusBtn:SetScript("OnLeave", function() plusLbl:SetTextColor(0.65, 0.65, 0.72) end)

        stepFrames[i] = {
            frame      = col,
            iconFrame  = iconFrame,
            iconTex    = iconTex,
            badge      = iconFrame.badge,
            nameLabel  = nameLabel,
            countLabel = countLabel,
            minusBtn   = minusBtn,
            plusBtn    = plusBtn,
            removeBtn  = removeBtn,
        }

        -- Arrow FontString after this slot
        local arrow = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        arrow:SetFont("Fonts\\FRIZQT__.TTF", 16, "OUTLINE")
        arrow:SetText(">>>")
        arrow:SetTextColor(0.28, 0.28, 0.35)
        arrow:Hide()
        arrowLabels[i] = arrow
    end

    -- ── Add-slot button ───────────────────────────────────────────────────────
    local addSlot = CreateFrame("Button", nil, content, "BackdropTemplate")
    addSlot:SetSize(56, 56)
    addSlot:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = false, tileSize = 0, edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    addSlot:SetBackdropColor(0.08, 0.08, 0.12, 1)
    addSlot:SetBackdropBorderColor(0.25, 0.25, 0.32, 1)

    local addLbl = addSlot:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    addLbl:SetAllPoints()
    addLbl:SetJustifyH("CENTER")
    addLbl:SetJustifyV("MIDDLE")
    addLbl:SetText("+")
    addLbl:SetTextColor(0.38, 0.38, 0.46)
    addSlot:SetScript("OnEnter", function()
        addLbl:SetTextColor(0.85, 0.75, 0.40)
        addSlot:SetBackdropBorderColor(0.55, 0.50, 0.28, 1)
    end)
    addSlot:SetScript("OnLeave", function()
        addLbl:SetTextColor(0.38, 0.38, 0.46)
        addSlot:SetBackdropBorderColor(0.25, 0.25, 0.32, 1)
    end)
    addSlot:SetScript("OnClick", function()
        if #builderSteps >= MAX_STEPS then return end
        OpenSpellPicker(function(spellID)
            local info = C_Spell.GetSpellInfo(spellID)
            if info then
                builderSteps[#builderSteps+1] = {
                    spellID = spellID,
                    name    = info.name,
                    iconID  = info.iconID,
                    count   = 1,
                }
                RebuildTimeline()
            end
        end)
    end)
    addSlotFrame = addSlot

    -- ── Bottom bar ────────────────────────────────────────────────────────────
    local div2 = win:CreateTexture(nil, "ARTWORK")
    div2:SetHeight(1)
    div2:SetPoint("BOTTOMLEFT",  win, "BOTTOMLEFT",   8, 52)
    div2:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", -8, 52)
    div2:SetColorTexture(0.20, 0.20, 0.26, 0.8)

    local nameLabel2 = win:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    nameLabel2:SetPoint("BOTTOMLEFT", win, "BOTTOMLEFT", 14, 36)
    nameLabel2:SetText("Profile name:")
    nameLabel2:SetTextColor(0.55, 0.55, 0.60)

    local nameInput = CreateFrame("EditBox", nil, win, "InputBoxTemplate")
    nameInput:SetSize(200, 22)
    nameInput:SetPoint("BOTTOMLEFT", win, "BOTTOMLEFT", 14, 12)
    nameInput:SetAutoFocus(false)
    nameInput:SetMaxLetters(48)
    self.builderNameInput = nameInput

    local feedbackLbl = win:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    feedbackLbl:SetPoint("BOTTOMLEFT", nameInput, "TOPLEFT", 0, 2)
    feedbackLbl:SetTextColor(0.9, 0.35, 0.35)
    feedbackLbl:SetText("")
    self.builderFeedback = feedbackLbl
    local feedbackTimer = nil
    local function ShowFeedback(msg)
        feedbackLbl:SetText(msg)
        if feedbackTimer then feedbackTimer:Cancel() end
        feedbackTimer = C_Timer.NewTimer(3, function()
            feedbackLbl:SetText("")
            feedbackTimer = nil
        end)
    end

    local saveBtn = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    saveBtn:SetSize(72, 24)
    saveBtn:SetPoint("BOTTOMLEFT", nameInput, "BOTTOMRIGHT", 8, 0)
    saveBtn:SetText("Save")
    saveBtn:SetScript("OnClick", function()
        local profileName = nameInput:GetText():trim()
        if profileName == "" then
            ShowFeedback("Enter a profile name.")
            return
        end
        if #builderSteps == 0 then
            ShowFeedback("Add at least one spell.")
            return
        end
        -- If editing and name changed, delete the old entry
        if builderEditName and builderEditName ~= profileName then
            ManualRotation:DeleteProfile(builderEditName)
        end
        -- Save steps (spellID + count) into DB
        local steps = {}
        for _, s in ipairs(builderSteps) do
            steps[#steps+1] = {
                spellID = s.spellID,
                count   = s.count,
            }
        end
        ManualRotation:SaveProfile(profileName, steps)
        -- Auto-select the saved profile and refresh the options tab
        RH.db.activeManualProfile = profileName
        local op = RH.modules.OptionsPanel
        if op and op.RefreshManualTab then op:RefreshManualTab() end
        win:Hide()
        CloseSpellPicker()
    end)

    local cancelBtn = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    cancelBtn:SetSize(72, 24)
    cancelBtn:SetPoint("BOTTOMLEFT", saveBtn, "BOTTOMRIGHT", 6, 0)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetScript("OnClick", function()
        win:Hide()
        CloseSpellPicker()
    end)

    -- ── RebuildTimeline closure ───────────────────────────────────────────────
    RebuildTimeline = function()
        local steps = builderSteps
        local n     = #steps
        local x     = 0

        for i = 1, MAX_STEPS do
            local sf_ref = stepFrames[i]
            local step   = steps[i]

            if step then
                sf_ref.frame:ClearAllPoints()
                sf_ref.frame:SetPoint("TOPLEFT", content, "TOPLEFT", x, 0)
                sf_ref.iconTex:SetTexture(step.iconID)
                sf_ref.badge:SetText("×" .. step.count)
                sf_ref.nameLabel:SetText(step.name)
                sf_ref.countLabel:SetText(tostring(step.count))
                sf_ref.frame:Show()

                -- Wire buttons — capture i as local idx to avoid the loop upvalue bug
                local idx = i
                sf_ref.minusBtn:SetScript("OnClick", function()
                    if builderSteps[idx] and builderSteps[idx].count > 1 then
                        builderSteps[idx].count = builderSteps[idx].count - 1
                        RebuildTimeline()
                    end
                end)
                sf_ref.plusBtn:SetScript("OnClick", function()
                    if builderSteps[idx] and builderSteps[idx].count < MAX_COUNT then
                        builderSteps[idx].count = builderSteps[idx].count + 1
                        RebuildTimeline()
                    end
                end)
                sf_ref.removeBtn:SetScript("OnClick", function()
                    table.remove(builderSteps, idx)
                    RebuildTimeline()
                end)
                sf_ref.iconFrame:SetScript("OnClick", function()
                    -- Re-pick a different spell for this slot
                    OpenSpellPicker(function(spellID)
                        local info = C_Spell.GetSpellInfo(spellID)
                        if info and builderSteps[idx] then
                            builderSteps[idx].spellID = spellID
                            builderSteps[idx].name    = info.name
                            builderSteps[idx].iconID  = info.iconID
                            RebuildTimeline()
                        end
                    end)
                end)
                x = x + SLOT_W

                -- Arrow between this slot and the next content (step or add button)
                local arrow = arrowLabels[i]
                arrow:ClearAllPoints()
                arrow:SetPoint("TOPLEFT", content, "TOPLEFT", x + 4, -26)
                arrow:Show()
                x = x + ARROW_W
            else
                sf_ref.frame:Hide()
                arrowLabels[i]:Hide()
            end
        end

        -- Add-slot position (always follows the last arrow / slot)
        addSlotFrame:ClearAllPoints()
        addSlotFrame:SetPoint("TOPLEFT", content, "TOPLEFT", x + (n > 0 and 0 or 6), -4)
        addSlotFrame:SetShown(n < MAX_STEPS)

        -- Grow the content frame to fit all slots + add button
        local totalW = x + 56 + 6
        content:SetWidth(math.max(totalW, scrollW))

        -- Update scrollbar range to match new content width
        local range = math.max(0, totalW - scrollW)
        scrollBar:SetMinMaxValues(0, range)
        -- Clamp current scroll position into new range
        local curScroll = sf:GetHorizontalScroll()
        if curScroll > range then
            sf:SetHorizontalScroll(range)
            sbUpdating = true
            scrollBar:SetValue(range)
            sbUpdating = false
        end
        scrollBar:SetShown(range > 0)
    end
end

-- ── Spell picker ──────────────────────────────────────────────────────────────

local pickerCallback = nil
local allSpells      = {}
local PICKER_ROW_H   = 24
local MAX_PICKER_ROWS = 50

OpenSpellPicker = function(callback)
    pickerCallback = callback

    if not pickerWin then
        local pw = CreateFrame("Frame", "RHSpellPicker", UIParent, "BackdropTemplate")
        pw:SetSize(PICKER_W, PICKER_H)
        pw:SetFrameStrata("FULLSCREEN_DIALOG")
        pw:SetClampedToScreen(true)
        pw:SetPoint("LEFT", builderWin, "RIGHT", 6, 0)
        pw:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            tile = false, tileSize = 0, edgeSize = 1,
            insets = { left = 1, right = 1, top = 1, bottom = 1 },
        })
        pw:SetBackdropColor(0.04, 0.04, 0.07, 0.97)
        pw:SetBackdropBorderColor(0.20, 0.20, 0.26, 0.9)
        pw:Hide()
        pickerWin = pw

        local ptitle = pw:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        ptitle:SetPoint("TOP", pw, "TOP", 0, -8)
        ptitle:SetText("Select Spell")
        ptitle:SetTextColor(0.85, 0.75, 0.40)

        local pdiv = pw:CreateTexture(nil, "ARTWORK")
        pdiv:SetHeight(1)
        pdiv:SetPoint("TOPLEFT",  pw, "TOPLEFT",  6, -20)
        pdiv:SetPoint("TOPRIGHT", pw, "TOPRIGHT", -6, -20)
        pdiv:SetColorTexture(0.20, 0.20, 0.26, 0.8)

        -- Search box
        local searchBox = CreateFrame("EditBox", nil, pw, "InputBoxTemplate")
        searchBox:SetSize(PICKER_W - 20, 20)
        searchBox:SetPoint("TOPLEFT", pw, "TOPLEFT", 10, -28)
        searchBox:SetAutoFocus(true)
        searchBox:SetMaxLetters(40)

        -- Scroll frame
        local psf = CreateFrame("ScrollFrame", nil, pw, "UIPanelScrollFrameTemplate")
        psf:SetPoint("TOPLEFT",     pw, "TOPLEFT",  6,  -54)
        psf:SetPoint("BOTTOMRIGHT", pw, "BOTTOMRIGHT", -24, 50)

        local pContent = CreateFrame("Frame", nil, psf)
        pContent:SetWidth(PICKER_W - 32)
        pContent:SetHeight(PICKER_ROW_H * MAX_PICKER_ROWS)
        psf:SetScrollChild(pContent)

        -- Pre-allocate row buttons
        local rowBtns = {}
        for r = 1, MAX_PICKER_ROWS do
            local row = CreateFrame("Button", nil, pContent)
            row:SetSize(PICKER_W - 32, PICKER_ROW_H)
            row:SetPoint("TOPLEFT", pContent, "TOPLEFT", 0, -(r - 1) * PICKER_ROW_H)
            row:Hide()

            local rowBg = row:CreateTexture(nil, "BACKGROUND")
            rowBg:SetAllPoints()
            rowBg:SetColorTexture(0, 0, 0, 0)

            local rowIcon = row:CreateTexture(nil, "ARTWORK")
            rowIcon:SetSize(20, 20)
            rowIcon:SetPoint("LEFT", row, "LEFT", 4, 0)
            rowIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            row.iconTex = rowIcon

            local rowLabel = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            rowLabel:SetPoint("LEFT", row, "LEFT", 28, 0)
            rowLabel:SetPoint("RIGHT", row, "RIGHT", -4, 0)
            rowLabel:SetJustifyH("LEFT")
            rowLabel:SetTextColor(0.88, 0.88, 0.88)
            row.label = rowLabel

            row:SetScript("OnEnter", function() rowBg:SetColorTexture(0.20, 0.20, 0.30, 0.55) end)
            row:SetScript("OnLeave", function() rowBg:SetColorTexture(0, 0, 0, 0) end)

            rowBtns[r] = row
        end

        local function RebuildPickerList(filter)
            filter = filter and filter:lower() or ""
            local filtered = {}
            for _, s in ipairs(allSpells) do
                if filter == "" or s.name:lower():find(filter, 1, true) then
                    filtered[#filtered+1] = s
                end
            end
            pContent:SetHeight(math.max(#filtered * PICKER_ROW_H, 1))
            for r = 1, MAX_PICKER_ROWS do
                local spell = filtered[r]
                local row   = rowBtns[r]
                if spell then
                    row.iconTex:SetTexture(spell.iconID)
                    row.label:SetText(spell.name)
                    row:SetScript("OnClick", function()
                        if pickerCallback then
                            pickerCallback(spell.spellID)
                        end
                        pickerCallback = nil
                        pw:Hide()
                    end)
                    row:Show()
                else
                    row:Hide()
                end
            end
        end

        searchBox:SetScript("OnTextChanged", function(self)
            RebuildPickerList(self:GetText())
        end)
        searchBox:SetScript("OnEscapePressed", function()
            pw:Hide()
            pickerCallback = nil
        end)

        pw:SetScript("OnShow", function()
            allSpells = GetKnownSpells()
            searchBox:SetText("")
            searchBox:SetFocus()
            RebuildPickerList("")
        end)

        -- ── Manual spell ID entry ──────────────────────────────────────────
        -- Allows adding proc/combo spells that don't appear in the spellbook
        -- while inactive (e.g. DH Death Sweep, Rogues' Ambush via Opportunity).

        local idDiv = pw:CreateTexture(nil, "ARTWORK")
        idDiv:SetHeight(1)
        idDiv:SetPoint("BOTTOMLEFT",  pw, "BOTTOMLEFT",  6, 48)
        idDiv:SetPoint("BOTTOMRIGHT", pw, "BOTTOMRIGHT", -6, 48)
        idDiv:SetColorTexture(0.20, 0.20, 0.26, 0.8)

        local idHint = pw:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
        idHint:SetPoint("BOTTOMLEFT", pw, "BOTTOMLEFT", 8, 34)
        idHint:SetText("Add by spell ID:")
        idHint:SetTextColor(0.45, 0.45, 0.50)

        local idBox = CreateFrame("EditBox", nil, pw, "InputBoxTemplate")
        idBox:SetSize(74, 18)
        idBox:SetPoint("BOTTOMLEFT", pw, "BOTTOMLEFT", 8, 12)
        idBox:SetAutoFocus(false)
        idBox:SetMaxLetters(8)
        idBox:SetNumeric(true)

        local idAddBtn = CreateFrame("Button", nil, pw, "UIPanelButtonTemplate")
        idAddBtn:SetSize(48, 20)
        idAddBtn:SetPoint("LEFT", idBox, "RIGHT", 4, 0)
        idAddBtn:SetText("Add")

        local idFeedback = pw:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
        idFeedback:SetPoint("LEFT", idAddBtn, "RIGHT", 4, 0)
        idFeedback:SetTextColor(0.9, 0.35, 0.35)
        idFeedback:SetText("")

        local idFeedbackTimer = nil
        local function ShowIDFeedback(msg)
            idFeedback:SetText(msg)
            if idFeedbackTimer then idFeedbackTimer:Cancel() end
            idFeedbackTimer = C_Timer.NewTimer(2, function()
                idFeedback:SetText("")
                idFeedbackTimer = nil
            end)
        end

        local function TryAddByID()
            local spellID = tonumber(idBox:GetText())
            if not spellID then ShowIDFeedback("Invalid ID"); return end
            local info = C_Spell.GetSpellInfo(spellID)
            if not info or not info.name then
                ShowIDFeedback("Unknown spell")
                return
            end
            if pickerCallback then pickerCallback(spellID) end
            pickerCallback = nil
            idBox:SetText("")
            idFeedback:SetText("")
            pw:Hide()
        end

        idAddBtn:SetScript("OnClick", TryAddByID)
        idBox:SetScript("OnEnterPressed", function(self)
            TryAddByID()
            self:ClearFocus()
        end)
        idBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
    end

    pickerWin:Show()
    pickerWin:Raise()
end

CloseSpellPicker = function()
    if pickerWin then pickerWin:Hide() end
    pickerCallback = nil
end

-- ── Share dialog ──────────────────────────────────────────────────────────────

local shareWin = nil

function ManualRotation:OpenShareDialog(name)
    local str = self:SerializeProfile(name)
    if not str then return end

    if not shareWin then
        local w = CreateFrame("Frame", "RHShareDialog", UIParent, "BackdropTemplate")
        w:SetSize(480, 110)
        w:SetFrameStrata("DIALOG")
        w:SetClampedToScreen(true)
        w:SetPoint("CENTER", UIParent, "CENTER", 0, 60)
        w:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            tile = false, tileSize = 0, edgeSize = 1,
            insets = { left = 1, right = 1, top = 1, bottom = 1 },
        })
        w:SetBackdropColor(0.04, 0.04, 0.07, 0.97)
        w:SetBackdropBorderColor(0.20, 0.20, 0.26, 0.9)
        w:SetMovable(true)
        w:EnableMouse(true)
        w:RegisterForDrag("LeftButton")
        w:SetScript("OnDragStart", function(self) self:StartMoving() end)
        w:SetScript("OnDragStop",  function(self) self:StopMovingOrSizing() end)
        w:Hide()
        shareWin = w

        local title = w:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        title:SetPoint("TOP", w, "TOP", 0, -8)
        title:SetText("Share Profile — select all and copy (Ctrl+A, Ctrl+C)")
        title:SetTextColor(0.85, 0.75, 0.40)

        local closeBtn = CreateFrame("Button", nil, w)
        closeBtn:SetSize(16, 16)
        closeBtn:SetPoint("TOPRIGHT", w, "TOPRIGHT", -8, -6)
        local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        closeLbl:SetAllPoints()
        closeLbl:SetText("×")
        closeLbl:SetTextColor(0.6, 0.6, 0.6)
        closeBtn:SetScript("OnEnter", function() closeLbl:SetTextColor(1, 0.3, 0.3) end)
        closeBtn:SetScript("OnLeave", function() closeLbl:SetTextColor(0.6, 0.6, 0.6) end)
        closeBtn:SetScript("OnClick", function() w:Hide() end)

        local eb = CreateFrame("EditBox", nil, w, "InputBoxTemplate")
        eb:SetSize(456, 22)
        eb:SetPoint("TOP", w, "TOP", 0, -32)
        eb:SetAutoFocus(true)
        eb:SetMaxLetters(0)
        w.editBox = eb
        eb:SetScript("OnEscapePressed", function() w:Hide() end)
        eb:SetScript("OnShow", function(self)
            self:SetFocus()
            self:HighlightText()
        end)

        local hint = w:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
        hint:SetPoint("TOP", eb, "BOTTOM", 0, -8)
        hint:SetText("This string encodes your profile. Paste it into the Import box on another character.")
        hint:SetTextColor(0.45, 0.45, 0.52)
    end

    shareWin.editBox:SetText(str)
    shareWin:Show()
    shareWin:Raise()
    shareWin.editBox:SetFocus()
    shareWin.editBox:HighlightText()
end

-- ── Import dialog ─────────────────────────────────────────────────────────────

local importWin = nil

function ManualRotation:OpenImportDialog()
    if not importWin then
        local w = CreateFrame("Frame", "RHImportDialog", UIParent, "BackdropTemplate")
        w:SetSize(480, 130)
        w:SetFrameStrata("DIALOG")
        w:SetClampedToScreen(true)
        w:SetPoint("CENTER", UIParent, "CENTER", 0, 60)
        w:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            tile = false, tileSize = 0, edgeSize = 1,
            insets = { left = 1, right = 1, top = 1, bottom = 1 },
        })
        w:SetBackdropColor(0.04, 0.04, 0.07, 0.97)
        w:SetBackdropBorderColor(0.20, 0.20, 0.26, 0.9)
        w:SetMovable(true)
        w:EnableMouse(true)
        w:RegisterForDrag("LeftButton")
        w:SetScript("OnDragStart", function(self) self:StartMoving() end)
        w:SetScript("OnDragStop",  function(self) self:StopMovingOrSizing() end)
        w:Hide()
        importWin = w

        local title = w:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        title:SetPoint("TOP", w, "TOP", 0, -8)
        title:SetText("Import Profile — paste share string below")
        title:SetTextColor(0.85, 0.75, 0.40)

        local closeBtn = CreateFrame("Button", nil, w)
        closeBtn:SetSize(16, 16)
        closeBtn:SetPoint("TOPRIGHT", w, "TOPRIGHT", -8, -6)
        local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        closeLbl:SetAllPoints()
        closeLbl:SetText("×")
        closeLbl:SetTextColor(0.6, 0.6, 0.6)
        closeBtn:SetScript("OnEnter", function() closeLbl:SetTextColor(1, 0.3, 0.3) end)
        closeBtn:SetScript("OnLeave", function() closeLbl:SetTextColor(0.6, 0.6, 0.6) end)
        closeBtn:SetScript("OnClick", function() w:Hide() end)

        local eb = CreateFrame("EditBox", nil, w, "InputBoxTemplate")
        eb:SetSize(456, 22)
        eb:SetPoint("TOP", w, "TOP", 0, -32)
        eb:SetAutoFocus(true)
        eb:SetMaxLetters(0)
        w.editBox = eb
        eb:SetScript("OnEscapePressed", function() w:Hide() end)

        local feedback = w:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
        feedback:SetPoint("TOP", eb, "BOTTOM", 0, -6)
        feedback:SetText("")
        w.feedback = feedback
        local feedbackTimer = nil
        local function ShowFeedback(msg, isError)
            feedback:SetText(msg)
            feedback:SetTextColor(isError and 0.9 or 0.35, isError and 0.35 or 0.85, 0.35)
            if feedbackTimer then feedbackTimer:Cancel() end
            feedbackTimer = C_Timer.NewTimer(3, function()
                feedback:SetText("")
                feedbackTimer = nil
            end)
        end

        local importBtn = CreateFrame("Button", nil, w, "UIPanelButtonTemplate")
        importBtn:SetSize(80, 24)
        importBtn:SetPoint("BOTTOMLEFT", w, "BOTTOMLEFT", 14, 12)
        importBtn:SetText("Import")
        importBtn:SetScript("OnClick", function()
            local str = eb:GetText()
            local data, err = ManualRotation:DeserializeProfile(str)
            if not data then
                ShowFeedback(err or "Invalid string.", true)
                return
            end
            -- Overwrite if a profile with that name already exists
            if not RH.db.manualProfiles then RH.db.manualProfiles = {} end
            RH.db.manualProfiles[data.name] = { specID = data.specID, steps = data.steps }
            ShowFeedback("Imported: " .. data.name, false)
            eb:SetText("")
            local op = RH.modules.OptionsPanel
            if op and op.RefreshManualTab then op:RefreshManualTab() end
        end)

        local cancelBtn = CreateFrame("Button", nil, w, "UIPanelButtonTemplate")
        cancelBtn:SetSize(80, 24)
        cancelBtn:SetPoint("BOTTOMLEFT", importBtn, "BOTTOMRIGHT", 6, 0)
        cancelBtn:SetText("Close")
        cancelBtn:SetScript("OnClick", function() w:Hide() end)
    end

    importWin.editBox:SetText("")
    importWin.feedback:SetText("")
    importWin:Show()
    importWin:Raise()
    importWin.editBox:SetFocus()
end

-- ── Open builder (new profile or edit existing) ───────────────────────────────

function ManualRotation:OpenBuilder(editName)
    if not builderWin then
        self:CreateBuilderWindow()
    end

    builderSteps    = {}
    builderEditName = editName

    if editName then
        -- Pre-populate from saved profile
        local profile = RH.db.manualProfiles and RH.db.manualProfiles[editName]
        if profile and profile.steps then
            for _, s in ipairs(profile.steps) do
                local info = C_Spell.GetSpellInfo(s.spellID)
                builderSteps[#builderSteps+1] = {
                    spellID = s.spellID,
                    name    = info and info.name or ("Spell " .. s.spellID),
                    iconID  = info and info.iconID or nil,
                    count   = s.count,
                }
            end
        end
        self.builderTitle:SetText("Edit Profile: " .. editName)
        self.builderNameInput:SetText(editName)
    else
        self.builderTitle:SetText("New Profile")
        self.builderNameInput:SetText("")
    end

    RebuildTimeline()
    builderWin:Show()
    builderWin:Raise()
end
