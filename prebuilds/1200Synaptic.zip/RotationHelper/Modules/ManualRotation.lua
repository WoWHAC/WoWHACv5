local RH = RotationHelper

local ManualRotation = {}
RH:RegisterModule("ManualRotation", ManualRotation)

-- ── Constants ───────────────────────────────────────────────────────────────

local MAX_STEPS = 20     -- hard cap on steps per profile
local MAX_COUNT = 10     -- max casts per step

-- Expose for ManualRotationUI.lua
ManualRotation.MAX_STEPS = MAX_STEPS
ManualRotation.MAX_COUNT = MAX_COUNT

-- ── Engine state ────────────────────────────────────────────────────────────

local stepIndex          = 1
local stepRemaining      = 0
local lastDisplaySpellID = nil
local lastDisplayRemain  = nil

-- spellID → GetTime() timestamp when cooldown expires.
-- Updated by TryAdvance (on cast) and seeded by LoadProfile from the live API.
-- Used instead of C_Spell.GetSpellCooldown comparisons, which throw on tainted
-- "secret numbers" during combat in Midnight.
local manualCooldownEnd  = {}

-- Returns the spell's base cooldown in seconds (static, never tainted).
-- Returns 0 for GCD-only spells (base CD == 0 or <= 1500ms).
local function GetBaseCD(spellID)
    local ms = GetSpellBaseCooldown(spellID)
    return (ms and ms > 1500) and (ms / 1000) or 0
end

-- Seeds manualCooldownEnd for every step in the given profile.
-- Must only be called outside combat — C_Spell.GetSpellCooldown values are
-- not tainted then, so we can read the real (talent-modified) cooldown.
local function SeedProfileCooldowns(profile)
    if not profile or not profile.steps then return end
    for _, step in ipairs(profile.steps) do
        local spellID = step.spellID
        if spellID then
            local seeded = false
            pcall(function()
                local info = C_Spell.GetSpellCooldown(spellID)
                if info and info.duration and info.startTime then
                    if info.duration > 1.5 then
                        manualCooldownEnd[spellID] = info.startTime + info.duration
                        seeded = true
                    end
                end
            end)
            if not seeded then
                manualCooldownEnd[spellID] = nil  -- not on CD, clear any stale entry
            end
        end
    end
end

-- ── Spell override helpers ───────────────────────────────────────────────────
-- Handles proc-based spell transformations (e.g. Festering Strike → Festering
-- Scythe, Sinister Strike → Ambush via Opportunity, etc.) for all classes.

-- Returns the spell currently overriding baseID (the proc'd version),
-- or baseID itself if no override is active.
local function GetDisplaySpell(spellID)
    local display = spellID
    pcall(function()
        local o = FindSpellOverrideByID(spellID)
        if o and o ~= 0 and o ~= spellID then display = o end
    end)
    return display
end

-- Returns the base spell that was overridden to produce overrideID,
-- or overrideID itself if it has no base (i.e. it is not a proc override).
local function GetBaseSpell(spellID)
    local base = spellID
    pcall(function()
        local b = FindBaseSpellByID(spellID)
        if b and b ~= 0 and b ~= spellID then base = b end
    end)
    return base
end

-- ── Profile management ──────────────────────────────────────────────────────

function ManualRotation:GetProfilesForSpec(specID)
    local result = {}
    for name, profile in pairs(RH.db.manualProfiles or {}) do
        if profile.specID == specID then
            result[#result+1] = name
        end
    end
    table.sort(result)
    return result
end

function ManualRotation:SaveProfile(name, steps)
    local specID = RH:GetSpecID()
    if not specID then return end
    if not RH.db.manualProfiles then RH.db.manualProfiles = {} end
    RH.db.manualProfiles[name] = { specID = specID, steps = steps }
end

function ManualRotation:DeleteProfile(name)
    if not RH.db.manualProfiles then return end
    RH.db.manualProfiles[name] = nil
    if RH.db.activeManualProfile == name then
        RH.db.activeManualProfile = nil
        RH.db.manualMode          = false
        lastDisplaySpellID        = nil
        lastDisplayRemain         = nil
    end
end

function ManualRotation:LoadProfile(name)
    RH.db.activeManualProfile = name
    stepIndex          = 1
    lastDisplaySpellID = nil
    lastDisplayRemain  = nil
    wipe(manualCooldownEnd)
    local profile = RH.db.manualProfiles and RH.db.manualProfiles[name]
    stepRemaining = (profile and profile.steps and profile.steps[1]
                    and profile.steps[1].count) or 1
    -- Seed accurate cooldown end times from the live API.
    -- Safe here (called outside combat); values are not tainted.
    SeedProfileCooldowns(profile)
end

-- ── Validation ──────────────────────────────────────────────────────────────

-- Returns true if every step's spell is on an action bar slot.
-- Returns false + table of missing spellIDs otherwise.
-- Skipped entirely when ignoreBarValidation is set (e.g. macro-based rotations).
function ManualRotation:ValidateProfile()
    local name = RH.db.activeManualProfile
    if not name then return false, {} end
    local profile = RH.db.manualProfiles and RH.db.manualProfiles[name]
    if not profile or not profile.steps or #profile.steps == 0 then
        return false, {}
    end

    if RH.db.ignoreBarValidation then return true, {} end

    local missing = {}
    for _, step in ipairs(profile.steps) do
        local found = false
        -- Also resolve what the step spell currently transforms into (proc active).
        -- GetActionInfo returns the override ID while the proc is up, so we need
        -- to match against both the base spell and its active proc form.
        local procForm = GetDisplaySpell(step.spellID)

        -- Helper: check a macro body for a /cast line containing the step spell.
        -- Strips [conditional] blocks and handles semicolon fallback targets.
        local spellInfo = C_Spell.GetSpellInfo(step.spellID)
        local spellName = spellInfo and spellInfo.name
        local spellLower = spellName and spellName:lower()

        local function CheckMacroBody(body)
            if not spellLower or not body or body == "" then return false end
            for line in body:gmatch("[^\n]+") do
                local castPart = line:match("^%s*/?cast%s+(.+)$")
                if castPart then
                    local stripped = castPart:gsub("%[.-%]", "")
                    for part in stripped:gmatch("[^;]+") do
                        local trimmed = part:match("^%s*(.-)%s*$")
                        if trimmed and trimmed:lower() == spellLower then
                            return true
                        end
                    end
                end
            end
            return false
        end

        -- Pass 1: scan action bar slots 1-120 (10 bars × 12 buttons).
        -- WoW supports up to 10 action bars; GetActionInfo returns nil safely
        -- for any slot that doesn't exist.
        --
        -- In WoW Midnight, GetActionInfo for macro-type slots returns the
        -- resolved spell ID as the `id` (not the macro index) when the macro
        -- casts a spell. GetMacroBody/GetMacroSpell with that id return nothing
        -- useful. Comparing id == spellID directly is the correct check.
        for slot = 1, 120 do
            local aType, id = GetActionInfo(slot)
            if aType == "spell" and id then
                if id == step.spellID          -- normal: base spell on bar
                or id == procForm              -- proc active: override on bar
                or GetBaseSpell(id) == step.spellID then  -- reverse lookup fallback
                    found = true
                    break
                end
            elseif aType == "macro" and id then
                -- Direct match: Midnight returns the resolved spellID as `id`.
                if id == step.spellID
                or id == procForm
                or GetBaseSpell(id) == step.spellID then
                    found = true
                    break
                end
                -- Legacy fallback: GetMacroSpell (works when id is a macro index
                -- and the target unit is present).
                local macroSpellID
                pcall(function() macroSpellID = GetMacroSpell(id) end)
                if macroSpellID and (
                    macroSpellID == step.spellID
                    or macroSpellID == procForm
                    or GetBaseSpell(macroSpellID) == step.spellID
                ) then
                    found = true
                    break
                end
                -- Legacy fallback: parse /cast lines from the macro body text.
                if CheckMacroBody(GetMacroBody(id)) then
                    found = true
                    break
                end
            end
        end

        if not found then
            missing[#missing+1] = step.spellID
        end
    end
    return #missing == 0, missing
end

-- ── Step advancement ────────────────────────────────────────────────────────

function ManualRotation:TryAdvance(castSpellID)
    local name = RH.db.activeManualProfile
    if not name then return end
    local profile = RH.db.manualProfiles and RH.db.manualProfiles[name]
    if not profile or not profile.steps or #profile.steps == 0 then return end

    local step = profile.steps[stepIndex]
    if not step then return end
    -- Accept the base spell OR any proc override of it (e.g. Festering Scythe)
    local matches = castSpellID == step.spellID
    if not matches then
        matches = GetBaseSpell(castSpellID) == step.spellID
    end
    if not matches then return end

    stepRemaining = stepRemaining - 1
    if stepRemaining <= 0 then
        -- Record that this spell was just cast so ShouldSkipSpell can avoid it.
        -- GetBaseCD returns static (untainted) data; GetTime() is never tainted.
        local baseCD = GetBaseCD(step.spellID)
        if baseCD > 0 then
            manualCooldownEnd[step.spellID] = GetTime() + baseCD
        end
        -- Advance to next step, wrapping back to 1
        stepIndex = (stepIndex % #profile.steps) + 1
        local nextStep = profile.steps[stepIndex]
        stepRemaining      = (nextStep and nextStep.count) or 1
        lastDisplaySpellID = nil  -- force full redraw on step change
    else
        lastDisplayRemain = nil   -- same spell, update count text
    end
end

-- ── Cooldown / resource helpers ─────────────────────────────────────────────

-- Returns true if the spell currently lacks the resources needed to cast it
-- (not enough mana / runic power / rage / etc.), safe to call in combat.
local function IsResourceLocked(spellID)
    local locked = false
    pcall(function()
        local _, insufficientPower = C_Spell.IsSpellUsable(spellID)
        if insufficientPower then locked = true end
    end)
    return locked
end

-- Returns true only if the spell is on a real cooldown (longer than the GCD).
-- Taint-free design: all comparisons use plain Lua numbers (GetTime() and
-- manualCooldownEnd entries). C_Spell.GetSpellCooldown comparisons throw on
-- "secret numbers" during Midnight combat even inside pcall, so we never
-- compare those values directly.
local function ShouldSkipSpell(spellID)
    -- Charge-based spells: check current charge count via tostring (taint-safe).
    -- If the spell has ≥1 charge it is always castable regardless of recharge CD.
    local isChargeBased = false
    local hasCharges    = true   -- default: assume available
    pcall(function()
        local cur, maxC = C_Spell.GetSpellCharges(spellID)
        local isCB = false
        pcall(function() isCB = maxC > 1 end)
        if isCB then
            isChargeBased = true
            hasCharges    = tostring(cur) ~= "0"
        end
    end)
    if isChargeBased then
        return not hasCharges   -- skip only when all charges depleted
    end

    -- Non-charge spell: use tracked cooldown end timestamp (plain Lua number).
    local cdEnd = manualCooldownEnd[spellID]
    if cdEnd and GetTime() < cdEnd then
        return true
    end

    return false
end

-- ── Display ─────────────────────────────────────────────────────────────────
-- Called from SpellSuggestion:UpdateSpell() when manualMode is true.
-- Drives the same frames SpellSuggestion owns; uses identical taint-safe patterns.

function ManualRotation:UpdateDisplay()
    local ss = RH.modules.SpellSuggestion
    if not ss then return end

    -- Priority items (trinkets / potions / priority spells) override manual rotation
    local priorityMod = RH.modules.PriorityItems
    if priorityMod then
        local item = priorityMod:GetPriorityItem()
        if item then
            ss.currentPriorityKey = item.isSpell
                and ("spell:" .. item.spellID)
                or  ("item:"  .. item.itemID)
            lastDisplaySpellID = nil  -- force full redraw when priority clears
            ss:ShowPriorityItem(item)
            return
        end
    end
    ss.currentPriorityKey = nil

    -- No active profile
    local name = RH.db.activeManualProfile
    if not name then
        ss:ClearDisplay(false)
        return
    end

    local profile = RH.db.manualProfiles and RH.db.manualProfiles[name]
    if not profile or not profile.steps or #profile.steps == 0 then
        ss:ClearDisplay(false)
        return
    end

    -- Guard stepIndex in bounds after profile edits
    if stepIndex > #profile.steps then
        stepIndex = 1
        local firstStep = profile.steps[1]
        stepRemaining      = firstStep and firstStep.count or 1
        lastDisplaySpellID = nil
    end

    -- All spells must be present on action bars
    local valid, missing = self:ValidateProfile()
    if not valid then
        ss.tooltipData = nil
        local firstMissingInfo = missing[1] and C_Spell.GetSpellInfo(missing[1])
        if firstMissingInfo then
            ss.iconFrame.icon:SetTexture(firstMissingInfo.iconID)
        else
            ss.iconFrame.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        end
        ss.iconFrame.icon:SetDesaturated(true)
        ss.chargeCooldown:SetCooldown(0, 0)
        ss:SetKeybind(nil)
        ss:HideGlow()
        ss.unavailLabel:Hide()
        ss.nameLabel:SetText(name)
        ss.nameLabel:SetTextColor(0.75, 0.75, 0.75)
        ss.nameLabel:Show()
        if #missing == 1 and firstMissingInfo then
            ss.statusLabel:SetText("Add \"" .. firstMissingInfo.name .. "\" to action bar")
        else
            ss.statusLabel:SetText("Paused — " .. #missing .. " spells missing from bars")
        end
        ss.statusLabel:SetTextColor(0.9, 0.55, 0.1)
        ss.statusLabel:Show()
        lastDisplaySpellID = nil
        return
    end

    -- Two-phase step selection:
    --   Phase 1 — find the next step that is both off-cooldown AND has resources.
    --             This is what the player can immediately cast.
    --   Phase 2 — if no such step exists (e.g. all resource-locked), find the
    --             next off-CD step regardless of resources and show it desaturated,
    --             so the player knows to wait for resources.
    --   Fallback — if every step is on cooldown, restore the original position and
    --              let the CD visuals communicate the wait state.
    local origIdx       = stepIndex
    local origRemaining = stepRemaining

    -- Phase 1: seek a step that is off-CD, has sufficient resources, AND meets conditions.
    local phase1Found = false
    local checkIdx    = stepIndex
    for _ = 1, #profile.steps do
        local s = profile.steps[checkIdx]
        if not ShouldSkipSpell(s.spellID)
        and not IsResourceLocked(s.spellID) then
            if checkIdx ~= stepIndex then
                stepIndex     = checkIdx
                stepRemaining = s.count
                lastDisplaySpellID = nil
            end
            phase1Found = true
            break
        end
        checkIdx = (checkIdx % #profile.steps) + 1
    end

    if not phase1Found then
        -- Phase 2: no fully-castable step; seek any off-CD step (may lack resources).
        stepIndex     = origIdx
        stepRemaining = origRemaining
        local skipped = 0
        while skipped < #profile.steps do
            local s2 = profile.steps[stepIndex]
            if not ShouldSkipSpell(s2.spellID) then
                break
            end
            stepIndex     = (stepIndex % #profile.steps) + 1
            stepRemaining = (profile.steps[stepIndex] and profile.steps[stepIndex].count) or 1
            lastDisplaySpellID = nil
            skipped = skipped + 1
        end
        if skipped == #profile.steps then
            -- Every step is on cooldown — restore original position and let the
            -- existing usability/cooldown visuals communicate the wait state.
            stepIndex     = origIdx
            stepRemaining = origRemaining
        end
    end

    local step    = profile.steps[stepIndex]
    local spellID = step.spellID

    -- Resolve any active proc override (e.g. Festering Scythe, Opportunity, etc.)
    -- displaySpellID is what we actually show; spellID is used for CD/resource checks.
    local displaySpellID = GetDisplaySpell(spellID)

    -- Count suffix: "(2/3)" while working through a multi-cast step
    local countSuffix = ""
    if step.count > 1 then
        local castNum = step.count - stepRemaining + 1
        countSuffix = string.format(" (%d/%d)", castNum, step.count)
    end

    -- Static: only update icon / name / keybind when the displayed spell changes.
    -- Fires both on step change AND when a proc activates/expires.
    if displaySpellID ~= lastDisplaySpellID then
        local info = C_Spell.GetSpellInfo(displaySpellID)
        if not info then return end  -- data not ready yet
        lastDisplaySpellID = displaySpellID
        lastDisplayRemain  = stepRemaining
        ss.tooltipData = { type = "spell", id = displaySpellID }
        ss.iconFrame.icon:SetTexture(info.iconID)
        ss.iconFrame.icon:SetDesaturated(false)
        ss.nameLabel:SetText(info.name .. countSuffix)
        ss.nameLabel:SetTextColor(1, 1, 1)
        ss.unavailLabel:Hide()
        ss.nameLabel:Show()
        ss.statusLabel:Show()
        ss:SetKeybind(RH.Utils.GetSpellKeybind(displaySpellID))
    elseif stepRemaining ~= lastDisplayRemain then
        -- Same spell, remaining count changed: refresh only the label suffix
        lastDisplayRemain = stepRemaining
        local info = C_Spell.GetSpellInfo(displaySpellID)
        if info then
            ss.nameLabel:SetText(info.name .. countSuffix)
        end
    end

    -- Dynamic: usability / charges / range — identical taint-safe pattern to SpellSuggestion
    local isUsable, insufficientPower = C_Spell.IsSpellUsable(spellID)
    if insufficientPower then
        ss.statusLabel:SetText(RotationHelperL.NOT_ENOUGH_POWER)
        ss.statusLabel:SetTextColor(0.9, 0.35, 0.35)
        ss.iconFrame.icon:SetDesaturated(true)
        ss:HideGlow()
    else
        local canCast   = isUsable
        local noCharges = false

        pcall(function()
            local currentCharges, maxCharges =
                C_Spell.GetSpellCharges(spellID)
            local isChargeBased = false
            pcall(function() isChargeBased = maxCharges > 1 end)
            if isChargeBased then
                local chargesStr = tostring(currentCharges)
                if chargesStr == "0" then
                    canCast   = false
                    noCharges = true
                else
                    canCast = true
                end
            end
        end)

        -- Check regular (non-charge) cooldown.
        -- Use manualCooldownEnd (plain Lua numbers) — never tainted.
        -- Sweep is driven via GetSpellCooldownDuration below (same as charge path).
        if not noCharges then
            local cdEnd = manualCooldownEnd[spellID]
            if cdEnd then
                local remaining = cdEnd - GetTime()
                if remaining > 0 then
                    canCast = false
                end
            end
        end

        local inRange = true
        if UnitExists("target") then
            pcall(function()
                local result = C_Spell.IsSpellInRange(spellID, "target")
                pcall(function()
                    if result == false then inRange = false end
                end)
            end)
        end

        if not canCast or not inRange then
            -- Drive the cooldown sweep using the DurationObject API (Patch 12.0).
            pcall(function()
                local dur = C_Spell.GetSpellCooldownDuration(spellID)
                if dur then
                    ss.chargeCooldown:SetCooldownFromDurationObject(dur)
                else
                    ss.chargeCooldown:SetCooldown(0, 0)
                end
            end)
            if not inRange then
                ss.statusLabel:SetText(RotationHelperL.OUT_OF_RANGE)
                ss.statusLabel:SetTextColor(0.9, 0.35, 0.35)
            elseif noCharges then
                ss.statusLabel:SetText(RotationHelperL.NO_CHARGES)
                ss.statusLabel:SetTextColor(0.9, 0.35, 0.35)
            else
                ss.statusLabel:SetText("")
                ss.statusLabel:SetTextColor(1, 1, 1)
            end
            ss.iconFrame.icon:SetDesaturated(true)
            ss:HideGlow()
        else
            ss.chargeCooldown:SetCooldown(0, 0)
            ss.statusLabel:SetText("")
            ss.statusLabel:SetTextColor(1, 1, 1)
            ss.iconFrame.icon:SetDesaturated(false)
            ss:ShowGlow()
        end
    end
end

-- ── Serialization ───────────────────────────────────────────────────────────
-- Format: RHP:specID:spellIDxcount,spellIDxcount,...:Profile Name
-- Profile name is last so it can safely contain colons.

local SHARE_PREFIX = "RHP"

function ManualRotation:SerializeProfile(name)
    local profile = RH.db.manualProfiles and RH.db.manualProfiles[name]
    if not profile or not profile.steps or #profile.steps == 0 then return nil end
    local parts = {}
    for _, step in ipairs(profile.steps) do
        parts[#parts+1] = step.spellID .. "x" .. step.count
    end
    return SHARE_PREFIX .. ":" .. profile.specID .. ":" .. table.concat(parts, ",") .. ":" .. name
end

function ManualRotation:DeserializeProfile(str)
    str = str:trim()
    -- Match prefix:specID:steps:name  (name may contain colons)
    local specIDStr, stepsStr, name = str:match("^" .. SHARE_PREFIX .. ":(%d+):([^:]+):(.+)$")
    if not specIDStr then return nil, "Unrecognised format." end
    local specID = tonumber(specIDStr)
    if not specID then return nil, "Invalid spec ID." end
    local steps = {}
    for part in stepsStr:gmatch("[^,]+") do
        local sid, cnt = part:match("^(%d+)x(%d+)$")
        if not sid then return nil, "Corrupt step: " .. part end
        steps[#steps+1] = { spellID = tonumber(sid), count = tonumber(cnt) }
    end
    if #steps == 0 then return nil, "No steps in string." end
    return { name = name, specID = specID, steps = steps }
end

-- ── Module init ──────────────────────────────────────────────────────────────

function ManualRotation:Init()
    -- Advance step index when the player casts the current step's spell
    RH.EventBus:On("UNIT_SPELLCAST_SUCCEEDED", function(_, unit, _, spellID)
        if unit == "player" and RH.db.manualMode then
            self:TryAdvance(spellID)
        end
    end, self)

    -- Deactivate if spec changes and saved profile is for a different spec
    RH.EventBus:On("PLAYER_SPECIALIZATION_CHANGED", function()
        local name = RH.db.activeManualProfile
        if name and RH.db.manualProfiles then
            local profile = RH.db.manualProfiles[name]
            if not profile or profile.specID ~= RH:GetSpecID() then
                RH.db.activeManualProfile = nil
                RH.db.manualMode          = false
                lastDisplaySpellID        = nil
                lastDisplayRemain         = nil
            end
        end
    end, self)

    -- Re-seed cooldown timestamps from live API after combat.
    -- Values are untainted outside combat, giving accurate talent-modified durations
    -- to replace the base-CD estimates recorded during the fight.
    RH.EventBus:On("PLAYER_REGEN_ENABLED", function()
        if RH.db.manualMode and RH.db.activeManualProfile then
            local profile = RH.db.manualProfiles
                and RH.db.manualProfiles[RH.db.activeManualProfile]
            SeedProfileCooldowns(profile)
        end
    end, self)

    -- Force full display redraw after action bar changes (spells may have moved)
    RH.EventBus:On("ACTIONBAR_SLOT_CHANGED", function()
        lastDisplaySpellID = nil
    end, self)

    -- Restore step state if the player reloaded with manual mode active
    if RH.db.manualMode and RH.db.activeManualProfile then
        local profile = RH.db.manualProfiles
            and RH.db.manualProfiles[RH.db.activeManualProfile]
        if profile and profile.specID == RH:GetSpecID() then
            self:LoadProfile(RH.db.activeManualProfile)
        else
            RH.db.manualMode          = false
            RH.db.activeManualProfile = nil
        end
    end
end
