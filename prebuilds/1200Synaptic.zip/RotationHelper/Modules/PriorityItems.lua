local RH = RotationHelper

local PriorityItems = {}
RH:RegisterModule("PriorityItems", PriorityItems)

local TRINKET_SLOTS = { 13, 14 }
local GCD_THRESHOLD = RH.GCD_THRESHOLD

-- ── Spell cooldown tracking ───────────────────────────────────────────────────
--
-- C_Spell.GetSpellCooldown is the primary source of truth and is called directly
-- wherever possible — it is always accurate and never tainted outside combat.
--
-- In combat its return values are "secret numbers"; comparisons on them throw.
-- The tracked tables below are used only as a fallback for that case:
--   spellCooldownEnd[id] — set on UNIT_SPELLCAST_SUCCEEDED via live API when safe,
--                          or GetTime() + spellBaseCD when tainted.
--   spellBaseCD[id]      — real (talent-modified) CD; refreshed from live API
--                          whenever a spell is cast outside combat, or seeded from
--                          GetSpellBaseCooldown as a last resort.
--   spellNameToID[name]  — name→ID map for matching UNIT_SPELLCAST_SUCCEEDED.

local spellCooldownEnd = {}
local spellBaseCD      = {}
local spellNameToID    = {}


-- Returns cdStart, cdDuration for a spell (both 0 if the spell is ready).
-- Tries the live API first; falls back to tracked tables when combat taint
-- prevents comparison on the returned values.
local function GetSpellCDInfo(spellID)
    local ok, info = pcall(C_Spell.GetSpellCooldown, spellID)
    if ok and info then
        local start, dur = 0, 0
        local cok = pcall(function()
            if info.duration > GCD_THRESHOLD then
                start = info.startTime
                dur   = info.duration
            end
        end)
        if cok then return start, dur end
    end

    -- Fallback: tracked timestamps (used only when in-combat taint blocks the API)
    local cdEnd  = spellCooldownEnd[spellID] or 0
    local baseCD = spellBaseCD[spellID]      or 0
    if GetTime() < cdEnd then
        return cdEnd - baseCD, baseCD
    end
    return 0, 0
end

local function SeedCooldownState()
    local spells = RH.db.prioritySpells or {}
    wipe(spellCooldownEnd)
    wipe(spellBaseCD)
    wipe(spellNameToID)

    for _, entry in ipairs(spells) do
        local spellID = entry.spellID
        if spellID then
            -- Live API is safe here (outside combat); get real talent-modified CD.
            -- Fall back to static GetSpellBaseCooldown if the API somehow fails.
            local ok, info = pcall(C_Spell.GetSpellCooldown, spellID)
            if ok and info then
                local cok = pcall(function()
                    if info.duration and info.duration > GCD_THRESHOLD then
                        spellBaseCD[spellID]      = info.duration
                        spellCooldownEnd[spellID] = info.startTime + info.duration
                    else
                        spellCooldownEnd[spellID] = 0
                    end
                end)
                if not cok then spellCooldownEnd[spellID] = 0 end
            else
                spellCooldownEnd[spellID] = 0
            end

            -- Seed baseCD from static data if the live API didn't give us a real CD
            -- (spell was ready, so info.duration was 0).
            if not spellBaseCD[spellID] then
                local baseCDms = GetSpellBaseCooldown(spellID)
                spellBaseCD[spellID] = (baseCDms and baseCDms > 1500)
                    and (baseCDms / 1000)
                    or  60
            end

            if entry.name then
                spellNameToID[entry.name:lower()] = spellID
            end
        end
    end
end

-- Called by OptionsPanel after the priority spell list changes.
function PriorityItems:RefreshData()
    SeedCooldownState()
end

-- ── Trinket check ─────────────────────────────────────────────────────────────

function PriorityItems:GetReadyTrinket()
    for _, slot in ipairs(TRINKET_SLOTS) do
        -- Respect per-slot enable setting.
        -- Explicit branch avoids the Lua `A and B or C` pitfall where a falsy B
        -- causes slot 13 to fall through to trinket2Priority incorrectly.
        local slotEnabled = (slot == 13) and RH.db.trinket1Priority or
                            (slot == 14) and RH.db.trinket2Priority
        if slotEnabled then
            local itemID = GetInventoryItemID("player", slot)
            if itemID then
                local spellName = C_Item.GetItemSpell(itemID)
                if spellName then
                    local start, duration, enable = GetInventoryItemCooldown("player", slot)
                    if enable == 1 and duration <= GCD_THRESHOLD then
                        local name = GetItemInfo(itemID) or RotationHelperL.PRIORITY_TRINKET
                        return {
                            itemID = itemID,
                            icon   = GetInventoryItemTexture("player", slot),
                            name   = name,
                            label  = RotationHelperL.PRIORITY_TRINKET,
                        }
                    end
                end
            end
        end
    end
    return nil
end

-- ── Potion check ──────────────────────────────────────────────────────────────
-- Iterates the user-defined whitelist (RH.db.priorityPotions) and returns the
-- first entry that is in the player's bags and off cooldown.

function PriorityItems:GetReadyPotion()
    local potions = RH.db.priorityPotions
    if not potions then return nil end

    for _, entry in ipairs(potions) do
        local itemID = entry.itemID
        if itemID and GetItemCount(itemID) > 0 then
            local _, duration = GetItemCooldown(itemID)
            if duration ~= nil and duration <= GCD_THRESHOLD then
                local name, _, _, _, _, _, _, _, _, texture = GetItemInfo(itemID)
                return {
                    itemID = itemID,
                    icon   = texture or C_Item.GetItemIconByID(itemID),
                    name   = name or entry.name or RotationHelperL.PRIORITY_POTION,
                    label  = RotationHelperL.PRIORITY_POTION,
                }
            end
        end
    end
    return nil
end

-- ── Priority spell check ──────────────────────────────────────────────────────

function PriorityItems:GetReadyPrioritySpell()
    local spells = RH.db.prioritySpells
    if not spells then return nil end

    for _, entry in ipairs(spells) do
        local spellID = entry.spellID
        if spellID then
            local _, dur = GetSpellCDInfo(spellID)
            if dur == 0 then
                -- Skip if the player lacks the resources to cast (e.g. not enough
                -- runic power for Breath of Sindragosa, not enough mana, rage, etc.)
                local resourceOk = true
                pcall(function()
                    local _, insufficientPower = C_Spell.IsSpellUsable(spellID)
                    if insufficientPower then resourceOk = false end
                end)
                if resourceOk then
                    local spellInfo = C_Spell.GetSpellInfo(spellID)
                    if spellInfo then
                        return {
                            spellID = spellID,
                            icon    = spellInfo.iconID,
                            name    = spellInfo.name,
                            label   = RotationHelperL.PRIORITY_SPELL,
                            isSpell = true,
                        }
                    end
                end
            end
        end
    end
    return nil
end

-- ── Strip data ────────────────────────────────────────────────────────────────

function PriorityItems:GetPrioritySpellStripData()
    local result = {}
    for _, entry in ipairs(RH.db.prioritySpells or {}) do
        local spellID = entry.spellID
        if spellID then
            local info = C_Spell.GetSpellInfo(spellID)
            if info then
                local cdStart, cdDuration = GetSpellCDInfo(spellID)
                result[#result + 1] = {
                    spellID    = spellID,
                    icon       = info.iconID,
                    isSpell    = true,
                    cdStart    = cdStart,
                    cdDuration = cdDuration,
                }
            end
        end
    end
    return result
end


-- ── Public API ────────────────────────────────────────────────────────────────

function PriorityItems:GetPriorityItem()
    if RH.db.spellPriority then
        local s = self:GetReadyPrioritySpell()
        if s then return s end
    end
    -- GetReadyTrinket handles per-slot enable checks internally
    local t = self:GetReadyTrinket()
    if t then return t end
    if RH.db.potionPriority then
        local p = self:GetReadyPotion()
        if p then return p end
    end
    return nil
end

-- ── Module init ───────────────────────────────────────────────────────────────

function PriorityItems:Init()
    RH.EventBus:On("PLAYER_ENTERING_WORLD", function()
        SeedCooldownState()
    end, self)

    -- Re-seed at combat end so cooldown state is accurate for the next pull.
    RH.EventBus:On("PLAYER_REGEN_ENABLED", function()
        SeedCooldownState()
    end, self)

    -- When the player casts a priority spell, update the tracked fallback tables.
    -- Try the live API first (always works outside combat, gives real talent-modified CD).
    -- If comparisons throw due to combat taint, fall back to the cached baseCD.
    RH.EventBus:On("UNIT_SPELLCAST_SUCCEEDED", function(_, unit, _, castSpellID)
        if unit ~= "player" then return end

        local castInfo = C_Spell.GetSpellInfo(castSpellID)
        if not castInfo then return end

        local storedID = spellNameToID[castInfo.name:lower()]
        if not storedID then return end

        local set = false
        local ok, info = pcall(C_Spell.GetSpellCooldown, storedID)
        if ok and info then
            local cok = pcall(function()
                if info.duration > GCD_THRESHOLD then
                    spellBaseCD[storedID]      = info.duration  -- real talent-modified CD
                    spellCooldownEnd[storedID] = info.startTime + info.duration
                    set = true
                end
            end)
        end

        if not set then
            -- Combat taint blocked the API: estimate from cached base CD
            spellCooldownEnd[storedID] = GetTime() + (spellBaseCD[storedID] or 60)
        end
    end, self)
end
