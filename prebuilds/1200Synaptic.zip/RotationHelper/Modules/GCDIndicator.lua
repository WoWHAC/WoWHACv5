local RH = RotationHelper

local GCDIndicator = {}
RH:RegisterModule("GCDIndicator", GCDIndicator)

-- ── UI creation ────────────────────────────────────────────────────────────
-- Parents the cooldown sweep directly onto the spell icon frame so it
-- overlays cleanly regardless of the main frame's position.

function GCDIndicator:CreateUI()
    -- RH.spellIconFrame is set by SpellSuggestion:CreateUI() which always
    -- runs first (see MODULE_ORDER in Core.lua).
    local iconFrame = RH.spellIconFrame

    local gcdFrame = CreateFrame("Cooldown", "RotationHelperGCDFrame", iconFrame, "CooldownFrameTemplate")
    gcdFrame:SetAllPoints(iconFrame)
    gcdFrame:SetFrameLevel(iconFrame:GetFrameLevel() + 5)
    gcdFrame:SetHideCountdownNumbers(true)
    gcdFrame:SetDrawEdge(false)
    gcdFrame:SetSwipeColor(0, 0, 0, 0.72)
    gcdFrame:SetDrawSwipe(true)

    if not RH.gdb.showGCD then gcdFrame:Hide() end
    self.gcdFrame = gcdFrame
end

-- ── Visibility ─────────────────────────────────────────────────────────────

function GCDIndicator:SetVisible(visible)
    if visible then
        self.gcdFrame:Show()
    else
        self.gcdFrame:Hide()
    end
end

-- ── Update ─────────────────────────────────────────────────────────────────

function GCDIndicator:OnCooldownUpdate()
    local isOnGCD, dur = RH.Utils.IsGCDActive()
    if isOnGCD and dur then
        self.gcdFrame:SetCooldownFromDurationObject(dur)
    else
        self.gcdFrame:SetCooldown(0, 0)
    end
end

-- ── Module init ────────────────────────────────────────────────────────────

function GCDIndicator:Init()
    self:CreateUI()
    RH.EventBus:On("SPELL_UPDATE_COOLDOWN", function() self:OnCooldownUpdate() end, self)
end
