local RH = RotationHelper

local OptionsPanel = {}
RH:RegisterModule("OptionsPanel", OptionsPanel)

local PANEL_W               = 280
local SPELL_ENTRY_H         = 20
local POTION_ENTRY_H        = 18
local MAX_PRIORITY_SPELLS   = 10
local MAX_PRIORITY_POTIONS  = 5
local SPELL_SCROLL_VISIBLE  = 5      -- max spell entries shown before scrolling kicks in
local SPELL_SCROLL_H        = SPELL_SCROLL_VISIBLE * 20  -- = 100px at SPELL_ENTRY_H
local CONTENT_Y             = -50    -- content frames start this far below panel top

-- Panel heights per tab (title area 50px + content)
local TAB1_BASE_H = 378   -- Rotation tab base (grows per spell/potion entry, capped by scroll)
local TAB2_H      = 616   -- Display tab
local TAB3_H      = 300   -- Sound tab (checkbox + sound picker + volume slider)
local TAB4_H      = 334   -- Manual profiles tab

-- ── Helpers ────────────────────────────────────────────────────────────────

local function MakeDivider(parent, yOff)
    local d = parent:CreateTexture(nil, "ARTWORK")
    d:SetHeight(1)
    d:SetPoint("TOPLEFT",  parent, "TOPLEFT",  10, yOff)
    d:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -10, yOff)
    d:SetColorTexture(0.20, 0.20, 0.26, 0.8)
end

local function MakeSectionLabel(parent, text, yOff)
    local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lbl:SetPoint("TOPLEFT", parent, "TOPLEFT", 12, yOff)
    lbl:SetText(text)
    lbl:SetTextColor(0.85, 0.75, 0.40)
end

local function MakeCheckbox(parent, label, yOff, getValue, setValue)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(22, 22)
    cb:SetPoint("TOPLEFT", parent, "TOPLEFT", 10, yOff)
    cb:SetChecked(getValue())

    local lbl = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lbl:SetPoint("LEFT", cb, "RIGHT", 2, 0)
    lbl:SetText(label)
    lbl:SetTextColor(0.88, 0.88, 0.88)

    cb:SetScript("OnClick", function(self)
        setValue(self:GetChecked())
    end)
    return cb
end

local function MakeSlider(parent, yOff, minVal, maxVal, step, initVal, formatFn, onChange)
    -- Background box spans full width; slider/track are shortened on the right
    -- to leave room for the numeric EditBox.
    local bgBorder = parent:CreateTexture(nil, "BACKGROUND")
    bgBorder:SetHeight(24)
    bgBorder:SetPoint("TOPLEFT",  parent, "TOPLEFT",  11, yOff + 4)
    bgBorder:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -11, yOff + 4)
    bgBorder:SetColorTexture(0.28, 0.28, 0.36, 1.0)

    local bgFill = parent:CreateTexture(nil, "BACKGROUND")
    bgFill:SetPoint("TOPLEFT",     bgBorder, "TOPLEFT",     1, -1)
    bgFill:SetPoint("BOTTOMRIGHT", bgBorder, "BOTTOMRIGHT", -1,  1)
    bgFill:SetColorTexture(0.10, 0.10, 0.14, 1.0)

    -- Track and slider shortened to leave ~52px on the right for the input
    local track = parent:CreateTexture(nil, "ARTWORK")
    track:SetHeight(3)
    track:SetPoint("TOPLEFT",  parent, "TOPLEFT",  18, yOff - 6)
    track:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -68, yOff - 6)
    track:SetColorTexture(0.35, 0.35, 0.46, 1.0)

    local slider = CreateFrame("Slider", nil, parent)
    slider:SetHeight(16)
    slider:SetPoint("TOPLEFT",  parent, "TOPLEFT",  16, yOff)
    slider:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -66, yOff)
    slider:SetOrientation("HORIZONTAL")
    slider:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    slider:SetMinMaxValues(minVal, maxVal)
    slider:SetValueStep(step)
    slider:SetObeyStepOnDrag(true)
    slider:SetValue(initVal)

    local valText = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    valText:SetPoint("TOP", slider, "BOTTOM", 0, -2)
    valText:SetTextColor(0.75, 0.75, 0.75)
    valText:SetText(formatFn(initVal))

    -- Numeric EditBox on the right side of the background box.
    -- Shows the formatted value; accepts raw numeric input on Enter.
    local inputEB = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    inputEB:SetSize(46, 18)
    inputEB:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -13, yOff + 1)
    inputEB:SetAutoFocus(false)
    inputEB:SetMaxLetters(8)
    inputEB:SetText(formatFn(initVal))
    inputEB:SetJustifyH("CENTER")

    slider:SetScript("OnValueChanged", function(self, val)
        valText:SetText(formatFn(val))
        inputEB:SetText(formatFn(val))
        onChange(val)
    end)

    inputEB:SetScript("OnEnterPressed", function(self)
        -- Strip everything except digits, decimal point, and minus sign
        local raw = self:GetText():gsub("[^%d%.%-]", "")
        local num = tonumber(raw)
        if num then
            -- Accept percentage input as a fraction when the range is 0-1
            if maxVal <= 1.0 and num > 1 then num = num / 100 end
            -- Snap to nearest step, then clamp
            num = math.floor((num - minVal) / step + 0.5) * step + minVal
            num = math.max(minVal, math.min(maxVal, num))
            slider:SetValue(num)   -- triggers OnValueChanged → updates both labels
        else
            self:SetText(formatFn(slider:GetValue()))  -- revert on invalid input
        end
        self:ClearFocus()
    end)
    inputEB:SetScript("OnEscapePressed", function(self)
        self:SetText(formatFn(slider:GetValue()))
        self:ClearFocus()
    end)

    return slider
end

local function pct(v)   return string.format("%.0f%%", v * 100) end
local function scale(v) return string.format("%.1fx", v) end
local function pt(v)    return string.format("%.0fpt", v) end
local function px(v)    return string.format("%+.0fpx", v) end

-- ── Out-of-combat fade ─────────────────────────────────────────────────────

local COG_FADED_ALPHA = 0.40
local fadeTimer = nil

local function FadeMainFrame(startAlpha, endAlpha, duration)
    if fadeTimer then fadeTimer:Cancel(); fadeTimer = nil end
    if duration <= 0 then
        RH.frame:SetAlpha(endAlpha)
        return
    end
    local elapsed = 0
    fadeTimer = C_Timer.NewTicker(0.05, function()
        elapsed = elapsed + 0.05
        local t = math.min(elapsed / duration, 1.0)
        RH.frame:SetAlpha(startAlpha + (endAlpha - startAlpha) * t)
        if t >= 1.0 then
            fadeTimer:Cancel()
            fadeTimer = nil
        end
    end)
end

-- ── Action bar lookup helpers ───────────────────────────────────────────────

local function FindSpellOnActionBars(spellName)
    local lower = spellName:lower()
    for slot = 1, 96 do
        local aType, id = GetActionInfo(slot)
        if aType == "spell" and id then
            local ok, info = pcall(C_Spell.GetSpellInfo, id)
            if ok and info and info.name and info.name:lower() == lower then
                return id, info.name, info.iconID
            end
        end
    end
    return nil
end

local function FindItemOnActionBars(itemName)
    local lower = itemName:lower()
    for slot = 1, 96 do
        local aType, itemID = GetActionInfo(slot)
        if aType == "item" and itemID then
            local name, _, _, _, _, _, _, _, _, texture = GetItemInfo(itemID)
            if name and name:lower() == lower then
                return itemID, name, texture
            end
        end
    end
    return nil
end

-- ── Settings panel ─────────────────────────────────────────────────────────

function OptionsPanel:CreatePanel()
    local panel = CreateFrame("Frame", "RHOptionsPanel", UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_W, TAB1_BASE_H)
    panel:SetFrameStrata("DIALOG")
    panel:SetClampedToScreen(true)
    panel:SetPoint("TOPLEFT", RH.frame, "TOPRIGHT", 4, 0)
    panel:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = false, tileSize = 0, edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    panel:SetBackdropColor(0.04, 0.04, 0.07, 0.97)
    panel:SetBackdropBorderColor(0.20, 0.20, 0.26, 0.9)
    panel:Hide()
    self.panel = panel

    -- Title
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", panel, "TOP", 0, -8)
    title:SetText("Settings")
    title:SetTextColor(0.85, 0.75, 0.40)

    -- Close button
    local closeBtn = CreateFrame("Button", nil, panel)
    closeBtn:SetSize(16, 16)
    closeBtn:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -6, -5)
    local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    closeLbl:SetAllPoints()
    closeLbl:SetText("×")
    closeLbl:SetTextColor(0.6, 0.6, 0.6)
    closeBtn:SetScript("OnEnter", function() closeLbl:SetTextColor(1, 0.3, 0.3) end)
    closeBtn:SetScript("OnLeave", function() closeLbl:SetTextColor(0.6, 0.6, 0.6) end)
    closeBtn:SetScript("OnClick", function() panel:Hide() end)

    -- Divider below title
    MakeDivider(panel, -22)

    -- ── Tab strip ─────────────────────────────────────────────────────────

    local TAB_NAMES    = { "Rotation", "Display", "Sound", "Manual" }
    local tabW         = math.floor((PANEL_W - 20) / 4)
    local tabs         = {}
    local contents     = {}
    local activeTabIdx = 1

    local function SetActiveTab(idx)
        activeTabIdx = idx
        for i = 1, 4 do
            if i == idx then
                tabs[i].lbl:SetTextColor(0.85, 0.75, 0.40)
                tabs[i].ul:Show()
                contents[i]:Show()
            else
                tabs[i].lbl:SetTextColor(0.50, 0.50, 0.55)
                tabs[i].ul:Hide()
                contents[i]:Hide()
            end
        end
        local h
        if idx == 2 then
            h = TAB2_H
        elseif idx == 3 then
            h = TAB3_H
        elseif idx == 4 then
            h = TAB4_H
        else
            local nSpells  = #(RH.db.prioritySpells  or {})
            local nPotions = #(RH.db.priorityPotions or {})
            h = TAB1_BASE_H
                + math.min(nSpells, SPELL_SCROLL_VISIBLE) * SPELL_ENTRY_H
                + nPotions * POTION_ENTRY_H
        end
        panel:SetHeight(h)
    end

    for i = 1, 4 do
        local btn = CreateFrame("Button", nil, panel)
        btn:SetSize(tabW, 22)
        btn:SetPoint("TOPLEFT", panel, "TOPLEFT", 10 + (i - 1) * tabW, -24)

        local lbl = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetAllPoints()
        lbl:SetJustifyH("CENTER")
        lbl:SetJustifyV("MIDDLE")
        lbl:SetText(TAB_NAMES[i])
        lbl:SetTextColor(0.50, 0.50, 0.55)
        btn.lbl = lbl

        -- Gold underline shown on active tab
        local ul = btn:CreateTexture(nil, "ARTWORK")
        ul:SetHeight(2)
        ul:SetPoint("BOTTOMLEFT",  btn, "BOTTOMLEFT",  4, 0)
        ul:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", -4, 0)
        ul:SetColorTexture(0.85, 0.75, 0.40, 1)
        ul:Hide()
        btn.ul = ul

        local idx = i
        btn:SetScript("OnClick", function() SetActiveTab(idx) end)
        tabs[i] = btn

        -- One content frame per tab, full panel width, starts at CONTENT_Y
        local cf = CreateFrame("Frame", nil, panel)
        cf:SetPoint("TOPLEFT",  panel, "TOPLEFT",  0, CONTENT_Y)
        cf:SetPoint("TOPRIGHT", panel, "TOPRIGHT", 0, CONTENT_Y)
        cf:SetHeight(1)
        cf:Hide()
        contents[i] = cf
    end

    -- Divider below tab strip
    MakeDivider(panel, -48)

    -- ── Tab 1: Rotation ───────────────────────────────────────────────────

    local c1 = contents[1]

    MakeSectionLabel(c1, "Priority", -10)

    local function WriteSpecField(key, val)
        RH.db[key] = val
        local specID = RH:GetSpecID()
        if specID and RH.db.specs and RH.db.specs[specID] then
            RH.db.specs[specID][key] = val
        end
    end

    local cbTrinket1 = MakeCheckbox(c1, "Trinket 1 (slot 13)", -28,
        function() return RH.db.trinket1Priority end,
        function(val)
            WriteSpecField("trinket1Priority", val)
            local m = RH.modules.SpellSuggestion
            if m then m:UpdateSpell() end
        end)

    local cbTrinket2 = MakeCheckbox(c1, "Trinket 2 (slot 14)", -52,
        function() return RH.db.trinket2Priority end,
        function(val)
            WriteSpecField("trinket2Priority", val)
            local m = RH.modules.SpellSuggestion
            if m then m:UpdateSpell() end
        end)

    local cbPotion = MakeCheckbox(c1, "Potions", -76,
        function() return RH.db.potionPriority end,
        function(val)
            WriteSpecField("potionPriority", val)
            local m = RH.modules.SpellSuggestion
            if m then m:UpdateSpell() end
        end)

    local cbSpell = MakeCheckbox(c1, "Spells", -100,
        function() return RH.db.spellPriority end,
        function(val)
            WriteSpecField("spellPriority", val)
            local m = RH.modules.SpellSuggestion
            if m then m:UpdateSpell() end
        end)

    -- Store for spec-switch refresh
    self.priorityCbs = { trinket1 = cbTrinket1, trinket2 = cbTrinket2, potion = cbPotion, spell = cbSpell }

    MakeDivider(c1, -124)

    -- ── Priority Potions subsection ───────────────────────────────────────

    MakeSectionLabel(c1, "Priority Potions", -156)

    local potionHint = c1:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    potionHint:SetPoint("TOPLEFT", c1, "TOPLEFT", 14, -170)
    potionHint:SetText("Must be in bags and on an action bar")
    potionHint:SetTextColor(0.55, 0.55, 0.55)

    local potionInputBox = CreateFrame("EditBox", nil, c1, "InputBoxTemplate")
    potionInputBox:SetSize(PANEL_W - 90, 20)
    potionInputBox:SetPoint("TOPLEFT", c1, "TOPLEFT", 14, -186)
    potionInputBox:SetAutoFocus(false)
    potionInputBox:SetMaxLetters(64)

    local potionAddBtn = CreateFrame("Button", nil, c1, "UIPanelButtonTemplate")
    potionAddBtn:SetSize(28, 20)
    potionAddBtn:SetPoint("LEFT", potionInputBox, "RIGHT", 4, 0)
    potionAddBtn:SetText("+")

    -- Browse button — opens a popup listing consumables found in bags
    local potionBrowseBtn = CreateFrame("Button", nil, c1, "UIPanelButtonTemplate")
    potionBrowseBtn:SetSize(28, 20)
    potionBrowseBtn:SetPoint("LEFT", potionAddBtn, "RIGHT", 4, 0)
    potionBrowseBtn:SetText("...")

    -- ── Bag browser popup ─────────────────────────────────────────────────
    local BROWSE_ROW_H  = 22
    local MAX_BROWSE    = 12

    local browsePopup = CreateFrame("Frame", nil, panel, "BackdropTemplate")
    browsePopup:SetWidth(PANEL_W - 20)
    browsePopup:SetFrameStrata("FULLSCREEN")
    browsePopup:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = false, tileSize = 0, edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    browsePopup:SetBackdropColor(0.06, 0.06, 0.10, 0.98)
    browsePopup:SetBackdropBorderColor(0.35, 0.35, 0.46, 1)
    browsePopup:Hide()

    local browseRows = {}
    for r = 1, MAX_BROWSE do
        local row = CreateFrame("Button", nil, browsePopup)
        row:SetHeight(BROWSE_ROW_H)
        row:SetPoint("TOPLEFT",  browsePopup, "TOPLEFT",  2, -(r - 1) * BROWSE_ROW_H - 2)
        row:SetPoint("TOPRIGHT", browsePopup, "TOPRIGHT", -2, -(r - 1) * BROWSE_ROW_H - 2)
        row:Hide()

        local rowBg = row:CreateTexture(nil, "BACKGROUND")
        rowBg:SetAllPoints()
        rowBg:SetColorTexture(0, 0, 0, 0)

        local rowIcon = row:CreateTexture(nil, "ARTWORK")
        rowIcon:SetSize(16, 16)
        rowIcon:SetPoint("LEFT", row, "LEFT", 2, 0)
        rowIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

        local rowLbl = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        rowLbl:SetPoint("LEFT",  row, "LEFT",  22, 0)
        rowLbl:SetPoint("RIGHT", row, "RIGHT", -4, 0)
        rowLbl:SetJustifyH("LEFT")
        rowLbl:SetTextColor(0.85, 0.85, 0.85)

        row.bg   = rowBg
        row.icon = rowIcon
        row.lbl  = rowLbl
        row:SetScript("OnEnter", function() rowBg:SetColorTexture(0.22, 0.22, 0.32, 0.7) end)
        row:SetScript("OnLeave", function() rowBg:SetColorTexture(0, 0, 0, 0) end)
        browseRows[r] = row
    end

    local function GetBagConsumables()
        -- Build a set of item IDs currently on action bars
        local onBar = {}
        for slot = 1, 96 do
            local aType, id = GetActionInfo(slot)
            if aType == "item" and id then onBar[id] = true end
        end

        local items = {}
        local seen  = {}
        for bag = 0, 4 do
            local numSlots = C_Container.GetContainerNumSlots(bag)
            for slot = 1, numSlots do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info and info.itemID and not seen[info.itemID] and onBar[info.itemID] then
                    local name, _, _, _, _, _, _, _, _, texture, _, classID, subclassID = GetItemInfo(info.itemID)
                    if name and classID == 0 and subclassID == 1 then  -- Potion on action bar
                        seen[info.itemID] = true
                        items[#items + 1] = { itemID = info.itemID, name = name,
                                              icon = texture or info.iconFileID }
                    end
                end
            end
        end
        table.sort(items, function(a, b) return a.name < b.name end)
        return items
    end

    local function PopulateBrowsePopup(addItemFn)
        local items = GetBagConsumables()
        local count = math.min(#items, MAX_BROWSE)
        for r = 1, MAX_BROWSE do
            local row  = browseRows[r]
            local item = items[r]
            if item and r <= count then
                row.icon:SetTexture(item.icon)
                row.lbl:SetText(item.name)
                row:SetScript("OnClick", function()
                    browsePopup:Hide()
                    addItemFn(item.itemID, item.name)
                end)
                row:Show()
            else
                row:Hide()
            end
        end
        browsePopup:SetHeight(count * BROWSE_ROW_H + 4)
        -- Position below the input row, anchored to the panel
        browsePopup:ClearAllPoints()
        browsePopup:SetPoint("TOPLEFT",  panel, "TOPLEFT",  10, CONTENT_Y - 186 - 22)
        browsePopup:SetShown(count > 0)
    end

    potionBrowseBtn:SetScript("OnClick", function()
        if browsePopup:IsShown() then
            browsePopup:Hide()
        else
            -- addItemFn is called when the user picks an item from the popup
            PopulateBrowsePopup(function(itemID, canonName)
                -- reuse TryAddPotion logic inline
                local potions = RH.db.priorityPotions or {}
                for _, e in ipairs(potions) do
                    if e.itemID == itemID then return end  -- already in list
                end
                if #potions >= MAX_PRIORITY_POTIONS then return end
                table.insert(RH.db.priorityPotions, { name = canonName, itemID = itemID })
                -- RebuildPotionList is defined below; call it via self to avoid forward-ref
                OptionsPanel:RebuildPotionList()
            end)
        end
    end)

    -- Hide popup when panel is hidden
    panel:HookScript("OnHide", function() browsePopup:Hide() end)

    local potionFeedbackLabel = c1:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    potionFeedbackLabel:SetPoint("TOPLEFT", c1, "TOPLEFT", 14, -208)
    potionFeedbackLabel:SetText("")
    potionFeedbackLabel:SetTextColor(1.0, 0.35, 0.35)

    local POTION_LIST_START_Y = -220  -- relative to c1

    local potionEntryFrames = {}
    for i = 1, MAX_PRIORITY_POTIONS do
        local ef = CreateFrame("Frame", nil, c1)
        ef:SetSize(PANEL_W - 24, POTION_ENTRY_H)
        ef:Hide()

        local iconTex = ef:CreateTexture(nil, "ARTWORK")
        iconTex:SetSize(12, 12)
        iconTex:SetPoint("LEFT", ef, "LEFT", 4, 0)
        iconTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)

        local nameLabel = ef:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        nameLabel:SetPoint("LEFT", ef, "LEFT", 20, 0)
        nameLabel:SetTextColor(0.88, 0.88, 0.88)

        local removeBtn = CreateFrame("Button", nil, ef)
        removeBtn:SetSize(14, 14)
        removeBtn:SetPoint("RIGHT", ef, "RIGHT", 0, 0)
        local removeLbl = removeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        removeLbl:SetAllPoints()
        removeLbl:SetText("×")
        removeLbl:SetTextColor(0.6, 0.4, 0.4)
        removeBtn:SetScript("OnEnter", function() removeLbl:SetTextColor(1, 0.3, 0.3) end)
        removeBtn:SetScript("OnLeave", function() removeLbl:SetTextColor(0.6, 0.4, 0.4) end)

        potionEntryFrames[i] = { frame = ef, label = nameLabel, icon = iconTex, btn = removeBtn }
    end
    self.potionEntryFrames = potionEntryFrames

    -- ── Priority Spells subsection (in a repositionable sub-frame) ────────

    -- spellSection moves down as potions are added; all spell UI lives inside it
    local spellSection = CreateFrame("Frame", nil, c1)
    spellSection:SetPoint("TOPLEFT",  c1, "TOPLEFT",  0, -206)
    spellSection:SetPoint("TOPRIGHT", c1, "TOPRIGHT", 0, -206)
    spellSection:SetHeight(1)

    local spellSectionDiv = spellSection:CreateTexture(nil, "ARTWORK")
    spellSectionDiv:SetHeight(1)
    spellSectionDiv:SetPoint("TOPLEFT",  spellSection, "TOPLEFT",  10, 0)
    spellSectionDiv:SetPoint("TOPRIGHT", spellSection, "TOPRIGHT", -10, 0)
    spellSectionDiv:SetColorTexture(0.20, 0.20, 0.26, 0.8)

    MakeSectionLabel(spellSection, "Priority Spells - (BETA FEATURE)", -8)

    local orderHint = spellSection:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    orderHint:SetPoint("TOPLEFT", spellSection, "TOPLEFT", 14, -22)
    orderHint:SetText("Top = highest priority, drag to reorder spells")
    orderHint:SetTextColor(0.55, 0.55, 0.55)

    local hintText = spellSection:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    hintText:SetPoint("TOPLEFT", spellSection, "TOPLEFT", 14, -34)
    hintText:SetText("Spell must be on an action bar")
    hintText:SetTextColor(0.55, 0.55, 0.55)

    local inputBox = CreateFrame("EditBox", nil, spellSection, "InputBoxTemplate")
    inputBox:SetSize(PANEL_W - 54, 20)
    inputBox:SetPoint("TOPLEFT", spellSection, "TOPLEFT", 14, -50)
    inputBox:SetAutoFocus(false)
    inputBox:SetMaxLetters(64)

    local addBtn = CreateFrame("Button", nil, spellSection, "UIPanelButtonTemplate")
    addBtn:SetSize(32, 20)
    addBtn:SetPoint("LEFT", inputBox, "RIGHT", 4, 0)
    addBtn:SetText("+")

    local feedbackLabel = spellSection:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    feedbackLabel:SetPoint("TOPLEFT", spellSection, "TOPLEFT", 14, -72)
    feedbackLabel:SetText("")
    feedbackLabel:SetTextColor(1.0, 0.35, 0.35)
    self.feedbackLabel = feedbackLabel

    -- Scrollable container for spell entries
    local SPELL_LIST_START_Y = -84   -- top of list relative to spellSection

    local spellScrollFrame = CreateFrame("ScrollFrame", nil, spellSection)
    spellScrollFrame:SetPoint("TOPLEFT",  spellSection, "TOPLEFT",  0, SPELL_LIST_START_Y)
    spellScrollFrame:SetPoint("TOPRIGHT", spellSection, "TOPRIGHT", 0, SPELL_LIST_START_Y)
    spellScrollFrame:SetHeight(SPELL_SCROLL_H)
    spellScrollFrame:EnableMouseWheel(true)

    local spellScrollChild = CreateFrame("Frame", nil, spellScrollFrame)
    spellScrollChild:SetSize(PANEL_W - 24, MAX_PRIORITY_SPELLS * SPELL_ENTRY_H)
    spellScrollFrame:SetScrollChild(spellScrollChild)

    spellScrollFrame:SetScript("OnMouseWheel", function(_, delta)
        local cur      = spellScrollFrame:GetVerticalScroll()
        local nSpells  = #(RH.db.prioritySpells or {})
        local maxScroll = math.max(0, nSpells * SPELL_ENTRY_H - SPELL_SCROLL_H)
        spellScrollFrame:SetVerticalScroll(math.max(0, math.min(maxScroll, cur - delta * SPELL_ENTRY_H)))
    end)

    -- Spell entry pool (parented to spellScrollChild)
    local spellEntryFrames = {}
    for i = 1, MAX_PRIORITY_SPELLS do
        local ef = CreateFrame("Frame", nil, spellScrollChild)
        ef:SetSize(PANEL_W - 24, SPELL_ENTRY_H)
        ef:Hide()

        local dragHandle = CreateFrame("Frame", nil, ef)
        dragHandle:SetSize(14, SPELL_ENTRY_H)
        dragHandle:SetPoint("LEFT", ef, "LEFT", 0, 0)
        dragHandle:EnableMouse(true)
        dragHandle:RegisterForDrag("LeftButton")
        local dragLbl = dragHandle:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
        dragLbl:SetAllPoints()
        dragLbl:SetJustifyH("CENTER")
        dragLbl:SetJustifyV("MIDDLE")
        dragLbl:SetText("•")
        dragLbl:SetTextColor(0.45, 0.45, 0.50)
        dragHandle:SetScript("OnEnter", function() dragLbl:SetTextColor(0.85, 0.75, 0.40) end)
        dragHandle:SetScript("OnLeave", function() dragLbl:SetTextColor(0.45, 0.45, 0.50) end)
        dragHandle:SetScript("OnDragStart", function()
            ef:SetMovable(true)
            ef:StartMoving()
            ef:SetAlpha(0.5)
        end)
        -- OnDragStop wired in RebuildSpellList with the correct live index

        local iconTex = ef:CreateTexture(nil, "ARTWORK")
        iconTex:SetSize(14, 14)
        iconTex:SetPoint("LEFT", ef, "LEFT", 18, 0)
        iconTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)

        local nameLabel = ef:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        nameLabel:SetPoint("LEFT", ef, "LEFT", 36, 0)
        nameLabel:SetTextColor(0.88, 0.88, 0.88)

        local removeBtn = CreateFrame("Button", nil, ef)
        removeBtn:SetSize(14, 14)
        removeBtn:SetPoint("RIGHT", ef, "RIGHT", 0, 0)
        local removeLbl = removeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        removeLbl:SetAllPoints()
        removeLbl:SetText("x")
        removeLbl:SetTextColor(0.6, 0.4, 0.4)
        removeBtn:SetScript("OnEnter", function() removeLbl:SetTextColor(1, 0.3, 0.3) end)
        removeBtn:SetScript("OnLeave", function() removeLbl:SetTextColor(0.6, 0.4, 0.4) end)

        nameLabel:SetPoint("RIGHT", removeBtn, "LEFT", -6, 0)

        spellEntryFrames[i] = { frame = ef, label = nameLabel, icon = iconTex,
                                 btn = removeBtn, handle = dragHandle }
    end
    self.spellEntryFrames = spellEntryFrames

    local SPELL_SECTION_GAP  = 10


    local function RepositionSpellSection()
        local nPotions = #(RH.db.priorityPotions or {})
        local y = POTION_LIST_START_Y - nPotions * POTION_ENTRY_H - SPELL_SECTION_GAP
        spellSection:ClearAllPoints()
        spellSection:SetPoint("TOPLEFT",  c1, "TOPLEFT",  0, y)
        spellSection:SetPoint("TOPRIGHT", c1, "TOPRIGHT", 0, y)
    end

    local function RebuildSpellList()
        local spells = RH.db.prioritySpells or {}

        for i = 1, MAX_PRIORITY_SPELLS do
            local e     = spellEntryFrames[i]
            local spell = spells[i]
            if spell then
                e.label:SetText(spell.name)
                if e.icon and spell.spellID then
                    local info = C_Spell.GetSpellInfo(spell.spellID)
                    e.icon:SetTexture(info and info.iconID or nil)
                end
                e.frame:ClearAllPoints()
                e.frame:SetPoint("TOPLEFT", spellScrollChild, "TOPLEFT",
                    0, -(i - 1) * SPELL_ENTRY_H)
                e.frame:Show()
                local idx = i
                e.btn:SetScript("OnClick", function()
                    table.remove(RH.db.prioritySpells, idx)
                    RebuildSpellList()
                    local pi = RH.modules.PriorityItems
                    if pi then pi:RefreshData() end
                end)
                e.handle:SetScript("OnDragStop", function()
                    e.frame:StopMovingOrSizing()
                    e.frame:SetMovable(false)
                    e.frame:SetAlpha(1.0)
                    local efTop = e.frame:GetTop()
                    local scTop = spellScrollChild:GetTop()
                    if efTop and scTop then
                        local relY   = scTop - efTop
                        local newIdx = 1 + math.floor(
                            (relY + SPELL_ENTRY_H / 2) / SPELL_ENTRY_H)
                        newIdx = math.max(1, math.min(#RH.db.prioritySpells, newIdx))
                        if newIdx ~= idx then
                            local spell = table.remove(RH.db.prioritySpells, idx)
                            table.insert(RH.db.prioritySpells, newIdx, spell)
                            local pi = RH.modules.PriorityItems
                            if pi then pi:RefreshData() end
                        end
                    end
                    RebuildSpellList()
                end)
            else
                e.frame:Hide()
            end
        end

        -- Resize scroll frame: grows with entries up to the cap, then scrolls
        local visibleH = math.min(#spells, SPELL_SCROLL_VISIBLE) * SPELL_ENTRY_H
        spellScrollFrame:SetHeight(math.max(visibleH, 1))
        spellScrollChild:SetHeight(math.max(SPELL_SCROLL_H, #spells * SPELL_ENTRY_H))

        if activeTabIdx == 1 then
            local nPotions = #(RH.db.priorityPotions or {})
            panel:SetHeight(TAB1_BASE_H + visibleH + nPotions * POTION_ENTRY_H)
        end
    end

    self.RebuildSpellList = RebuildSpellList

    -- Potion list rebuild (also repositions spell section)
    local potionFeedbackTimer = nil

    local function ShowPotionFeedback(msg)
        potionFeedbackLabel:SetText(msg)
        if potionFeedbackTimer then potionFeedbackTimer:Cancel() end
        potionFeedbackTimer = C_Timer.NewTimer(3, function()
            potionFeedbackLabel:SetText("")
            potionFeedbackTimer = nil
        end)
    end

    local function RebuildPotionList()
        local potions = RH.db.priorityPotions or {}

        for i = 1, MAX_PRIORITY_POTIONS do
            local e      = potionEntryFrames[i]
            local potion = potions[i]
            if potion then
                e.label:SetText(potion.name)
                if e.icon and potion.itemID then
                    local _, _, _, _, _, _, _, _, _, texture = GetItemInfo(potion.itemID)
                    e.icon:SetTexture(texture or C_Item.GetItemIconByID(potion.itemID))
                end
                e.frame:ClearAllPoints()
                e.frame:SetPoint("TOPLEFT", c1, "TOPLEFT",
                    14, POTION_LIST_START_Y - (i - 1) * POTION_ENTRY_H)
                e.frame:Show()
                local idx = i
                e.btn:SetScript("OnClick", function()
                    table.remove(RH.db.priorityPotions, idx)
                    RebuildPotionList()
                end)
            else
                e.frame:Hide()
            end
        end

        RepositionSpellSection()
        if activeTabIdx == 1 then
            local nSpells  = #(RH.db.prioritySpells  or {})
            local nPotions = #(RH.db.priorityPotions or {})
            panel:SetHeight(TAB1_BASE_H
                + math.min(nSpells, SPELL_SCROLL_VISIBLE) * SPELL_ENTRY_H
                + nPotions * POTION_ENTRY_H)
        end
    end

    self.RebuildPotionList = RebuildPotionList

    local function TryAddPotion()
        local raw = potionInputBox:GetText()
        if not raw or raw:trim() == "" then return end
        local name = raw:trim()

        local potions = RH.db.priorityPotions or {}
        for _, e in ipairs(potions) do
            if e.name:lower() == name:lower() then
                ShowPotionFeedback("Already in list.")
                return
            end
        end

        if #potions >= MAX_PRIORITY_POTIONS then
            ShowPotionFeedback("Max " .. MAX_PRIORITY_POTIONS .. " items reached.")
            return
        end

        local itemID, canonName = FindItemOnActionBars(name)
        if not itemID then
            ShowPotionFeedback("Not found on action bars.")
            return
        end

        table.insert(RH.db.priorityPotions, { name = canonName, itemID = itemID })
        potionInputBox:SetText("")
        potionFeedbackLabel:SetText("")
        if potionFeedbackTimer then potionFeedbackTimer:Cancel(); potionFeedbackTimer = nil end
        RebuildPotionList()
    end

    potionAddBtn:SetScript("OnClick", TryAddPotion)
    potionInputBox:SetScript("OnEnterPressed", function(self)
        TryAddPotion()
        self:ClearFocus()
    end)

    local feedbackTimer = nil

    local function ShowFeedback(msg)
        feedbackLabel:SetText(msg)
        if feedbackTimer then feedbackTimer:Cancel() end
        feedbackTimer = C_Timer.NewTimer(3, function()
            feedbackLabel:SetText("")
            feedbackTimer = nil
        end)
    end

    local function TryAddSpell()
        local raw = inputBox:GetText()
        if not raw or raw:trim() == "" then return end
        local name = raw:trim()

        local spells = RH.db.prioritySpells
        for _, e in ipairs(spells) do
            if e.name:lower() == name:lower() then
                ShowFeedback("Already in list.")
                return
            end
        end

        if #spells >= MAX_PRIORITY_SPELLS then
            ShowFeedback("Max " .. MAX_PRIORITY_SPELLS .. " spells reached.")
            return
        end

        local spellID, canonName = FindSpellOnActionBars(name)
        if not spellID then
            ShowFeedback("Not found on action bars.")
            return
        end

        table.insert(RH.db.prioritySpells, { name = canonName, spellID = spellID })
        inputBox:SetText("")
        feedbackLabel:SetText("")
        if feedbackTimer then feedbackTimer:Cancel(); feedbackTimer = nil end
        RebuildSpellList()
        local pi = RH.modules.PriorityItems
        if pi then pi:RefreshData() end
    end

    addBtn:SetScript("OnClick", TryAddSpell)
    inputBox:SetScript("OnEnterPressed", function(self)
        TryAddSpell()
        self:ClearFocus()
    end)

    -- ── Tab 2: Display ────────────────────────────────────────────────────

    local c2 = contents[2]

    MakeSectionLabel(c2, "Visibility", -10)

    MakeCheckbox(c2, "Hide background", -28,
        function() return not RH.gdb.showBg end,
        function(val)
            RH.gdb.showBg = not val
            if RH.gdb.showBg then
                local c = RH.gdb.bgColor
                RH.frame:SetBackdropColor(c.r, c.g, c.b, RH.gdb.bgOpacity)
                RH.frame:SetBackdropBorderColor(0.20, 0.20, 0.26, 0.9)
                if RH.titleText then RH.titleText:Show() end
                if RH.titleDiv  then RH.titleDiv:Show() end
            else
                RH.frame:SetBackdropColor(0, 0, 0, 0)
                RH.frame:SetBackdropBorderColor(0, 0, 0, 0)
                if RH.titleText then RH.titleText:Hide() end
                if RH.titleDiv  then RH.titleDiv:Hide() end
            end
        end)

    MakeCheckbox(c2, "Cooldown strip", -52,
        function() return RH.gdb.showTrinkets end,
        function(val)
            RH.gdb.showTrinkets = val
            local m = RH.modules.TrinketCooldowns
            if m then m:SetVisible(val) end
        end)

    MakeCheckbox(c2, "GCD indicator", -76,
        function() return RH.gdb.showGCD end,
        function(val)
            RH.gdb.showGCD = val
            local m = RH.modules.GCDIndicator
            if m then m:SetVisible(val) end
        end)

    MakeCheckbox(c2, "Spell glow", -100,
        function() return RH.gdb.showSpellGlow end,
        function(val)
            RH.gdb.showSpellGlow = val
            -- If turning off, hide the glow immediately
            if not val then
                local m = RH.modules.SpellSuggestion
                if m then m:HideGlow() end
            end
        end)

    MakeCheckbox(c2, "Hide out of combat", -124,
        function() return RH.gdb.hideOutOfCombat end,
        function(val)
            RH.gdb.hideOutOfCombat = val
            if val then
                if not InCombatLockdown() then
                    FadeMainFrame(RH.frame:GetAlpha(), 0.0, 0.8)
                    if RH.dragHandle then RH.dragHandle:EnableMouse(false) end
                    self.cogBtn:SetAlpha(COG_FADED_ALPHA)
                    panel:Hide()
                end
            else
                FadeMainFrame(RH.frame:GetAlpha(), 1.0, 0.3)
                if RH.dragHandle then RH.dragHandle:EnableMouse(true) end
                self.cogBtn:SetAlpha(1.0)
            end
        end)

    MakeCheckbox(c2, "Show cog & lock buttons", -148,
        function() return RH.gdb.showControls end,
        function(val)
            RH.gdb.showControls = val
            self:SetControlsVisible(val)
        end)

    MakeCheckbox(c2, "Show spell name", -172,
        function() return RH.gdb.showSpellName end,
        function(val)
            RH.gdb.showSpellName = val
            local m = RH.modules.SpellSuggestion
            if m then m:ApplyNameVisibility() end
        end)

    MakeDivider(c2, -196)

    MakeSectionLabel(c2, "Background Opacity", -204)
    MakeSlider(c2, -218, 0.1, 1.0, 0.05, RH.gdb.bgOpacity, pct, function(val)
        RH.gdb.bgOpacity = val
        if RH.gdb.showBg then
            local c = RH.gdb.bgColor
            RH.frame:SetBackdropColor(c.r, c.g, c.b, val)
        end
    end)

    MakeSectionLabel(c2, "Background Colour", -254)

    local swatchBtn = CreateFrame("Button", nil, c2)
    swatchBtn:SetHeight(18)
    swatchBtn:SetPoint("TOPLEFT",  c2, "TOPLEFT",  14, -270)
    swatchBtn:SetPoint("TOPRIGHT", c2, "TOPRIGHT", -14, -270)

    local swatchBorder = swatchBtn:CreateTexture(nil, "BACKGROUND")
    swatchBorder:SetAllPoints()
    swatchBorder:SetColorTexture(0.40, 0.40, 0.46, 1)

    local swatchFill = swatchBtn:CreateTexture(nil, "ARTWORK")
    swatchFill:SetPoint("TOPLEFT",     swatchBtn, "TOPLEFT",     1, -1)
    swatchFill:SetPoint("BOTTOMRIGHT", swatchBtn, "BOTTOMRIGHT", -1,  1)
    local c0 = RH.gdb.bgColor
    swatchFill:SetColorTexture(c0.r, c0.g, c0.b, 1)

    swatchBtn:SetScript("OnClick", function()
        local gdb = RH.gdb
        local function applyColor()
            local r, g, b = ColorPickerFrame:GetColorRGB()
            gdb.bgColor.r, gdb.bgColor.g, gdb.bgColor.b = r, g, b
            swatchFill:SetColorTexture(r, g, b, 1)
            if gdb.showBg then RH.frame:SetBackdropColor(r, g, b, gdb.bgOpacity) end
        end
        local info = {}
        info.r, info.g, info.b = gdb.bgColor.r, gdb.bgColor.g, gdb.bgColor.b
        info.hasOpacity = false
        info.swatchFunc = applyColor
        info.func       = applyColor
        info.cancelFunc = function(prev)
            gdb.bgColor.r, gdb.bgColor.g, gdb.bgColor.b = prev.r, prev.g, prev.b
            swatchFill:SetColorTexture(prev.r, prev.g, prev.b, 1)
            if gdb.showBg then RH.frame:SetBackdropColor(prev.r, prev.g, prev.b, gdb.bgOpacity) end
        end
        ColorPickerFrame:SetupColorPickerAndShow(info)
    end)
    swatchBtn:SetScript("OnEnter", function() swatchBorder:SetColorTexture(0.65, 0.65, 0.72, 1) end)
    swatchBtn:SetScript("OnLeave", function() swatchBorder:SetColorTexture(0.40, 0.40, 0.46, 1) end)

    MakeDivider(c2, -296)

    MakeSectionLabel(c2, "Hotkey Opacity", -304)
    MakeSlider(c2, -318, 0.0, 1.0, 0.05, RH.gdb.hotkeyOpacity, pct, function(val)
        RH.gdb.hotkeyOpacity = val
        if RH.keybindLabel then
            RH.keybindLabel:SetTextColor(1, 1, 1, val)
        end
    end)

    MakeSectionLabel(c2, "Hotkey Size", -354)
    MakeSlider(c2, -368, 8, 40, 1, RH.gdb.hotkeySize, pt, function(val)
        RH.gdb.hotkeySize = val
        if RH.keybindLabel then
            RH.keybindLabel:SetFont("Fonts\\FRIZQT__.TTF", val, "OUTLINE")
        end
    end)

    MakeSectionLabel(c2, "Hotkey Horizontal Position", -404)
    MakeSlider(c2, -418, -50, 50, 1, RH.gdb.hotkeyOffsetX, px, function(val)
        RH.gdb.hotkeyOffsetX = val
        if RH.keybindLabel then
            RH.keybindLabel:ClearAllPoints()
            RH.keybindLabel:SetPoint("CENTER", RH.keybindLabel:GetParent(), "CENTER",
                RH.gdb.hotkeyOffsetX, RH.gdb.hotkeyOffsetY)
        end
    end)

    MakeSectionLabel(c2, "Hotkey Vertical Position", -454)
    MakeSlider(c2, -468, -50, 50, 1, RH.gdb.hotkeyOffsetY, px, function(val)
        RH.gdb.hotkeyOffsetY = val
        if RH.keybindLabel then
            RH.keybindLabel:ClearAllPoints()
            RH.keybindLabel:SetPoint("CENTER", RH.keybindLabel:GetParent(), "CENTER",
                RH.gdb.hotkeyOffsetX, RH.gdb.hotkeyOffsetY)
        end
    end)

    MakeDivider(c2, -504)

    MakeSectionLabel(c2, "Scale", -512)
    local scaleSlider = MakeSlider(c2, -526, 0.5, 2.0, 0.05, RH.gdb.scale, scale, function(val)
        RH.gdb.scale = val
    end)
    scaleSlider:SetScript("OnMouseUp", function(self)
        RH.frame:SetScale(self:GetValue())
    end)

    -- ── Tab 3: Sound ──────────────────────────────────────────────────────

    local c3 = contents[3]

    MakeCheckbox(c3, "Alert sound", -10,
        function() return RH.gdb.soundAlert end,
        function(val) RH.gdb.soundAlert = val end)

    MakeDivider(c3, -36)
    MakeSectionLabel(c3, "Sound", -44)

    -- Build the sound picker rows (one per entry in RH.alertSounds).
    -- RH.alertSounds is populated by SpellSuggestion during its module init,
    -- which runs before OptionsPanel, so it is always available here.
    local SOUND_ROW_H  = 24
    local soundRows    = {}   -- { dot, label } per row

    -- Radio-button textures — these WoW UI textures exist in all retail builds.
    local RADIO_ON  = "|TInterface\\Buttons\\UI-RadioButton-On:14:14|t"
    local RADIO_OFF = "|TInterface\\Buttons\\UI-RadioButton-Off:14:14|t"

    local function RefreshSoundRows()
        local selectedKey = RH.gdb.soundKey or "RAID_WARNING"
        for _, row in ipairs(soundRows) do
            if row.key == selectedKey then
                row.dot:SetText(RADIO_ON)
                row.lbl:SetTextColor(1.0, 1.0, 1.0)
            else
                row.dot:SetText(RADIO_OFF)
                row.lbl:SetTextColor(0.55, 0.55, 0.62)
            end
        end
    end

    local sounds = RH.alertSounds or {}
    for i, sound in ipairs(sounds) do
        local rowY = -58 - (i - 1) * SOUND_ROW_H

        local rowBtn = CreateFrame("Button", nil, c3)
        rowBtn:SetHeight(SOUND_ROW_H)
        rowBtn:SetPoint("TOPLEFT",  c3, "TOPLEFT",  12, rowY)
        rowBtn:SetPoint("TOPRIGHT", c3, "TOPRIGHT", -44, rowY)

        -- Radio dot — text is swapped in RefreshSoundRows between ON and OFF textures
        local dot = rowBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        dot:SetPoint("LEFT", rowBtn, "LEFT", 0, 0)
        dot:SetText(RADIO_OFF)

        local lbl = rowBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetPoint("LEFT",  rowBtn, "LEFT",  18, 0)
        lbl:SetPoint("RIGHT", rowBtn, "RIGHT", 0, 0)
        lbl:SetJustifyH("LEFT")
        lbl:SetText(sound.name)

        local soundKey = sound.key
        rowBtn:SetScript("OnClick", function()
            RH.gdb.soundKey = soundKey
            RefreshSoundRows()
        end)

        -- Preview button: plain ">>" text — guaranteed to render in WoW's font
        local previewBtn = CreateFrame("Button", nil, c3)
        previewBtn:SetSize(36, 20)
        previewBtn:SetPoint("TOPRIGHT", c3, "TOPRIGHT", -6, rowY - 2)
        local previewLbl = previewBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        previewLbl:SetAllPoints()
        previewLbl:SetJustifyH("CENTER")
        previewLbl:SetText(">>")
        previewLbl:SetTextColor(0.45, 0.45, 0.52)
        previewBtn:SetScript("OnEnter", function() previewLbl:SetTextColor(0.85, 0.75, 0.40) end)
        previewBtn:SetScript("OnLeave", function() previewLbl:SetTextColor(0.45, 0.45, 0.52) end)
        previewBtn:SetScript("OnClick", function()
            local ss = RH.modules.SpellSuggestion
            if ss and ss.PreviewSound then ss:PreviewSound(soundKey) end
        end)

        soundRows[i] = { dot = dot, lbl = lbl, key = soundKey }
    end

    -- Separator + volume below the sound list
    local soundListBottom = -58 - #sounds * SOUND_ROW_H
    MakeDivider(c3, soundListBottom - 6)
    MakeSectionLabel(c3, "Volume", soundListBottom - 14)
    MakeSlider(c3, soundListBottom - 28, 0.0, 1.0, 0.05, RH.gdb.soundVolume, pct, function(val)
        RH.gdb.soundVolume = val
    end)

    -- Initialise row highlight state when the panel first shows
    panel:HookScript("OnShow", function() RefreshSoundRows() end)
    -- Also refresh immediately so the initial state is correct
    RefreshSoundRows()

    -- ── Tab 4: Manual Profiles ────────────────────────────────────────────

    local c4 = contents[4]

    -- BETA FEATURE label with logo icons on each side
    local betaLabel = c4:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    betaLabel:SetPoint("TOP", c4, "TOP", 0, -7)
    betaLabel:SetText("BETA FEATURE")
    betaLabel:SetTextColor(1, 0.15, 0.15)

    local betaIconL = c4:CreateTexture(nil, "OVERLAY")
    betaIconL:SetTexture("Interface\\AddOns\\RotationHelper\\media\\small")
    betaIconL:SetSize(16, 16)
    betaIconL:SetPoint("RIGHT", betaLabel, "LEFT", -4, 0)

    local betaIconR = c4:CreateTexture(nil, "OVERLAY")
    betaIconR:SetTexture("Interface\\AddOns\\RotationHelper\\media\\small")
    betaIconR:SetSize(16, 16)
    betaIconR:SetPoint("LEFT", betaLabel, "RIGHT", 4, 0)

    local betaFeedback = c4:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    betaFeedback:SetPoint("TOPLEFT",  c4, "TOPLEFT",  14, -28)
    betaFeedback:SetPoint("TOPRIGHT", c4, "TOPRIGHT", -14, -28)
    betaFeedback:SetJustifyH("CENTER")
    betaFeedback:SetWordWrap(true)
    betaFeedback:SetText("We'd love your feedback! Let us know what's working or what could be better.")
    betaFeedback:SetTextColor(0.55, 0.55, 0.60)

    MakeSectionLabel(c4, "Profile", -58)

    -- Custom dropdown button (shows selected profile name)
    local dropBtn = CreateFrame("Button", nil, c4, "BackdropTemplate")
    dropBtn:SetHeight(22)
    dropBtn:SetPoint("TOPLEFT",  c4, "TOPLEFT",  12, -74)
    dropBtn:SetPoint("TOPRIGHT", c4, "TOPRIGHT", -44, -74)
    dropBtn:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = false, tileSize = 0, edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    dropBtn:SetBackdropColor(0.10, 0.10, 0.14, 1)
    dropBtn:SetBackdropBorderColor(0.28, 0.28, 0.36, 1)
    local dropLbl = dropBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    dropLbl:SetPoint("LEFT",  dropBtn, "LEFT",  6, 0)
    dropLbl:SetPoint("RIGHT", dropBtn, "RIGHT", -6, 0)
    dropLbl:SetJustifyH("LEFT")
    dropLbl:SetText("Select a profile...")
    dropLbl:SetTextColor(0.55, 0.55, 0.60)
    dropBtn:SetScript("OnEnter", function()
        dropBtn:SetBackdropBorderColor(0.45, 0.45, 0.55, 1)
    end)
    dropBtn:SetScript("OnLeave", function()
        dropBtn:SetBackdropBorderColor(0.28, 0.28, 0.36, 1)
    end)

    -- Delete button (right of dropdown)
    local deleteBtn = CreateFrame("Button", nil, c4)
    deleteBtn:SetSize(32, 22)
    deleteBtn:SetPoint("TOPLEFT", dropBtn, "TOPRIGHT", 2, 0)
    local deleteLbl = deleteBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    deleteLbl:SetAllPoints()
    deleteLbl:SetText("Del")
    deleteLbl:SetTextColor(0.55, 0.30, 0.30)
    deleteBtn:SetScript("OnEnter", function() deleteLbl:SetTextColor(1, 0.25, 0.25) end)
    deleteBtn:SetScript("OnLeave", function() deleteLbl:SetTextColor(0.55, 0.30, 0.30) end)

    -- Dropdown popup list
    local dropList = CreateFrame("Frame", nil, c4, "BackdropTemplate")
    dropList:SetPoint("TOPLEFT",  dropBtn, "BOTTOMLEFT",  0, -1)
    dropList:SetPoint("TOPRIGHT", dropBtn, "BOTTOMRIGHT", 0, -1)
    dropList:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        tile = false, tileSize = 0, edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    dropList:SetBackdropColor(0.06, 0.06, 0.10, 1)
    dropList:SetBackdropBorderColor(0.28, 0.28, 0.36, 1)
    dropList:SetFrameStrata("FULLSCREEN")
    dropList:Hide()

    local DROP_ROW_H   = 20
    local MAX_DROP_ROWS = 8
    local dropRows = {}
    for r = 1, MAX_DROP_ROWS do
        local row = CreateFrame("Button", nil, dropList)
        row:SetHeight(DROP_ROW_H)
        row:SetPoint("TOPLEFT",  dropList, "TOPLEFT",  2, -(r - 1) * DROP_ROW_H - 2)
        row:SetPoint("TOPRIGHT", dropList, "TOPRIGHT", -2, -(r - 1) * DROP_ROW_H - 2)
        row:Hide()
        local rowBg = row:CreateTexture(nil, "BACKGROUND")
        rowBg:SetAllPoints()
        rowBg:SetColorTexture(0, 0, 0, 0)
        local rowLbl = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        rowLbl:SetPoint("LEFT", row, "LEFT", 4, 0)
        rowLbl:SetTextColor(0.85, 0.85, 0.85)
        row.bg  = rowBg
        row.lbl = rowLbl
        row:SetScript("OnEnter", function() rowBg:SetColorTexture(0.22, 0.22, 0.32, 0.7) end)
        row:SetScript("OnLeave", function() rowBg:SetColorTexture(0, 0, 0, 0) end)
        dropRows[r] = row
    end

    local function PopulateDropList()
        local mr      = RH.modules.ManualRotation
        local specID  = RH:GetSpecID()
        local names   = (mr and specID) and mr:GetProfilesForSpec(specID) or {}
        for r = 1, MAX_DROP_ROWS do
            local row  = dropRows[r]
            local name = names[r]
            if name then
                row.lbl:SetText(name)
                row:SetScript("OnClick", function()
                    RH.db.activeManualProfile = name
                    if mr then mr:LoadProfile(name) end
                    dropList:Hide()
                    OptionsPanel:RefreshManualTab()
                end)
                row:Show()
            else
                row:Hide()
            end
        end
        dropList:SetHeight(#names * DROP_ROW_H + 4)
        dropList:SetShown(#names > 0)
    end

    dropBtn:SetScript("OnClick", function()
        if dropList:IsShown() then
            dropList:Hide()
        else
            PopulateDropList()
        end
    end)

    -- Mode radio buttons
    MakeDivider(c4, -104)
    MakeSectionLabel(c4, "Mode", -112)

    local assistedBtn = CreateFrame("Button", nil, c4)
    assistedBtn:SetSize(110, 22)
    assistedBtn:SetPoint("TOPLEFT", c4, "TOPLEFT", 12, -128)
    local assistedLbl = assistedBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    assistedLbl:SetAllPoints()
    assistedLbl:SetJustifyH("CENTER")
    assistedLbl:SetText("Assisted Combat")

    local manualBtn = CreateFrame("Button", nil, c4)
    manualBtn:SetSize(90, 22)
    manualBtn:SetPoint("TOPLEFT", assistedBtn, "TOPRIGHT", 4, 0)
    local manualModeLbl = manualBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    manualModeLbl:SetAllPoints()
    manualModeLbl:SetJustifyH("CENTER")
    manualModeLbl:SetText("Manual")

    -- Status line
    local statusLabel = c4:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    statusLabel:SetPoint("TOPLEFT",  c4, "TOPLEFT",  14, -158)
    statusLabel:SetPoint("TOPRIGHT", c4, "TOPRIGHT", -14, -158)
    statusLabel:SetJustifyH("LEFT")
    statusLabel:SetWordWrap(true)
    statusLabel:SetText("")
    statusLabel:SetTextColor(0.55, 0.55, 0.60)

    MakeDivider(c4, -172)
    MakeSectionLabel(c4, "Profiles", -180)

    -- New / Edit buttons
    local newBtn = CreateFrame("Button", nil, c4, "UIPanelButtonTemplate")
    newBtn:SetSize(78, 22)
    newBtn:SetPoint("TOPLEFT", c4, "TOPLEFT", 12, -196)
    newBtn:SetText("New")

    local editBtn = CreateFrame("Button", nil, c4, "UIPanelButtonTemplate")
    editBtn:SetSize(78, 22)
    editBtn:SetPoint("TOPLEFT", newBtn, "TOPRIGHT", 4, 0)
    editBtn:SetText("Edit")

    local importBtn = CreateFrame("Button", nil, c4, "UIPanelButtonTemplate")
    importBtn:SetSize(78, 22)
    importBtn:SetPoint("TOPLEFT", c4, "TOPLEFT", 12, -224)
    importBtn:SetText("Import")

    local shareBtn = CreateFrame("Button", nil, c4, "UIPanelButtonTemplate")
    shareBtn:SetSize(78, 22)
    shareBtn:SetPoint("TOPLEFT", importBtn, "TOPRIGHT", 4, 0)
    shareBtn:SetText("Share")

    MakeDivider(c4, -252)
    MakeCheckbox(c4, "Ignore action bar validation", -260,
        function() return RH.db.ignoreBarValidation end,
        function(val)
            RH.db.ignoreBarValidation = val
            local ss = RH.modules.SpellSuggestion
            if ss then ss:UpdateSpell() end
        end)

    -- Wire up mode buttons and profile actions
    local function UpdateModeButtons()
        local isManual = RH.db.manualMode
        local hasProfile = RH.db.activeManualProfile ~= nil
        if isManual then
            assistedLbl:SetTextColor(0.50, 0.50, 0.55)
            manualModeLbl:SetTextColor(0.85, 0.75, 0.40)
        else
            assistedLbl:SetTextColor(0.85, 0.75, 0.40)
            manualModeLbl:SetTextColor(0.50, 0.50, 0.55)
        end
        manualBtn:SetEnabled(hasProfile)
        editBtn:SetEnabled(hasProfile)
        deleteBtn:SetEnabled(hasProfile)
        shareBtn:SetEnabled(hasProfile)
    end

    assistedBtn:SetScript("OnClick", function()
        if RH.db.manualMode then
            RH.db.manualMode = false
            local ss = RH.modules.SpellSuggestion
            if ss then ss:UpdateSpell() end
        end
        UpdateModeButtons()
        OptionsPanel:RefreshManualTab()
    end)

    manualBtn:SetScript("OnClick", function()
        if not RH.db.activeManualProfile then return end
        if not RH.db.manualMode then
            RH.db.manualMode = true
            local mr = RH.modules.ManualRotation
            if mr then mr:LoadProfile(RH.db.activeManualProfile) end
            local ss = RH.modules.SpellSuggestion
            if ss then ss:UpdateSpell() end
        end
        UpdateModeButtons()
        OptionsPanel:RefreshManualTab()
    end)

    newBtn:SetScript("OnClick", function()
        local mr = RH.modules.ManualRotation
        if mr then mr:OpenBuilder(nil) end
    end)

    editBtn:SetScript("OnClick", function()
        local name = RH.db.activeManualProfile
        if not name then return end
        local mr = RH.modules.ManualRotation
        if mr then mr:OpenBuilder(name) end
    end)

    importBtn:SetScript("OnClick", function()
        local mr = RH.modules.ManualRotation
        if mr then mr:OpenImportDialog() end
    end)

    shareBtn:SetScript("OnClick", function()
        local name = RH.db.activeManualProfile
        if not name then return end
        local mr = RH.modules.ManualRotation
        if mr then mr:OpenShareDialog(name) end
    end)

    deleteBtn:SetScript("OnClick", function()
        local name = RH.db.activeManualProfile
        if not name then return end
        local mr = RH.modules.ManualRotation
        if mr then mr:DeleteProfile(name) end
        local ss = RH.modules.SpellSuggestion
        if ss then ss:UpdateSpell() end
        OptionsPanel:RefreshManualTab()
    end)

    -- Store references for RefreshManualTab
    self.manualTabRefs = {
        dropBtn       = dropBtn,
        dropLbl       = dropLbl,
        dropList      = dropList,
        assistedLbl   = assistedLbl,
        manualModeLbl = manualModeLbl,
        manualBtn     = manualBtn,
        editBtn       = editBtn,
        deleteBtn     = deleteBtn,
        shareBtn      = shareBtn,
        statusLabel   = statusLabel,
        updateMode    = UpdateModeButtons,
    }

    -- ── Panel OnShow ──────────────────────────────────────────────────────

    panel:SetScript("OnShow", function()
        RebuildPotionList()
        RebuildSpellList()
        SetActiveTab(activeTabIdx)
    end)

    -- Initialise to first tab
    SetActiveTab(1)
end

-- ── Priority checkbox sync ─────────────────────────────────────────────────
-- Called after any external toggle (keybindings) to keep the UI in sync.

function OptionsPanel:SyncPriorityCbs()
    if not self.priorityCbs then return end
    self.priorityCbs.trinket1:SetChecked(RH.db.trinket1Priority)
    self.priorityCbs.trinket2:SetChecked(RH.db.trinket2Priority)
    self.priorityCbs.potion:SetChecked(RH.db.potionPriority)
    self.priorityCbs.spell:SetChecked(RH.db.spellPriority)
end

-- ── Spec change ────────────────────────────────────────────────────────────
-- Called by Core after LoadSpecProfile swaps in the new spec's data.

function OptionsPanel:OnSpecChanged()
    -- Sync priority checkboxes to the newly loaded spec's values
    if self.priorityCbs then
        self.priorityCbs.trinket1:SetChecked(RH.db.trinket1Priority)
        self.priorityCbs.trinket2:SetChecked(RH.db.trinket2Priority)
        self.priorityCbs.potion:SetChecked(RH.db.potionPriority)
        self.priorityCbs.spell:SetChecked(RH.db.spellPriority)
    end
    if self.RebuildPotionList then self:RebuildPotionList() end
    self:RebuildSpellList()
    self:RefreshManualTab()
end

-- ── Manual tab refresh ──────────────────────────────────────────────────────
-- Updates the dropdown label, mode button states, and status line to reflect
-- the current DB state. Safe to call at any time.

function OptionsPanel:RefreshManualTab()
    local refs = self.manualTabRefs
    if not refs then return end

    local mr      = RH.modules.ManualRotation
    local specID  = RH:GetSpecID()
    local active  = RH.db.activeManualProfile

    -- Validate the active profile is still present and for this spec
    if active and RH.db.manualProfiles then
        local profile = RH.db.manualProfiles[active]
        if not profile or (specID and profile.specID ~= specID) then
            active = nil
            RH.db.activeManualProfile = nil
            RH.db.manualMode          = false
        end
    end

    -- Dropdown label
    if active then
        refs.dropLbl:SetText(active)
        refs.dropLbl:SetTextColor(0.88, 0.88, 0.88)
    else
        refs.dropLbl:SetText("Select a profile...")
        refs.dropLbl:SetTextColor(0.45, 0.45, 0.52)
    end

    -- Mode button highlights
    refs.updateMode()

    -- Status line
    local status = refs.statusLabel
    if not active then
        local names = (mr and specID) and mr:GetProfilesForSpec(specID) or {}
        if #names == 0 then
            status:SetText("No profiles saved for this spec.")
        else
            status:SetText(#names .. " profile(s) available — select one above.")
        end
        status:SetTextColor(0.45, 0.45, 0.52)
    else
        if mr then
            local valid, missing = mr:ValidateProfile()
            if valid then
                local profile   = RH.db.manualProfiles[active]
                local stepCount = profile and profile.steps and #profile.steps or 0
                status:SetText(stepCount .. " steps — ready")
                status:SetTextColor(0.35, 0.85, 0.35)
            else
                status:SetText("Paused — " .. #missing .. " spell(s) not on action bars")
                status:SetTextColor(0.9, 0.55, 0.1)
            end
        end
    end
end

-- ── Cog button ─────────────────────────────────────────────────────────────

function OptionsPanel:CreateCogButton()
    local btn = CreateFrame("Button", "RHCogButton", UIParent)
    btn:SetSize(16, 16)
    btn:SetPoint("TOPRIGHT", RH.frame, "TOPRIGHT", -5, -4)
    btn:SetFrameStrata(RH.frame:GetFrameStrata())
    btn:SetFrameLevel(RH.frame:GetFrameLevel() + 5)

    local icon = btn:CreateFontString(nil, "OVERLAY")
    icon:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE")
    icon:SetAllPoints()
    icon:SetJustifyH("CENTER")
    icon:SetJustifyV("MIDDLE")
    icon:SetText("|TInterface\\Buttons\\UI-OptionsButton:14:14|t")
    self.cogIcon = icon

    btn:SetScript("OnEnter", function() icon:SetAlpha(0.7) end)
    btn:SetScript("OnLeave", function() icon:SetAlpha(1.0) end)
    btn:SetScript("OnClick", function()
        if self.panel:IsShown() then
            self.panel:Hide()
        else
            self.panel:ClearAllPoints()
            self.panel:SetPoint("TOPLEFT", RH.frame, "TOPRIGHT", 4, 0)
            self.panel:Show()
        end
    end)

    self.cogBtn = btn
end

-- ── Minimap button ─────────────────────────────────────────────────────────

function OptionsPanel:CreateMinimapButton()
    local btn = CreateFrame("Button", "RHMinimapButton", Minimap)
    btn:SetSize(31, 31)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFixedFrameStrata(true)
    btn:SetFrameLevel(8)
    btn:SetFixedFrameLevel(true)
    btn:RegisterForClicks("LeftButtonUp")
    btn:RegisterForDrag("LeftButton")

    -- Circular background (same size/texture as LibDBIcon uses)
    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetTexture(136467)  -- Interface\Minimap\UI-Minimap-Background
    bg:SetSize(24, 24)
    bg:SetPoint("CENTER")

    -- Border ring — must anchor TOPLEFT (50×50 texture designed for TOPLEFT of 31×31 button)
    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetTexture(136430)  -- Interface\Minimap\MiniMap-TrackingBorder
    border:SetSize(50, 50)
    border:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, 0)

    -- Highlight on hover
    btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    -- Icon: 18×18 with 5% inset, no masking needed at this size (LibDBIcon pattern)
    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetSize(18, 18)
    icon:SetPoint("CENTER")
    icon:SetTexture("Interface\\AddOns\\RotationHelper\\media\\Logo.png")
    icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)

    -- Position around the minimap ring at a saved angle
    local function UpdatePos()
        local r   = (Minimap:GetWidth() / 2) + 5
        local rad = math.rad(RH.gdb.minimapAngle or 215)
        btn:ClearAllPoints()
        btn:SetPoint("CENTER", Minimap, "CENTER", r * math.cos(rad), r * math.sin(rad))
    end
    UpdatePos()

    -- Drag to reposition; OnUpdate tracks cursor angle only while dragging
    local isDragging = false
    btn:SetScript("OnDragStart", function() isDragging = true end)
    btn:SetScript("OnDragStop",  function()
        isDragging = false
        UpdatePos()  -- snap back to exact ring position
    end)
    btn:SetScript("OnUpdate", function()
        if not isDragging then return end
        local cx, cy   = Minimap:GetCenter()
        local mx, my   = GetCursorPosition()
        local s        = UIParent:GetEffectiveScale()
        RH.gdb.minimapAngle = math.deg(math.atan2(my / s - cy, mx / s - cx))
        UpdatePos()
    end)

    -- Click: toggle options panel, anchored to this button (drag suppresses OnClick automatically)
    btn:SetScript("OnClick", function()
        if self.panel:IsShown() then
            self.panel:Hide()
        else
            self.panel:ClearAllPoints()
            self.panel:SetPoint("TOPRIGHT", btn, "TOPLEFT", -4, 0)
            self.panel:Show()
        end
    end)

    -- Tooltip
    btn:SetScript("OnEnter", function()
        border:SetVertexColor(0.85, 0.75, 0.40, 1)
        GameTooltip:SetOwner(btn, "ANCHOR_LEFT")
        GameTooltip:AddLine("Synaptic", 0.85, 0.75, 0.40)
        GameTooltip:AddLine("Click to open settings", 0.7, 0.7, 0.7)
        GameTooltip:AddLine("Drag to reposition", 0.5, 0.5, 0.5)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function()
        border:SetVertexColor(1, 1, 1, 1)
        GameTooltip:Hide()
    end)

    self.minimapBtn = btn
end

-- ── Lock button ────────────────────────────────────────────────────────────

local LOCKED_TEX   = "Interface\\Buttons\\LockButton-Locked-Up"
local UNLOCKED_TEX = "Interface\\Buttons\\LockButton-Unlocked-Up"

function OptionsPanel:CreateLockButton()
    local btn = CreateFrame("Button", nil, RH.frame)
    btn:SetSize(21, 21)
    btn:SetPoint("RIGHT", self.cogBtn, "LEFT", -4, 0)

    local icon = btn:CreateTexture(nil, "OVERLAY")
    icon:SetAllPoints()
    icon:SetTexture(RH.gdb.locked and LOCKED_TEX or UNLOCKED_TEX)
    self.lockIcon = icon

    btn:SetScript("OnEnter", function()
        icon:SetAlpha(0.7)
        GameTooltip:SetOwner(btn, "ANCHOR_BOTTOM")
        GameTooltip:SetText(RH.gdb.locked and "Locked" or "Unlocked", 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function()
        icon:SetAlpha(1.0)
        GameTooltip:Hide()
    end)
    btn:SetScript("OnClick", function()
        RH.gdb.locked = not RH.gdb.locked
        icon:SetTexture(RH.gdb.locked and LOCKED_TEX or UNLOCKED_TEX)
        if GameTooltip:GetOwner() == btn then
            GameTooltip:SetText(RH.gdb.locked and "Locked" or "Unlocked", 1, 1, 1, 1, true)
        end
        if RH.dragHandle then RH.dragHandle:EnableMouse(not RH.gdb.locked) end
    end)

    self.lockBtn = btn
end

-- ── Controls visibility ────────────────────────────────────────────────────

function OptionsPanel:SetControlsVisible(visible)
    if visible then
        self.cogBtn:Show()
        self.lockBtn:Show()
    else
        self.cogBtn:Hide()
        self.lockBtn:Hide()
    end
end

-- ── Module init ────────────────────────────────────────────────────────────

function OptionsPanel:Init()
    self:CreatePanel()
    self:CreateMinimapButton()
    self:CreateCogButton()
    self:CreateLockButton()

    RH.EventBus:On("PLAYER_REGEN_DISABLED", function()
        if RH.gdb.hideOutOfCombat then
            FadeMainFrame(RH.frame:GetAlpha(), 1.0, 0.3)
            if RH.dragHandle then RH.dragHandle:EnableMouse(true) end
            self.cogBtn:SetAlpha(1.0)
        end
    end, self)

    RH.EventBus:On("PLAYER_REGEN_ENABLED", function()
        if RH.gdb.hideOutOfCombat then
            self.panel:Hide()
            FadeMainFrame(1.0, 0.0, 1.5)
            if RH.dragHandle then RH.dragHandle:EnableMouse(false) end
            self.cogBtn:SetAlpha(COG_FADED_ALPHA)
        end
    end, self)

    if RH.gdb.hideOutOfCombat and not InCombatLockdown() then
        RH.frame:SetAlpha(0)
        if RH.dragHandle then RH.dragHandle:EnableMouse(false) end
        self.cogBtn:SetAlpha(COG_FADED_ALPHA)
    elseif RH.gdb.locked then
        if RH.dragHandle then RH.dragHandle:EnableMouse(false) end
    end

    if not RH.gdb.showControls then
        self:SetControlsVisible(false)
    end
end
