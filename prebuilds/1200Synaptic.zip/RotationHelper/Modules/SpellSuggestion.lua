local RH = RotationHelper

local SpellSuggestion = {}
RH:RegisterModule("SpellSuggestion", SpellSuggestion)

local ICON_SIZE      = 56
local currentSpellID = nil

-- ── Sound alert ────────────────────────────────────────────────────────────
-- Temporarily overrides Sound_SFXVolume so we can control alert loudness
-- without touching the user's permanent settings.

-- Curated list of alert sounds. Each entry has a display name and a SOUNDKIT
-- key string. The key is looked up at runtime via SOUNDKIT[key] so missing
-- entries return nil safely (pcall guards the PlaySound call).
-- Candidate alert sounds. At load time any entry whose SOUNDKIT key does not
-- exist in this client build is silently dropped, so the picker only ever
-- shows sounds that actually play. The preference is stored as the key string
-- (not an index) so saved choices survive list changes across patches.
local SOUND_CANDIDATES = {
    { name = "Raid Warning",  key = "RAID_WARNING"              },
    { name = "Ready Check",   key = "READY_CHECK"               },
    { name = "Whisper",       key = "TELL_MESSAGE"              },
    { name = "Boss Alert",    key = "RAID_BOSS_WHISPER"         },
    { name = "Queue Pop",     key = "PVP_THROUGH_QUEUE_BUTTON"  },
    { name = "Level Up",      key = "LEVEL_UP"                  },
    { name = "Menu Open",     key = "IG_MAINMENU_OPEN"          },
    { name = "Auction",       key = "AUCTION_WINDOW_OPEN"       },
    { name = "Friend Login",  key = "FRIEND_JOIN_GAME"          },
}

local ALERT_SOUNDS = {}
for _, s in ipairs(SOUND_CANDIDATES) do
    if SOUNDKIT and SOUNDKIT[s.key] then
        ALERT_SOUNDS[#ALERT_SOUNDS + 1] = s
    end
end
-- Expose for OptionsPanel sound-picker UI
RH.alertSounds = ALERT_SOUNDS

local function PlayByKey(key)
    local kit = SOUNDKIT and SOUNDKIT[key]
    if not kit then return end
    local vol     = RH.gdb.soundVolume or 0.7
    local prevSFX = GetCVar("Sound_SFXVolume") or "1"
    SetCVar("Sound_SFXVolume", tostring(vol))
    pcall(C_Sound.PlaySound, kit, "SFX")
    C_Timer.After(0.15, function()
        SetCVar("Sound_SFXVolume", prevSFX)
    end)
end

local function PlayAlertSound()
    if not RH.gdb.soundAlert then return end
    PlayByKey(RH.gdb.soundKey or "RAID_WARNING")
end

-- Called by OptionsPanel preview buttons. Accepts the SOUNDKIT key string.
function SpellSuggestion:PreviewSound(key)
    PlayByKey(key)
end

-- ── UI creation ────────────────────────────────────────────────────────────

function SpellSuggestion:CreateUI()
    local parent = RH.frame

    -- Section container — sits just below the title bar
    local section = CreateFrame("Frame", nil, parent)
    section:SetPoint("TOPLEFT",  parent, "TOPLEFT",  10, -24)
    section:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -10, -24)
    section:SetHeight(ICON_SIZE + 20)
    self.section = section

    -- ── Spell icon ──────────────────────────────────────────────────────────
    local iconFrame = CreateFrame("Frame", nil, section)
    iconFrame:SetSize(ICON_SIZE, ICON_SIZE)
    iconFrame:SetPoint("TOPLEFT", section, "TOPLEFT", 0, -8)

    local iconTex = iconFrame:CreateTexture(nil, "ARTWORK")
    iconTex:SetAllPoints()
    iconTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    iconFrame.icon = iconTex


    -- Keybind label — needs its own frame with a higher level than the glow
    -- so it draws on top of everything inside iconFrame.
    local keybindOverlay = CreateFrame("Frame", nil, iconFrame)
    keybindOverlay:SetAllPoints(iconFrame)
    keybindOverlay:SetFrameLevel(iconFrame:GetFrameLevel() + 10)
    local keybindLabel = keybindOverlay:CreateFontString(nil, "OVERLAY")
    keybindLabel:SetFont("Fonts\\FRIZQT__.TTF", RH.gdb.hotkeySize, "OUTLINE")
    keybindLabel:SetPoint("CENTER", keybindOverlay, "CENTER",
        RH.gdb.hotkeyOffsetX or 0, RH.gdb.hotkeyOffsetY or 0)
    keybindLabel:SetTextColor(1, 1, 1, RH.gdb.hotkeyOpacity)
    keybindLabel:SetText("")
    self.keybindLabel = keybindLabel
    RH.keybindLabel   = keybindLabel

    -- Charge recharge sweep — visible when all charges are depleted.
    -- Sits at level +2 so GCDIndicator's sweep (level +5) renders above it.
    local chargeCooldown = CreateFrame("Cooldown", nil, iconFrame, "CooldownFrameTemplate")
    chargeCooldown:SetAllPoints(iconFrame)
    chargeCooldown:SetFrameLevel(iconFrame:GetFrameLevel() + 2)
    chargeCooldown:SetHideCountdownNumbers(false)
    chargeCooldown:SetDrawEdge(false)
    chargeCooldown:SetSwipeColor(0, 0, 0, 0.72)
    chargeCooldown:SetDrawSwipe(true)
    chargeCooldown:Hide()
    self.chargeCooldown = chargeCooldown

    -- Native Blizzard glow animation (ActionButtonSpellAlertTemplate)
    local glow = CreateFrame("Frame", nil, iconFrame, "ActionButtonSpellAlertTemplate")
    glow:SetSize(ICON_SIZE * 1.4, ICON_SIZE * 1.4)
    glow:SetPoint("CENTER", iconFrame, "CENTER", 0, 0)
    glow:Hide()
    iconFrame.glow = glow

    -- Static border shown instead of the animated glow when showSpellGlow is false.
    -- Parented to section (not iconFrame) so it sits behind the icon without
    -- interfering with child frame levels.
    local iconBorder = CreateFrame("Frame", nil, section, "BackdropTemplate")
    iconBorder:SetSize(ICON_SIZE + 4, ICON_SIZE + 4)
    iconBorder:SetPoint("CENTER", iconFrame, "CENTER", 0, 0)
    iconBorder:SetFrameLevel(iconFrame:GetFrameLevel() - 1)
    iconBorder:SetBackdrop({
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 2,
        insets = { left = 2, right = 2, top = 2, bottom = 2 },
    })
    iconBorder:SetBackdropBorderColor(0, 0, 0, 1)
    iconBorder:Hide()
    self.iconBorder = iconBorder

    -- Expose the icon frame so GCDIndicator can overlay on it
    RH.spellIconFrame = iconFrame
    self.iconFrame    = iconFrame

    -- Tooltip on hover
    iconFrame:EnableMouse(true)
    iconFrame:SetScript("OnEnter", function(frame)
        local td = SpellSuggestion.tooltipData
        if not td then return end
        GameTooltip:SetOwner(frame, "ANCHOR_RIGHT")
        if td.type == "spell" then
            GameTooltip:SetSpellByID(td.id)
        else
            GameTooltip:SetItemByID(td.id)
        end
        GameTooltip:Show()
    end)
    iconFrame:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    -- ── Text labels ─────────────────────────────────────────────────────────
    local nameLabel = section:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    nameLabel:SetPoint("TOPLEFT",  iconFrame, "TOPRIGHT", 8, -4)
    nameLabel:SetPoint("TOPRIGHT", section,   "TOPRIGHT", 0, -4)
    nameLabel:SetJustifyH("LEFT")
    nameLabel:SetWordWrap(false)
    self.nameLabel = nameLabel

    local statusLabel = section:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    statusLabel:SetPoint("TOPLEFT", nameLabel, "BOTTOMLEFT", 0, -3)
    statusLabel:SetJustifyH("LEFT")
    self.statusLabel = statusLabel

    -- Shown when C_AssistedCombat.IsAvailable() returns false
    local unavailLabel = section:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    unavailLabel:SetPoint("LEFT", iconFrame, "RIGHT", 8, 0)
    unavailLabel:SetJustifyH("LEFT")
    unavailLabel:SetText(RotationHelperL.SYSTEM_UNAVAILABLE)
    unavailLabel:Hide()
    self.unavailLabel = unavailLabel

end

-- ── Glow helpers ───────────────────────────────────────────────────────────

function SpellSuggestion:ShowGlow()
    if not RH.gdb.showSpellGlow then
        self.iconBorder:Show()
        return
    end
    self.iconBorder:Hide()
    local glow = self.iconFrame.glow
    glow:Show()
    if not glow.ProcStartAnim:IsPlaying() then
        glow.ProcStartAnim:Play()
    end
end

function SpellSuggestion:HideGlow()
    self.iconBorder:Hide()
    local glow = self.iconFrame.glow
    glow.ProcStartAnim:Stop()
    glow:Hide()
end

-- ── Keybind helper ──────────────────────────────────────────────────────────

function SpellSuggestion:SetKeybind(key)
    self.keybindLabel:SetText(key or "")
end

-- ── Name visibility ─────────────────────────────────────────────────────────
-- Enforces the showSpellName setting after any display path that shows labels.

function SpellSuggestion:ApplyNameVisibility()
    if not RH.gdb.showSpellName then
        self.nameLabel:Hide()
        self.statusLabel:Hide()
    end
end

-- ── Priority item display ───────────────────────────────────────────────────

function SpellSuggestion:ShowPriorityItem(item)
    currentSpellID = nil  -- force redraw when priority clears
    self.tooltipData = {
        type = item.isSpell and "spell" or "item",
        id   = item.isSpell and item.spellID or item.itemID,
    }
    self.iconFrame.icon:SetTexture(item.icon)
    self.iconFrame.icon:SetDesaturated(false)
    -- Action text is always short ("Use Trinket!") — make it the primary label
    self.nameLabel:SetText(item.label)
    self.nameLabel:SetTextColor(1.0, 0.82, 0.0)  -- gold
    self.nameLabel:Show()
    -- Item name is secondary — smaller font handles long names fine
    self.statusLabel:SetText(item.name)
    self.statusLabel:SetTextColor(0.75, 0.75, 0.75)
    self.statusLabel:Show()
    self.unavailLabel:Hide()
    self:ShowGlow()
    if item.isSpell then
        self:SetKeybind(RH.Utils.GetSpellKeybind(item.spellID))
    else
        self:SetKeybind(item.itemID and RH.Utils.GetItemKeybind(item.itemID))
    end
    self:ApplyNameVisibility()
end

-- ── Display update ─────────────────────────────────────────────────────────

function SpellSuggestion:UpdateSpell()
    -- Manual rotation mode: hand off to ManualRotation module entirely.
    if RH.db.manualMode then
        local mr = RH.modules.ManualRotation
        if mr then mr:UpdateDisplay() end
        self:ApplyNameVisibility()
        return
    end

    -- Priority items (trinkets / potions / spells) take precedence over everything,
    -- including the IsAvailable() gate — defensive cooldowns and trinkets must fire
    -- regardless of whether Assisted Combat has a rotation suggestion.
    local priorityMod = RH.modules.PriorityItems
    if priorityMod then
        local item = priorityMod:GetPriorityItem()
        if item then
            local newKey = item.isSpell and ("spell:" .. item.spellID)
                                        or  ("item:"  .. item.itemID)
            if newKey ~= self.currentPriorityKey then
                self.currentPriorityKey = newKey
                PlayAlertSound()
            end
            self:ShowPriorityItem(item)
            return
        end
    end
    self.currentPriorityKey = nil

    local isAvailable = C_AssistedCombat.IsAvailable()
    if not isAvailable then
        self:ClearDisplay(true)
        return
    end

    local spellID = C_AssistedCombat.GetNextCastSpell()
    if not spellID then
        self:ClearDisplay(false)
        return
    end

    -- No target: clear the icon and tell the player to select one.
    -- Reset currentSpellID each time so the static update re-fires when
    -- a target is acquired and we need to set the icon/name/keybind again.
    if not UnitExists("target") then
        currentSpellID = nil
        self.tooltipData = nil
        self.iconFrame.icon:SetTexture("Interface\\Icons\\Ability_hisek_aim")
        self.iconFrame.icon:SetDesaturated(true)
        self.chargeCooldown:SetCooldown(0, 0)
        self.chargeCooldown:Hide()
        self:SetKeybind(nil)
        self:HideGlow()
        self.unavailLabel:Hide()
        self.nameLabel:SetText(RotationHelperL.NO_TARGET)
        self.nameLabel:SetTextColor(0.55, 0.55, 0.55)
        self.nameLabel:Show()
        self.statusLabel:SetText("")
        self.statusLabel:Show()
        self:ApplyNameVisibility()
        return
    end

    -- Static spell info: only update icon/name/keybind when the suggestion changes.
    -- The 96-slot keybind scan is skipped on every tick when the same spell holds.
    if spellID ~= currentSpellID then
        local info = C_Spell.GetSpellInfo(spellID)
        if not info then return end  -- wait for data; retry next tick
        currentSpellID = spellID
        self.tooltipData = { type = "spell", id = spellID }
        self.iconFrame.icon:SetTexture(info.iconID)
        self.nameLabel:SetText(info.name)
        self.nameLabel:SetTextColor(1, 1, 1)
        self.unavailLabel:Hide()
        self.nameLabel:Show()
        self.statusLabel:Show()
        self:SetKeybind(RH.Utils.GetSpellKeybind(spellID))
    end

    -- Dynamic state: always re-evaluate so the icon reacts to cooldown expiry,
    -- resource changes, and the player moving in/out of range between ticks.
    local isUsable, insufficientPower = C_Spell.IsSpellUsable(spellID)
    if insufficientPower then
        self.statusLabel:SetText(RotationHelperL.NOT_ENOUGH_POWER)
        self.statusLabel:SetTextColor(0.9, 0.35, 0.35)
        self.iconFrame.icon:SetDesaturated(true)
        self:HideGlow()
    else
        -- Charge-based spells (e.g. Judgement): castable while currentCharges > 0
        -- even while another charge recharges. Check directly; IsSpellUsable may
        -- not reliably reflect charge state under Midnight combat taint.
        local canCast = isUsable
        local noCharges = false
        pcall(function()
            local currentCharges, maxCharges = C_Spell.GetSpellCharges(spellID)
            -- maxCharges is a static property, less likely to be tainted; guard with pcall anyway.
            local isChargeBased = false
            pcall(function() isChargeBased = maxCharges > 1 end)
            if isChargeBased then
                -- tostring() converts the tainted number to a plain string so we can
                -- branch without triggering "attempt to compare secret number" errors.
                local chargesStr = tostring(currentCharges)
                if chargesStr == "0" then
                    canCast   = false
                    noCharges = true
                else
                    canCast = true
                end
            end
        end)

        -- Range check. Target is guaranteed to exist here (early return above).
        -- IsSpellInRange returns true (in range), false (out of range), nil (no restriction).
        local inRange = true
        pcall(function()
            local result = C_Spell.IsSpellInRange(spellID, "target")
            pcall(function()
                if result == false then inRange = false end
            end)
        end)

        if not canCast or not inRange then
            -- Drive the charge recharge sweep using the DurationObject API (Patch 12.0).
            -- GetSpellCooldownDuration returns a secret-safe DurationObject for both
            -- charge recharge and regular cooldowns; avoids secret number comparisons.
            pcall(function()
                local dur = C_Spell.GetSpellCooldownDuration(spellID)
                if dur then
                    self.chargeCooldown:SetCooldownFromDurationObject(dur)
                else
                    self.chargeCooldown:SetCooldown(0, 0)
                end
            end)
            self.chargeCooldown:Show()
            if not inRange then
                self.statusLabel:SetText(RotationHelperL.OUT_OF_RANGE)
                self.statusLabel:SetTextColor(0.9, 0.35, 0.35)
            elseif noCharges then
                self.statusLabel:SetText(RotationHelperL.NO_CHARGES)
                self.statusLabel:SetTextColor(0.9, 0.35, 0.35)
            else
                self.statusLabel:SetText("")
                self.statusLabel:SetTextColor(1, 1, 1)
            end
            self.iconFrame.icon:SetDesaturated(true)
            self:HideGlow()
        else
            self.chargeCooldown:SetCooldown(0, 0)
            self.chargeCooldown:Hide()
            self.statusLabel:SetText("")
            self.statusLabel:SetTextColor(1, 1, 1)
            self.iconFrame.icon:SetDesaturated(false)
            self:ShowGlow()
        end
    end
    self:ApplyNameVisibility()
end

function SpellSuggestion:ClearDisplay(systemUnavailable)
    currentSpellID          = nil
    self.tooltipData        = nil
    self.currentPriorityKey = nil
    self.iconFrame.icon:SetTexture(nil)
    self.iconFrame.icon:SetDesaturated(false)
    self.chargeCooldown:SetCooldown(0, 0)
    self.chargeCooldown:Hide()
    self.nameLabel:SetText("")
    self.statusLabel:SetText("")
    self:SetKeybind(nil)
    self:HideGlow()

    if systemUnavailable then
        self.unavailLabel:Show()
        self.nameLabel:Hide()
        self.statusLabel:Hide()
    else
        self.unavailLabel:Hide()
        self.nameLabel:Show()
        self.statusLabel:Show()
    end
end

-- ── Module init ────────────────────────────────────────────────────────────

function SpellSuggestion:Init()
    self:CreateUI()

    -- Primary signal: Blizzard's recommendation changed
    EventRegistry:RegisterCallback(
        "AssistedCombatManager.OnAssistedHighlightSpellChange",
        function() self:UpdateSpell() end,
        self
    )

    -- Re-evaluate suggestions on power change.
    RH.EventBus:On("UNIT_POWER_UPDATE", function(_, unit)
        if unit == "player" then self:UpdateSpell() end
    end, self)
    -- Refresh when usability state changes (resources, range)
    RH.EventBus:On("SPELL_UPDATE_USABLE",           function() self:UpdateSpell() end, self)
    -- Re-evaluate range immediately on target change, not just on next 0.25s tick
    RH.EventBus:On("PLAYER_TARGET_CHANGED",         function() self:UpdateSpell() end, self)
    RH.EventBus:On("PLAYER_SPECIALIZATION_CHANGED", function() self:UpdateSpell() end, self)
    RH.EventBus:On("PLAYER_ENTERING_WORLD", function()
        RH.Utils.InvalidateHotkeyMap()
        currentSpellID = nil  -- force keybind re-evaluation after load
        self:UpdateSpell()
    end, self)

    -- Refresh when bag item cooldowns change (potions becoming ready)
    RH.EventBus:On("BAG_UPDATE_COOLDOWN",      function() self:UpdateSpell() end, self)
    -- Refresh when action bar contents change (spell moved to a different bar)
    -- Must clear currentSpellID so GetSlotKey re-runs for the new bar position.
    RH.EventBus:On("ACTIONBAR_SLOT_CHANGED", function()
        currentSpellID = nil
        self:UpdateSpell()
    end, self)
    -- GetItemInfo loads async; re-check when data arrives (needed for potion classID)
    RH.EventBus:On("GET_ITEM_INFO_RECEIVED",   function() self:UpdateSpell() end, self)

    -- Re-read keybinds if the player changes their bindings
    RH.EventBus:On("UPDATE_BINDINGS", function()
        RH.Utils.InvalidateHotkeyMap()
        currentSpellID = nil  -- force full redraw with fresh keybind lookup
        self:UpdateSpell()
    end, self)

    -- Druid/Rogue form changes page bar 1 to a different slot range (73-96).
    -- Clear currentSpellID so the keybind re-evaluates against the new active bar.
    RH.EventBus:On("UPDATE_SHAPESHIFT_FORM", function()
        currentSpellID = nil
        self:UpdateSpell()
    end, self)

    -- Fire immediately when the player finishes a cast — this is the exact
    -- moment a spell's cooldown starts and another may come off cooldown.
    RH.EventBus:On("UNIT_SPELLCAST_SUCCEEDED", function(_, unit)
        if unit == "player" then self:UpdateSpell() end
    end, self)

    local ss = self
    C_Timer.NewTicker(0.25, function()
        ss:UpdateSpell()
    end)

    self:UpdateSpell()
end
