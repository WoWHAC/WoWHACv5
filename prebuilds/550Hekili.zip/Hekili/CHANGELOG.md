# Hekili

## [v5.5.4-1](https://github.com/Smufrik/Hekili/tree/v5.5.4-1) (2026-06-03)
[Full Changelog](https://github.com/Smufrik/Hekili/compare/v5.5.3-1.0.0z...v5.5.4-1) [Previous Releases](https://github.com/Smufrik/Hekili/releases)

- Refactor APL for various classes to improve performance and align with recent updates  
    - Death Knight Frost: Adjusted Horn of Winter condition and Empower Rune Weapon usage.  
    - Death Knight Unholy: Updated proc window to include trinket procs.  
    - Druid Balance: Enhanced cooldown usage with trinket proc conditions and optimized DoT refresh logic.  
    - Hunter Beast Mastery: Added Fervor and Dire Beast to core rotation.  
    - Hunter Marksmanship: Included Dire Beast in sustain phase.  
    - Hunter Survival: Integrated Dire Beast into cooldowns.  
    - Monk Windwalker: Refined item usage conditions and Xuen alignment with cooldowns.  
    - Paladin Retribution: Updated Divine Storm and Templar's Verdict conditions for better synergy with set bonuses.  
    - Rogue Combat: Modified generator actions to prioritize Revealing Strike over Sinister Strike.  
    - Shaman Elemental: Improved Ascendance and Flame Shock management.  
    - Warlock Affliction: Gated Malefic Grasp on active Agony window.  
    - Added regression tests for Death Knight Unholy and Paladin Retribution packs.  
    - Implemented UI event checks to ensure compatibility with WoW 5.5.4.  
    - Added tests for APL updates across multiple classes to ensure correctness.  
