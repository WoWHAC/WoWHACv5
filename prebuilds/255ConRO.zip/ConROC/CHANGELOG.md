# -ConROC- Conflict Rotation Optimizer Classic

## [v2.12.0](https://github.com/knifebunny/ConROC-TBC/tree/v2.12.0) (2026-04-02)
[Full Changelog](https://github.com/knifebunny/ConROC-TBC/compare/v2.11.0...v2.12.0) [Previous Releases](https://github.com/knifebunny/ConROC-TBC/releases)

- Release v2.12.0 — Final six class module overhauls  
    Complete TBC module overhauls for Warlock, Warrior, Paladin, Mage, Hunter,  
    and Priest. Adds all missing TBC spell ranks (61-70), new TBC abilities,  
    checkbox guards on all suggested spells, and removes all Season of Discovery  
    dead code. Also fixes Druid cat form rotation bug where only Tiger's Fury  
    and Mangle were suggested (6 combined issues: TarYou gate on Shred, missing  
    energy checks on Mangle, nil-unsafe debuff duration, missing spellmenu  
    entries for Shred/FerociousBite).  
    This completes the module overhaul process for all 9 playable classes.  
    Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>  
