# MaxDps_Paladin

## [v11.1.42](https://github.com/kaminaris/MaxDps-Paladin/tree/v11.1.42) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Paladin/compare/v11.1.41...v11.1.42) [Previous Releases](https://github.com/kaminaris/MaxDps-Paladin/releases)

- MIDNIGHT  
