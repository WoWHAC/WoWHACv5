# MaxDps_Paladin

## [v11.1.52](https://github.com/kaminaris/MaxDps-Paladin/tree/v11.1.52) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Paladin/compare/v11.1.51...v11.1.52) [Previous Releases](https://github.com/kaminaris/MaxDps-Paladin/releases)

- Update All Retail  
