# MaxDps_Priest

## [v11.1.29](https://github.com/kaminaris/MaxDps-Priest/tree/v11.1.29) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Priest/compare/v11.1.28...v11.1.29) [Previous Releases](https://github.com/kaminaris/MaxDps-Priest/releases)

- Update All Retail  
