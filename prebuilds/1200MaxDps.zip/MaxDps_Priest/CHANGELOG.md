# MaxDps_Priest

## [v11.1.20](https://github.com/kaminaris/MaxDps-Priest/tree/v11.1.20) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Priest/compare/v11.1.19...v11.1.20) [Previous Releases](https://github.com/kaminaris/MaxDps-Priest/releases)

- MIDNIGHT  
