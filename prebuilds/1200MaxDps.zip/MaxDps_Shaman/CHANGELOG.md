# MaxDps_Shaman

## [v11.1.44](https://github.com/kaminaris/MaxDps-Shaman/tree/v11.1.44) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Shaman/compare/v11.1.43...v11.1.44) [Previous Releases](https://github.com/kaminaris/MaxDps-Shaman/releases)

- MIDNIGHT  
