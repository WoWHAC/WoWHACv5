# MaxDps_Shaman

## [v11.1.54](https://github.com/kaminaris/MaxDps-Shaman/tree/v11.1.54) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Shaman/compare/v11.1.53...v11.1.54) [Previous Releases](https://github.com/kaminaris/MaxDps-Shaman/releases)

- Update All Retail  
