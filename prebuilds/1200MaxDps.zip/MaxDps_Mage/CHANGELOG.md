# MaxDps_Mage

## [v11.1.45](https://github.com/kaminaris/MaxDps-Mage/tree/v11.1.45) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Mage/compare/v11.1.44...v11.1.45) [Previous Releases](https://github.com/kaminaris/MaxDps-Mage/releases)

- MIDNIGHT  
