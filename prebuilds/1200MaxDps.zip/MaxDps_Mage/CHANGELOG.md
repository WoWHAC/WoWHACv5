# MaxDps_Mage

## [v11.1.54](https://github.com/kaminaris/MaxDps-Mage/tree/v11.1.54) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Mage/compare/v11.1.53...v11.1.54) [Previous Releases](https://github.com/kaminaris/MaxDps-Mage/releases)

- Update All Retail  
