# MaxDps_Rogue

## [v11.1.37](https://github.com/kaminaris/MaxDps-Rogue/tree/v11.1.37) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Rogue/compare/v11.1.36...v11.1.37) [Previous Releases](https://github.com/kaminaris/MaxDps-Rogue/releases)

- Update All Retail  
