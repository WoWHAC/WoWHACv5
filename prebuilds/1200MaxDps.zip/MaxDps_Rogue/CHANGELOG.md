# MaxDps_Rogue

## [v11.1.28](https://github.com/kaminaris/MaxDps-Rogue/tree/v11.1.28) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Rogue/compare/v11.1.27...v11.1.28) [Previous Releases](https://github.com/kaminaris/MaxDps-Rogue/releases)

- MIDNIGHT  
