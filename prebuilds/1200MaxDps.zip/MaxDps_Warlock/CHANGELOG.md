# MaxDps_Warlock

## [v11.1.59](https://github.com/kaminaris/MaxDps-Warlock/tree/v11.1.59) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warlock/compare/v11.1.58...v11.1.59) [Previous Releases](https://github.com/kaminaris/MaxDps-Warlock/releases)

- Update All Retail  
