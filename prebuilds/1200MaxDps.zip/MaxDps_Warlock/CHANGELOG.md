# MaxDps_Warlock

## [v11.1.49](https://github.com/kaminaris/MaxDps-Warlock/tree/v11.1.49) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warlock/compare/v11.1.48...v11.1.49) [Previous Releases](https://github.com/kaminaris/MaxDps-Warlock/releases)

- MIDNIGHT  
