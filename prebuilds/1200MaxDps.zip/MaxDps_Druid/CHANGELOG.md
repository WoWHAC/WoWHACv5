# MaxDps_Druid

## [v11.1.83](https://github.com/kaminaris/MaxDps-Druid/tree/v11.1.83) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Druid/compare/v11.1.82...v11.1.83) [Previous Releases](https://github.com/kaminaris/MaxDps-Druid/releases)

- Update All Retail  
