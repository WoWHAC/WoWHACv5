# MaxDps_Druid

## [v11.1.66](https://github.com/kaminaris/MaxDps-Druid/tree/v11.1.66) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Druid/compare/v11.1.65...v11.1.66) [Previous Releases](https://github.com/kaminaris/MaxDps-Druid/releases)

- MIDNIGHT  
