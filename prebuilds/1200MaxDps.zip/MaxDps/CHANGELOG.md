# MaxDps

## [v11.2.32](https://github.com/kaminaris/MaxDps/tree/v11.2.32) (2026-01-21)
[Full Changelog](https://github.com/kaminaris/MaxDps/compare/v11.2.31...v11.2.32) [Previous Releases](https://github.com/kaminaris/MaxDps/releases)

- [Core][Retail] Check Spell Set  
- [Helper] Fix CheckSpellUsable For Retail  
