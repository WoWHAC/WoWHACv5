# MaxDps

## [v11.3.1](https://github.com/kaminaris/MaxDps/tree/v11.3.1) (2026-04-11)
[Full Changelog](https://github.com/kaminaris/MaxDps/compare/v11.3.0...v11.3.1) [Previous Releases](https://github.com/kaminaris/MaxDps/releases)

- Update Cooldowns  
