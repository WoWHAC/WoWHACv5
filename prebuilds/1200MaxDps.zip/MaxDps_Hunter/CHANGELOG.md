# MaxDps_Hunter

## [v11.1.41](https://github.com/kaminaris/MaxDps-Hunter/tree/v11.1.41) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Hunter/compare/v11.1.40...v11.1.41) [Previous Releases](https://github.com/kaminaris/MaxDps-Hunter/releases)

- MIDNIGHT  
