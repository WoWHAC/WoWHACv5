# MaxDps_Hunter

## [v11.1.51](https://github.com/kaminaris/MaxDps-Hunter/tree/v11.1.51) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Hunter/compare/v11.1.50...v11.1.51) [Previous Releases](https://github.com/kaminaris/MaxDps-Hunter/releases)

- Update All Retail  
