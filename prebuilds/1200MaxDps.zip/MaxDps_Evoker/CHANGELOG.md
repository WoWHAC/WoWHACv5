# MaxDps_Evoker

## [v11.1.15](https://github.com/kaminaris/MaxDps-Evoker/tree/v11.1.15) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Evoker/compare/v11.1.14...v11.1.15) [Previous Releases](https://github.com/kaminaris/MaxDps-Evoker/releases)

- MIDNIGHT  
