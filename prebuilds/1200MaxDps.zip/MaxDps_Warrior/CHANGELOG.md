# MaxDps_Warrior

## [v11.1.37](https://github.com/kaminaris/MaxDps-Warrior/tree/v11.1.37) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warrior/compare/v11.1.36...v11.1.37) [Previous Releases](https://github.com/kaminaris/MaxDps-Warrior/releases)

- MIDNIGHT  
