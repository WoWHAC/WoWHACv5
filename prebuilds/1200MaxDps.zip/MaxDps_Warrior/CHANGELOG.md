# MaxDps_Warrior

## [v11.1.48](https://github.com/kaminaris/MaxDps-Warrior/tree/v11.1.48) (2026-04-10)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warrior/compare/v11.1.47...v11.1.48) [Previous Releases](https://github.com/kaminaris/MaxDps-Warrior/releases)

- Update All MoP  
