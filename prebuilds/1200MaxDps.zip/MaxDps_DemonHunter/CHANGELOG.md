# MaxDps_DemonHunter

## [v11.1.31](https://github.com/kaminaris/MaxDps-DemonHunter/tree/v11.1.31) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-DemonHunter/compare/v11.1.30...v11.1.31) [Previous Releases](https://github.com/kaminaris/MaxDps-DemonHunter/releases)

- Update All Retail  
