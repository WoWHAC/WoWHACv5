# MaxDps_DemonHunter

## [v11.1.21](https://github.com/kaminaris/MaxDps-DemonHunter/tree/v11.1.21) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-DemonHunter/compare/v11.1.20...v11.1.21) [Previous Releases](https://github.com/kaminaris/MaxDps-DemonHunter/releases)

- MIDNIGHT  
