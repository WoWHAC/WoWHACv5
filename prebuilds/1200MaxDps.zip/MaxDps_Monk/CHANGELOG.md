# MaxDps_Monk

## [v11.1.27](https://github.com/kaminaris/MaxDps-Monk/tree/v11.1.27) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-Monk/compare/v11.1.26...v11.1.27) [Previous Releases](https://github.com/kaminaris/MaxDps-Monk/releases)

- MIDNIGHT  
