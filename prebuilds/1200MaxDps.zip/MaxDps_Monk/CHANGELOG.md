# MaxDps_Monk

## [v11.1.34](https://github.com/kaminaris/MaxDps-Monk/tree/v11.1.34) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-Monk/compare/v11.1.33...v11.1.34) [Previous Releases](https://github.com/kaminaris/MaxDps-Monk/releases)

- Update All Retail  
