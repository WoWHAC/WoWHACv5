# MaxDps_DeathKnight

## [v11.1.64](https://github.com/kaminaris/MaxDps-DeathKnight/tree/v11.1.64) (2026-04-08)
[Full Changelog](https://github.com/kaminaris/MaxDps-DeathKnight/compare/v11.1.63...v11.1.64) [Previous Releases](https://github.com/kaminaris/MaxDps-DeathKnight/releases)

- Update All Retail  
