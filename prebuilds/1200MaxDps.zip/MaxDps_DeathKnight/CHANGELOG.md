# MaxDps_DeathKnight

## [v11.1.57](https://github.com/kaminaris/MaxDps-DeathKnight/tree/v11.1.57) (2026-01-20)
[Full Changelog](https://github.com/kaminaris/MaxDps-DeathKnight/compare/v11.1.56...v11.1.57) [Previous Releases](https://github.com/kaminaris/MaxDps-DeathKnight/releases)

- MIDNIGHT  
