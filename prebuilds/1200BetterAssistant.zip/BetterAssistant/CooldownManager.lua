local _, addon = ...

addon.cdm = {}
local M = addon.cdm

local QUESTION_MARK_ICON = "Interface\\Icons\\INV_Misc_QuestionMark"

local DEFAULT_CONFIG = {
    enabled  = true,
    iconSize = 48,
    showSwipe = true,
    maxAuras = 12,
}

local DEBUG = false
local function dbg(...)
    if DEBUG then
        print("|cff80ff80[BA-CDM]|r", ...)
    end
end

local PLAYER_FILTER = "HELPFUL"
local TARGET_FILTER = "HARMFUL|PLAYER"

local EMPTY_FILTERS = { includeSpellIDs = {} }

function M.GetMaxAuras(core)
    local cfg = core and core.config and core.config.cdm
    return (cfg and tonumber(cfg.maxAuras)) or DEFAULT_CONFIG.maxAuras
end

function M.EnsureConfig(core)
    if not core.config.cdm then core.config.cdm = {} end
    for k, v in pairs(DEFAULT_CONFIG) do
        if core.config.cdm[k] == nil then
            core.config.cdm[k] = v
        end
    end
    if type(core.config.cdm.auras) ~= "table" then
        core.config.cdm.auras = {}
    end
end

function M.QueueRebuild()
    M.rebuildQueued = true
end


local function GetCatalog()
    if M.cdmCatalog then return M.cdmCatalog end

    local auraCategories = {}
    for _, key in ipairs({ "TrackedBuff", "TrackedBar", "EquipSlotTracked", "SpecAgnosticTracked" }) do
        if Enum.CooldownViewerCategory[key] then
            auraCategories[Enum.CooldownViewerCategory[key]] = true
        end
    end

    local matchIDs, list, listed = {}, {}, {}

    local function UnionInto(key, set)
        local dst = matchIDs[key]
        if not dst then
            dst = {}
            matchIDs[key] = dst
        end
        for id in pairs(set) do dst[id] = true end
    end

    local categories = {}
    for _, category in pairs(Enum.CooldownViewerCategory) do
        if category >= 0 then
            categories[#categories + 1] = category
        end
    end

    for _, category in ipairs(categories) do
        for _, cooldownID in ipairs(C_CooldownViewer.GetCooldownViewerCategorySet(category, true)) do
            local info = C_CooldownViewer.GetCooldownViewerCooldownInfo(cooldownID)
            if info and info.spellID then
                local set = { [info.spellID] = true }
                if info.overrideSpellID then set[info.overrideSpellID] = true end
                if info.overrideTooltipSpellID then set[info.overrideTooltipSpellID] = true end
                if info.linkedSpellIDs then
                    for _, id in ipairs(info.linkedSpellIDs) do set[id] = true end
                end

                local displayID = info.overrideTooltipSpellID or info.spellID
                local labelID = info.overrideTooltipSpellID or info.overrideSpellID or info.spellID

                UnionInto(displayID, set)
                if displayID ~= info.spellID then
                    UnionInto(info.spellID, set)
                end

                if DEBUG and auraCategories[category] then
                    dbg(("entry cd=%d spell=%d display=%d '%s' cat=%d linked=%s"):format(
                        cooldownID, info.spellID, displayID,
                        C_Spell.GetSpellName(labelID) or "?", category,
                        info.linkedSpellIDs and #info.linkedSpellIDs > 0
                            and table.concat(info.linkedSpellIDs, "/") or "-"))
                end

                if auraCategories[category] and not listed[displayID] then
                    listed[displayID] = true
                    list[#list + 1] = {
                        spellID = displayID,
                        name = C_Spell.GetSpellName(labelID) or ("Spell " .. displayID),
                        icon = C_Spell.GetSpellTexture(labelID),
                        known = info.isKnown ~= false,
                    }
                end
            end
        end
    end
    local basesByName = {}
    for base in pairs(matchIDs) do
        local name = C_Spell.GetSpellName(base)
        if name then
            basesByName[name] = basesByName[name] or {}
            table.insert(basesByName[name], base)
        end
    end
    for name, bases in pairs(basesByName) do
        if #bases > 1 then
            local union = {}
            for _, base in ipairs(bases) do
                for id in pairs(matchIDs[base]) do union[id] = true end
            end
            for _, base in ipairs(bases) do
                matchIDs[base] = union
            end
            dbg("name-merge:", name, "->", table.concat(bases, ", "))
        end
    end

    table.sort(list, function(a, b)
        if a.known ~= b.known then return a.known end
        return a.name < b.name
    end)

    M.cdmCatalog = { matchIDs = matchIDs, list = list }
    dbg("CDM catalog built:", #list, "auras")
    return M.cdmCatalog
end

function M.GetCDMAuraList()
    return GetCatalog().list
end

local function BuildIncludedSpellIDs(spellID, catalog)
    local map = { [spellID] = true }
    local merged = catalog.matchIDs[spellID]
    if merged then
        for id in pairs(merged) do map[id] = true end
    end

    return map
end

M.BuildIncludedSpellIDs = BuildIncludedSpellIDs


local TOTEM_CAST_WINDOW = 2.0

local function DetectTotemSupport()
    assert(type(GetNumTotemSlots) == "function",
        "BetterAssistant: GetNumTotemSlots is required for totem tracking")
    assert(type(GetTotemDuration) == "function",
        "BetterAssistant: GetTotemDuration is required for totem tracking")
    assert(type(GetTotemInfo) == "function",
        "BetterAssistant: GetTotemInfo is required for totem tracking")
    assert(C_Secrets ~= nil
            and type(C_Secrets.ShouldTotemSlotBeSecret) == "function",
        "BetterAssistant: C_Secrets.ShouldTotemSlotBeSecret is required for totem tracking")
    assert(type(C_Secrets.ShouldUnitSpellCastingBeSecret) == "function",
        "BetterAssistant: C_Secrets.ShouldUnitSpellCastingBeSecret is required for secret-safe totem correlation")
    return true
end

local function ReportTotemCorrelationUnavailable(totemSlot)
    if M.totemCorrelationWarningShown then return end
    M.totemCorrelationWarningShown = true

    local message = ("BetterAssistant: cannot associate secret totem slot %s "
        .. "with a configured spell because UNIT_SPELLCAST_SUCCEEDED is "
        .. "restricted and Blizzard provides no TotemContainer."):format(tostring(totemSlot))
    geterrorhandler()(message)
end

local function CreateTotemWidgets(slot)
    if not M.totemsSupported then return end

    slot.totemCooldown = CreateFrame("Cooldown", nil, slot.holder, "CooldownFrameTemplate")
    slot.totemCooldown:SetAllPoints(slot.holder)
    slot.totemCooldown:SetDrawEdge(false)
    slot.totemCooldown:SetDrawBling(false)
    slot.totemCooldown:SetHideCountdownNumbers(true)
    slot.totemCooldown:SetUseAuraDisplayTime(true)
    slot.totemCooldown:SetFrameLevel(M.frame:GetFrameLevel() + 1)
    slot.totemCooldown:Hide()

    slot.totemOverlay = CreateFrame("Frame", nil, slot.holder)
    slot.totemOverlay:SetAllPoints(slot.holder)
    slot.totemOverlay:SetFrameLevel(slot.totemCooldown:GetFrameLevel())

    slot.totemCountBg = slot.totemOverlay:CreateTexture(nil, "ARTWORK")
    slot.totemCountBg:SetColorTexture(0, 0, 0, 1)
    slot.totemCountBg:SetPoint("BOTTOMRIGHT", slot.holder, "BOTTOMRIGHT", 0, 0)
    slot.totemCountBg:Hide()

    slot.totemCount = slot.totemOverlay:CreateFontString(nil, "OVERLAY")
    slot.totemCount:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE, addon.DEBUG_FONT_FLAGS)
    slot.totemCount:SetJustifyH("RIGHT")
    slot.totemCount:SetText("")
    slot.totemCount:Hide()

    slot.totemPercentBg = slot.totemOverlay:CreateTexture(nil, "ARTWORK")
    slot.totemPercentBg:SetColorTexture(0, 0, 0, 1)
    slot.totemPercentBg:SetPoint("BOTTOMLEFT", slot.holder, "BOTTOMLEFT", 0, 0)
    slot.totemPercentBg:Hide()

    slot.totemPercent = slot.totemOverlay:CreateFontString(nil, "OVERLAY")
    slot.totemPercent:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE, addon.DEBUG_FONT_FLAGS)
    slot.totemPercent:SetJustifyH("LEFT")
    slot.totemPercent:Hide()

    slot.totemDurationBinding = C_DurationUtil.CreateDurationTextBinding()
    slot.totemDurationBinding:SetFontString(slot.totemPercent)
    slot.totemDurationBinding:SetTextFormat("{}", {
        { property = Enum.DurationTextBindingProperty.RemainingPercent, formatter = M.percentFormatter },
    })
    slot.totemDurationBinding:SetZeroDurationText("1")
    slot.totemDurationBinding:SetExpiredText("1")
    slot.totemDurationBinding:Disable()
end

local function ShowTotemDebug(slot, shown)
    if not slot.totemCooldown then return end
    slot.totemCountBg:SetShown(shown)
    slot.totemCount:SetShown(shown)
    slot.totemPercentBg:SetShown(shown)
    slot.totemPercent:SetShown(shown)
end

local function ApplyTotemSlotParams(slot, fontSize, scale, showSwipe, isDebug)
    if not slot.totemCooldown then return end

    slot.totemCooldown:SetDrawSwipe(showSwipe)

    slot.totemCount:SetFont(addon.DEBUG_FONT_FILE, fontSize, addon.DEBUG_FONT_FLAGS)
    slot.totemCount:ClearAllPoints()
    slot.totemCount:SetPoint("BOTTOMRIGHT", slot.holder, "BOTTOMRIGHT",
        addon.DEBUG_RIGHT_FONT_X * scale, addon.DEBUG_BOTTOM_FONT_Y * scale)
    slot.totemCount:SetText("")

    slot.totemPercent:SetFont(addon.DEBUG_FONT_FILE, fontSize, addon.DEBUG_FONT_FLAGS)
    slot.totemPercent:ClearAllPoints()
    slot.totemPercent:SetPoint("BOTTOMLEFT", slot.holder, "BOTTOMLEFT",
        addon.DEBUG_LEFT_FONT_X * scale, addon.DEBUG_BOTTOM_FONT_Y * scale)

    local bgW, bgH = addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale
    slot.totemCountBg:SetSize(bgW, bgH)
    slot.totemPercentBg:SetSize(bgW, bgH)

    ShowTotemDebug(slot, isDebug and slot.totemDuration ~= nil)
end

local function ApplyAllTotemParams(fontSize, scale, showSwipe, isDebug)
    if not M.totemsSupported then return end
    for i = 1, M.slotCount do
        ApplyTotemSlotParams(M.slots[i], fontSize, scale, showSwipe, isDebug)
    end
end

local function CreateLearnedWidgets(slot)
    slot.learnedOverlay = CreateFrame("Frame", nil, slot.holder)
    slot.learnedOverlay:SetAllPoints(slot.holder)
    slot.learnedOverlay:SetFrameLevel(M.frame:GetFrameLevel() + 1)
    slot.learnedOverlay:Hide()

    slot.learnedDurationBg = slot.learnedOverlay:CreateTexture(nil, "ARTWORK")
    slot.learnedDurationBg:SetColorTexture(0, 0, 0, 1)
    slot.learnedDurationBg:SetPoint("BOTTOMLEFT", slot.holder, "BOTTOMLEFT", 0, 0)

    slot.learnedCountBg = slot.learnedOverlay:CreateTexture(nil, "ARTWORK")
    slot.learnedCountBg:SetColorTexture(0, 0, 0, 1)
    slot.learnedCountBg:SetPoint("BOTTOMRIGHT", slot.holder, "BOTTOMRIGHT", 0, 0)

    slot.learnedDuration = slot.learnedOverlay:CreateFontString(nil, "OVERLAY")
    slot.learnedDuration:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE, addon.DEBUG_FONT_FLAGS)
    slot.learnedDuration:SetJustifyH("LEFT")
    slot.learnedDuration:SetText("1")
end

local function ApplyLearnedSlotParams(slot, fontSize, scale, isDebug)
    slot.learnedOverlay:SetAlpha(slot.baseIcon:GetAlpha())

    slot.learnedDuration:SetFont(addon.DEBUG_FONT_FILE, fontSize, addon.DEBUG_FONT_FLAGS)
    slot.learnedDuration:ClearAllPoints()
    slot.learnedDuration:SetPoint("BOTTOMLEFT", slot.holder, "BOTTOMLEFT",
        addon.DEBUG_LEFT_FONT_X * scale, addon.DEBUG_BOTTOM_FONT_Y * scale)
    slot.learnedDuration:SetText("1")

    slot.learnedDurationBg:SetSize(addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale)
    slot.learnedCountBg:SetSize(addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale)

    local shown = isDebug == true and slot.active == true and slot.learnedMode == true
    slot.learnedOverlay:SetShown(shown)
end
M.ApplyLearnedSlotParams = ApplyLearnedSlotParams

local function ApplyAllLearnedParams(fontSize, scale, isDebug)
    for i = 1, M.slotCount do
        ApplyLearnedSlotParams(M.slots[i], fontSize, scale, isDebug)
    end
end

local function FindSlotForSpell(spellID)
    if spellID == nil or type(spellID) ~= "number" then
        return nil
    end

    for i = 1, M.slotCount do
        local slot = M.slots[i]
        if slot.active and not slot.learnedMode
            and slot.filters and slot.filters.includeSpellIDs[spellID] then
            return i
        end
    end

    local spellName = C_Spell.GetSpellName(spellID)
    if spellName then
        for i = 1, M.slotCount do
            local slot = M.slots[i]
            if slot.active and not slot.learnedMode and slot.trackedSpellID
                and C_Spell.GetSpellName(slot.trackedSpellID) == spellName then
                return i
            end
        end
    end
end

local function ClearTotem(index)
    local slot = M.slots[index]
    if not slot or not slot.totemCooldown or slot.clearingTotem then return end
    slot.clearingTotem = true

    if slot.totemSlot then
        M.totemOwner[slot.totemSlot] = nil
        slot.totemSlot = nil
    end

    slot.totemDuration = nil
    slot.totemDurationBinding:Disable()
    slot.totemPercent:SetText("")
    slot.baseIcon:SetAlpha(0.2)
    slot.totemCooldown:Clear()
    slot.totemCooldown:Hide()
    ShowTotemDebug(slot, false)
    slot.clearingTotem = nil
end

local function BindTotem(index, totemSlot, duration)
    local slot = M.slots[index]
    if not slot or not slot.active or not slot.totemCooldown then return end

    local previous = M.totemOwner[totemSlot]
    if previous and previous ~= index then
        ClearTotem(previous)
    end

    if slot.totemSlot and slot.totemSlot ~= totemSlot then
        M.totemOwner[slot.totemSlot] = nil
    end

    slot.totemSlot = totemSlot
    slot.totemDuration = duration
    M.totemOwner[totemSlot] = index

    slot.baseIcon:SetAlpha(1)
    slot.totemCooldown:Show()
    slot.totemDurationBinding:SetDuration(duration)
    slot.totemDurationBinding:Enable()
    slot.totemDurationBinding:UpdateFontString()
    ShowTotemDebug(slot, M.curParams.isDebug)

    if not slot.totemCooldownDoneHooked then
        slot.totemCooldown:SetScript("OnCooldownDone", function()
            ClearTotem(index)
        end)
        slot.totemCooldownDoneHooked = true
    end
    slot.totemCooldown:SetCooldownFromDurationObject(duration, false)

    dbg("totem slot", totemSlot, "-> tracked slot", index)
end

local function ResolveTotemSlot(totemSlot, fromEvent)
    if not M.totemsSupported or type(totemSlot) ~= "number" then return end

    local duration = GetTotemDuration(totemSlot)
    if not duration then return end

    local owner = M.totemOwner[totemSlot]
    local index
    if not C_Secrets.ShouldTotemSlotBeSecret(totemSlot) then
        local haveTotem, _name, _startTime, _duration, _icon, _modRate, spellID = GetTotemInfo(totemSlot)
        if haveTotem and spellID then
            index = FindSlotForSpell(spellID)
        end

        if not index then
            if owner then ClearTotem(owner) end
        end
    elseif fromEvent then
        local cast = M.lastPlayerCast
        local recentCast = cast and (GetTime() - cast.time) <= TOTEM_CAST_WINDOW
        if recentCast and cast.unavailable then
            M.lastPlayerCast = nil
            ReportTotemCorrelationUnavailable(totemSlot)
            return
        elseif recentCast and cast.index then
            index = cast.index
            M.lastPlayerCast = nil
        elseif owner then
            ClearTotem(owner)
            M.pendingTotems[totemSlot] = GetTime()
            return
        else
            M.pendingTotems[totemSlot] = GetTime()
        end
    end

    if index then
        M.pendingTotems[totemSlot] = nil
        BindTotem(index, totemSlot, duration)
    end
end

local function OnPlayerCast(spellID)
    if not M.totemsSupported then return end

    local now = GetTime()
    local index = FindSlotForSpell(spellID)
    M.lastPlayerCast = { index = index, time = now }

    local matchedPendingTotem = false
    for totemSlot, eventTime in pairs(M.pendingTotems) do
        M.pendingTotems[totemSlot] = nil
        if index and (now - eventTime) <= TOTEM_CAST_WINDOW then
            local duration = GetTotemDuration(totemSlot)
            if duration then
                BindTotem(index, totemSlot, duration)
                matchedPendingTotem = true
            end
        end
    end
    if matchedPendingTotem then
        M.lastPlayerCast = nil
    end
end

local function OnSecretPlayerCast()
    if not M.totemsSupported then return end

    local now = GetTime()
    M.lastPlayerCast = { unavailable = true, time = now }

    local unavailableSlot
    for totemSlot, eventTime in pairs(M.pendingTotems) do
        if (now - eventTime) <= TOTEM_CAST_WINDOW then
            M.pendingTotems[totemSlot] = nil
            unavailableSlot = unavailableSlot or totemSlot
        end
    end
    if unavailableSlot then
        M.lastPlayerCast = nil
        ReportTotemCorrelationUnavailable(unavailableSlot)
    end
end

local function RescanTotems()
    if not M.totemsSupported then return end
    for totemSlot = 1, GetNumTotemSlots() do
        ResolveTotemSlot(totemSlot)
    end
end

local function UpdateTotems()
    if not M.totemsSupported then return end

    local now = GetTime()
    if M.lastPlayerCast and (now - M.lastPlayerCast.time) > TOTEM_CAST_WINDOW then
        M.lastPlayerCast = nil
    end
    for totemSlot, eventTime in pairs(M.pendingTotems) do
        if (now - eventTime) > TOTEM_CAST_WINDOW then
            M.pendingTotems[totemSlot] = nil
        end
    end
end


local function ApplyButtonParams(w, anchor, fontSize, scale, showSwipe, isDebug)
    w.cooldown:SetDrawSwipe(showSwipe)

    w.count:SetFont(addon.DEBUG_FONT_FILE, fontSize, addon.DEBUG_FONT_FLAGS)
    w.count:ClearAllPoints()
    w.count:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMRIGHT",
        addon.DEBUG_RIGHT_FONT_X * scale, addon.DEBUG_BOTTOM_FONT_Y * scale)

    w.dbgDuration:SetFont(addon.DEBUG_FONT_FILE, fontSize, addon.DEBUG_FONT_FLAGS)
    w.dbgDuration:ClearAllPoints()
    w.dbgDuration:SetPoint("BOTTOMLEFT", anchor, "BOTTOMLEFT",
        addon.DEBUG_LEFT_FONT_X * scale, addon.DEBUG_BOTTOM_FONT_Y * scale)

    local bgW, bgH = addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale
    w.countBg:SetSize(bgW, bgH)
    w.dbgDurationBg:SetSize(bgW, bgH)

    w.countBg:SetShown(isDebug)
    w.dbgDuration:SetShown(isDebug)
    w.dbgDurationBg:SetShown(isDebug)
end

local function InitAuraButton(btn, tag, holder, p)
    dbg("initializeFrame called for", tag)
    local w = {}

    btn:SetAllPoints(holder)

    w.icon = btn:CreateTexture(nil, "BACKGROUND")
    w.icon:SetAllPoints(btn)
    btn:SetIcon(w.icon)

    w.cooldown = CreateFrame("Cooldown", nil, btn, "CooldownFrameTemplate")
    w.cooldown:SetAllPoints(btn)
    w.cooldown:SetDrawEdge(false)
    w.cooldown:SetDrawBling(false)
    w.cooldown:SetHideCountdownNumbers(true)
    btn:SetDurationCooldown(w.cooldown)

    w.overlay = CreateFrame("Frame", nil, btn)
    w.overlay:SetAllPoints(btn)
    w.overlay:SetFrameLevel(w.cooldown:GetFrameLevel() + 5)

    w.countBg = w.overlay:CreateTexture(nil, "ARTWORK")
    w.countBg:SetColorTexture(0, 0, 0, 1)
    w.countBg:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 0, 0)
    w.countBg:Hide()

    w.count = w.overlay:CreateFontString(nil, "OVERLAY")
    w.count:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE, addon.DEBUG_FONT_FLAGS)
    w.count:SetJustifyH("RIGHT")
    w.count:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", addon.DEBUG_RIGHT_FONT_X, addon.DEBUG_BOTTOM_FONT_Y)
    btn:SetApplicationCount(w.count)

    w.dbgDurationBg = w.overlay:CreateTexture(nil, "ARTWORK")
    w.dbgDurationBg:SetColorTexture(0, 0, 0, 1)
    w.dbgDurationBg:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 0, 0)
    w.dbgDurationBg:Hide()

    w.dbgDuration = w.overlay:CreateFontString(nil, "OVERLAY")
    w.dbgDuration:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE, addon.DEBUG_FONT_FLAGS)
    w.dbgDuration:SetJustifyH("LEFT")
    w.dbgDuration:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", addon.DEBUG_LEFT_FONT_X, addon.DEBUG_BOTTOM_FONT_Y)
    w.dbgDuration:Hide()
    btn:SetDurationText(w.dbgDuration, {
        binding = M.durationBinding,
        textFormat = {
            formatString = "{}",
            components = {
                { property = Enum.DurationTextBindingProperty.RemainingPercent, formatter = M.percentFormatter },
            },
        },
    })

    ApplyButtonParams(w, btn, p.fontSize, p.scale, p.showSwipe, p.isDebug)

    dbg("initializeFrame done for", tag)
    return w
end

local function CreateContainer(unit)
    local container = CreateFrame("AuraContainer", nil, M.frame, "CustomAuraContainerTemplate")
    container:SetPoint("TOPLEFT")
    container:SetSize(1, 1)
    container:SetUnit(unit)
    dbg("container created for unit:", unit)
    return container
end

local function EnsureSlot(index)
    local slot = M.slots[index]
    if slot then return slot end

    slot = { key = "BASlot" .. index }

    slot.baseIcon = M.frame:CreateTexture(nil, "BACKGROUND")
    slot.baseIcon:SetAlpha(0.2)
    slot.baseIcon:Hide()

    slot.holder = CreateFrame("Frame", nil, M.frame)

    local p = M.curParams
    CreateLearnedWidgets(slot)
    ApplyLearnedSlotParams(slot, p.fontSize, p.scale, p.isDebug)
    CreateTotemWidgets(slot)
    ApplyTotemSlotParams(slot, p.fontSize, p.scale, p.showSwipe, p.isDebug)

    local playerFrame = M.playerContainer:AddAuraSlot(slot.key, PLAYER_FILTER, {
        candidateFilters = EMPTY_FILTERS,
        initializeFrame = function(btn) slot.player = InitAuraButton(btn, slot.key .. "/player", slot.holder, p) end,
    })
    slot.player.frame = playerFrame

    local targetFrame = M.targetContainer:AddAuraSlot(slot.key, TARGET_FILTER, {
        candidateFilters = EMPTY_FILTERS,
        initializeFrame = function(btn) slot.target = InitAuraButton(btn, slot.key .. "/target", slot.holder, p) end,
    })
    slot.target.frame = targetFrame

    dbg("slot", index, "created")

    M.slots[index] = slot
    if index > M.slotCount then M.slotCount = index end
    return slot
end

local function ApplySlotFilters(slot)
    local filters = slot.filters or EMPTY_FILTERS
    M.playerContainer:SetAuraSlotCandidateFilters(slot.key, filters)
    M.targetContainer:SetAuraSlotCandidateFilters(slot.key, filters)
end

local function UpdateTargetUnit(forceRefresh)
    local desiredUnit = UnitExists("target")
        and not UnitCanAssist("player", "target")
        and "target"
        or "none"

    if M.targetContainerUnit ~= desiredUnit then
        M.targetContainer:SetUnit(desiredUnit)
        M.targetContainerUnit = desiredUnit
        dbg("target container unit:", desiredUnit)
    elseif forceRefresh and desiredUnit == "target" then
        M.targetContainer:UpdateAllAuras()
    end
end

local function ReadAuraEntry(entry)
    if type(entry) == "table" then
        local id = tonumber(entry.id)
        return id and id > 0 and math.floor(id) or nil, entry.learned == true
    end
    local id = tonumber(entry)
    return id and id > 0 and math.floor(id) or nil, false
end
M.ReadAuraEntry = ReadAuraEntry

function M.MakeAuraEntry(id, learned)
    id = tonumber(id)
    if not id or id <= 0 then return nil end
    id = math.floor(id)
    return learned and { id = id, learned = true } or id
end

function M.SetAuraEntryLearned(list, index, learned)
    local id = ReadAuraEntry(list[index])
    if not id then return end
    list[index] = M.MakeAuraEntry(id, learned)
end

local function IsSpellLearned(spellID)
    return C_SpellBook.IsSpellKnownOrInSpellBook(spellID) and true or false
end

local function RebuildTracked()
    M.rebuildQueued = false

    local cfg = M.core.config.cdm
    local specKey = M.core:GetSpecKey()
    local list = (specKey and cfg.auras[specKey]) or {}
    local maxAuras = M.GetMaxAuras(M.core)
    local catalog = GetCatalog()

    dbg("RebuildTracked: spec:", tostring(specKey), "configured auras:", #list)

    local n = 0
    for i = 1, math.min(#list, maxAuras) do
        local spellID, learnedMode = ReadAuraEntry(list[i])
        if spellID then
            n = n + 1
            local slot = EnsureSlot(n)

            if slot.totemDuration and slot.trackedSpellID ~= spellID then
                ClearTotem(n)
            end

            slot.active = true
            slot.trackedSpellID = spellID
            slot.learnedMode = learnedMode
            slot.baseIcon:SetTexture(C_Spell.GetSpellTexture(spellID) or QUESTION_MARK_ICON)

            if learnedMode then
                if slot.totemDuration then ClearTotem(n) end
                slot.filters = nil
                slot.baseIcon:SetAlpha(IsSpellLearned(spellID) and 1 or 0.2)
                dbg("slot", n, "-> spellID", spellID, "(learned check)")
            else
                slot.baseIcon:SetAlpha(0.2)
                local include = BuildIncludedSpellIDs(spellID, catalog)
                if DEBUG then
                    local ids = {}
                    for id in pairs(include) do ids[#ids + 1] = id end
                    table.sort(ids)
                    dbg("slot", n, "-> spellID", spellID, catalog.matchIDs[spellID] and "(CDM)" or "(manual)",
                        "matches:", table.concat(ids, ", "))
                end
                slot.filters = { includeSpellIDs = include }
            end
            ApplyLearnedSlotParams(slot, M.curParams.fontSize, M.curParams.scale, M.curParams.isDebug)
            ApplySlotFilters(slot)
        end
    end

    for i = n + 1, M.slotCount do
        local slot = M.slots[i]
        if slot.totemDuration then
            ClearTotem(i)
        end
        slot.trackedSpellID = nil
        slot.learnedMode = nil
        if slot.active then
            slot.active = false
            slot.filters = nil
            ApplySlotFilters(slot)
        end
        ApplyLearnedSlotParams(slot, M.curParams.fontSize, M.curParams.scale, M.curParams.isDebug)
    end

    M.activeCount = n
    M.layoutSize = nil

    RescanTotems()

    dbg("RebuildTracked done, active slots:", n)
end


local function ApplyLayout(size)
    dbg("ApplyLayout: slots:", M.slotCount, "active:", M.activeCount, "size:", size)
    for i = 1, M.slotCount do
        local slot = M.slots[i]
        local x = (i - 1) * size

        slot.baseIcon:ClearAllPoints()
        slot.baseIcon:SetPoint("TOPLEFT", M.frame, "TOPLEFT", x, 0)
        slot.baseIcon:SetSize(size, size)
        slot.baseIcon:SetShown(slot.active)

        slot.holder:ClearAllPoints()
        slot.holder:SetPoint("TOPLEFT", M.frame, "TOPLEFT", x, 0)
        slot.holder:SetSize(size, size)
    end
end

local function ApplyAllButtonParams(fontSize, scale, showSwipe, isDebug)
    local allOk = true
    local function apply(w)
        local ok = pcall(ApplyButtonParams, w, w.frame, fontSize, scale, showSwipe, isDebug)
        allOk = allOk and ok
    end
    for i = 1, M.slotCount do
        apply(M.slots[i].player)
        apply(M.slots[i].target)
    end
    return allOk
end

local function SetContainersEnabled(enabled)
    if M.containersEnabled == enabled then return end
    M.containersEnabled = enabled
    dbg("containers enabled:", tostring(enabled))
    M.playerContainer:SetEnabled(enabled)
    M.targetContainer:SetEnabled(enabled)
end


local function DetectSupport()
    local hasTemplate = false
    if C_XMLUtil and C_XMLUtil.GetTemplateInfo then
        hasTemplate = C_XMLUtil.GetTemplateInfo("CustomAuraContainerTemplate") ~= nil
    end
    local hasExports = type(CustomAuraContainerSlotDefaultOptions) == "table"
    local hasViewer = C_CooldownViewer ~= nil and C_CooldownViewer.GetCooldownViewerCategorySet ~= nil
    local hasEnum = Enum.CooldownViewerCategory ~= nil and Enum.CooldownViewerCategory.TrackedBuff ~= nil

    dbg("DetectSupport: template:", tostring(hasTemplate),
        "exports:", tostring(hasExports),
        "C_CooldownViewer:", tostring(hasViewer),
        "enum:", tostring(hasEnum))

    return (hasTemplate or hasExports) and hasViewer and hasEnum
end

function M.Init(core)
    M.EnsureConfig(core)

    M.core = core
    M.frame = CreateFrame("Frame", nil, UIParent)
    M.frame:SetAlpha(0)
    M.slots = {}
    M.slotCount = 0
    M.activeCount = 0
    M.totemOwner = {}
    M.pendingTotems = {}
    M.totemCorrelationWarningShown = false
    M.rebuildQueued = true
    M.containersEnabled = true
    M.learnedChildKey = nil
    M.curParams = {
        fontSize = addon.DEBUG_FONT_SIZE,
        scale = 1,
        showSwipe = core.config.cdm.showSwipe ~= false,
        isDebug = core.config.debug == true,
    }

    M.supported = DetectSupport()
    M.totemsSupported = M.supported and DetectTotemSupport() or false
    dbg("Init: supported:", tostring(M.supported),
        "totems:", tostring(M.totemsSupported))
    if not M.supported then return end

    M.percentFormatter = C_StringUtil.CreateNumericRuleFormatter()
    M.percentFormatter:AddBreakpoint({
        threshold = 0,
        step = 1,
        rounding = Enum.NumericRuleFormatRounding.Up,
        format = "%d",
    })

    M.durationBinding = C_DurationUtil.CreateDurationTextBinding()
    M.durationBinding:SetZeroDurationText("1")

    M.playerContainer = CreateContainer("player")
    M.targetContainer = CreateContainer("none")
    M.targetContainerUnit = "none"

    local targetLevel = M.frame:GetFrameLevel() + 1
    M.targetContainer:SetFrameLevel(targetLevel)
    M.playerContainer:SetFrameLevel(targetLevel + 10)

    M.eventFrame = CreateFrame("Frame")
    M.eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
    M.eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    M.eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    M.eventFrame:RegisterEvent("COOLDOWN_VIEWER_DATA_LOADED")
    M.eventFrame:RegisterEvent("COOLDOWN_VIEWER_TABLE_HOTFIXED")
    M.eventFrame:RegisterEvent("COOLDOWN_VIEWER_SPELL_OVERRIDE_UPDATED")
    M.eventFrame:RegisterEvent("TRAIT_CONFIG_UPDATED")
    M.eventFrame:RegisterUnitEvent("PLAYER_SPECIALIZATION_CHANGED", "player")
    if M.totemsSupported then
        M.eventFrame:RegisterEvent("PLAYER_TOTEM_UPDATE")
        M.eventFrame:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player")
    end
    M.eventFrame:SetScript("OnEvent", function(_, event, ...)
        if event == "PLAYER_TARGET_CHANGED" then
            UpdateTargetUnit(true)
        elseif event == "PLAYER_TOTEM_UPDATE" then
            local totemSlot = ...
            ResolveTotemSlot(totemSlot, true)
        elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
            if C_Secrets.ShouldUnitSpellCastingBeSecret("player") then
                OnSecretPlayerCast()
            else
                local _unit, _castGUID, spellID = ...
                OnPlayerCast(spellID)
            end
        elseif event == "PLAYER_REGEN_ENABLED" then
            M.childKey = nil
            RescanTotems()
        else
            dbg("event:", event, "-> rebuild queued")
            M.cdmCatalog = nil
            M.rebuildQueued = true
        end
    end)
end

local function TraceUpdateState(state)
    if M.lastTracedState ~= state then
        M.lastTracedState = state
        dbg("Update state:", state)
    end
end

function M.Update(core, renderScale)
    if not M.supported then
        TraceUpdateState("unsupported")
        return
    end

    local cfg = core.config.cdm

    if not cfg.enabled then
        TraceUpdateState("disabled by config")
        M.frame:SetAlpha(0)
        SetContainersEnabled(false)
        return
    end

    SetContainersEnabled(true)

    local scale = renderScale or 1
    local size = cfg.iconSize * scale
    local fontSize = addon.DEBUG_FONT_SIZE * scale
    local isDebug = core.config.debug == true
    local showSwipe = cfg.showSwipe ~= false
    M.curParams = { fontSize = fontSize, scale = scale, showSwipe = showSwipe, isDebug = isDebug }

    UpdateTargetUnit(false)

    if M.rebuildQueued then
        RebuildTracked()
    end

    M.frame:ClearAllPoints()
    M.frame:SetPoint("TOPLEFT", core.defensivesFrames[1], "BOTTOMLEFT", 0, 0)
    M.frame:SetSize(math.max(M.activeCount, 1) * size, size)
    M.frame:SetFrameStrata(core.config.strata)
    M.frame:SetAlpha(M.activeCount > 0 and 1 or 0)

    TraceUpdateState("active, slots: " .. M.activeCount)

    if M.layoutSize ~= size then
        M.layoutSize = size
        ApplyLayout(size)
    end

    UpdateTotems()

    local childKey = string.join(":", fontSize, showSwipe and 1 or 0, isDebug and 1 or 0)

    if M.totemChildKey ~= childKey then
        ApplyAllTotemParams(fontSize, scale, showSwipe, isDebug)
        M.totemChildKey = childKey
    end

    if M.learnedChildKey ~= childKey then
        ApplyAllLearnedParams(fontSize, scale, isDebug)
        M.learnedChildKey = childKey
    end

    if M.childKey ~= childKey then
        if ApplyAllButtonParams(fontSize, scale, showSwipe, isDebug) then
            M.childKey = childKey
        end
    end
end
