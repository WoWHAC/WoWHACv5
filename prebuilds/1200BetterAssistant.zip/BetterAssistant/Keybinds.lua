local _, addon = ...

addon.keybinds = {}
local M = addon.keybinds

local DEFAULT_CONFIG = {
    enabled = true,
    background = false,
    largeFont = false,
    colorMods = false,
    dimWithIcon = false,
}

local NUM_BUTTONS = 12

local BLIZZ_BARS = {
    { page = 3,  cmd = "MULTIACTIONBAR3BUTTON" },
    { page = 4,  cmd = "MULTIACTIONBAR4BUTTON" },
    { page = 5,  cmd = "MULTIACTIONBAR2BUTTON" },
    { page = 6,  cmd = "MULTIACTIONBAR1BUTTON" },
    { page = 13, cmd = "MULTIACTIONBAR5BUTTON" },
    { page = 14, cmd = "MULTIACTIONBAR6BUTTON" },
    { page = 15, cmd = "MULTIACTIONBAR7BUTTON" },
}

local MOD_LETTER = {
    ALT = "A", CTRL = "C", SHIFT = "S",
    LALT = "A", RALT = "A", LCTRL = "C", RCTRL = "C", LSHIFT = "S", RSHIFT = "S",
}

local MOD_COLOR = {
    C = { 1.00, 0.00, 0.00 },
    S = { 0.00, 1.00, 0.00 },
    A = { 0.00, 0.00, 1.00 },
}
local NO_MOD_COLOR = { 1, 1, 1 }

local KEY_ABBREV = {
    NUMPADDIVIDE = "N/", NUMPADMULTIPLY = "N*", NUMPADMINUS = "N-",
    NUMPADPLUS = "N+", NUMPADDECIMAL = "N.", NUMPADENTER = "NE", NUMLOCK = "NL",
    MOUSEWHEELUP = "MWU", MOUSEWHEELDOWN = "MWD",
    PAGEUP = "PU", PAGEDOWN = "PD", INSERT = "INS", DELETE = "DEL",
    HOME = "HM", END = "END",
    UP = "UP", DOWN = "DN", LEFT = "LT", RIGHT = "RT",
    BACKSPACE = "BS", CAPSLOCK = "CL", ESCAPE = "ESC", PRINTSCREEN = "PS",
    SCROLLLOCK = "SL", PAUSE = "PA", SPACE = "SPC", TAB = "TAB", ENTER = "ENT",
    BACKQUOTE = "`", MINUS = "-", EQUALS = "=",
    LEFTBRACKET = "[", RIGHTBRACKET = "]", BACKSLASH = "\\",
    SEMICOLON = ";", QUOTE = "'", COMMA = ",", PERIOD = ".", SLASH = "/",
}

local VK_SPECIAL = {
    BACKSPACE = 8, TAB = 9, ENTER = 13, NUMPADENTER = 13, PAUSE = 19,
    CAPSLOCK = 20, ESCAPE = 27, SPACE = 32,
    PAGEUP = 33, PAGEDOWN = 34, END = 35, HOME = 36,
    LEFT = 37, UP = 38, RIGHT = 39, DOWN = 40,
    PRINTSCREEN = 44, INSERT = 45, DELETE = 46,
    NUMPADMULTIPLY = 106, NUMPADPLUS = 107, NUMPADMINUS = 109,
    NUMPADDECIMAL = 110, NUMPADDIVIDE = 111,
    NUMLOCK = 144, SCROLLLOCK = 145,
    SEMICOLON = 186, EQUALS = 187, COMMA = 188, MINUS = 189,
    PERIOD = 190, SLASH = 191, BACKQUOTE = 192,
    LEFTBRACKET = 219, BACKSLASH = 220, RIGHTBRACKET = 221, QUOTE = 222,
    [";"] = 186, ["="] = 187, [","] = 188, ["-"] = 189,
    ["."] = 190, ["/"] = 191, ["`"] = 192,
    ["["] = 219, ["\\"] = 220, ["]"] = 221, ["'"] = 222,
    BUTTON1 = 1, BUTTON2 = 2, BUTTON3 = 4, BUTTON4 = 5, BUTTON5 = 6,
}


local slotKeys = {}
local displayCache = {}
local keysDirty = true
local cfgVersion = 0

local function InvalidateKeys()
    keysDirty = true
    wipe(displayCache)
end

local function InvalidateSpells()
    wipe(displayCache)
end

function M.QueueRefresh()
    cfgVersion = cfgVersion + 1
    wipe(displayCache)
end

function M.EnsureConfig(core)
    if not core.config.keybinds then
        core.config.keybinds = {}
    end
    local cfg = core.config.keybinds
    for k, v in pairs(DEFAULT_CONFIG) do
        if cfg[k] == nil then
            cfg[k] = v
        end
    end
    return cfg
end


local function IsGamepadKey(key)
    local pos = key:find("PAD", 1, true)
    if not pos then return false end
    return not (pos >= 4 and key:sub(pos - 3, pos - 1) == "NUM")
end

local function SplitBindingKey(raw)
    local mod
    local key = raw
    local token, rest = key:match("^([^%-]+)%-(.+)$")
    while token and MOD_LETTER[token] do
        mod = mod or MOD_LETTER[token]
        key = rest
        token, rest = key:match("^([^%-]+)%-(.+)$")
    end
    return mod or "", key
end

local function IsMouseKey(raw)
    local _, key = SplitBindingKey(raw)
    return key:match("^BUTTON%d+$") ~= nil
        or key:match("^MOUSEBUTTON%d+$") ~= nil
        or key:find("MOUSEWHEEL", 1, true) == 1
end

local function AddSlotKeys(slot, ...)
    local keys = slotKeys[slot]
    for i = 1, select("#", ...) do
        local k = select(i, ...)
        if type(k) == "string" and k ~= "" and not IsGamepadKey(k) then
            if not keys then
                keys = {}
                slotKeys[slot] = keys
            end
            local duplicate = false
            for j = 1, #keys do
                if keys[j] == k then
                    duplicate = true
                    break
                end
            end
            if not duplicate then
                keys[#keys + 1] = k
            end
        end
    end
end

local function AddCommandKeys(slot, command)
    if command and command ~= "" then
        AddSlotKeys(slot, GetBindingKey(command))
    end
end

local function GetMainBarPage()
    if HasVehicleActionBar and HasVehicleActionBar() and GetVehicleBarIndex then
        return GetVehicleBarIndex()
    end
    if HasOverrideActionBar and HasOverrideActionBar() and GetOverrideBarIndex then
        return GetOverrideBarIndex()
    end
    if HasTempShapeshiftActionBar and HasTempShapeshiftActionBar() and GetTempShapeshiftBarIndex then
        return GetTempShapeshiftBarIndex()
    end
    local bonus = GetBonusBarOffset and GetBonusBarOffset() or 0
    if bonus > 0 then
        return 6 + bonus
    end
    return GetActionBarPage and GetActionBarPage() or 1
end

local function AddLABButton(btn)
    local action = btn._state_action or btn.action
    if type(action) ~= "number" or action <= 0 then return end

    local cmd = btn.keyBoundTarget or (btn.config and btn.config.keyBoundTarget)
    AddCommandKeys(action, cmd)

    local name = btn.GetName and btn:GetName()
    if name then
        AddCommandKeys(action, "CLICK " .. name .. ":LeftButton")
        AddCommandKeys(action, "CLICK " .. name .. ":Keybind")
    end
end

local function ScanAddonBars()
    if _G["ElvUI_Bar1Button1"] then
        for bar = 1, 15 do
            for b = 1, NUM_BUTTONS do
                local btn = _G["ElvUI_Bar" .. bar .. "Button" .. b]
                if btn then AddLABButton(btn) end
            end
        end
    end
    if _G["BT4Button1"] then
        for i = 1, 180 do
            local btn = _G["BT4Button" .. i]
            if btn then AddLABButton(btn) end
        end
    end
end

local function RebuildSlotKeys()
    wipe(slotKeys)

    for _, bar in ipairs(BLIZZ_BARS) do
        local baseSlot = (bar.page - 1) * NUM_BUTTONS
        for b = 1, NUM_BUTTONS do
            AddCommandKeys(baseSlot + b, bar.cmd .. b)
        end
    end

    local mainBase = (GetMainBarPage() - 1) * NUM_BUTTONS
    for b = 1, NUM_BUTTONS do
        local command = "ACTIONBUTTON" .. b
        AddCommandKeys(b, command)
        if mainBase + b ~= b then
            AddCommandKeys(mainBase + b, command)
        end
    end

    ScanAddonBars()
    keysDirty = false
end

local function RebuildIfDirty()
    if keysDirty then
        RebuildSlotKeys()
    end
end


local function IsAssistedSlot(slot)
    return C_ActionBar and C_ActionBar.IsAssistedCombatAction
        and C_ActionBar.IsAssistedCombatAction(slot)
end

local function SlotMatchesSpell(slot, spellID)
    if not HasAction(slot) or IsAssistedSlot(slot) then return false end

    local aType, id, subType = GetActionInfo(slot)
    local slotSpell
    if aType == "spell" and type(id) == "number" then
        slotSpell = id
    elseif aType == "macro" then
        if subType == "spell" and type(id) == "number" then
            slotSpell = id
        elseif GetMacroSpell then
            slotSpell = GetMacroSpell(id)
        end
    elseif aType == "item" and GetItemSpell then
        local _, castSpellID = GetItemSpell(id)
        slotSpell = castSpellID
    end
    if not slotSpell then return false end

    if slotSpell == spellID then return true end
    if C_Spell.GetOverrideSpell then
        if C_Spell.GetOverrideSpell(slotSpell) == spellID then return true end
        if C_Spell.GetOverrideSpell(spellID) == slotSpell then return true end
    end
    if FindBaseSpellByID then
        if FindBaseSpellByID(spellID) == slotSpell then return true end
        if FindBaseSpellByID(slotSpell) == spellID then return true end
    end
    return false
end

local function FindRawKey(spellID)
    local mouseFallback
    local visited = {}

    local function ConsiderSlot(slot)
        local keys = slotKeys[slot]
        if not keys then return end
        for i = 1, #keys do
            local key = keys[i]
            if IsMouseKey(key) then
                mouseFallback = mouseFallback or key
            else
                return key
            end
        end
    end

    if C_ActionBar and C_ActionBar.FindSpellActionButtons then
        local base = FindBaseSpellByID and FindBaseSpellByID(spellID) or spellID
        local slots = C_ActionBar.FindSpellActionButtons(base)
        if slots then
            for i = 1, #slots do
                local slot = slots[i]
                if not visited[slot] then
                    visited[slot] = true
                    if not IsAssistedSlot(slot) then
                        local key = ConsiderSlot(slot)
                        if key then return key end
                    end
                end
            end
        end
    end

    local remaining = {}
    for slot in pairs(slotKeys) do
        if not visited[slot] then
            remaining[#remaining + 1] = slot
        end
    end
    table.sort(remaining)
    for i = 1, #remaining do
        local slot = remaining[i]
        if SlotMatchesSpell(slot, spellID) then
            local key = ConsiderSlot(slot)
            if key then return key end
        end
    end
    return mouseFallback
end


local function KeyToVK(key)
    local vk = VK_SPECIAL[key]
    if vk then return tostring(vk) end
    if #key == 1 then
        local b = key:byte()
        if (b >= 65 and b <= 90) or (b >= 48 and b <= 57) then
            return tostring(b)
        end
    end
    local n = key:match("^NUMPAD(%d)$")
    if n then return tostring(96 + tonumber(n)) end
    local f = tonumber(key:match("^F(%d+)$"))
    if f and f >= 1 and f <= 24 then return tostring(111 + f) end
end

local function AbbrevKey(key)
    local abbrev = KEY_ABBREV[key]
    if abbrev then return abbrev end
    local n = key:match("^NUMPAD(%d)$")
    if n then return "N" .. n end
    local b = key:match("^BUTTON(%d+)$")
    if b then return "M" .. b end
    return key
end

local function FormatKey(raw, numeric)
    local mod, key = SplitBindingKey(raw)

    if IsGamepadKey(key) then
        if not numeric then return nil end
        return mod, "0"
    end

    if numeric then
        return mod, KeyToVK(key) or "0"
    end
    return mod, AbbrevKey(key)
end

local function GetDisplay(spellID, numeric)
    if not spellID or spellID == 0 then return false end
    RebuildIfDirty()
    local cached = displayCache[spellID]
    if cached ~= nil then return cached end

    local disp = false
    local raw = FindRawKey(spellID)
    if raw then
        local mod, key = FormatKey(raw, numeric)
        if key then
            disp = { mod, key }
        end
    end
    if not disp and numeric then
        disp = { "", "0" }
    end
    displayCache[spellID] = disp
    return disp
end


local widgets = {}

local function EnsureWidget(target, overlayParent)
    local w = widgets[target]
    if w then return w end

    w = {}

    w.holder = CreateFrame("Frame", nil, overlayParent)
    w.holder:SetAllPoints(overlayParent)

    w.bg = w.holder:CreateTexture(nil, "ARTWORK")
    w.bg:SetColorTexture(0, 0, 0, 1)
    w.bg:SetPoint("RIGHT", target, "RIGHT", 0, 0)
    w.bg:Hide()

    w.key = w.holder:CreateFontString(nil, "OVERLAY")
    w.key:SetJustifyH("RIGHT")
    w.key:Hide()

    widgets[target] = w
    return w
end

local function ApplyWidget(w, target, disp, scale, cfg, isDebug, alpha, colorAlpha)
    if not disp then
        w.key:Hide()
        w.bg:Hide()
        return
    end

    local modText, keyText = disp[1], disp[2]
    if w.lastMod ~= modText or w.lastKey ~= keyText
       or w.lastScale ~= scale or w.lastVer ~= cfgVersion then
        local mult = (cfg.largeFont and not isDebug) and 1.5 or 1
        local fontSize = addon.DEBUG_FONT_SIZE * scale * mult
        local x = addon.DEBUG_RIGHT_FONT_X * scale

        w.key:SetFont(addon.DEBUG_FONT_FILE, fontSize, addon.DEBUG_FONT_FLAGS)
        w.key:ClearAllPoints()
        w.key:SetPoint("RIGHT", target, "RIGHT", x, 0)

        if cfg.colorMods or isDebug then
            local c = MOD_COLOR[modText] or NO_MOD_COLOR
            w.key:SetText(keyText)
            w.key:SetTextColor(c[1], c[2], c[3])
        else
            w.key:SetText(modText ~= "" and (modText .. " " .. keyText) or keyText)
            w.key:SetTextColor(1, 1, 1)
        end
        w.bg:SetSize(addon.KEYBIND_BG_W * scale * mult, addon.DEBUG_BG_H * scale * mult)

        w.lastMod, w.lastKey, w.lastScale, w.lastVer = modText, keyText, scale, cfgVersion
    end

    w.holder:SetAlpha(colorAlpha)
    w.key:SetAlpha(alpha)
    w.bg:SetAlpha(alpha)

    w.key:Show()
    w.bg:SetShown(cfg.background or isDebug)
end

local function MirrorAlpha(target, dim)
    if not dim then return 1, 1 end
    return target:GetAlpha(), target.iconColorAlpha or 1
end

local function HideWidget(w)
    w.key:Hide()
    w.bg:Hide()
end

local function HideAll()
    for _, w in pairs(widgets) do
        HideWidget(w)
    end
end


local lastCfgSig

function M.Update(core, scale)
    local cfg = M.EnsureConfig(core)
    scale = scale or 1
    local isDebug = core.config.debug == true
    local numeric = isDebug
    local dim = cfg.dimWithIcon or isDebug

    local sig = (cfg.background and 1 or 0) + (cfg.largeFont and 2 or 0)
        + (isDebug and 4 or 0) + (cfg.colorMods and 8 or 0)
    if sig ~= lastCfgSig then
        if lastCfgSig ~= nil then
            M.QueueRefresh()
        end
        lastCfgSig = sig
    end

    if not cfg.enabled then
        HideAll()
        return
    end

    local mainAlpha, mainColorAlpha = 1, 1
    if dim then
        local ready, cdAlpha, poolAlpha = core:GetMainIconReadiness()
        if not ready or core:GetAlpha() < 1 then
            mainAlpha = 0.2
        else
            mainAlpha, mainColorAlpha = cdAlpha, poolAlpha
        end
    end
    local w = EnsureWidget(core, core.overlay)
    ApplyWidget(w, core, GetDisplay(core.currentSpellID, numeric), scale, cfg, isDebug,
        mainAlpha, mainColorAlpha)

    if not M.interruptOverlay then
        M.interruptOverlay = CreateFrame("Frame", nil, UIParent)
        M.interruptOverlay:SetAllPoints(core.interruptFrame)
    end
    if M.lastStrata ~= core.config.strata then
        M.interruptOverlay:SetFrameStrata(core.config.strata)
        M.interruptOverlay:SetFrameLevel(core.interruptFrame.cooldown:GetFrameLevel() + 5)
        M.lastStrata = core.config.strata
    end
    w = EnsureWidget(core.interruptFrame, M.interruptOverlay)
    if core.config.interruptEnabled and core.interruptSpellID then
        ApplyWidget(w, core.interruptFrame, GetDisplay(core.interruptSpellID, numeric), scale, cfg,
            isDebug, MirrorAlpha(core.interruptFrame, dim))
    else
        HideWidget(w)
    end

    for i = 1, core.config.maxDefensiveSlots do
        local frame = core.defensivesFrames[i]
        local data = core.defensivesSlotData[i]
        if frame then
            w = EnsureWidget(frame, frame.overlay)
            if core.config.defensivesEnabled and data and data.active and data.spellID then
                ApplyWidget(w, frame, GetDisplay(data.spellID, numeric), scale, cfg, isDebug,
                    MirrorAlpha(frame, dim))
            else
                HideWidget(w)
            end
        end
    end
end


local eventFrame = CreateFrame("Frame")

local KEY_EVENTS = {
    PLAYER_ENTERING_WORLD = true,
    UPDATE_BINDINGS = true,
    ACTIONBAR_PAGE_CHANGED = true,
    UPDATE_BONUS_ACTIONBAR = true,
    UPDATE_OVERRIDE_ACTIONBAR = true,
    UPDATE_VEHICLE_ACTIONBAR = true,
    UPDATE_SHAPESHIFT_FORM = true,
}

local SPELL_EVENTS = {
    ACTIONBAR_SLOT_CHANGED = true,
    SPELLS_CHANGED = true,
    UPDATE_MACROS = true,
    PLAYER_SPECIALIZATION_CHANGED = true,
}

eventFrame:SetScript("OnEvent", function(_, event)
    if KEY_EVENTS[event] then
        InvalidateKeys()
    elseif SPELL_EVENTS[event] then
        InvalidateSpells()
    end
end)

function M.Init(core)
    M.EnsureConfig(core)
    for event in pairs(KEY_EVENTS) do
        eventFrame:RegisterEvent(event)
    end
    for event in pairs(SPELL_EVENTS) do
        eventFrame:RegisterEvent(event)
    end
end


function M.DumpKeyCodes()
    local byCode = {}

    local function Add(key)
        local vk = KeyToVK(key)
        if not vk then return end
        local code = tonumber(vk)
        local names = byCode[code]
        if not names then
            names = {}
            byCode[code] = names
        end
        names[#names + 1] = key
    end

    for key in pairs(VK_SPECIAL) do Add(key) end
    for b = 65, 90 do Add(string.char(b)) end
    for b = 48, 57 do Add(string.char(b)) end
    for i = 0, 9 do Add("NUMPAD" .. i) end
    for i = 1, 24 do Add("F" .. i) end

    local codes = {}
    for code in pairs(byCode) do
        codes[#codes + 1] = code
    end
    table.sort(codes)

    print(string.format(
        "|cff00ff00[BetterAssistant]|r key codes (decimal VK), %d total:", #codes))

    local function NameOrder(a, b)
        if (#a == 1) ~= (#b == 1) then return #a > #b end
        return a < b
    end

    local line = {}
    local shown = {}
    for _, code in ipairs(codes) do
        local names = byCode[code]
        table.sort(names, NameOrder)
        wipe(shown)
        for i, name in ipairs(names) do
            shown[i] = #name == 1 and ('"' .. name .. '"') or name
        end
        line[#line + 1] = string.format("%d=%s", code, table.concat(shown, "/"))
        if #line == 5 then
            print("  " .. table.concat(line, "   "))
            wipe(line)
        end
    end
    if #line > 0 then
        print("  " .. table.concat(line, "   "))
    end
end
