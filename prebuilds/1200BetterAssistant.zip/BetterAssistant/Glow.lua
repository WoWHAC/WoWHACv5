local addonName, addon = ...

addon.glow = {}
local Glow = addon.glow

local ACTIONBAR_PAD_FRAC = 0.18 
local BORDER_BASE = 2           

local function EnsureFX(frame)
    if not frame.glowFX then
        frame.glowFX = { shownStyle = nil, active = false }
    end
    return frame.glowFX
end


local function ConfigFlipBook(anim, duration)
    anim:SetDuration(duration)
    anim:SetFlipBookRows(6)
    anim:SetFlipBookColumns(5)
    anim:SetFlipBookFrames(30)
    anim:SetFlipBookFrameWidth(0)
    anim:SetFlipBookFrameHeight(0)
end

local function EnsureActionBar(frame, fx)
    if fx.proc then return fx.proc end

    local proc = CreateFrame("Frame", nil, frame)
    proc:SetAllPoints(frame)
    proc:SetFrameLevel(frame:GetFrameLevel() + 1)
    proc:SetIgnoreParentAlpha(true)
    proc:Hide()

    local loop = proc:CreateTexture(nil, "OVERLAY")
    loop:SetAllPoints(proc)
    proc.loopTex = loop

    loop:SetAtlas("UI-HUD-ActionBar-Proc-Loop-Flipbook", true)

    local ag = loop:CreateAnimationGroup()
    ag:SetLooping("REPEAT")
    ConfigFlipBook(ag:CreateAnimation("FlipBook"), 1)
    proc.loopAnim = ag

    fx.proc = proc
    return proc
end

local function StartActionBar(frame, fx)
    local proc = EnsureActionBar(frame, fx)
    local w = frame:GetWidth() or 0
    local pad = w * ACTIONBAR_PAD_FRAC
    proc:ClearAllPoints()
    proc:SetPoint("TOPLEFT", frame, "TOPLEFT", -pad, pad)
    proc:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", pad, -pad)
    proc:Show()
    if proc.loopAnim then
        proc.loopAnim:Stop()
        proc.loopAnim:Play()
    end
end

local function StopActionBar(fx)
    local proc = fx.proc
    if not proc then return end
    if proc.loopAnim then proc.loopAnim:Stop() end
    proc:Hide()
end


local function EnsureAutoCast(frame, fx)
    if fx.autoCast ~= nil then return fx.autoCast end

    local ac = CreateFrame("Frame", nil, frame, "AutoCastOverlayTemplate")
    ac:SetAllPoints(frame)
    ac:SetIgnoreParentAlpha(true)
    ac:Hide()

    fx.autoCast = ac
    return ac
end

local function StartAutoCast(frame, fx)
    local ac = EnsureAutoCast(frame, fx)
    ac:Show()
    ac:ShowAutoCastEnabled(true)
end

local function StopAutoCast(fx)
    local ac = fx.autoCast
    if not ac then return end
    ac:ShowAutoCastEnabled(false)
    ac:Hide()
end


local function EnsureBorder(frame, fx)
    if fx.border then return fx.border end

    local function mk()
        local t = frame:CreateTexture(nil, "OVERLAY")
        t:SetColorTexture(1, 1, 1, 1)
        t:SetIgnoreParentAlpha(true)
        t:Hide()
        return t
    end

    local b = { top = mk(), bottom = mk(), left = mk(), right = mk() }
    fx.border = b
    return b
end

local function StartBorder(frame, fx, scale)
    local b = EnsureBorder(frame, fx)
    local th = BORDER_BASE * (scale or 1)
    if th < 1 then th = 1 end

    b.top:ClearAllPoints()
    b.top:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    b.top:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    b.top:SetHeight(th)

    b.bottom:ClearAllPoints()
    b.bottom:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, 0)
    b.bottom:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
    b.bottom:SetHeight(th)

    b.left:ClearAllPoints()
    b.left:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    b.left:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, 0)
    b.left:SetWidth(th)

    b.right:ClearAllPoints()
    b.right:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    b.right:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
    b.right:SetWidth(th)

    b.top:Show(); b.bottom:Show(); b.left:Show(); b.right:Show()
end

local function StopBorder(fx)
    local b = fx.border
    if not b then return end
    b.top:Hide(); b.bottom:Hide(); b.left:Hide(); b.right:Hide()
end


local function StopStyle(fx, style)
    if style == "ActionBar" then
        StopActionBar(fx)
    elseif style == "AutoCast" then
        StopAutoCast(fx)
    elseif style == "SimpleBorder" then
        StopBorder(fx)
    end
end

function Glow.Stop(frame)
    if not frame or not frame.glowFX then return end
    local fx = frame.glowFX
    if fx.shownStyle then
        StopStyle(fx, fx.shownStyle)
        fx.shownStyle = nil
    end
    fx.active = false
end

function Glow.Apply(frame, active, style, scale)
    if not frame then return end
    if not active or not style or style == "Off" then
        return Glow.Stop(frame)
    end

    local fx = EnsureFX(frame)
    if fx.active and fx.shownStyle == style then
        return
    end

    if fx.shownStyle and fx.shownStyle ~= style then
        StopStyle(fx, fx.shownStyle)
    end

    if style == "ActionBar" then
        StartActionBar(frame, fx)
    elseif style == "AutoCast" then
        StartAutoCast(frame, fx)
    elseif style == "SimpleBorder" then
        StartBorder(frame, fx, scale)
    else
        return Glow.Stop(frame)
    end

    fx.shownStyle = style
    fx.active = true
end
