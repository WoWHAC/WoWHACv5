local addonName, addon = ...

local defaultConfig = {
    X = 0,
    Y = -225,
    size = 64,
    enabled = true,
    hideWhenMounted = false,
    rangeCheck = true,
    castCheck = true,
    channelCheck = true,
    trueScale = false,
    showWhen = "HasTarget",
    strata = "FULLSCREEN_DIALOG",
    checkForVisibleButton = false,
    interruptEnabled = true,
    silentMode = false,
    defensivesEnabled = true,
    ignoreClicks = false,
    debug = false,
    maxDefensiveSlots = 6,
    glowStyle = "Off",
    targetRangeEnabled = true,
}

local advancedDefaults = {
    empoweredStageThreshold = 2,
    resourcePoolingType = -1,
    resourcePoolingThreshold = 40,
    movingOverrideEnabled = false,
    movingOverrideSpellID = 0,
    nameplateCounterEnabled = true,
    nameplateCounterRange = 38,
    nameplateCounterCombatOnly = true,
}

addon.advancedOptionKeys = {
    "empoweredStageThreshold",
    "resourcePoolingType",
    "resourcePoolingThreshold",
    "movingOverrideEnabled",
    "movingOverrideSpellID",
    "nameplateCounterEnabled",
    "nameplateCounterRange",
    "nameplateCounterCombatOnly",
}

local CLASS_ADVANCED_DEFAULTS = {
    ["MONK"] = {
        resourcePoolingType = 3,
        resourcePoolingThreshold = 45,
    },
}

local function ResolveAdvancedDefault(option)
    local _, classToken = UnitClass("player")
    local classOverrides = CLASS_ADVANCED_DEFAULTS[classToken]
    if classOverrides and classOverrides[option] ~= nil then
        return classOverrides[option]
    end
    return advancedDefaults[option]
end

local CALL_PET_SPELLS = {
    [883] = true,
    [83242] = true,
    [83243] = true,
    [83244] = true,
    [83245] = true,
}

local SPELL_RANGE_DEFAULTS = {
    DRUID   = { { spellID = 77758,  distance = 8 } },
    PALADIN = { { spellID = 53600,  distance = 5 },
                { spellID = 26573,  distance = 8 },
                { spellID = 204019, distance = 8 } },
    WARRIOR = { { spellID = 6343,   distance = 8 },
                { spellID = 190411, distance = 8 } },
}

local SPEC_POWER_TYPES = {
    [71]   = { {type = 1, name = "Rage"} },
    [72]   = { {type = 1, name = "Rage"} },
    [73]   = { {type = 1, name = "Rage"} },
    [65]   = { {type = 0, name = "Mana"}, {type = 9, name = "Holy Power"} },
    [66]   = { {type = 0, name = "Mana"}, {type = 9, name = "Holy Power"} },
    [70]   = { {type = 0, name = "Mana"}, {type = 9, name = "Holy Power"} },
    [253]  = { {type = 2, name = "Focus"} },
    [254]  = { {type = 2, name = "Focus"} },
    [255]  = { {type = 2, name = "Focus"} },
    [259]  = { {type = 3, name = "Energy"}, {type = 4, name = "Combo Points"} },
    [260]  = { {type = 3, name = "Energy"}, {type = 4, name = "Combo Points"} },
    [261]  = { {type = 3, name = "Energy"}, {type = 4, name = "Combo Points"} },
    [256]  = { {type = 0, name = "Mana"}, {type = 13, name = "Insanity"} },
    [257]  = { {type = 0, name = "Mana"}, {type = 13, name = "Insanity"} },
    [258]  = { {type = 0, name = "Mana"}, {type = 13, name = "Insanity"} },
    [250]  = { {type = -101, name = "Runes"}, {type = 6, name = "Runic Power"} },
    [251]  = { {type = -101, name = "Runes"}, {type = 6, name = "Runic Power"} },
    [252]  = { {type = -101, name = "Runes"}, {type = 6, name = "Runic Power"} },
    [262]  = { {type = 0, name = "Mana"}, {type = 11, name = "Maelstrom"} },
    [263]  = { {type = 0, name = "Mana"}, {type = 11, name = "Maelstrom"} },
    [264]  = { {type = 0, name = "Mana"}, {type = 11, name = "Maelstrom"} },
    [62]   = { {type = 0, name = "Mana"}, {type = 16, name = "Arcane Charges"} },
    [63]   = { {type = 0, name = "Mana"}, {type = 16, name = "Arcane Charges"} },
    [64]   = { {type = 0, name = "Mana"}, {type = 16, name = "Arcane Charges"} },
    [265]  = { {type = 0, name = "Mana"}, {type = 7, name = "Soul Shards"} },
    [266]  = { {type = 0, name = "Mana"}, {type = 7, name = "Soul Shards"} },
    [267]  = { {type = 0, name = "Mana"}, {type = 7, name = "Soul Shards"} },
    [268]  = { {type = 3, name = "Energy"}, {type = -100, name = "Stagger"} },
    [270]  = { {type = 0, name = "Mana"} },
    [269]  = { {type = 3, name = "Energy"}, {type = 12, name = "Chi"} },
    [102]  = { {type = 0, name = "Mana"}, {type = 8, name = "Astral Power"} },
    [103]  = { {type = 3, name = "Energy"}, {type = 4, name = "Combo Points"} },
    [104]  = { {type = 1, name = "Rage"} },
    [105]  = { {type = 0, name = "Mana"}, {type = 8, name = "Astral Power"} },
    [577]  = { {type = 17, name = "Fury"} },
    [581]  = { {type = 17, name = "Fury"} },
    [1480]  = { {type = 17, name = "Fury"} },
    [1467] = { {type = 0, name = "Mana"}, {type = 19, name = "Essence"} },
    [1468] = { {type = 0, name = "Mana"}, {type = 19, name = "Essence"} },
    [1473] = { {type = 0, name = "Mana"}, {type = 19, name = "Essence"} },
}
addon.SPEC_POWER_TYPES = SPEC_POWER_TYPES

local function GetCurrentSpecPowers()
    local specIndex = GetSpecialization()
    if not specIndex then return {} end
    local specID = GetSpecializationInfo(specIndex)
    return specID and SPEC_POWER_TYPES[specID] or {}
end
addon.GetCurrentSpecPowers = GetCurrentSpecPowers

addon.DEBUG_FONT_FILE = "Fonts\\ARIALN.TTF"
addon.DEBUG_FONT_SIZE = 12
addon.DEBUG_FONT_FLAGS = "OUTLINE"
addon.DEBUG_BG_W = 20
addon.DEBUG_BG_H = 14
addon.KEYBIND_BG_W = 30
addon.DEBUG_LEFT_FONT_X = 0
addon.DEBUG_RIGHT_FONT_X = 3
addon.DEBUG_TOP_FONT_Y = -1
addon.DEBUG_BOTTOM_FONT_Y = 1

addon.DEBUG_BOUNDS_MARKER_SIZE = 1
addon.DEBUG_BOUNDS_MARKER_COLOR = { 1, 0, 1, 1 }

addon.PERCENT_CURVE = C_CurveUtil.CreateCurve()
addon.PERCENT_CURVE:AddPoint(0, 0)
addon.PERCENT_CURVE:AddPoint(1, 100)

local IGNORED_CAST_SPELLS = {
    [1250609] = true,
    [15407] = true,
}

local INTERRUPT_SPELLS = {
     47528,
    183752,
     78675,
    106839,
    147362,
    187707,
      2139,
    116705,
     96231,
     15487,
      1766,
     57994,
    119910,
    119914,
      6552,
    351338,
}

local INTERRUPT_CD_READY_CURVE = C_CurveUtil.CreateCurve()
INTERRUPT_CD_READY_CURVE:AddPoint(0.0, 1)
INTERRUPT_CD_READY_CURVE:AddPoint(0.2, 1)
INTERRUPT_CD_READY_CURVE:AddPoint(0.3, 0.2)
INTERRUPT_CD_READY_CURVE:AddPoint(120, 0.2)

local DEFENSIVES_CD_READY_CURVE = C_CurveUtil.CreateCurve()
DEFENSIVES_CD_READY_CURVE:AddPoint(0.0, 1)
DEFENSIVES_CD_READY_CURVE:AddPoint(0.2, 1)
DEFENSIVES_CD_READY_CURVE:AddPoint(0.3, 0.2)
DEFENSIVES_CD_READY_CURVE:AddPoint(120, 0.2)

local MAIN_CD_READY_CURVE = C_CurveUtil.CreateCurve()
MAIN_CD_READY_CURVE:AddPoint(0.0, 1)
MAIN_CD_READY_CURVE:AddPoint(0.2, 1)
MAIN_CD_READY_CURVE:AddPoint(0.3, 0.2)
MAIN_CD_READY_CURVE:AddPoint(120, 0.2)

local function CreateDefensiveCurve(threshold, op)
    local t      = threshold / 100
    local eps    = 0.001
    local opaque = CreateColor(1, 1, 1, 1)
    local faded  = CreateColor(1, 1, 1, 0.2)
    local curve  = C_CurveUtil.CreateColorCurve()
    curve:SetType(Enum.LuaCurveType.Linear)

    if op == "<" then
        if threshold <= 0 then
            curve:AddPoint(0, faded); curve:AddPoint(1, faded)
        elseif threshold >= 100 then
            curve:AddPoint(0, opaque); curve:AddPoint(1 - eps, opaque); curve:AddPoint(1, faded)
        else
            curve:AddPoint(0, opaque)
            curve:AddPoint(t - eps, opaque)
            curve:AddPoint(t, faded)
            curve:AddPoint(1, faded)
        end
    elseif op == "<=" then
        if threshold >= 100 then
            curve:AddPoint(0, opaque); curve:AddPoint(1, opaque)
        else
            curve:AddPoint(0, opaque)
            curve:AddPoint(t, opaque)
            curve:AddPoint(t + eps, faded)
            curve:AddPoint(1, faded)
        end
    elseif op == ">" then
        if threshold >= 100 then
            curve:AddPoint(0, faded); curve:AddPoint(1, faded)
        elseif threshold <= 0 then
            curve:AddPoint(0, faded); curve:AddPoint(eps, opaque); curve:AddPoint(1, opaque)
        else
            curve:AddPoint(0, faded)
            curve:AddPoint(t, faded)
            curve:AddPoint(t + eps, opaque)
            curve:AddPoint(1, opaque)
        end
    elseif op == ">=" then
        if threshold <= 0 then
            curve:AddPoint(0, opaque); curve:AddPoint(1, opaque)
        else
            curve:AddPoint(0, faded)
            curve:AddPoint(t - eps, faded)
            curve:AddPoint(t, opaque)
            curve:AddPoint(1, opaque)
        end
    elseif op == "=" then
        local right = math.min(t + 0.01, 1)
        curve:AddPoint(0, faded)
        if t > 0 then curve:AddPoint(t - eps, faded) end
        curve:AddPoint(t, opaque)
        if right - eps > t then curve:AddPoint(right - eps, opaque) end
        if right < 1 then
            curve:AddPoint(right, faded)
            curve:AddPoint(1, faded)
        end
    else
        curve:AddPoint(0, opaque); curve:AddPoint(1, opaque)
    end

    return curve
end

local function ResolvePowerType(resource)
    if resource == "health" then return nil end
    if resource == "stagger" then return nil end
    if resource == "runes" then return nil end
    for _, pt in ipairs(GetCurrentSpecPowers()) do
        if pt.name:lower() == resource then return pt.type end
    end
    return nil
end

local function GetDefensiveSlotColor(unit, data)
    if data.resource == "stagger" then
        local maxHP = UnitHealthMax("player")
        local pct = (maxHP > 0) and (UnitStagger("player") / maxHP) or 0
        if pct > 1 then pct = 1 end
        return data.defensiveCurve:Evaluate(pct)
    end
    if data.resource == "runes" then
        local ready = 0
        for i = 1, 6 do
            local _, _, runeReady = GetRuneCooldown(i)
            if runeReady then ready = ready + 1 end
        end
        return data.defensiveCurve:Evaluate(ready / 6)
    end
    if data.resource ~= "health" then
        local powerType = ResolvePowerType(data.resource)
        if powerType then
            return UnitPowerPercent(unit, powerType, true, data.defensiveCurve)
        end
    end
    return UnitHealthPercent(unit, false, data.defensiveCurve)
end

local function GetResourcePercent(pt)
    if pt.type == -100 then
        local maxHP = UnitHealthMax("player")
        local pct = (maxHP > 0) and (UnitStagger("player") / maxHP) or 0
        if pct > 1 then pct = 1 end
        return addon.PERCENT_CURVE:Evaluate(pct)
    end
    if pt.type == -101 then
        local ready = 0
        for i = 1, 6 do
            local _, _, runeReady = GetRuneCooldown(i)
            if runeReady then ready = ready + 1 end
        end
        return addon.PERCENT_CURVE:Evaluate(ready / 6)
    end
    return UnitPowerPercent("player", pt.type, true, addon.PERCENT_CURVE)
end

local WHISTLE_ICON = "Interface\\Icons\\Ability_Hunter_BeastCall"

local DefinitelyNotHekili = CreateFrame("Frame", nil, UIParent)
DefinitelyNotHekili.config = nil
DefinitelyNotHekili.currentSpellID = nil
DefinitelyNotHekili.isDragging = false
DefinitelyNotHekili.isConfiguring = false
DefinitelyNotHekili:RegisterEvent("ADDON_LOADED")
DefinitelyNotHekili:EnableMouse(true)
DefinitelyNotHekili:SetMovable(true)
DefinitelyNotHekili:RegisterForDrag("LeftButton")

DefinitelyNotHekili.icon = DefinitelyNotHekili:CreateTexture(nil, "BACKGROUND")
DefinitelyNotHekili.icon:SetAllPoints()
DefinitelyNotHekili.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
DefinitelyNotHekili:SetAlpha(0.2)

DefinitelyNotHekili.cooldown = CreateFrame("Cooldown", nil, DefinitelyNotHekili, "CooldownFrameTemplate")
DefinitelyNotHekili.cooldown:SetAllPoints()
DefinitelyNotHekili.cooldown:SetDrawEdge(false)
DefinitelyNotHekili.cooldown:SetDrawSwipe(true)
DefinitelyNotHekili.cooldown:SetDrawBling(false)
DefinitelyNotHekili.cooldown:SetHideCountdownNumbers(true)

DefinitelyNotHekili.overlay = CreateFrame("Frame", nil, UIParent)
DefinitelyNotHekili.overlay:SetAllPoints(DefinitelyNotHekili)

DefinitelyNotHekili.dbgPctBg = DefinitelyNotHekili.overlay:CreateTexture(nil, "ARTWORK")
DefinitelyNotHekili.dbgPctBg:SetColorTexture(0, 0, 0, 1)
DefinitelyNotHekili.dbgPctBg:SetPoint("BOTTOMLEFT", DefinitelyNotHekili, "BOTTOMLEFT", 0, 0)
DefinitelyNotHekili.dbgPctBg:Hide()

DefinitelyNotHekili.dbgPctText = DefinitelyNotHekili.overlay:CreateFontString(nil, "OVERLAY")
DefinitelyNotHekili.dbgPctText:SetPoint("BOTTOMLEFT", DefinitelyNotHekili, "BOTTOMLEFT", addon.DEBUG_LEFT_FONT_X, addon.DEBUG_BOTTOM_FONT_Y)
DefinitelyNotHekili.dbgPctText:SetJustifyH("LEFT")
DefinitelyNotHekili.dbgPctText:Hide()

DefinitelyNotHekili.dbgTargetHpBg = DefinitelyNotHekili.overlay:CreateTexture(nil, "ARTWORK")
DefinitelyNotHekili.dbgTargetHpBg:SetColorTexture(0, 0, 0, 1)
DefinitelyNotHekili.dbgTargetHpBg:SetPoint("TOPLEFT", DefinitelyNotHekili, "TOPLEFT", 0, 0)
DefinitelyNotHekili.dbgTargetHpBg:Hide()

DefinitelyNotHekili.dbgTargetHpText = DefinitelyNotHekili.overlay:CreateFontString(nil, "OVERLAY")
DefinitelyNotHekili.dbgTargetHpText:SetPoint("TOPLEFT", DefinitelyNotHekili, "TOPLEFT", addon.DEBUG_LEFT_FONT_X, addon.DEBUG_TOP_FONT_Y)
DefinitelyNotHekili.dbgTargetHpText:SetJustifyH("LEFT")
DefinitelyNotHekili.dbgTargetHpText:Hide()

DefinitelyNotHekili.nameplateCountBg = DefinitelyNotHekili.overlay:CreateTexture(nil, "ARTWORK")
DefinitelyNotHekili.nameplateCountBg:SetColorTexture(0, 0, 0, 1)
DefinitelyNotHekili.nameplateCountBg:SetPoint("TOPRIGHT", DefinitelyNotHekili, "TOPRIGHT", 0, 0)
DefinitelyNotHekili.nameplateCountBg:Hide()

DefinitelyNotHekili.nameplateCountText = DefinitelyNotHekili.overlay:CreateFontString(nil, "OVERLAY")
DefinitelyNotHekili.nameplateCountText:SetPoint("TOPRIGHT", DefinitelyNotHekili, "TOPRIGHT", addon.DEBUG_RIGHT_FONT_X, addon.DEBUG_TOP_FONT_Y)
DefinitelyNotHekili.nameplateCountText:SetJustifyH("RIGHT")
DefinitelyNotHekili.nameplateCountText:Hide()

DefinitelyNotHekili.targetRangeBg = DefinitelyNotHekili.overlay:CreateTexture(nil, "ARTWORK")
DefinitelyNotHekili.targetRangeBg:SetColorTexture(0, 0, 0, 1)
DefinitelyNotHekili.targetRangeBg:SetPoint("BOTTOMRIGHT", DefinitelyNotHekili, "BOTTOMRIGHT", 0, 0)
DefinitelyNotHekili.targetRangeBg:Hide()

DefinitelyNotHekili.targetRangeText = DefinitelyNotHekili.overlay:CreateFontString(nil, "OVERLAY")
DefinitelyNotHekili.targetRangeText:SetPoint("BOTTOMRIGHT", DefinitelyNotHekili, "BOTTOMRIGHT", addon.DEBUG_RIGHT_FONT_X, addon.DEBUG_BOTTOM_FONT_Y)
DefinitelyNotHekili.targetRangeText:SetJustifyH("RIGHT")
DefinitelyNotHekili.targetRangeText:Hide()

local BOUNDS_MARKERS = {
    { "TOPLEFT",      1,  0 },
    { "TOPRIGHT",    -1,  0 },
    { "BOTTOMLEFT",   1,  0 },
    { "BOTTOMRIGHT", -1,  0 },
    { "TOPLEFT",      0, -1 },
    { "BOTTOMLEFT",   0,  1 },
    { "TOPRIGHT",     0, -1 },
    { "BOTTOMRIGHT",  0,  1 },
}
DefinitelyNotHekili.dbgBoundsMarkers = {}
for i in ipairs(BOUNDS_MARKERS) do
    local px = DefinitelyNotHekili.overlay:CreateTexture(nil, "OVERLAY")
    px:SetColorTexture(unpack(addon.DEBUG_BOUNDS_MARKER_COLOR))
    px:Hide()
    DefinitelyNotHekili.dbgBoundsMarkers[i] = px
end

DefinitelyNotHekili.interruptSpellID = nil
DefinitelyNotHekili.interruptFrame = CreateFrame("Frame", nil, UIParent)
DefinitelyNotHekili.interruptFrame.icon = DefinitelyNotHekili.interruptFrame:CreateTexture(nil, "BACKGROUND")
DefinitelyNotHekili.interruptFrame.icon:SetAllPoints()
DefinitelyNotHekili.interruptFrame.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
DefinitelyNotHekili.interruptFrame.cooldown = CreateFrame("Cooldown", nil, DefinitelyNotHekili.interruptFrame, "CooldownFrameTemplate")
DefinitelyNotHekili.interruptFrame.cooldown:SetAllPoints()
DefinitelyNotHekili.interruptFrame.cooldown:SetDrawEdge(false)
DefinitelyNotHekili.interruptFrame.cooldown:SetDrawSwipe(true)
DefinitelyNotHekili.interruptFrame.cooldown:SetDrawBling(false)
DefinitelyNotHekili.interruptFrame.cooldown:SetHideCountdownNumbers(true)
DefinitelyNotHekili.interruptFrame:SetAlpha(0.2)

DefinitelyNotHekili.defensivesFrames = {}
DefinitelyNotHekili.defensivesSlotData = {}

function DefinitelyNotHekili:EnsureDefensiveFramePool(count)
    for i = #self.defensivesFrames + 1, count do
        local f = CreateFrame("Frame", nil, UIParent)
        f.icon = f:CreateTexture(nil, "BACKGROUND")
        f.icon:SetAllPoints()
        f.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        f:SetAlpha(0)

        f.overlay = CreateFrame("Frame", nil, UIParent)
        f.overlay:SetAllPoints(f)

        f.chargeCountBg = f.overlay:CreateTexture(nil, "ARTWORK")
        f.chargeCountBg:SetColorTexture(0, 0, 0, 1)
        f.chargeCountBg:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
        f.chargeCountBg:Hide()

        f.chargeCountText = f.overlay:CreateFontString(nil, "OVERLAY")
        f.chargeCountText:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", addon.DEBUG_RIGHT_FONT_X, addon.DEBUG_BOTTOM_FONT_Y)
        f.chargeCountText:SetJustifyH("RIGHT")
        f.chargeCountText:Hide()

        f.dbgResourceBg = f.overlay:CreateTexture(nil, "ARTWORK")
        f.dbgResourceBg:SetColorTexture(0, 0, 0, 1)
        f.dbgResourceBg:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
        f.dbgResourceBg:Hide()

        f.dbgResourceText = f.overlay:CreateFontString(nil, "OVERLAY")
        f.dbgResourceText:SetPoint("TOPLEFT", f, "TOPLEFT", addon.DEBUG_LEFT_FONT_X, addon.DEBUG_TOP_FONT_Y)
        f.dbgResourceText:SetJustifyH("LEFT")
        f.dbgResourceText:Hide()

        f.dbgCooldownBg = f.overlay:CreateTexture(nil, "ARTWORK")
        f.dbgCooldownBg:SetColorTexture(0, 0, 0, 1)
        f.dbgCooldownBg:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)
        f.dbgCooldownBg:Hide()

        f.dbgCooldownText = f.overlay:CreateFontString(nil, "OVERLAY")
        f.dbgCooldownText:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", addon.DEBUG_LEFT_FONT_X, addon.DEBUG_BOTTOM_FONT_Y)
        f.dbgCooldownText:SetJustifyH("LEFT")
        f.dbgCooldownText:Hide()

        self.defensivesFrames[i] = f
        self.defensivesSlotData[i] = { active = false }
    end
end

function DefinitelyNotHekili:GetNextSpell()
    if not C_AssistedCombat or not C_AssistedCombat.GetNextCastSpell then
        return nil
    end

    local spellID = C_AssistedCombat.GetNextCastSpell(self.config.checkForVisibleButton or false)

    if spellID and self:GetAdvancedOption("movingOverrideEnabled") and self.isMoving then
        local info = C_Spell.GetSpellInfo(spellID)
        local castTime = info and info.castTime or 0
        if castTime > 0 then
            local override = self:GetAdvancedOption("movingOverrideSpellID")
            if override and override > 0 then
                return override
            end
        end
    end

    return spellID
end

function DefinitelyNotHekili:UpdateSpellTexture(spellID)
    if spellID == self.currentSpellID then return end
    
    self.currentSpellID = spellID

    if spellID then        
        if CALL_PET_SPELLS[spellID] then
            self.icon:SetTexture(WHISTLE_ICON)
            return
        end

        local texture = C_Spell.GetSpellTexture(spellID)
        if texture then
            self.icon:SetTexture(texture)
            return
        end
    end
    self.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
end

local function ShouldShowForCondition(showWhen, conditionUnit)
    conditionUnit = conditionUnit or "target"
    if showWhen == "Always" then
        return true
    elseif showWhen == "HasTarget" then
        return UnitCanAttack("player", conditionUnit) and not UnitIsDead(conditionUnit)
    elseif showWhen == "InCombat" then
        return UnitAffectingCombat("player")
    elseif showWhen == "TargetInCombat" then
        return UnitExists(conditionUnit) and UnitCanAttack("player", conditionUnit) and UnitAffectingCombat(conditionUnit)
    end
    return true
end

function DefinitelyNotHekili:UpdateVisibility()
    if not self.config.enabled then
        self:SetAlpha(0.2)
        return
    end

    if self.config.hideWhenMounted and self:IsMounted() then
        self:SetAlpha(0.2)
        return
    end

    self:SetAlpha(ShouldShowForCondition(self.config.showWhen) and 1 or 0.2)
end

function DefinitelyNotHekili:GetAdvancedOption(option)
    local specKey = self:GetSpecKey()
    if not specKey then return ResolveAdvancedDefault(option) end

    if not self.config.advanced then
        self.config.advanced = {}
    end

    if not self.config.advanced[specKey] then
        self.config.advanced[specKey] = {}
    end

    if self.config.advanced[specKey][option] == nil then
        self.config.advanced[specKey][option] = ResolveAdvancedDefault(option)
    end

    return self.config.advanced[specKey][option]
end

function DefinitelyNotHekili:SetAdvancedOption(option, value)
    local specKey = self:GetSpecKey()
    if not specKey then return end

    if not self.config.advanced then
        self.config.advanced = {}
    end

    if not self.config.advanced[specKey] then
        self.config.advanced[specKey] = {}
    end

    self.config.advanced[specKey][option] = value
end

function DefinitelyNotHekili:IsEmpowerReady()
    local _, _, _, channelStartMS, channelEndMS, _, _, _, _, numStages = UnitChannelInfo("player")

    if numStages and numStages > 0 then
        local elapsed = GetTime() - channelStartMS / 1000
        local cumulative = 0
        local currentStage = 0

        for i = 0, numStages - 1 do
            cumulative = cumulative + GetUnitEmpowerStageDuration("player", i) / 1000
            if elapsed >= cumulative then
                currentStage = i + 1
            end
        end

        local minReleaseStage = self:GetAdvancedOption("empoweredStageThreshold")
        if minReleaseStage > 0 and currentStage >= minReleaseStage then
            self.empowerReadyUntil = channelEndMS / 1000
            return true
        end
        return false
    end

    if self.empowerReadyUntil and GetTime() < self.empowerReadyUntil then
        return true
    end
    self.empowerReadyUntil = nil
    return false
end

function DefinitelyNotHekili:UpdateIconColor(spellID)
    if not spellID then
        self.icon:SetVertexColor(0.5, 0.5, 0.5)
        return
    end

    if self:IsEmpowerReady() then
        self.icon:SetVertexColor(1, 1, 1)
        return
    end

    local isUsable, notEnoughResource = self:IsSpellUsable(spellID)

    if notEnoughResource then
        self.icon:SetVertexColor(0.5, 0.5, 1)
    elseif not isUsable then
        self.icon:SetVertexColor(0.4, 0.4, 0.4)
    elseif self.config.rangeCheck and not self:IsSpellInRange(spellID) then
        self.icon:SetVertexColor(1, 0.3, 0.3)
    else
        self.icon:SetVertexColor(1, 1, 1)
    end
end

local function SpellCostsPower(spellID, powerType)
    if not spellID then return false end
    local costs = C_Spell.GetSpellPowerCost(spellID)
    if not costs then return false end
    for _, cost in ipairs(costs) do
        if cost.type == powerType and ((cost.cost or 0) > 0 or (cost.costPerSec or 0) > 0) then
            return true
        end
    end
    return false
end

local function CreatePoolingCurve(pct, below, above)
    local curve = C_CurveUtil.CreateColorCurve()
    curve:SetType(Enum.LuaCurveType.Linear)
    curve:AddPoint(0, below)
    curve:AddPoint(pct - 0.01, below)
    curve:AddPoint(pct, above)
    curve:AddPoint(1, above)
    return curve
end

function DefinitelyNotHekili:UpdateResourcePooling(spellID)
    local powerType = self:GetAdvancedOption("resourcePoolingType")
    if powerType == -1 then return end
    if not SpellCostsPower(spellID, powerType) then return end

    local pct = self:GetAdvancedOption("resourcePoolingThreshold") / 100
    if self.poolingCachedThreshold ~= pct then
        self.poolingCachedThreshold = pct
        self.resourcePoolingCurve = CreatePoolingCurve(pct,
            CreateColor(0.5, 0.5, 1, 1), CreateColor(1, 1, 1, 1))
        self.poolingReadyCurve = CreatePoolingCurve(pct,
            CreateColor(1, 1, 1, 0.2), CreateColor(1, 1, 1, 1))
    end

    local color = UnitPowerPercent("player", powerType, true, self.resourcePoolingCurve)
    self.icon:SetVertexColor(color:GetRGBA())
end

function DefinitelyNotHekili:GetMainIconReadiness()
    local spellID = self.currentSpellID
    if not spellID then
        return false, 1, 1
    end

    local now = GetTime() * 1000

    if self.config.castCheck then
        local castName, _, _, _, castEndMS, _, _, _, castSpellID = UnitCastingInfo("player")
        if castName and castEndMS and (castEndMS - now) >= 200
           and not IGNORED_CAST_SPELLS[castSpellID] then
            return false, 1, 1
        end
    end

    if self.config.channelCheck then
        local channelName, _, _, _, channelEndMS, _, _, channelSpellID, _, numStages =
            UnitChannelInfo("player")
        if channelName and channelEndMS and (channelEndMS - now) >= 200
           and (not IGNORED_CAST_SPELLS[channelSpellID] or channelSpellID == spellID) then
            if not (numStages and numStages > 0 and self:IsEmpowerReady()) then
                return false, 1, 1
            end
        end
    end

    if self:IsEmpowerReady() then
        return true, 1, 1
    end

    local isUsable, notEnoughResource = self:IsSpellUsable(spellID)
    if not isUsable or notEnoughResource then
        return false, 1, 1
    end

    if self.config.rangeCheck and not self:IsSpellInRange(spellID) then
        return false, 1, 1
    end

    local cdAlpha = 1
    local cdDuration = C_Spell.GetSpellCooldownDuration(spellID)
    if cdDuration then
        cdAlpha = cdDuration:EvaluateRemainingDuration(MAIN_CD_READY_CURVE)
    end

    local poolAlpha = 1
    local powerType = self:GetAdvancedOption("resourcePoolingType")
    if powerType ~= -1 and SpellCostsPower(spellID, powerType) then
        local _, _, _, alpha =
            UnitPowerPercent("player", powerType, true, self.poolingReadyCurve):GetRGBA()
        poolAlpha = alpha
    end

    return true, cdAlpha, poolAlpha
end

function DefinitelyNotHekili:UpdatePosition()
    self:ClearAllPoints()

    local renderedSize
    self.renderScale = 1
    if self.config.trueScale then
        local scale = 768 / select(2, GetPhysicalScreenSize()) / UIParent:GetScale()
        self.renderScale = scale
        renderedSize = self.config.size * scale
        self:SetPoint("CENTER", UIParent, "CENTER", self.config.X * scale, self.config.Y * scale)
        self:SetSize(renderedSize, renderedSize)
        self.icon:SetTexCoord(0, 1, 0, 1)
        self.interruptFrame:SetSize(renderedSize, renderedSize)
        self.interruptFrame.icon:SetTexCoord(0, 1, 0, 1)
        for i = 1, self.config.maxDefensiveSlots do
            self.defensivesFrames[i]:SetSize(renderedSize, renderedSize)
            self.defensivesFrames[i].icon:SetTexCoord(0, 1, 0, 1)
        end
    else
        renderedSize = self.config.size
        self:SetPoint("CENTER", UIParent, "CENTER", self.config.X, self.config.Y)
        self:SetSize(renderedSize, renderedSize)
        self.icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
        self.interruptFrame:SetSize(renderedSize, renderedSize)
        self.interruptFrame.icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
        for i = 1, self.config.maxDefensiveSlots do
            self.defensivesFrames[i]:SetSize(renderedSize, renderedSize)
            self.defensivesFrames[i].icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
        end
    end

    self:SetFrameStrata(self.config.strata)
    self.interruptFrame:ClearAllPoints()
    self.interruptFrame:SetPoint("LEFT", self, "RIGHT", 0, 0)
    self.interruptFrame:SetFrameStrata(self.config.strata)

    for i = 1, self.config.maxDefensiveSlots do
        local df = self.defensivesFrames[i]
        df:ClearAllPoints()
        df:SetPoint("TOPLEFT", self, "BOTTOMLEFT", (i - 1) * renderedSize, 0)
        df:SetFrameStrata(self.config.strata)
        df.overlay:SetFrameStrata(self.config.strata)
        df.overlay:SetFrameLevel(df:GetFrameLevel() + 5)
    end

    self:UpdateDebugOverlay()
    self:UpdateNameplateCounter()
    self:UpdateTargetRange()
    addon.cdm.Update(self, self.renderScale)
    addon.keybinds.Update(self, self.renderScale)
end

function DefinitelyNotHekili:ClampPosition()
    local minSize, maxSize = 16, 256
    if self.config.size < minSize then
        self.config.size = minSize
    elseif self.config.size > maxSize then
        self.config.size = maxSize
    end

    local halfSize = self.config.size / 2
    local maxX, maxY

    if self.config.trueScale then
        local scale = 768 / select(2, GetPhysicalScreenSize()) / UIParent:GetScale()
        maxX = (GetScreenWidth()  / 2 - halfSize * scale) / scale
        maxY = (GetScreenHeight() / 2 - halfSize * scale) / scale
    else
        maxX = (GetScreenWidth()  / 2) - halfSize
        maxY = (GetScreenHeight() / 2) - halfSize
    end

    self.config.X = math.max(-maxX, math.min(self.config.X, maxX))
    self.config.Y = math.max(-maxY, math.min(self.config.Y, maxY))
end

function DefinitelyNotHekili:UpdateCooldown(spellID)
    if not spellID then
        self.cooldown:Clear()
        return
    end
    
    if self.config.castCheck then
        local castName, _, _, castStartMS, castEndMS, _, _, _, castSpellID = UnitCastingInfo("player")
        if castName and castStartMS and castEndMS and castEndMS > GetTime() * 1000
        and not IGNORED_CAST_SPELLS[castSpellID] then
            local startTime = castStartMS / 1000
            local duration = (castEndMS - castStartMS) / 1000
            self.cooldown:SetCooldown(startTime, duration)
            return
        end
    end

    if self.config.channelCheck then
        local channelName, _, _, channelStartMS, channelEndMS, _, _, channelSpellID, _, numStages = UnitChannelInfo("player")
        if channelName and channelStartMS and channelEndMS and channelEndMS > GetTime() * 1000
        and (not IGNORED_CAST_SPELLS[channelSpellID] or channelSpellID == spellID) then
            if numStages and numStages > 0 and self:IsEmpowerReady() then
                self.cooldown:Clear()
                return
            end
            local startTime = channelStartMS / 1000
            local duration = (channelEndMS - channelStartMS) / 1000
            self.cooldown:SetCooldown(startTime, duration)
            return
        end
    end
    
    if self:IsEmpowerReady() then
        self.cooldown:Clear()
        return
    end

    local cdDuration = C_Spell.GetSpellCooldownDuration(spellID)
    if cdDuration then
        self.cooldown:SetCooldownFromDurationObject(cdDuration)
    else
        self.cooldown:Clear()
    end
end

function DefinitelyNotHekili:IsSpellUsable(spellID)
    if not spellID then return true, false end
    return C_Spell.IsSpellUsable(spellID)
end

function DefinitelyNotHekili:IsSpellOffGCD(spellID)
    if not spellID or spellID == 0 then return false end
    local _, gcdMS = GetSpellBaseCooldown(spellID)
    return gcdMS == 0
end

function DefinitelyNotHekili:GetSpellRangeLookup()
    if self.spellRangeLookup then return self.spellRangeLookup end

    local list = self:GetOrCreateSpecRangeList()
    local lookup = {}
    if list then
        for _, entry in ipairs(list) do
            if entry.spellID and entry.spellID > 0 and entry.distance then
                lookup[entry.spellID] = entry.distance
            end
        end
    end
    self.spellRangeLookup = lookup
    return lookup
end

function DefinitelyNotHekili:InvalidateSpellRangeCache()
    self.spellRangeLookup = nil
end

function DefinitelyNotHekili:IsSpellInRange(spellID, unit)
    if not spellID then return true end
    unit = unit or "target"

    local distance = self:GetSpellRangeLookup()[spellID]
    if distance then
        if not UnitExists(unit) then return true end

        local rc = addon.range
        if not (rc and rc.GetRange and rc.GetAvailableRanges) then return true end
        local available = rc.GetAvailableRanges()
        if not available or #available == 0 then return true end

        local r = rc.GetRange("player", unit)
        if r == nil then return false end
        return r <= distance
    end

    local inRange = C_Spell.IsSpellInRange(spellID, unit)
    if inRange ~= nil then
        return inRange
    end
    return true
end

function DefinitelyNotHekili:DetectInterruptSpell()
    self.interruptSpellID = nil

    for _, spellID in ipairs(INTERRUPT_SPELLS) do
        if C_SpellBook.IsSpellInSpellBook(spellID) then
            self.interruptSpellID = C_Spell.GetOverrideSpell(spellID)
            local texture = C_Spell.GetSpellTexture(self.interruptSpellID)
            if texture then
                self.interruptFrame.icon:SetTexture(texture)
            end
            break
        end
    end
end

function DefinitelyNotHekili:GetSpecKey()
    local _, _, classID = UnitClass("player")
    local specIndex = GetSpecialization()
    if not specIndex then return nil end
    local specID = GetSpecializationInfo(specIndex)
    if not specID then return nil end
    return classID .. "-" .. specID
end

function DefinitelyNotHekili:GetOrCreateSpecSlots()
    local key = self:GetSpecKey()
    if not key then return nil end

    if not self.config.defensivesSpells then
        self.config.defensivesSpells = {}
    end

    if not self.config.defensivesSpells[key] then
        self.config.defensivesSpells[key] = {}
        for i = 1, self.config.maxDefensiveSlots do
            self.config.defensivesSpells[key][i] = {
                spellID = 0,
                healthPct = 100,
                enabled = i <= 2,
                buffDuration = 0,
                showWhen = "HasTarget",
                unit = "player",
                resource = "health",
                operator = "<=",
                glow = false,
                dispelable = false,
            }
        end
    else
        for i = 1, self.config.maxDefensiveSlots do
            if not self.config.defensivesSpells[key][i] then
                self.config.defensivesSpells[key][i] = {
                    spellID = 0,
                    healthPct = 100,
                    enabled = false,
                    buffDuration = 0,
                    showWhen = "HasTarget",
                    unit = "player",
                    resource = "health",
                    operator = "<=",
                    glow = false,
                    dispelable = false,
                }
            else
                local s = self.config.defensivesSpells[key][i]
                s.spellID = s.spellID or 0
                s.healthPct = s.healthPct or 100
                s.enabled = s.enabled or false
                s.buffDuration = s.buffDuration or 0
                s.showWhen = s.showWhen or "HasTarget"
                s.unit = s.unit or "player"
                s.resource = s.resource or "health"
                s.operator = s.operator or "<="
                s.glow = s.glow or false
                s.dispelable = s.dispelable or false
            end
        end
    end

    return self.config.defensivesSpells[key], key
end

function DefinitelyNotHekili:GetOrCreateSpecRangeList()
    local key = self:GetSpecKey()
    if not key then return nil end

    if not self.config.spellRange then
        self.config.spellRange = {}
    end

    if not self.config.spellRange[key] then
        local list = {}
        local _, classToken = UnitClass("player")
        local seed = SPELL_RANGE_DEFAULTS[classToken]
        if seed then
            for _, entry in ipairs(seed) do
                list[#list + 1] = { spellID = entry.spellID, distance = entry.distance }
            end
        end
        self.config.spellRange[key] = list
    end

    return self.config.spellRange[key], key
end

function DefinitelyNotHekili:DetectDefensivesSpells()
    if not self.config.defensivesEnabled then
        for i = 1, self.config.maxDefensiveSlots do
            self.defensivesFrames[i]:SetAlpha(0)
            self.defensivesSlotData[i] = { active = false }
        end
        return
    end

    local slots = self:GetOrCreateSpecSlots()

    for i = 1, self.config.maxDefensiveSlots do
        local slot = slots and slots[i]
        local frame = self.defensivesFrames[i]

        if slot and slot.enabled then
            if slot.spellID and slot.spellID > 0 and C_SpellBook.IsSpellInSpellBook(slot.spellID) then
                local resolvedID = C_Spell.GetOverrideSpell(slot.spellID)
                local texture = C_Spell.GetSpellTexture(resolvedID)
                if texture then
                    frame.icon:SetTexture(texture)
                end
                local prev = self.defensivesSlotData[i]
                self.defensivesSlotData[i] = {
                    active = true,
                    spellID = resolvedID,
                    defensiveCurve = CreateDefensiveCurve(slot.healthPct or 50, slot.operator or "<"),
                    resource = slot.resource or "health",
                    glow = slot.glow or false,
                    dispelable = slot.dispelable or false,
                    buffDuration = slot.buffDuration or 0,
                    showWhen = slot.showWhen or "Always",
                    unit = slot.unit or "player",
                    lastCastTime = prev and prev.lastCastTime,
                    glowCastSuppressUntil = prev and prev.glowCastSuppressUntil,
                    buffCastSuppressUntil = prev and prev.buffCastSuppressUntil,
                }
            else
                frame.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
                frame.icon:SetVertexColor(1, 1, 1, 1)
                frame.iconColorAlpha = 1
                frame:SetAlpha(0.2)
                self.defensivesSlotData[i] = { active = false }
                frame.chargeCountText:Hide()
                frame.chargeCountBg:Hide()
            end
        else
            frame:SetAlpha(0)
            self.defensivesSlotData[i] = { active = false }
            frame.chargeCountText:Hide()
            frame.chargeCountBg:Hide()
        end
    end
end

function DefinitelyNotHekili:IsMounted()
    local isMounted = IsMounted()
    if not isMounted then
        local formID = GetShapeshiftFormID()
        if formID == 3 or formID == 27 then
            isMounted = true
        end
    end
    return isMounted
end

function DefinitelyNotHekili:ApplyClickBehavior()
    self:EnableMouse(not self.config.ignoreClicks)
end

function DefinitelyNotHekili:UpdateInterrupt()
    if not self.config.interruptEnabled then
        self.interruptFrame:SetAlpha(0)
        return
    end

    if not self.config.enabled or (self.config.hideWhenMounted and self:IsMounted()) then
        self.interruptFrame:SetAlpha(0.2)
        return
    end

    if not self.interruptSpellID or not UnitCanAttack("player", "target") then
        self.interruptFrame:SetAlpha(0.2)
        return
    end

    local active = false
    local notInterruptible = false
    local activeSpellID = nil

    local _, _, _, _, _, _, _, castNI, castSpellID = UnitCastingInfo("target")
    if castSpellID then
        active = true
        notInterruptible = castNI
        activeSpellID = castSpellID
    end

    if not active then
        local _, _, _, _, _, _, channelNI, channelSpellID = UnitChannelInfo("target")
        if channelSpellID then
            active = true
            notInterruptible = channelNI
            activeSpellID = channelSpellID
        end
    end

    if active then
        if not self:IsSpellInRange(self.interruptSpellID) then
            self.interruptFrame:SetAlpha(0.2)
            return
        end

        local cdDuration = C_Spell.GetSpellCooldownDuration(self.interruptSpellID)
        if cdDuration then
            local cdAlpha = cdDuration:EvaluateRemainingDuration(INTERRUPT_CD_READY_CURVE)
            self.interruptFrame:SetAlphaFromBoolean(notInterruptible, 0.2, cdAlpha)
        else
            self.interruptFrame:SetAlphaFromBoolean(notInterruptible, 0.2, 1)
        end
    else
        self.interruptFrame:SetAlpha(0.2)
    end
end

function DefinitelyNotHekili:UnitHasDispellableDebuff(unit)
    unit = unit or "player"
    if not UnitExists(unit) then return false end
    if not C_UnitAuras or not C_UnitAuras.GetAuraDataByIndex then return false end
    return C_UnitAuras.GetAuraDataByIndex(unit, 1, "HARMFUL|RAID_PLAYER_DISPELLABLE") ~= nil
end

function DefinitelyNotHekili:IsSpellGlowActive(spellID)
    if not spellID or not C_SpellActivationOverlay or not C_SpellActivationOverlay.IsSpellOverlayed then
        return false
    end

    return C_SpellActivationOverlay.IsSpellOverlayed(spellID)
end

function DefinitelyNotHekili:UpdateMainGlow(spellID)
    local active = spellID ~= nil and self:GetAlpha() > 0.5 and self:IsSpellGlowActive(spellID)
    addon.glow.Apply(self, active, self.config.glowStyle, self.renderScale or 1)
end

function DefinitelyNotHekili:IsPlayerCastingSpell(spellID)
    if not spellID then
        return false
    end

    local _, _, _, _, _, _, _, _, castSpellID = UnitCastingInfo("player")
    if castSpellID == spellID then
        return true
    end

    local _, _, _, _, _, _, _, channelSpellID = UnitChannelInfo("player")
    if channelSpellID == spellID then
        return true
    end

    local overrideCastID = castSpellID and C_Spell.GetOverrideSpell(castSpellID)
    if overrideCastID == spellID then
        return true
    end

    local overrideChannelID = channelSpellID and C_Spell.GetOverrideSpell(channelSpellID)
    return overrideChannelID == spellID
end

function DefinitelyNotHekili:UpdateDefensiveChargeCounter(frame, spellID)
    local info = spellID and C_Spell and C_Spell.GetSpellCharges and C_Spell.GetSpellCharges(spellID) or nil
    local maxCharges = info and info.maxCharges or 0
    if maxCharges > 1 then
        local scale = self.renderScale or 1
        frame.chargeCountText:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE * scale, addon.DEBUG_FONT_FLAGS)
        frame.chargeCountText:ClearAllPoints()
        frame.chargeCountText:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT",
            addon.DEBUG_RIGHT_FONT_X * scale, addon.DEBUG_BOTTOM_FONT_Y * scale)
        frame.chargeCountText:SetText(info.currentCharges)
        frame.chargeCountText:Show()
        if self.config.debug then
            frame.chargeCountBg:SetSize(addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale)
            frame.chargeCountBg:Show()
        else
            frame.chargeCountBg:Hide()
        end
    else
        frame.chargeCountText:Hide()
        frame.chargeCountBg:Hide()
    end
end

function DefinitelyNotHekili:UpdateDefensives()
    if not self.config.defensivesEnabled then
        for i = 1, self.config.maxDefensiveSlots do
            self.defensivesFrames[i]:SetAlpha(0)
            addon.glow.Stop(self.defensivesFrames[i])
        end
        return
    end

    if not self.config.enabled or (self.config.hideWhenMounted and self:IsMounted()) then
        for i = 1, self.config.maxDefensiveSlots do
            local data = self.defensivesSlotData[i]
            addon.glow.Stop(self.defensivesFrames[i])
            if data and data.active then
                self.defensivesFrames[i]:SetAlpha(0.2)
            end
        end
        return
    end

    for i = 1, self.config.maxDefensiveSlots do
        local data = self.defensivesSlotData[i]
        local frame = self.defensivesFrames[i]

        if data and data.active then
            self:UpdateDefensiveChargeCounter(frame, data.spellID)
            local unit = data.unit or "player"
            local conditionUnit = (unit == "mouseover") and "mouseover" or "target"
            local rangeUnit = (unit == "player") and "target" or unit
            local isUsable, notEnoughResource = self:IsSpellUsable(data.spellID)
            local showGlow = self:IsSpellGlowActive(data.spellID)
            
            if not UnitExists(unit) then
                frame:SetAlpha(0.2)
            elseif not ShouldShowForCondition(data.showWhen, conditionUnit) then
                frame:SetAlpha(0.2)
            elseif data.glow and not showGlow then
                frame:SetAlpha(0.2)
            elseif data.glow and self:IsPlayerCastingSpell(data.spellID) then
                data.glowCastSuppressUntil = GetTime() + 0.35
                frame:SetAlpha(0.2)
            elseif data.glowCastSuppressUntil and GetTime() < data.glowCastSuppressUntil then
                frame:SetAlpha(0.2)
            elseif data.dispelable and not self:UnitHasDispellableDebuff(unit) then
                frame:SetAlpha(0.2)
            elseif data.buffDuration > 0 and data.lastCastTime and (GetTime() - data.lastCastTime) < data.buffDuration then
                frame:SetAlpha(0.2)
            elseif data.buffDuration > 0 and self:IsPlayerCastingSpell(data.spellID) then
                data.buffCastSuppressUntil = GetTime() + 0.35
                frame:SetAlpha(0.2)
            elseif data.buffCastSuppressUntil and GetTime() < data.buffCastSuppressUntil then
                frame:SetAlpha(0.2)
            elseif not isUsable or notEnoughResource then
                frame:SetAlpha(0.2)
            elseif self.config.rangeCheck and not self:IsSpellInRange(data.spellID, rangeUnit) then
                frame:SetAlpha(0.2)
            else
                local r, g, b, a = GetDefensiveSlotColor(unit, data):GetRGBA()
                frame.icon:SetVertexColor(r, g, b, a)
                frame.iconColorAlpha = a

                local cdDuration = C_Spell.GetSpellCooldownDuration(data.spellID, true)
                if cdDuration then
                    frame:SetAlpha(cdDuration:EvaluateRemainingDuration(DEFENSIVES_CD_READY_CURVE))
                else
                    frame:SetAlpha(1)
                end
            end

            addon.glow.Apply(frame, showGlow, self.config.glowStyle, self.renderScale or 1)
        else
            addon.glow.Stop(frame)
        end
    end
end

function DefinitelyNotHekili:UpdateDefensivesDebugOverlay()
    local scale = self.renderScale or 1
    local powers = GetCurrentSpecPowers()
    local debug = self.config.debug
    local playerDeadOrGhost = UnitIsDeadOrGhost("player")

    for i = 1, self.config.maxDefensiveSlots do
        local frame = self.defensivesFrames[i]
        local data = self.defensivesSlotData[i]

        local showTopLeft, topLeftValue = false, 0
        if debug then
            if i == 1 then
                showTopLeft = true
                if not playerDeadOrGhost then
                    topLeftValue = UnitHealthPercent("player", false, addon.PERCENT_CURVE)
                end
            else
                local pt = powers[i - 1]
                if pt then
                    showTopLeft = true
                    topLeftValue = GetResourcePercent(pt)
                end
            end
        end
        if showTopLeft then
            frame.dbgResourceBg:SetSize(addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale)
            frame.dbgResourceBg:Show()
            frame.dbgResourceText:SetFont(addon.DEBUG_FONT_FILE,
                addon.DEBUG_FONT_SIZE * scale, addon.DEBUG_FONT_FLAGS)
            frame.dbgResourceText:ClearAllPoints()
            frame.dbgResourceText:SetPoint("TOPLEFT", frame, "TOPLEFT",
                addon.DEBUG_LEFT_FONT_X * scale, addon.DEBUG_TOP_FONT_Y * scale)
            frame.dbgResourceText:SetFormattedText("%d", topLeftValue)
            frame.dbgResourceText:Show()
        else
            frame.dbgResourceBg:Hide()
            frame.dbgResourceText:Hide()
        end

        local showCd, cdValue, offGCD = false, 0, false
        if debug and data and data.active and data.spellID and data.spellID ~= 0 then
            showCd = true
            offGCD = self:IsSpellOffGCD(data.spellID)

            local charges = C_Spell.GetSpellCharges(data.spellID)
            local maxCharges = charges and charges.maxCharges or 0
            local cdDur
            if maxCharges > 1 then
                cdDur = C_Spell.GetSpellChargeDuration(data.spellID, true)
            else
                cdDur = C_Spell.GetSpellCooldownDuration(data.spellID, true)
            end
            if cdDur then
                cdValue = cdDur:EvaluateRemainingPercent(addon.PERCENT_CURVE)
            end
        end
        if showCd then
            frame.dbgCooldownBg:SetSize(addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale)
            frame.dbgCooldownBg:Show()
            frame.dbgCooldownText:SetFont(addon.DEBUG_FONT_FILE,
                addon.DEBUG_FONT_SIZE * scale, addon.DEBUG_FONT_FLAGS)
            frame.dbgCooldownText:ClearAllPoints()
            frame.dbgCooldownText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT",
                addon.DEBUG_LEFT_FONT_X * scale, addon.DEBUG_BOTTOM_FONT_Y * scale)
            frame.dbgCooldownText:SetFormattedText("%d", cdValue)
            if offGCD then
                frame.dbgCooldownText:SetTextColor(1, 1, 1, 1)
            else
                frame.dbgCooldownText:SetTextColor(1, 1, 1, 1)
            end
            frame.dbgCooldownText:Show()
        else
            frame.dbgCooldownBg:Hide()
            frame.dbgCooldownText:Hide()
        end
    end
end

function DefinitelyNotHekili:EnsureOverlay()
    self.overlay:SetFrameStrata(self.config.strata)
    self.overlay:SetFrameLevel(self.cooldown:GetFrameLevel() + 5)
    self.overlay:SetAlpha(1)
    self.overlay:Show()
end

function DefinitelyNotHekili:UpdateDebugOverlay()
    if not self.config.debug then
        self.dbgPctBg:Hide()
        self.dbgPctText:Hide()
        self.dbgTargetHpBg:Hide()
        self.dbgTargetHpText:Hide()
        for _, px in pairs(self.dbgBoundsMarkers) do
            px:Hide()
        end
        return
    end

    self:EnsureOverlay()
    local scale = self.renderScale or 1

    local boundsMarkerSize = addon.DEBUG_BOUNDS_MARKER_SIZE * scale
    local bgW, bgH = addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale
    for i, m in ipairs(BOUNDS_MARKERS) do
        local px = self.dbgBoundsMarkers[i]
        px:SetSize(boundsMarkerSize, boundsMarkerSize)
        px:ClearAllPoints()
        px:SetPoint(m[1], self, m[1], m[2] * bgW, m[3] * bgH)
        px:SetAlpha(1)
        px:Show()
    end

    self.dbgPctBg:SetSize(addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale)
    self.dbgPctBg:SetAlpha(1)
    self.dbgPctBg:Show()

    self.dbgPctText:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE * scale, addon.DEBUG_FONT_FLAGS)
    self.dbgPctText:ClearAllPoints()
    self.dbgPctText:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT",
        addon.DEBUG_LEFT_FONT_X * scale, addon.DEBUG_BOTTOM_FONT_Y * scale)
    self.dbgPctText:SetAlpha(1)
    self.dbgPctText:Show()

    local now = GetTime()
    local castPct, channelPct, gcdPct = 0, 0, 0

    local _, _, _, castStartMS, castEndMS = UnitCastingInfo("player")
    if castStartMS and castEndMS and castEndMS > castStartMS then
        local total = (castEndMS - castStartMS) / 1000
        local remaining = castEndMS / 1000 - now
        if remaining > 0 then castPct = remaining / total * 100 end
    end

    if self.config.channelCheck then
        local _, _, _, chStartMS, chEndMS = UnitChannelInfo("player")
        if chStartMS and chEndMS and chEndMS > chStartMS then
            local total = (chEndMS - chStartMS) / 1000
            local remaining = chEndMS / 1000 - now
            if remaining > 0 then channelPct = remaining / total * 100 end
        end
    end

    local gcdInfo = C_Spell.GetSpellCooldown(61304)
    if gcdInfo and gcdInfo.duration and gcdInfo.duration > 0 then
        local remaining = gcdInfo.startTime + gcdInfo.duration - now
        if remaining > 0 then gcdPct = remaining / gcdInfo.duration * 100 end
    end

    self.dbgPctText:SetFormattedText("%d", math.max(castPct, channelPct, gcdPct))

    self.dbgTargetHpBg:SetSize(addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale)
    self.dbgTargetHpBg:SetAlpha(1)
    self.dbgTargetHpBg:Show()

    self.dbgTargetHpText:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE * scale, addon.DEBUG_FONT_FLAGS)
    self.dbgTargetHpText:ClearAllPoints()
    self.dbgTargetHpText:SetPoint("TOPLEFT", self, "TOPLEFT",
        addon.DEBUG_LEFT_FONT_X * scale, addon.DEBUG_TOP_FONT_Y * scale)
    self.dbgTargetHpText:SetAlpha(1)
    self.dbgTargetHpText:Show()

    if UnitExists("target") then
        self.dbgTargetHpText:SetFormattedText("%d", UnitHealthPercent("target", false, addon.PERCENT_CURVE))
    else
        self.dbgTargetHpText:SetText("0")
    end
end

function DefinitelyNotHekili:ApplyNameplateCVars()
    SetCVar("nameplateMaxDistance", 41)
    SetCVar("nameplateShowAll", "1")
    if GetCVar("nameplateShowEnemies") == "0" then
        SetCVar("nameplateShowEnemies", "1")
    end
    if GetCVar("nameplateShowFriends") == "1" then
        SetCVar("nameplateShowFriends", "0")
    end
end

function DefinitelyNotHekili:UpdateNameplateCounter()
    if not self:GetAdvancedOption("nameplateCounterEnabled") then
        self.nameplateCountText:Hide()
        self.nameplateCountBg:Hide()
        return
    end

    self:EnsureOverlay()
    local scale = self.renderScale or 1
    local threshold = self:GetAdvancedOption("nameplateCounterRange") or 30

    self.nameplateCountText:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE * scale, addon.DEBUG_FONT_FLAGS)
    self.nameplateCountText:ClearAllPoints()
    self.nameplateCountText:SetPoint("TOPRIGHT", self, "TOPRIGHT",
        addon.DEBUG_RIGHT_FONT_X * scale, addon.DEBUG_TOP_FONT_Y * scale)
    self.nameplateCountText:SetAlpha(1)
    self.nameplateCountText:Show()

    if self.config.debug then
        self.nameplateCountBg:SetSize(addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale)
        self.nameplateCountBg:SetAlpha(1)
        self.nameplateCountBg:Show()
    else
        self.nameplateCountBg:Hide()
    end

    local combatOnly = self:GetAdvancedOption("nameplateCounterCombatOnly")
    local count = 0
    if addon.range and addon.range.GetRange then
        for i = 1, 40 do
            local unit = "nameplate" .. i
            if UnitExists(unit) and not UnitIsDead(unit) and UnitCanAttack("player", unit)
               and (not combatOnly or UnitAffectingCombat(unit)) then
                local r = addon.range.GetRange("player", unit) or 99
                if r <= threshold then
                    count = count + 1
                end
            end
        end
    end

    self.nameplateCountText:SetText(count)
end

function DefinitelyNotHekili:UpdateTargetRange()
    if not self.config.targetRangeEnabled then
        self.targetRangeText:Hide()
        self.targetRangeBg:Hide()
        return
    end

    self:EnsureOverlay()
    local scale = self.renderScale or 1

    self.targetRangeText:SetFont(addon.DEBUG_FONT_FILE, addon.DEBUG_FONT_SIZE * scale, addon.DEBUG_FONT_FLAGS)
    self.targetRangeText:ClearAllPoints()
    self.targetRangeText:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT",
        addon.DEBUG_RIGHT_FONT_X * scale, addon.DEBUG_BOTTOM_FONT_Y * scale)
    self.targetRangeText:SetAlpha(1)
    self.targetRangeText:Show()

    if self.config.debug then
        self.targetRangeBg:SetSize(addon.DEBUG_BG_W * scale, addon.DEBUG_BG_H * scale)
        self.targetRangeBg:SetAlpha(1)
        self.targetRangeBg:Show()
    else
        self.targetRangeBg:Hide()
    end

    local distance = 0
    if addon.range and addon.range.GetTargetRange then
        distance = addon.range.GetTargetRange() or 0
        if distance == 0 and UnitExists("target") and not UnitIsDead("target")
           and UnitCanAttack("player", "target") then
            distance = 1
        end
    end

    self.targetRangeText:SetText(distance)
end

function DefinitelyNotHekili:OnUpdate()
    if self.isDragging then return end

    local spellID = self:GetNextSpell()

    self:UpdateSpellTexture(spellID)
    self:UpdateCooldown(spellID)
    self:UpdateVisibility()
    self:UpdateMainGlow(spellID)
    self:UpdateIconColor(spellID)
    self:UpdateResourcePooling(spellID)
    self:UpdateInterrupt()
    self:UpdateDefensives()
    self:UpdateDefensivesDebugOverlay()
    self:UpdatePosition()
end

function DefinitelyNotHekili:RegisterSlashCommands()

    SLASH_BETTERASSISTANT1 = "/ba"
    SLASH_BETTERASSISTANT2 = "/betterassistant"
    
    SlashCmdList["BETTERASSISTANT"] = function(msg)
        if msg == "" then
            addon:UpdateSettingsFrame()
            addon.settingsFrame:Show()
            return
        end
        
        if msg == "reset" then
            for k, v in pairs(defaultConfig) do
                self.config[k] = v
            end
            addon:UpdateSettingsFrame()
            print("|cff00ff00[BetterAssistant]|r Config reset to defaults!")
            return
        end

        if msg == "hardreset" then
            for k, v in pairs(defaultConfig) do
                self.config[k] = v
            end
            self.config.defensivesSpells = nil
            self:DetectDefensivesSpells()
            addon:UpdateSettingsFrame()
            print("|cff00ff00[BetterAssistant]|r Full config reset!")
            return
        end

        if msg == "keycodes" then
            addon.keybinds.DumpKeyCodes()
            return
        end

        local debugArg = msg:match("^debug%s*(%S*)$")
        if debugArg then
            if debugArg == "on" then
                self.config.debug = true
            elseif debugArg == "off" then
                self.config.debug = false
            else
                self.config.debug = not self.config.debug
            end
            print(string.format("|cff00ff00[BetterAssistant]|r debug: %s",
                self.config.debug and "ON" or "OFF"))
            return
        end

        local npArg = msg:match("^np%s*(%S*)$")
        if npArg then
            local cur = self:GetAdvancedOption("nameplateCounterEnabled")
            local newVal
            if npArg == "on" then
                newVal = true
            elseif npArg == "off" then
                newVal = false
            else
                newVal = not cur
            end
            self:SetAdvancedOption("nameplateCounterEnabled", newVal)
            if newVal then
                self:ApplyNameplateCVars()
            end
            if addon.settingsFrame and addon.settingsFrame.nameplateCounterCB then
                addon.settingsFrame.nameplateCounterCB:SetChecked(newVal)
            end
            print(string.format("|cff00ff00[BetterAssistant]|r nameplate counter: %s",
                newVal and "ON" or "OFF"))
            return
        end

        local cdmSize = msg:match("^cdm%s+size%s+(%d+)$")
        if cdmSize then
            addon.cdm.EnsureConfig(self)
            local val = math.max(16, math.min(128, tonumber(cdmSize)))
            self.config.cdm.iconSize = val
            if addon.settingsFrame and addon.settingsFrame.cdmIconSize then
                addon.settingsFrame.cdmIconSize:SetText(tostring(val))
                addon.settingsFrame.cdmIconSize:SetCursorPosition(0)
            end
            print(string.format("|cff00ff00[BetterAssistant]|r CDM icon size: %d", val))
            return
        end

        local setArgs = msg:match("^set%s+(.+)$")
        if setArgs then
            local function SetByPath(root, path, value)
                local parts = {}
                for p in string.gmatch(path, "[^.]+") do
                    table.insert(parts, p)
                end
                if #parts == 0 then return nil, "empty path" end
                local cur = root
                for i = 1, #parts - 1 do
                    local k = parts[i]
                    if type(cur[k]) ~= "table" then
                        return nil, "no such path"
                    end
                    cur = cur[k]
                end
                local key = parts[#parts]
                local old = cur[key]
                local oldType = type(old)
                if oldType == "boolean" then
                    if value == "1" or value == "true" or value == "on" then
                        cur[key] = true
                    elseif value == "0" or value == "false" or value == "off" then
                        cur[key] = false
                    else
                        return nil, "expected 1/0/true/false/on/off"
                    end
                elseif oldType == "number" then
                    local n = tonumber(value)
                    if not n then return nil, "expected number" end
                    cur[key] = n
                elseif oldType == "string" then
                    cur[key] = value
                elseif old == nil then
                    cur[key] = tonumber(value) or value
                else
                    return nil, "unsupported field type " .. oldType
                end
                return cur[key]
            end

            addon.cdm.EnsureConfig(self)

            local tokens = {}
            for t in setArgs:gmatch("%S+") do
                table.insert(tokens, t)
            end
            if #tokens == 0 or #tokens % 2 ~= 0 then
                print("|cffff8080[BetterAssistant]|r set: нужны пары key value")
                return
            end

            local maxDefensiveSlotsChanged = false
            for i = 1, #tokens, 2 do
                local key = tokens[i]:gsub("^cfg%.", "")
                local value = tokens[i + 1]
                local applied, err = SetByPath(self.config, key, value)
                if applied == nil then
                    print(string.format("|cffff8080[BetterAssistant]|r %s: %s",
                        key, err or "set failed"))
                else
                    print(string.format("|cff00ff00[BetterAssistant]|r set %s = %s",
                        key, tostring(applied)))
                    if key == "maxDefensiveSlots" then
                        maxDefensiveSlotsChanged = true
                    end
                end
            end

            if maxDefensiveSlotsChanged then
                self:EnsureDefensiveFramePool(self.config.maxDefensiveSlots)
                if addon.settingsFrame and addon.settingsFrame.EnsureDefensiveSlotRows then
                    addon.settingsFrame.EnsureDefensiveSlotRows(self.config.maxDefensiveSlots)
                end
                self:UpdatePosition()
                self:DetectDefensivesSpells()
            end

            self:ClampPosition()
            addon:UpdateSettingsFrame()
            return
        end

        local defSlot = msg:match("^toggle%s+defensive%s+(%d+)$")
        if defSlot then
            local idx = tonumber(defSlot)
            local slots = self:GetOrCreateSpecSlots()
            if slots and idx >= 1 and idx <= self.config.maxDefensiveSlots and slots[idx] then
                slots[idx].enabled = not slots[idx].enabled
                self:DetectDefensivesSpells()
                if not self.config.silentMode then
                    print(string.format(
                        "|cff00ff00[BetterAssistant]|r Defensive slot %d: %s",
                        idx,
                        slots[idx].enabled and "ON" or "OFF"
                    ))
                end
            end
            return
        end

        local toggleArg = msg:match("^toggle%s+(%S+)$")
        if toggleArg and self.config[toggleArg] ~= nil and type(self.config[toggleArg]) == "boolean" then

            self.config[toggleArg] = not self.config[toggleArg]

            if not self.config.silentMode then
                print(string.format(
                    "|cff00ff00[BetterAssistant]|r %s: %s",
                    toggleArg,
                    self.config[toggleArg] and "ON" or "OFF"
                ))
            end

            return
        end
    end
end	
    
DefinitelyNotHekili:SetScript("OnEvent", function(self, event, ...)
    if event == "SPELLS_CHANGED" then
        self:DetectInterruptSpell()
        self:DetectDefensivesSpells()
        return
    elseif event == "UNIT_PET" then
        local unit = ...
        if unit == "player" then
            self:DetectInterruptSpell()
        end
        return
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
        self:InvalidateSpellRangeCache()
        self:DetectDefensivesSpells()
        return
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        local unit, _, spellID = ...
        if unit == "player" then
            local overrideID = C_Spell.GetOverrideSpell(spellID)
            for i = 1, self.config.maxDefensiveSlots do
                local data = self.defensivesSlotData[i]
                if data and data.active and data.buffDuration > 0
                   and (data.spellID == spellID or data.spellID == overrideID) then
                    data.lastCastTime = GetTime()
                end
            end
        end
        return
    elseif event == "PLAYER_STARTED_MOVING" then
        self.isMoving = true
        return
    elseif event == "PLAYER_STOPPED_MOVING" then
        self.isMoving = false
        return
    end

    local loadedAddonName = ...
    if event ~= "ADDON_LOADED" or loadedAddonName ~= addonName then return end
    
    if type(BetterAssistantDB) ~= "table" then
        BetterAssistantDB = {}
    end
    self.config = BetterAssistantDB

    for k, v in pairs(defaultConfig) do
        if self.config[k] == nil then
            self.config[k] = v
        end
    end

    self:EnsureDefensiveFramePool(self.config.maxDefensiveSlots)

    self:ApplyClickBehavior()

    self:RegisterEvent("SPELLS_CHANGED")
    self:RegisterEvent("UNIT_PET")
    self:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
    self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
    self:RegisterEvent("PLAYER_STARTED_MOVING")
    self:RegisterEvent("PLAYER_STOPPED_MOVING")

    self:DetectInterruptSpell()
    self:DetectDefensivesSpells()
    addon.cdm.Init(self)
    addon.keybinds.Init(self)
    addon.range.Init(true)

    if self:GetAdvancedOption("nameplateCounterEnabled") then
        self:ApplyNameplateCVars()
    end

    addon.core = self
    addon.settingsFrame = addon:CreateSettingsFrame()
    
    self:SetScript("OnUpdate", self.OnUpdate)
    
    self:SetScript("OnDragStart", function(self)
        if not self.isConfiguring and IsShiftKeyDown() then
            self.isDragging = true
            self:StartMoving()
        end
    end)

    self:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        
        local centerX, centerY = self:GetCenter()
        local screenWidth = GetScreenWidth()
        local screenHeight = GetScreenHeight()
        local offsetX = centerX - (screenWidth / 2)
        local offsetY = centerY - (screenHeight / 2)

        if self.config.trueScale then
            local scale = 768 / select(2, GetPhysicalScreenSize()) / UIParent:GetScale()
            self.config.X = offsetX / scale
            self.config.Y = offsetY / scale
        else
            self.config.X = offsetX
            self.config.Y = offsetY
        end
        
        self:ClampPosition()
        self.isDragging = false
    end)
    
    self:SetScript("OnMouseUp", function(self, button)
        if button == "RightButton" and IsShiftKeyDown() then
            addon:UpdateSettingsFrame()
            addon.settingsFrame:Show()
        end
    end)
    
    self:RegisterSlashCommands()
    self:ClearAllPoints()
    self:Show()                    
end)
