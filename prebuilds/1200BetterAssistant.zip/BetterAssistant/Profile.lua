local addonName, addon = ...

local Profile = {}
addon.Profile = Profile

local PREFIX = "BA1"


local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

local b64dec = {}
for i = 1, #B64 do
    b64dec[B64:sub(i, i)] = i - 1
end

local function base64encode(data)
    local result = {}
    local len = #data
    local i = 1
    while i <= len do
        local b1 = string.byte(data, i)
        local b2 = string.byte(data, i + 1)
        local b3 = string.byte(data, i + 2)
        local n = b1 * 65536 + (b2 or 0) * 256 + (b3 or 0)
        local c1 = math.floor(n / 262144) % 64
        local c2 = math.floor(n / 4096) % 64
        local c3 = math.floor(n / 64) % 64
        local c4 = n % 64
        result[#result + 1] = B64:sub(c1 + 1, c1 + 1)
        result[#result + 1] = B64:sub(c2 + 1, c2 + 1)
        result[#result + 1] = b2 and B64:sub(c3 + 1, c3 + 1) or "="
        result[#result + 1] = b3 and B64:sub(c4 + 1, c4 + 1) or "="
        i = i + 3
    end
    return table.concat(result)
end

local function base64decode(data)
    data = data:gsub("%s", "")
    if data == "" or data:find("[^A-Za-z0-9+/=]") then
        return nil
    end
    local result = {}
    local len = #data
    local i = 1
    while i <= len do
        local s1 = data:sub(i, i)
        local s2 = data:sub(i + 1, i + 1)
        local s3 = data:sub(i + 2, i + 2)
        local s4 = data:sub(i + 3, i + 3)
        local c1 = b64dec[s1]
        local c2 = b64dec[s2]
        if c1 == nil or c2 == nil then return nil end
        local hasC3 = (s3 ~= "" and s3 ~= "=")
        local hasC4 = (s4 ~= "" and s4 ~= "=")
        local c3 = hasC3 and b64dec[s3] or 0
        local c4 = hasC4 and b64dec[s4] or 0
        local n = c1 * 262144 + c2 * 4096 + c3 * 64 + c4
        result[#result + 1] = string.char(math.floor(n / 65536) % 256)
        if hasC3 then result[#result + 1] = string.char(math.floor(n / 256) % 256) end
        if hasC4 then result[#result + 1] = string.char(n % 256) end
        i = i + 4
    end
    return table.concat(result)
end


local function checksum(str)
    local sum = 0
    for i = 1, #str do
        sum = (sum * 31 + string.byte(str, i)) % 1000000007
    end
    return sum
end

local function isInList(list, value)
    if not list then return false end
    for _, v in ipairs(list) do
        if v == value then return true end
    end
    return false
end

local ADV_BOOL = {
    movingOverrideEnabled = true,
    nameplateCounterEnabled = true,
    nameplateCounterCombatOnly = true,
}

local function splitFields(str, sep)
    local out = {}
    for field in (str .. sep):gmatch("(.-)" .. sep) do
        out[#out + 1] = field
    end
    return out
end


local function serializeSlot(s)
    return table.concat({
        tostring(math.floor(tonumber(s.spellID) or 0)),
        tostring(math.floor(tonumber(s.healthPct) or 0)),
        s.enabled and "1" or "0",
        tostring(math.floor(tonumber(s.buffDuration) or 0)),
        tostring(s.showWhen or "Always"),
        tostring(s.unit or "player"),
        tostring(s.resource or "health"),
        tostring(s.operator or "<"),
        s.glow and "1" or "0",
        s.dispelable and "1" or "0",
    }, ",")
end

local function serializeAdvanced(core)
    local out = {}
    for idx, key in ipairs(addon.advancedOptionKeys) do
        local v = core:GetAdvancedOption(key)
        if ADV_BOOL[key] then
            out[idx] = v and "1" or "0"
        else
            out[idx] = tostring(math.floor(tonumber(v) or 0))
        end
    end
    return table.concat(out, ",")
end

local function serializeSpellRangeRow(e)
    return table.concat({
        tostring(math.floor(tonumber(e.spellID) or 0)),
        tostring(math.floor(tonumber(e.distance) or 0)),
    }, ",")
end

local function parseSlot(str)
    local f = splitFields(str, ",")
    if #f ~= 10 then return nil, "Corrupt defensive slot." end

    local spellID = tonumber(f[1])
    local healthPct = tonumber(f[2])
    local buffDuration = tonumber(f[4])
    local showWhen, unit, resource, operator = f[5], f[6], f[7], f[8]

    if not spellID or spellID < 0 then return nil, "Corrupt spellID." end
    if not healthPct or healthPct < 0 or healthPct > 100 then return nil, "Corrupt healthPct." end
    if not buffDuration or buffDuration < 0 then return nil, "Corrupt buffDuration." end
    if not isInList(addon.showWhenOptions, showWhen) then return nil, "Corrupt showWhen value." end
    if not isInList(addon.unitOptions, unit) then return nil, "Corrupt unit value." end
    if not isInList(addon.operatorOptions, operator) then return nil, "Corrupt operator value." end
    if resource == "" then return nil, "Corrupt resource value." end

    return {
        spellID = math.floor(spellID),
        healthPct = math.floor(healthPct),
        enabled = (f[3] == "1"),
        buffDuration = math.floor(buffDuration),
        showWhen = showWhen,
        unit = unit,
        resource = resource,
        operator = operator,
        glow = (f[9] == "1"),
        dispelable = (f[10] == "1"),
    }
end

local function parseAdvanced(str)
    local vals = splitFields(str, ",")
    local keys = addon.advancedOptionKeys
    if #vals ~= #keys then return nil, "Corrupt Advanced settings." end

    local out = {}
    for idx, key in ipairs(keys) do
        local raw = vals[idx]
        if ADV_BOOL[key] then
            out[key] = (raw == "1")
        else
            local n = tonumber(raw)
            if not n then return nil, "Corrupt Advanced option: " .. key end
            out[key] = n
        end
    end
    return out
end

local function parseSpellRangeRow(str)
    local f = splitFields(str, ",")
    if #f ~= 2 then return nil, "Corrupt spell range row." end
    local spellID = tonumber(f[1])
    local distance = tonumber(f[2])
    if not spellID or spellID < 0 then return nil, "Corrupt spell range spellID." end
    if not distance or distance <= 0 then return nil, "Corrupt spell range distance." end
    return { spellID = math.floor(spellID), distance = math.floor(distance) }
end


function Profile.Export(core)
    local specKey = core:GetSpecKey()
    if not specKey then return nil, "No active specialization." end

    local slots = core:GetOrCreateSpecSlots()
    if not slots then return nil, "Could not read defensive slots." end

    local parts = { "v4", specKey, tostring(#slots) }
    for i = 1, #slots do
        parts[#parts + 1] = serializeSlot(slots[i])
    end
    parts[#parts + 1] = serializeAdvanced(core)

    local rangeList = core:GetOrCreateSpecRangeList() or {}
    parts[#parts + 1] = tostring(#rangeList)
    for i = 1, #rangeList do
        parts[#parts + 1] = serializeSpellRangeRow(rangeList[i])
    end

    local auraIDs = {}
    local cdmCfg = core.config.cdm
    if cdmCfg and type(cdmCfg.auras) == "table" and type(cdmCfg.auras[specKey]) == "table" then
        local maxAuras = addon.cdm.GetMaxAuras(core)
        for _, raw in ipairs(cdmCfg.auras[specKey]) do
            local id, learned = addon.cdm.ReadAuraEntry(raw)
            if id and #auraIDs < maxAuras then
                auraIDs[#auraIDs + 1] = tostring(id) .. "," .. (learned and "1" or "0")
            end
        end
    end
    parts[#parts + 1] = tostring(#auraIDs)
    for i = 1, #auraIDs do
        parts[#parts + 1] = auraIDs[i]
    end

    local dataStr = table.concat(parts, "|")
    local payload = tostring(checksum(dataStr)) .. "|" .. dataStr
    return PREFIX .. base64encode(payload)
end

function Profile.Decode(str)
    if type(str) ~= "string" then return nil, "Empty string." end
    str = str:gsub("^%s+", ""):gsub("%s+$", "")
    if str == "" then return nil, "Empty string." end
    if str:sub(1, #PREFIX) ~= PREFIX then
        return nil, "Invalid string format (missing BA1 prefix)."
    end

    local payload = base64decode(str:sub(#PREFIX + 1))
    if not payload then return nil, "Corrupt string (base64 error)." end

    local sep = payload:find("|", 1, true)
    if not sep then return nil, "Corrupt string." end

    local expected = tonumber(payload:sub(1, sep - 1))
    local dataStr = payload:sub(sep + 1)
    if not expected or checksum(dataStr) ~= expected then
        return nil, "Checksum mismatch - string is corrupt."
    end

    local tokens = splitFields(dataStr, "|")
    local version = tokens[1]
    if version ~= "v1" and version ~= "v2" and version ~= "v3" and version ~= "v4" then
        return nil, "Unsupported profile version."
    end

    local specKey = tokens[2]
    if not specKey or not specKey:match("^%d+%-%d+$") then
        return nil, "Corrupt spec key."
    end

    local numSlots = tonumber(tokens[3])
    if not numSlots or numSlots < 0 or numSlots > 50 then
        return nil, "Corrupt slot count."
    end

    local advIndex = 3 + numSlots + 1
    if #tokens < advIndex then
        return nil, "Corrupt profile structure."
    end

    local slots = {}
    for i = 1, numSlots do
        local slot, err = parseSlot(tokens[3 + i])
        if not slot then return nil, err end
        slots[i] = slot
    end

    local advanced, aerr = parseAdvanced(tokens[advIndex])
    if not advanced then return nil, aerr end

    local spellRange = nil
    local auras = nil
    if version == "v1" then
        if #tokens ~= advIndex then
            return nil, "Corrupt profile structure."
        end
    else
        local countIndex = advIndex + 1
        local numRange = tonumber(tokens[countIndex])
        if not numRange or numRange < 0 or numRange > 100 then
            return nil, "Corrupt spell range count."
        end
        local rangeEnd = countIndex + numRange

        if version == "v2" then
            if #tokens ~= rangeEnd then
                return nil, "Corrupt profile structure."
            end
        else
            local auraCountIndex = rangeEnd + 1
            if #tokens < auraCountIndex then
                return nil, "Corrupt profile structure."
            end
            local numAuras = tonumber(tokens[auraCountIndex])
            if not numAuras or numAuras < 0 or numAuras > 24 then
                return nil, "Corrupt aura count."
            end
            if #tokens ~= auraCountIndex + numAuras then
                return nil, "Corrupt profile structure."
            end
            auras = {}
            for i = 1, numAuras do
                local fields = splitFields(tokens[auraCountIndex + i], ",")
                local id = tonumber(fields[1])
                if not id or id <= 0 or id ~= math.floor(id) then
                    return nil, "Corrupt aura spell ID."
                end
                if fields[2] and fields[2] ~= "0" and fields[2] ~= "1" then
                    return nil, "Corrupt aura mode."
                end
                auras[i] = { id = id, learned = fields[2] == "1" }
            end
        end

        spellRange = {}
        for i = 1, numRange do
            local row, rerr = parseSpellRangeRow(tokens[countIndex + i])
            if not row then return nil, rerr end
            spellRange[i] = row
        end
    end

    return { specKey = specKey, slots = slots, advanced = advanced, spellRange = spellRange, auras = auras }
end

function Profile.Apply(core, data)
    local specKey = data.specKey
    local config = core.config

    if not config.defensivesSpells then config.defensivesSpells = {} end
    if not config.advanced then config.advanced = {} end

    local newSlots = {}
    for i, s in ipairs(data.slots) do
        newSlots[i] = {
            spellID = s.spellID,
            healthPct = s.healthPct,
            enabled = s.enabled,
            buffDuration = s.buffDuration,
            showWhen = s.showWhen,
            unit = s.unit,
            resource = s.resource,
            operator = s.operator,
            glow = s.glow,
            dispelable = s.dispelable,
        }
    end
    config.defensivesSpells[specKey] = newSlots

    local adv = {}
    for _, key in ipairs(addon.advancedOptionKeys) do
        adv[key] = data.advanced[key]
    end
    config.advanced[specKey] = adv

    if data.spellRange then
        if not config.spellRange then config.spellRange = {} end
        local newRange = {}
        for i, e in ipairs(data.spellRange) do
            newRange[i] = { spellID = e.spellID, distance = e.distance }
        end
        config.spellRange[specKey] = newRange
        if core.InvalidateSpellRangeCache then
            core:InvalidateSpellRangeCache()
        end
    end

    if data.auras then
        if type(config.cdm) ~= "table" then config.cdm = {} end
        if type(config.cdm.auras) ~= "table" then config.cdm.auras = {} end
        local maxAuras = addon.cdm.GetMaxAuras(core)
        local newAuras = {}
        for i = 1, math.min(#data.auras, maxAuras) do
            local e = data.auras[i]
            newAuras[#newAuras + 1] = addon.cdm.MakeAuraEntry(e.id, e.learned)
        end
        config.cdm.auras[specKey] = newAuras
        if addon.cdm and addon.cdm.QueueRebuild then
            addon.cdm.QueueRebuild()
        end
    end

    return specKey
end

function Profile.DescribeSpec(specKey)
    local classIDStr, specIDStr = specKey:match("^(%d+)%-(%d+)$")
    local classID = tonumber(classIDStr)
    local specID = tonumber(specIDStr)

    local specName, className
    if specID then
        local _, name = GetSpecializationInfoByID(specID)
        specName = name
    end
    if classID then
        className = GetClassInfo(classID)
    end

    if specName and className then
        return specName .. " " .. className
    end
    return specName or className or specKey
end
