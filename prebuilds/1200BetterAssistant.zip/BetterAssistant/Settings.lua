local addonName, addon = ...

addon.showWhenOptions = {
    "Always",
    "HasTarget",
    "InCombat",
    "TargetInCombat"
}

addon.unitOptions = {
    "player",
    "pet",
    "mouseover",
}

addon.operatorOptions = { "<", ">", "=", "<=", ">=" }

addon.strataOptions = {
    "BACKGROUND",
    "LOW",
    "MEDIUM",
    "HIGH",
    "DIALOG",
    "FULLSCREEN",
    "FULLSCREEN_DIALOG",
    "TOOLTIP"
}

addon.glowStyleOptions = {
    "ActionBar",
    "AutoCast",
    "SimpleBorder",
    "Off",
}

local SIDEBAR_WIDTH = 130
local CONTENT_WIDTH = 350
local FRAME_HEIGHT = 420
local BUTTON_HEIGHT = 24

local function CreateSidebarButton(parent, text, onClick)
    local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    btn:SetSize(SIDEBAR_WIDTH - 24, BUTTON_HEIGHT)
    btn:SetText(text)
    btn:SetScript("OnClick", onClick)
    return btn
end

local function CreatePage(parent)
    local page = CreateFrame("Frame", nil, parent)
    page:SetPoint("TOPLEFT", SIDEBAR_WIDTH, -12)
    page:SetPoint("BOTTOMRIGHT", -8, 8)
    page:Hide()
    return page
end

local function ShowPage(frame, index)
    for i, page in ipairs(frame.pages) do
        page:SetShown(i == index)
        local btn = frame.sidebarButtons[i]
        btn:SetEnabled(i ~= index)
    end
end


local function CreateGeneralPage(frame, core)
    local page = CreatePage(frame)

    local scrollFrame = CreateFrame("ScrollFrame", nil, page, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 0, 0)
    scrollFrame:SetPoint("BOTTOMRIGHT", -28, 0)

    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetWidth(CONTENT_WIDTH - 40)
    scrollChild:SetHeight(500)
    scrollFrame:SetScrollChild(scrollChild)

    local labelX = 12
    local boxX = 192

    local xText = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    xText:SetPoint("TOPLEFT", labelX, -15)
    xText:SetText("X Position:")

    frame.xBox = CreateFrame("EditBox", nil, scrollChild, "InputBoxTemplate")
    frame.xBox:SetSize(80, 25)
    frame.xBox:SetAutoFocus(false)
    frame.xBox:SetPoint("TOPLEFT", boxX, -15)
    frame.xBox:SetText(string.format("%.2f", core.config.X))
    frame.xBox:SetCursorPosition(0)
    frame.xBox:SetScript("OnEnterPressed", function(self)
        local val = tonumber(self:GetText())
        if val then
            core.config.X = val
            core:ClampPosition()
        end
        self:SetText(string.format("%.2f", core.config.X))
        self:ClearFocus()
    end)
    frame.xBox:SetScript("OnEditFocusLost", function(self)
        local val = tonumber(self:GetText())
        if val then
            core.config.X = val
            core:ClampPosition()
        end
        self:SetText(string.format("%.2f", core.config.X))
    end)
    frame.xBox:SetScript("OnEscapePressed", function(self)
        self:SetText(string.format("%.2f", core.config.X))
        self:ClearFocus()
    end)

    local yText = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    yText:SetPoint("TOPLEFT", labelX, -45)
    yText:SetText("Y Position:")

    frame.yBox = CreateFrame("EditBox", nil, scrollChild, "InputBoxTemplate")
    frame.yBox:SetSize(80, 25)
    frame.yBox:SetAutoFocus(false)
    frame.yBox:SetPoint("TOPLEFT", boxX, -45)
    frame.yBox:SetText(string.format("%.2f", core.config.Y))
    frame.yBox:SetCursorPosition(0)
    frame.yBox:SetScript("OnEnterPressed", function(self)
        local val = tonumber(self:GetText())
        if val then
            core.config.Y = val
            core:ClampPosition()
        end
        self:SetText(string.format("%.2f", core.config.Y))
        self:ClearFocus()
    end)
    frame.yBox:SetScript("OnEditFocusLost", function(self)
        local val = tonumber(self:GetText())
        if val then
            core.config.Y = val
            core:ClampPosition()
        end
        self:SetText(string.format("%.2f", core.config.Y))
    end)
    frame.yBox:SetScript("OnEscapePressed", function(self)
        self:SetText(string.format("%.2f", core.config.Y))
        self:ClearFocus()
    end)

    local sizeText = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    sizeText:SetPoint("TOPLEFT", labelX, -75)
    sizeText:SetText("Size:")

    frame.sizeBox = CreateFrame("EditBox", nil, scrollChild, "InputBoxTemplate")
    frame.sizeBox:SetSize(80, 25)
    frame.sizeBox:SetAutoFocus(false)
    frame.sizeBox:SetPoint("TOPLEFT", boxX, -75)
    frame.sizeBox:SetText(string.format("%.2f", core.config.size))
    frame.sizeBox:SetCursorPosition(0)
    frame.sizeBox:SetScript("OnEnterPressed", function(self)
        local val = tonumber(self:GetText())
        if val then
            core.config.size = val
            core:ClampPosition()
        end
        self:SetText(string.format("%.2f", core.config.size))
        self:ClearFocus()
    end)
    frame.sizeBox:SetScript("OnEditFocusLost", function(self)
        local val = tonumber(self:GetText())
        if val then
            core.config.size = val
            core:ClampPosition()
        end
        self:SetText(string.format("%.2f", core.config.size))
    end)
    frame.sizeBox:SetScript("OnEscapePressed", function(self)
        self:SetText(string.format("%.2f", core.config.size))
        self:ClearFocus()
    end)

    frame.enabled = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.enabled:SetPoint("TOPLEFT", labelX, -110)
    frame.enabled.Text:SetText("Enabled")
    frame.enabled:SetChecked(core.config.enabled or false)
    frame.enabled:SetScript("OnClick", function(self)
        core.config.enabled = self:GetChecked()
    end)

    frame.hideWhenMounted = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.hideWhenMounted:SetPoint("TOPLEFT", labelX, -140)
    frame.hideWhenMounted.Text:SetText("Hide When Mounted")
    frame.hideWhenMounted:SetChecked(core.config.hideWhenMounted or false)
    frame.hideWhenMounted:SetScript("OnClick", function(self)
        core.config.hideWhenMounted = self:GetChecked()
    end)

    frame.rangeCheck = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.rangeCheck:SetPoint("TOPLEFT", labelX, -170)
    frame.rangeCheck.Text:SetText("Range Check")
    frame.rangeCheck:SetChecked(core.config.rangeCheck or false)
    frame.rangeCheck:SetScript("OnClick", function(self)
        core.config.rangeCheck = self:GetChecked()
    end)

    frame.castCheck = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.castCheck:SetPoint("TOPLEFT", labelX, -200)
    frame.castCheck.Text:SetText("Cast Check")
    frame.castCheck:SetChecked(core.config.castCheck or false)
    frame.castCheck:SetScript("OnClick", function(self)
        core.config.castCheck = self:GetChecked()
    end)

    frame.channelCheck = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.channelCheck:SetPoint("TOPLEFT", labelX, -230)
    frame.channelCheck.Text:SetText("Channel Check")
    frame.channelCheck:SetChecked(core.config.channelCheck or false)
    frame.channelCheck:SetScript("OnClick", function(self)
        core.config.channelCheck = self:GetChecked()
    end)

    frame.checkForVisibleButton = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.checkForVisibleButton:SetPoint("TOPLEFT", labelX, -260)
    frame.checkForVisibleButton.Text:SetText("Suggest Visible Spells Only")
    frame.checkForVisibleButton:SetChecked(core.config.checkForVisibleButton or false)
    frame.checkForVisibleButton:SetScript("OnClick", function(self)
        core.config.checkForVisibleButton = self:GetChecked()
    end)

    frame.silentMode = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.silentMode:SetPoint("TOPLEFT", labelX, -290)
    frame.silentMode.Text:SetText("Silent Mode")
    frame.silentMode:SetChecked(core.config.silentMode or false)
    frame.silentMode:SetScript("OnClick", function(self)
        core.config.silentMode = self:GetChecked()
    end)
    frame.silentMode:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Silent Mode", 1, 1, 1)
        GameTooltip:AddLine("When enabled, BetterAssistant won't print state changes\nto the chat (toggle confirmations, config updates).", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Useful when you bind toggles to hotkeys\nand don't want chat spam.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    frame.silentMode:SetScript("OnLeave", GameTooltip_Hide)

    frame.ignoreClicks = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.ignoreClicks:SetPoint("TOPLEFT", labelX, -320)
    frame.ignoreClicks.Text:SetText("Ignore Clicks")
    frame.ignoreClicks:SetChecked(core.config.ignoreClicks or false)
    frame.ignoreClicks:SetScript("OnClick", function(self)
        core.config.ignoreClicks = self:GetChecked()
    end)
    frame.ignoreClicks:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Ignore Clicks", 1, 1, 1)
        GameTooltip:AddLine("When enabled, the BetterAssistant icon passes mouse\nclicks through to anything beneath it.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("The icon can no longer be dragged or shift-right-clicked.\nUse /ba to reopen the settings window.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    frame.ignoreClicks:SetScript("OnLeave", GameTooltip_Hide)

    frame.targetRangeEnabled = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.targetRangeEnabled:SetPoint("TOPLEFT", labelX, -350)
    frame.targetRangeEnabled.Text:SetText("Target Range Display")
    frame.targetRangeEnabled:SetChecked(core.config.targetRangeEnabled)
    frame.targetRangeEnabled:SetScript("OnClick", function(self)
        core.config.targetRangeEnabled = self:GetChecked()
    end)
    frame.targetRangeEnabled:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Target Range Display", 1, 1, 1)
        GameTooltip:AddLine("Shows the distance to the current target in the\nbottom-right corner of the main icon.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Shows 0 when there is no attackable target.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    frame.targetRangeEnabled:SetScript("OnLeave", GameTooltip_Hide)

    local showWhenText = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    showWhenText:SetPoint("TOPLEFT", labelX, -395)
    showWhenText:SetText("Show When:")

    frame.showWhenDropdown = CreateFrame("Frame", "DefinitelyNotHekiliShowWhenDD", scrollChild, "UIDropDownMenuTemplate")
    frame.showWhenDropdown:SetPoint("TOPLEFT", boxX - 50, -390)

    local function ShowWhenDropdown_OnClick(self)
        core.config.showWhen = self.value
        UIDropDownMenu_SetText(frame.showWhenDropdown, self.value)
        CloseDropDownMenus()
    end

    UIDropDownMenu_Initialize(frame.showWhenDropdown, function(self, level)
        for _, option in ipairs(addon.showWhenOptions) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = option
            info.value = option
            info.func = ShowWhenDropdown_OnClick
            info.checked = (core.config.showWhen == option)
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(frame.showWhenDropdown, 120)
    UIDropDownMenu_SetText(frame.showWhenDropdown, core.config.showWhen)

    local strataText = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    strataText:SetPoint("TOPLEFT", labelX, -425)
    strataText:SetText("Frame Strata:")

    frame.strataDropdown = CreateFrame("Frame", "DefinitelyNotHekiliStrataDD", scrollChild, "UIDropDownMenuTemplate")
    frame.strataDropdown:SetPoint("TOPLEFT", boxX - 50, -420)

    local function StrataDropdown_OnClick(self)
        core.config.strata = self.value
        UIDropDownMenu_SetText(frame.strataDropdown, self.value)
        CloseDropDownMenus()
    end

    UIDropDownMenu_Initialize(frame.strataDropdown, function(self, level)
        for _, option in ipairs(addon.strataOptions) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = option
            info.value = option
            info.func = StrataDropdown_OnClick
            info.checked = (core.config.strata == option)
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(frame.strataDropdown, 120)
    UIDropDownMenu_SetText(frame.strataDropdown, core.config.strata)

    local glowText = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    glowText:SetPoint("TOPLEFT", labelX, -455)
    glowText:SetText("Spell Glow:")

    frame.glowStyleDropdown = CreateFrame("Frame", "DefinitelyNotHekiliGlowStyleDD", scrollChild, "UIDropDownMenuTemplate")
    frame.glowStyleDropdown:SetPoint("TOPLEFT", boxX - 50, -450)

    local function GlowStyleDropdown_OnClick(self)
        core.config.glowStyle = self.value
        UIDropDownMenu_SetText(frame.glowStyleDropdown, self.value)
        CloseDropDownMenus()
    end

    UIDropDownMenu_Initialize(frame.glowStyleDropdown, function(self, level)
        for _, option in ipairs(addon.glowStyleOptions) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = option
            info.value = option
            info.func = GlowStyleDropdown_OnClick
            info.checked = (core.config.glowStyle == option)
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(frame.glowStyleDropdown, 120)
    UIDropDownMenu_SetText(frame.glowStyleDropdown, core.config.glowStyle)

    return page
end


local function CreateInterruptPage(frame, core)
    local page = CreatePage(frame)

    local labelX = 12

    frame.interruptEnabled = CreateFrame("CheckButton", nil, page, "ChatConfigCheckButtonTemplate")
    frame.interruptEnabled:SetPoint("TOPLEFT", labelX, -15)
    frame.interruptEnabled.Text:SetText("Enable Interrupts")
    frame.interruptEnabled:SetChecked(core.config.interruptEnabled)
    frame.interruptEnabled:SetScript("OnClick", function(self)
        core.config.interruptEnabled = self:GetChecked()
    end)

    return page
end


local function FormatSpellDisplay(spellID)
    if not spellID or spellID == 0 then return "None" end
    local name = C_Spell.GetSpellName(spellID)
    local texture = C_Spell.GetSpellTexture(spellID)
    if name and texture then
        return "|T" .. texture .. ":16:16|t " .. name
    end
    return name or "None"
end

local function AddSpell(list, seen, spellID)
    if not spellID or spellID <= 0 or seen[spellID] then return end
    if C_Spell.IsSpellPassive(spellID) then return end
    local name = C_Spell.GetSpellName(spellID)
    local texture = C_Spell.GetSpellTexture(spellID)
    if not name or not texture then return end
    seen[spellID] = true
    table.insert(list, { spellID = spellID, name = name, icon = texture })
end

local cachedLearnedSpellTree = nil

local function GetLearnedSpellTree()
    cachedLearnedSpellTree = {}
    table.insert(cachedLearnedSpellTree, { kind = "spell", spellID = 0, name = "None", icon = nil })

    local seen = {}
    for i = 1, C_SpellBook.GetNumSpellBookSkillLines() do
        local skillLineInfo = C_SpellBook.GetSpellBookSkillLineInfo(i)
        local offset = skillLineInfo.itemIndexOffset
        local numSlots = skillLineInfo.numSpellBookItems
        for j = offset + 1, offset + numSlots do
            local itemInfo = C_SpellBook.GetSpellBookItemInfo(j, Enum.SpellBookSpellBank.Player)
            if itemInfo and not itemInfo.isOffSpec then
                if itemInfo.itemType == Enum.SpellBookItemType.Flyout and itemInfo.actionID then
                    local fName, fTexture, flyoutSlots, isKnown = GetFlyoutInfo(itemInfo.actionID)
                    if isKnown and flyoutSlots and flyoutSlots > 0 then
                        local group = { kind = "flyout", name = fName, icon = fTexture, spells = {} }
                        for k = 1, flyoutSlots do
                            local fSpellID, _, fIsKnown = GetFlyoutSlotInfo(itemInfo.actionID, k)
                            if fIsKnown then
                                AddSpell(group.spells, seen, fSpellID)
                            end
                        end
                        if #group.spells > 0 then
                            table.sort(group.spells, function(a, b) return a.name < b.name end)
                            table.insert(cachedLearnedSpellTree, group)
                        end
                    end
                else
                    local spellID = itemInfo.spellID
                    if spellID and spellID > 0 and not seen[spellID] and not C_Spell.IsSpellPassive(spellID) then
                        local name = C_Spell.GetSpellName(spellID)
                        local texture = C_Spell.GetSpellTexture(spellID)
                        if name and texture then
                            seen[spellID] = true
                            table.insert(cachedLearnedSpellTree,
                                { kind = "spell", spellID = spellID, name = name, icon = texture })
                        end
                    end
                end
            end
        end
    end

    table.sort(cachedLearnedSpellTree, function(a, b)
        if a.kind == "spell" and a.spellID == 0 then return true end
        if b.kind == "spell" and b.spellID == 0 then return false end
        return a.name < b.name
    end)

    return cachedLearnedSpellTree
end

local function FormatMenuLabel(name, icon)
    if icon then
        return "|T" .. icon .. ":16:16|t " .. name
    end
    return name
end

local function HookDropdownToMenuUtil(dropdown, ddName, getCurrentID, onSelect)
    local btn = _G[ddName .. "Button"]
    if not btn then return end
    btn:SetScript("OnClick", function()
        MenuUtil.CreateContextMenu(dropdown, function(owner, root)
            root:SetScrollMode(300)
            local tree = cachedLearnedSpellTree or GetLearnedSpellTree()
            local function isSelected(spellID) return getCurrentID() == spellID end
            local function setSelected(spellID) onSelect(spellID) end

            for _, entry in ipairs(tree) do
                if entry.kind == "spell" then
                    root:CreateRadio(FormatMenuLabel(entry.name, entry.icon),
                        isSelected, setSelected, entry.spellID)
                else
                    local sub = root:CreateButton(FormatMenuLabel(entry.name, entry.icon))
                    for _, spell in ipairs(entry.spells) do
                        sub:CreateRadio(FormatMenuLabel(spell.name, spell.icon),
                            isSelected, setSelected, spell.spellID)
                    end
                end
            end
        end)
    end)
end

local function HookOptionsDropdown(dropdown, ddName, getCurrent, onSelect, getOptions, labelFn)
    local btn = _G[ddName .. "Button"]
    if not btn then return end
    btn:SetScript("OnClick", function()
        MenuUtil.CreateContextMenu(dropdown, function(owner, root)
            root:SetScrollMode(300)
            local function isSelected(value) return getCurrent() == value end
            local function setSelected(value) onSelect(value) end
            for _, opt in ipairs(getOptions()) do
                root:CreateRadio(labelFn(opt), isSelected, setSelected, opt)
            end
        end)
    end)
end

local function CreateDefensivesSlotRow(frame, page, core, slotIndex, yOffset)
    local labelX = 12

    local enableCB = CreateFrame("CheckButton", nil, page, "UICheckButtonTemplate")
    enableCB:SetPoint("TOPLEFT", labelX, yOffset + 3)
    enableCB:SetSize(24, 24)
    enableCB:SetScript("OnClick", function(self)
        local slots = core:GetOrCreateSpecSlots()
        if slots then
            slots[slotIndex].enabled = self:GetChecked()
            core:DetectDefensivesSpells()
        end
    end)

    local ddName = "DefinitelyNotHekiliDefensivesDD" .. slotIndex
    local dropdown = CreateFrame("Frame", ddName, page, "UIDropDownMenuTemplate")
    dropdown:SetPoint("LEFT", enableCB, "RIGHT", -8, -3)

    HookDropdownToMenuUtil(dropdown, ddName,
        function()
            local slots = core:GetOrCreateSpecSlots()
            return slots and slots[slotIndex] and slots[slotIndex].spellID or 0
        end,
        function(spellID)
            local s = core:GetOrCreateSpecSlots()
            if s then
                s[slotIndex].spellID = spellID
                UIDropDownMenu_SetText(dropdown, FormatSpellDisplay(spellID))
                core:DetectDefensivesSpells()
            end
        end)

    UIDropDownMenu_SetWidth(dropdown, 120)

    local ddText = _G[ddName .. "Text"]
    if ddText then
        ddText:ClearAllPoints()
        ddText:SetPoint("LEFT", dropdown, "LEFT", 30, 2)
        ddText:SetJustifyH("LEFT")
    end

    local glowCB = CreateFrame("CheckButton", nil, page, "UICheckButtonTemplate")
    glowCB:SetPoint("LEFT", dropdown, "RIGHT", -5, 2)
    glowCB:SetSize(24, 24)
    glowCB:SetScript("OnClick", function(self)
        local slots = core:GetOrCreateSpecSlots()
        if slots then
            slots[slotIndex].glow = self:GetChecked()
            core:DetectDefensivesSpells()
        end
    end)
    local glowLabel = page:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    glowLabel:SetPoint("LEFT", glowCB, "RIGHT", -2, 0)
    glowLabel:SetText("Glow")
    local function ShowGlowTooltip(owner)
        GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
        GameTooltip:SetText("Require Spell Glow", 1, 1, 1)
        GameTooltip:AddLine("Only recommend this defensive when the game shows its spell activation glow.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("If the glow is not active, this icon stays dim and will not be recommended.", 0.5, 0.5, 0.5, true)
        GameTooltip:AddLine("Useful for procs or abilities that should only be used when Blizzard highlights them.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end
    glowCB:SetScript("OnEnter", ShowGlowTooltip)
    glowCB:SetScript("OnLeave", GameTooltip_Hide)
    glowLabel:EnableMouse(true)
    glowLabel:SetScript("OnEnter", ShowGlowTooltip)
    glowLabel:SetScript("OnLeave", GameTooltip_Hide)

    local dispelCB = CreateFrame("CheckButton", nil, page, "UICheckButtonTemplate")
    dispelCB:SetPoint("LEFT", glowLabel, "RIGHT", 4, 0)
    dispelCB:SetSize(24, 24)
    dispelCB:SetScript("OnClick", function(self)
        local slots = core:GetOrCreateSpecSlots()
        if slots then
            slots[slotIndex].dispelable = self:GetChecked()
            core:DetectDefensivesSpells()
        end
    end)
    local dispelLabel = page:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    dispelLabel:SetPoint("LEFT", dispelCB, "RIGHT", -2, 0)
    dispelLabel:SetText("Dispel")
    local function ShowDispelTooltip(owner)
        GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
        GameTooltip:SetText("Require Dispellable Debuff", 1, 1, 1)
        GameTooltip:AddLine("Only recommend this defensive while the player has a debuff that they can dispel.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Useful for tying a defensive/dispel cooldown to the presence of an actually dispellable effect.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end
    dispelCB:SetScript("OnEnter", ShowDispelTooltip)
    dispelCB:SetScript("OnLeave", GameTooltip_Hide)
    dispelLabel:EnableMouse(true)
    dispelLabel:SetScript("OnEnter", ShowDispelTooltip)
    dispelLabel:SetScript("OnLeave", GameTooltip_Hide)

    local showWhenDDName = "DefinitelyNotHekiliDefShowWhenDD" .. slotIndex
    local showWhenDD = CreateFrame("Frame", showWhenDDName, page, "UIDropDownMenuTemplate")
    showWhenDD:SetPoint("TOPLEFT", dropdown, "BOTTOMLEFT", 0, -2)

    UIDropDownMenu_Initialize(showWhenDD, function(self, level)
        local slots = core:GetOrCreateSpecSlots()
        local currentVal = slots and slots[slotIndex] and slots[slotIndex].showWhen or "Always"

        for _, option in ipairs(addon.showWhenOptions) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = option
            info.value = option
            info.func = function(btnSelf)
                local s = core:GetOrCreateSpecSlots()
                if s then
                    s[slotIndex].showWhen = btnSelf.value
                    UIDropDownMenu_SetText(showWhenDD, btnSelf.value)
                    core:DetectDefensivesSpells()
                end
                CloseDropDownMenus()
            end
            info.checked = (currentVal == option)
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(showWhenDD, 120)

    local showWhenDDText = _G[showWhenDDName .. "Text"]
    if showWhenDDText then
        showWhenDDText:ClearAllPoints()
        showWhenDDText:SetPoint("LEFT", showWhenDD, "LEFT", 30, 2)
        showWhenDDText:SetJustifyH("LEFT")
    end

    showWhenDD:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Show When", 1, 1, 1)
        GameTooltip:AddLine("Controls when this defensive icon is visible.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Always — always shown", 0.5, 0.5, 0.5)
        GameTooltip:AddLine("HasTarget — when you have an attackable target", 0.5, 0.5, 0.5)
        GameTooltip:AddLine("InCombat — when you are in combat", 0.5, 0.5, 0.5)
        GameTooltip:AddLine("TargetInCombat — when target is in combat", 0.5, 0.5, 0.5)
        GameTooltip:Show()
    end)
    showWhenDD:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    local buffLabel = page:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    buffLabel:SetPoint("LEFT", showWhenDD, "RIGHT", -7, 2)
    buffLabel:SetText("Buff Duration")
    buffLabel:EnableMouse(true)
    buffLabel:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Buff Duration (seconds)", 1, 1, 1)
        GameTooltip:AddLine("After successfully casting this spell,\nit will not be recommended again for this many seconds.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Set to 0 to disable.", 0.5, 0.5, 0.5)
        GameTooltip:AddLine("Useful for spells that apply a buff\n(e.g. Survival Instincts, Frenzied Regeneration)\nwhere re-casting while active is wasteful.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    buffLabel:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    local buffDurBox = CreateFrame("EditBox", nil, page, "InputBoxTemplate")
    buffDurBox:SetSize(36, 22)
    buffDurBox:SetAutoFocus(false)
    buffDurBox:SetPoint("LEFT", buffLabel, "RIGHT", 8, 0)
    buffDurBox:SetScript("OnEnterPressed", function(self)
        local val = tonumber(self:GetText())
        local slots = core:GetOrCreateSpecSlots()
        if val and slots then
            val = math.max(0, math.min(60, val))
            slots[slotIndex].buffDuration = val
            self:SetText(tostring(val))
            core:DetectDefensivesSpells()
        end
        self:ClearFocus()
    end)
    buffDurBox:SetScript("OnEditFocusLost", function(self)
        local val = tonumber(self:GetText())
        local slots = core:GetOrCreateSpecSlots()
        if val and slots then
            val = math.max(0, math.min(60, val))
            slots[slotIndex].buffDuration = val
            self:SetText(tostring(val))
            core:DetectDefensivesSpells()
        elseif slots then
            self:SetText(tostring(slots[slotIndex].buffDuration))
        end
    end)
    buffDurBox:SetScript("OnEscapePressed", function(self)
        local slots = core:GetOrCreateSpecSlots()
        if slots then
            self:SetText(tostring(slots[slotIndex].buffDuration))
        end
        self:ClearFocus()
    end)

    local resourceDD, opDD, thresholdBox

    local function GetResourceList(unit)
        if unit ~= "player" then return { "health" } end
        local list = { "health" }
        for _, pt in ipairs(addon.GetCurrentSpecPowers()) do
            table.insert(list, pt.name:lower())
        end
        return list
    end

    local unitDDName = "DefinitelyNotHekiliDefUnitDD" .. slotIndex
    local unitDD = CreateFrame("Frame", unitDDName, page, "UIDropDownMenuTemplate")
    unitDD:SetPoint("TOPLEFT", showWhenDD, "BOTTOMLEFT", 0, -2)

    UIDropDownMenu_Initialize(unitDD, function(self, level)
        local slots = core:GetOrCreateSpecSlots()
        local currentVal = slots and slots[slotIndex] and slots[slotIndex].unit or "player"

        for _, opt in ipairs(addon.unitOptions) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = opt
            info.value = opt
            info.func = function(btnSelf)
                local s = core:GetOrCreateSpecSlots()
                if s then
                    s[slotIndex].unit = btnSelf.value
                    UIDropDownMenu_SetText(unitDD, btnSelf.value)
                    if btnSelf.value ~= "player" and s[slotIndex].resource ~= "health" then
                        s[slotIndex].resource = "health"
                        if resourceDD then UIDropDownMenu_SetText(resourceDD, "health") end
                    end
                    core:DetectDefensivesSpells()
                end
                CloseDropDownMenus()
            end
            info.checked = (currentVal == opt)
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(unitDD, 60)

    local unitDDText = _G[unitDDName .. "Text"]
    if unitDDText then
        unitDDText:ClearAllPoints()
        unitDDText:SetPoint("LEFT", unitDD, "LEFT", 30, 2)
        unitDDText:SetJustifyH("LEFT")
    end

    unitDD:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Health Source", 1, 1, 1)
        GameTooltip:AddLine("Which unit's HP and range are checked\nwhen evaluating this defensive.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Player — your own HP (default)", 0.5, 0.5, 0.5)
        GameTooltip:AddLine("Pet — your active pet (e.g. Mend Pet)", 0.5, 0.5, 0.5)
        GameTooltip:AddLine("Mouseover — unit your cursor is over", 0.5, 0.5, 0.5)
        GameTooltip:Show()
    end)
    unitDD:SetScript("OnLeave", GameTooltip_Hide)

    local resourceDDName = "DefinitelyNotHekiliDefResourceDD" .. slotIndex
    resourceDD = CreateFrame("Frame", resourceDDName, page, "UIDropDownMenuTemplate")
    resourceDD:SetPoint("LEFT", unitDD, "RIGHT", -25, 0)

    UIDropDownMenu_Initialize(resourceDD, function(self, level)
        local slots = core:GetOrCreateSpecSlots()
        local slot = slots and slots[slotIndex]
        local currentVal = slot and slot.resource or "health"
        local unit = slot and slot.unit or "player"

        for _, opt in ipairs(GetResourceList(unit)) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = opt
            info.value = opt
            info.func = function(btnSelf)
                local s = core:GetOrCreateSpecSlots()
                if s then
                    s[slotIndex].resource = btnSelf.value
                    UIDropDownMenu_SetText(resourceDD, btnSelf.value)
                    core:DetectDefensivesSpells()
                end
                CloseDropDownMenus()
            end
            info.checked = (currentVal == opt)
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(resourceDD, 60)

    local resourceDDText = _G[resourceDDName .. "Text"]
    if resourceDDText then
        resourceDDText:ClearAllPoints()
        resourceDDText:SetPoint("LEFT", resourceDD, "LEFT", 30, 2)
        resourceDDText:SetJustifyH("LEFT")
    end

    resourceDD:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Resource", 1, 1, 1)
        GameTooltip:AddLine("Which resource on the chosen unit drives this defensive.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Player — health or any class power (mana, energy, rage…)\nPet/Mouseover — health only.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    resourceDD:SetScript("OnLeave", GameTooltip_Hide)

    local opDDName = "DefinitelyNotHekiliDefOpDD" .. slotIndex
    opDD = CreateFrame("Frame", opDDName, page, "UIDropDownMenuTemplate")
    opDD:SetPoint("LEFT", resourceDD, "RIGHT", -25, 0)

    UIDropDownMenu_Initialize(opDD, function(self, level)
        local slots = core:GetOrCreateSpecSlots()
        local currentVal = slots and slots[slotIndex] and slots[slotIndex].operator or "<"

        for _, opt in ipairs(addon.operatorOptions) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = opt
            info.value = opt
            info.func = function(btnSelf)
                local s = core:GetOrCreateSpecSlots()
                if s then
                    s[slotIndex].operator = btnSelf.value
                    UIDropDownMenu_SetText(opDD, btnSelf.value)
                    core:DetectDefensivesSpells()
                end
                CloseDropDownMenus()
            end
            info.checked = (currentVal == opt)
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(opDD, 40)

    local opDDText = _G[opDDName .. "Text"]
    if opDDText then
        opDDText:ClearAllPoints()
        opDDText:SetPoint("LEFT", opDD, "LEFT", 30, 2)
        opDDText:SetJustifyH("LEFT")
    end

    opDD:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Comparison", 1, 1, 1)
        GameTooltip:AddLine("How the current resource value compares to the threshold.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("<, >, =, <=, >= — applies to the resource percent.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    opDD:SetScript("OnLeave", GameTooltip_Hide)

    thresholdBox = CreateFrame("EditBox", nil, page, "InputBoxTemplate")
    thresholdBox:SetSize(30, 22)
    thresholdBox:SetAutoFocus(false)
    thresholdBox:SetPoint("LEFT", opDD, "RIGHT", -5, 0)
    thresholdBox:SetScript("OnEnterPressed", function(self)
        local val = tonumber(self:GetText())
        local slots = core:GetOrCreateSpecSlots()
        if val and slots then
            val = math.max(1, math.min(100, math.floor(val)))
            slots[slotIndex].healthPct = val
            self:SetText(tostring(val))
            core:DetectDefensivesSpells()
        end
        self:ClearFocus()
    end)
    thresholdBox:SetScript("OnEditFocusLost", function(self)
        local val = tonumber(self:GetText())
        local slots = core:GetOrCreateSpecSlots()
        if val and slots then
            val = math.max(1, math.min(100, math.floor(val)))
            slots[slotIndex].healthPct = val
            self:SetText(tostring(val))
            core:DetectDefensivesSpells()
        elseif slots then
            self:SetText(tostring(slots[slotIndex].healthPct))
        end
    end)
    thresholdBox:SetScript("OnEscapePressed", function(self)
        local slots = core:GetOrCreateSpecSlots()
        if slots then
            self:SetText(tostring(slots[slotIndex].healthPct))
        end
        self:ClearFocus()
    end)
    thresholdBox:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Threshold (%)", 1, 1, 1)
        GameTooltip:AddLine("Value 1–100, compared against the resource percent.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("= operator: matches floor(percent) == value\n(good for runes / combo points).", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    thresholdBox:SetScript("OnLeave", GameTooltip_Hide)

    return dropdown, thresholdBox, enableCB, buffDurBox, showWhenDD, unitDD, resourceDD, opDD, glowCB, dispelCB
end

local function CreateDefensivesPage(frame, core)
    local page = CreatePage(frame)

    local labelX = 12

    frame.defensivesEnabled = CreateFrame("CheckButton", nil, page, "ChatConfigCheckButtonTemplate")
    frame.defensivesEnabled:SetPoint("TOPLEFT", labelX, -15)
    frame.defensivesEnabled.Text:SetText("Enable Defensives Icons")
    frame.defensivesEnabled:SetChecked(core.config.defensivesEnabled or false)
    frame.defensivesEnabled:SetScript("OnClick", function(self)
        core.config.defensivesEnabled = self:GetChecked()
        core:DetectDefensivesSpells()
    end)

    local scrollFrame = CreateFrame("ScrollFrame", nil, page, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 0, -45)
    scrollFrame:SetPoint("BOTTOMRIGHT", -28, 0)

    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetWidth(CONTENT_WIDTH - 40)
    scrollFrame:SetScrollChild(scrollChild)

    frame.defensivesSlotDropdowns = {}
    frame.defensivesSlotHP = {}
    frame.defensivesSlotEnabled = {}
    frame.defensivesSlotBuffDuration = {}
    frame.defensivesSlotShowWhen = {}
    frame.defensivesSlotUnit = {}
    frame.defensivesSlotResource = {}
    frame.defensivesSlotOperator = {}
    frame.defensivesSlotGlow = {}
    frame.defensivesSlotDispel = {}

    local function EnsureRows(count)
        scrollChild:SetHeight(count * 115 + 10)
        local slots = core:GetOrCreateSpecSlots()
        for i = #frame.defensivesSlotDropdowns + 1, count do
            local yOffset = -(i - 1) * 115
            local dd, thresholdBox, en, buffDurBox, showWhenDD, unitDD, resourceDD, opDD, glowCB, dispelCB =
                CreateDefensivesSlotRow(frame, scrollChild, core, i, yOffset)
            frame.defensivesSlotDropdowns[i] = dd
            frame.defensivesSlotHP[i] = thresholdBox
            frame.defensivesSlotEnabled[i] = en
            frame.defensivesSlotBuffDuration[i] = buffDurBox
            frame.defensivesSlotShowWhen[i] = showWhenDD
            frame.defensivesSlotUnit[i] = unitDD
            frame.defensivesSlotResource[i] = resourceDD
            frame.defensivesSlotOperator[i] = opDD
            frame.defensivesSlotGlow[i] = glowCB
            frame.defensivesSlotDispel[i] = dispelCB

            if slots and slots[i] then
                local slot = slots[i]
                UIDropDownMenu_SetText(dd, FormatSpellDisplay(slot.spellID))
                thresholdBox:SetText(tostring(slot.healthPct))
                thresholdBox:SetCursorPosition(0)
                en:SetChecked(slot.enabled)
                buffDurBox:SetText(tostring(slot.buffDuration))
                buffDurBox:SetCursorPosition(0)
                UIDropDownMenu_SetText(showWhenDD, slot.showWhen or "Always")
                UIDropDownMenu_SetText(unitDD, slot.unit or "player")
                UIDropDownMenu_SetText(resourceDD, slot.resource or "health")
                UIDropDownMenu_SetText(opDD, slot.operator or "<")
                glowCB:SetChecked(slot.glow or false)
                dispelCB:SetChecked(slot.dispelable or false)
            end
        end
    end

    frame.EnsureDefensiveSlotRows = EnsureRows
    EnsureRows(core.config.maxDefensiveSlots)

    return page
end


local empoweredThresholdOptions = {
    { text = "Unlimited", value = 0 },
    { text = "1", value = 1 },
    { text = "2", value = 2 },
}

local function GetPowerTypeName(powerType)
    if powerType == -1 then return "Disabled" end
    for _, pt in ipairs(addon.GetCurrentSpecPowers()) do
        if pt.type == powerType then return pt.name end
    end
    return "Unknown"
end


local function CreateCDMPage(frame, core)
    local page = CreatePage(frame)

    local scrollFrame = CreateFrame("ScrollFrame", nil, page, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 0, 0)
    scrollFrame:SetPoint("BOTTOMRIGHT", -28, 0)

    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetWidth(CONTENT_WIDTH - 40)
    scrollChild:SetHeight(390)
    scrollFrame:SetScrollChild(scrollChild)

    local labelX = 12
    local boxX = 192

    addon.cdm.EnsureConfig(core)
    local cfg = core.config.cdm

    frame.cdmEnabled = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.cdmEnabled:SetPoint("TOPLEFT", labelX, -15)
    frame.cdmEnabled.Text:SetText("Enable Aura Bar")
    frame.cdmEnabled:SetChecked(cfg.enabled)
    frame.cdmEnabled:SetScript("OnClick", function(self)
        cfg.enabled = self:GetChecked()
    end)
    frame.cdmEnabled:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Enable Aura Bar", 1, 1, 1)
        GameTooltip:AddLine("Shows the tracked auras configured below in a row\nbelow the assistant icon.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Independent from the Blizzard Cooldown Manager -\nit does not need to be enabled or visible.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    frame.cdmEnabled:SetScript("OnLeave", GameTooltip_Hide)

    local sizeLabel = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    sizeLabel:SetPoint("TOPLEFT", labelX, -50)
    sizeLabel:SetText("Icon Size:")

    frame.cdmIconSize = CreateFrame("EditBox", nil, scrollChild, "InputBoxTemplate")
    frame.cdmIconSize:SetSize(60, 22)
    frame.cdmIconSize:SetAutoFocus(false)
    frame.cdmIconSize:SetPoint("TOPLEFT", boxX, -47)
    frame.cdmIconSize:SetText(tostring(cfg.iconSize))
    frame.cdmIconSize:SetCursorPosition(0)
    local function ApplyIconSize(self)
        local val = tonumber(self:GetText())
        if val then
            val = math.max(16, math.min(128, math.floor(val)))
            cfg.iconSize = val
        end
        self:SetText(tostring(cfg.iconSize))
    end
    frame.cdmIconSize:SetScript("OnEnterPressed", function(self)
        ApplyIconSize(self)
        self:ClearFocus()
    end)
    frame.cdmIconSize:SetScript("OnEditFocusLost", ApplyIconSize)
    frame.cdmIconSize:SetScript("OnEscapePressed", function(self)
        self:SetText(tostring(cfg.iconSize))
        self:ClearFocus()
    end)
    frame.cdmIconSize:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Icon Size", 1, 1, 1)
        GameTooltip:AddLine("Side length in pixels of each mirrored buff icon.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Value 16–128. Default 48.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    frame.cdmIconSize:SetScript("OnLeave", GameTooltip_Hide)

    frame.cdmShowSwipe = CreateFrame("CheckButton", nil, scrollChild, "ChatConfigCheckButtonTemplate")
    frame.cdmShowSwipe:SetPoint("TOPLEFT", labelX, -85)
    frame.cdmShowSwipe.Text:SetText("Show Cooldown Swipe")
    frame.cdmShowSwipe:SetChecked(cfg.showSwipe)
    frame.cdmShowSwipe:SetScript("OnClick", function(self)
        cfg.showSwipe = self:GetChecked()
    end)
    frame.cdmShowSwipe:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Show Cooldown Swipe", 1, 1, 1)
        GameTooltip:AddLine("When enabled, mirrored buff icons display\nthe radial cooldown swipe for their remaining duration.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Disable for a cleaner look if you don't need\nthe time-remaining visual.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    frame.cdmShowSwipe:SetScript("OnLeave", GameTooltip_Hide)


    local function GetMaxAuras()
        return addon.cdm.GetMaxAuras(core)
    end

    local function GetAuraList(create)
        addon.cdm.EnsureConfig(core)
        local specKey = core:GetSpecKey()
        if not specKey then return nil end
        local auras = core.config.cdm.auras
        if not auras[specKey] and create then auras[specKey] = {} end
        return auras[specKey]
    end

    frame.cdmAurasTitle = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    frame.cdmAurasTitle:SetPoint("TOPLEFT", labelX, -125)
    frame.cdmAurasTitle:SetText(("Tracked Auras (0/%d):"):format(GetMaxAuras()))

    local function RefreshAuraRows()
        local list = GetAuraList(false) or {}
        local maxAuras = GetMaxAuras()
        local shown = math.min(#list, maxAuras)
        frame.cdmAurasTitle:SetText(("Tracked Auras (%d/%d):"):format(shown, maxAuras))
        for i = 1, #frame.cdmAuraRows do
            local row = frame.cdmAuraRows[i]
            local id, learned = addon.cdm.ReadAuraEntry(list[i])
            if id and i <= maxAuras then
                row.icon:SetTexture(C_Spell.GetSpellTexture(id) or "Interface\\Icons\\INV_Misc_QuestionMark")
                row.text:SetText(("%s |cff888888(%d)|r"):format(C_Spell.GetSpellName(id) or "Unknown", id))
                row.learned:SetChecked(learned)
                row.up:SetEnabled(i > 1)
                row.down:SetEnabled(i < shown)
                row:Show()
            else
                row:Hide()
            end
        end
    end
    frame.RefreshCDMAuraRows = RefreshAuraRows

    local function Notify(msg)
        print("|cff00ff00[BetterAssistant]|r " .. msg)
    end

    local function AddAura(spellID)
        local list = GetAuraList(true)
        if not list then
            Notify("No active specialization.")
            return
        end
        if #list >= GetMaxAuras() then
            Notify(("Aura list is full (max %d)."):format(GetMaxAuras()))
            return
        end
        list[#list + 1] = spellID
        addon.cdm.QueueRebuild()
        RefreshAuraRows()
    end

    local function RemoveAuraAt(index)
        local list = GetAuraList(false)
        if not list then return end
        table.remove(list, index)
        addon.cdm.QueueRebuild()
        RefreshAuraRows()
    end

    local function MoveAura(index, delta)
        local list = GetAuraList(false)
        if not list then return end
        local target = index + delta
        if target < 1 or target > #list then return end
        list[index], list[target] = list[target], list[index]
        addon.cdm.QueueRebuild()
        RefreshAuraRows()
    end

    frame.cdmAuraDropdown = CreateFrame("DropdownButton", nil, scrollChild, "WowStyle1DropdownTemplate")
    frame.cdmAuraDropdown:SetSize(150, 24)
    frame.cdmAuraDropdown:SetPoint("TOPLEFT", labelX + 2, -145)
    frame.cdmAuraDropdown:SetDefaultText("Add from CDM list...")
    frame.cdmAuraDropdown:SetupMenu(function(_, rootDescription)
        rootDescription:SetScrollMode(20 * 15)
        local entries = addon.cdm.GetCDMAuraList()
        if #entries == 0 then
            rootDescription:CreateTitle("No CDM aura data for this spec")
        end
        for _, e in ipairs(entries) do
            local text
            if e.known then
                text = ("|T%s:16|t %s |cff888888(%d)|r"):format(tostring(e.icon or 134400), e.name, e.spellID)
            else
                text = ("|T%s:16|t |cff808080%s (%d)|r"):format(tostring(e.icon or 134400), e.name, e.spellID)
            end
            rootDescription:CreateButton(text, function() AddAura(e.spellID) end)
        end
    end)
    frame.cdmAuraDropdown:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Add from CDM list", 1, 1, 1)
        GameTooltip:AddLine("All aura-based entries the Cooldown Manager knows\nfor your class and spec (buffs and tracked debuffs).", nil, nil, nil, true)
        GameTooltip:Show()
    end)
    frame.cdmAuraDropdown:SetScript("OnLeave", GameTooltip_Hide)

    frame.cdmAuraInput = CreateFrame("EditBox", nil, scrollChild, "InputBoxTemplate")
    frame.cdmAuraInput:SetSize(60, 22)
    frame.cdmAuraInput:SetAutoFocus(false)
    frame.cdmAuraInput:SetNumeric(true)
    frame.cdmAuraInput:SetPoint("LEFT", frame.cdmAuraDropdown, "RIGHT", 10, 0)
    frame.cdmAuraInput:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Manual Spell ID", 1, 1, 1)
        GameTooltip:AddLine("Type any aura spell ID and press Add\n(or Enter) to track it.", nil, nil, nil, true)
        GameTooltip:Show()
    end)
    frame.cdmAuraInput:SetScript("OnLeave", GameTooltip_Hide)

    local function AddManualAura()
        local id = tonumber(frame.cdmAuraInput:GetText())
        if not id or id <= 0 then return end
        id = math.floor(id)
        if not C_Spell.GetSpellName(id) then
            Notify(("Unknown spell ID: %d."):format(id))
            return
        end
        frame.cdmAuraInput:SetText("")
        frame.cdmAuraInput:ClearFocus()
        AddAura(id)
    end

    frame.cdmAuraAddBtn = CreateFrame("Button", nil, scrollChild, "UIPanelButtonTemplate")
    frame.cdmAuraAddBtn:SetSize(45, 22)
    frame.cdmAuraAddBtn:SetPoint("LEFT", frame.cdmAuraInput, "RIGHT", 6, 0)
    frame.cdmAuraAddBtn:SetText("Add")
    frame.cdmAuraAddBtn:SetScript("OnClick", AddManualAura)
    frame.cdmAuraInput:SetScript("OnEnterPressed", AddManualAura)
    frame.cdmAuraInput:SetScript("OnEscapePressed", function(self)
        self:SetText("")
        self:ClearFocus()
    end)

    frame.cdmAuraRows = {}
    local rowsTop = -178
    local ROW_PITCH = 22
    local ARROW_ATLAS = "common-dropdown-c-button-hover-arrow"
    local function CreateArrowButton(parent, dir)
        local btn = CreateFrame("Button", nil, parent)
        btn:SetSize(16, 16)

        local arrow = btn:CreateTexture(nil, "ARTWORK")
        arrow:SetAtlas(ARROW_ATLAS, true)
        arrow:SetPoint("CENTER")
        if dir == "up" then arrow:SetRotation(math.pi) end
        btn.arrow = arrow

        local hl = btn:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAtlas(ARROW_ATLAS, true)
        hl:SetPoint("CENTER")
        hl:SetBlendMode("ADD")
        hl:SetAlpha(0.4)
        if dir == "up" then hl:SetRotation(math.pi) end

        btn:SetScript("OnEnable", function(self)
            self.arrow:SetDesaturated(false)
            self.arrow:SetAlpha(1)
        end)
        btn:SetScript("OnDisable", function(self)
            self.arrow:SetDesaturated(true)
            self.arrow:SetAlpha(0.3)
        end)
        return btn
    end

    local rowCount = GetMaxAuras()
    scrollChild:SetHeight(math.max(390, -rowsTop + rowCount * ROW_PITCH + 30))

    for i = 1, rowCount do
        local row = CreateFrame("Frame", nil, scrollChild)
        row:SetSize(285, 20)
        row:SetPoint("TOPLEFT", labelX - 4, rowsTop - (i - 1) * ROW_PITCH)

        row.up = CreateArrowButton(row, "up")
        row.up:SetPoint("LEFT", 0, 0)
        row.up:SetScript("OnClick", function() MoveAura(i, -1) end)

        row.down = CreateArrowButton(row, "down")
        row.down:SetPoint("LEFT", row.up, "RIGHT", 1, 0)
        row.down:SetScript("OnClick", function() MoveAura(i, 1) end)

        row.learned = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
        row.learned:SetSize(20, 20)
        row.learned:SetScript("OnClick", function(self)
            local list = GetAuraList(false)
            if not list then return end
            addon.cdm.SetAuraEntryLearned(list, i, self:GetChecked())
            addon.cdm.QueueRebuild()
            RefreshAuraRows()
        end)
        row.learned:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Track as learned spell", 1, 1, 1)
            GameTooltip:AddLine("Stops watching for the aura and instead asks whether\nthis spell ID is learned: full opacity when it is,\nfaded when it is not.", nil, nil, nil, true)
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("Useful for seeing at a glance whether a talent is taken.\nThe same ID may be added twice - once as an aura,\nonce as a learned-check.", 0.5, 0.5, 0.5, true)
            GameTooltip:Show()
        end)
        row.learned:SetScript("OnLeave", GameTooltip_Hide)

        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(18, 18)
        row.icon:SetPoint("LEFT", row.down, "RIGHT", 6, 0)
        row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        row.text:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)
        row.text:SetPoint("RIGHT", row.learned, "LEFT", -4, 0)
        row.text:SetJustifyH("LEFT")
        row.text:SetWordWrap(false)

        row.remove = CreateFrame("Button", nil, row, "UIPanelCloseButton")
        row.remove:SetSize(24, 24)
        row.remove:SetPoint("RIGHT", row, "RIGHT", 2, 0)
        row.remove:SetScript("OnClick", function() RemoveAuraAt(i) end)
        row.learned:SetPoint("RIGHT", row.remove, "LEFT", -2, 0)

        row:Hide()
        frame.cdmAuraRows[i] = row
    end

    page:SetScript("OnShow", RefreshAuraRows)
    RefreshAuraRows()

    return page
end

local function CreateAdvancedPage(frame, core)
    local page = CreatePage(frame)

    local labelX = 12

    local label = page:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetPoint("TOPLEFT", labelX, -25)
    label:SetText("Empowered Stage Threshold")

    frame.empoweredThresholdDD = CreateFrame("Frame", "DefinitelyNotHekiliEmpowerDD", page, "UIDropDownMenuTemplate")
    frame.empoweredThresholdDD:SetPoint("LEFT", label, "RIGHT", -10, -2)
    frame.empoweredThresholdDD:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Empowered Stage Threshold", 1, 1, 1)
        GameTooltip:AddLine("Hide cooldown swipe when empowered spell\nreaches the selected stage.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Unlimited = never hide the swipe.", 0.5, 0.5, 0.5)
        GameTooltip:Show()
    end)
    frame.empoweredThresholdDD:SetScript("OnLeave", GameTooltip_Hide)

    local function EmpoweredThreshold_OnClick(self, arg1)
        core:SetAdvancedOption("empoweredStageThreshold", self.value)
        UIDropDownMenu_SetText(frame.empoweredThresholdDD, arg1)
        CloseDropDownMenus()
    end

    UIDropDownMenu_Initialize(frame.empoweredThresholdDD, function(self, level)
        local currentValue = core:GetAdvancedOption("empoweredStageThreshold")
        for _, option in ipairs(empoweredThresholdOptions) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = option.text
            info.value = option.value
            info.arg1 = option.text
            info.func = EmpoweredThreshold_OnClick
            info.checked = (currentValue == option.value)
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(frame.empoweredThresholdDD, 120)

    local currentValue = core:GetAdvancedOption("empoweredStageThreshold")
    for _, option in ipairs(empoweredThresholdOptions) do
        if option.value == currentValue then
            UIDropDownMenu_SetText(frame.empoweredThresholdDD, option.text)
            break
        end
    end

    local rpLabel = page:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    rpLabel:SetPoint("TOPLEFT", labelX, -80)
    rpLabel:SetText("Resource Pooling")

    frame.resourcePoolingDD = CreateFrame("Frame", "DefinitelyNotHekiliResPoolDD", page, "UIDropDownMenuTemplate")
    frame.resourcePoolingDD:SetPoint("LEFT", rpLabel, "RIGHT", -10, -2)
    frame.resourcePoolingDD:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Resource Pooling", 1, 1, 1)
        GameTooltip:AddLine("Tint the icon blue when the selected resource\nis below the threshold percentage.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Helps work around Blizzard's rotation assistant, which may\nsuggest a cheap filler spell when you lack resource for the\nactual priority ability. The blue tint tells you to wait\nand pool instead of pressing the suggested filler.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    frame.resourcePoolingDD:SetScript("OnLeave", GameTooltip_Hide)

    local function ResourcePooling_OnClick(self, arg1)
        core:SetAdvancedOption("resourcePoolingType", self.value)
        UIDropDownMenu_SetText(frame.resourcePoolingDD, arg1)
        CloseDropDownMenus()
    end

    UIDropDownMenu_Initialize(frame.resourcePoolingDD, function(self, level)
        local currentRP = core:GetAdvancedOption("resourcePoolingType")
        local types = addon.GetCurrentSpecPowers()

        local info = UIDropDownMenu_CreateInfo()
        info.text = "Disabled"
        info.value = -1
        info.arg1 = "Disabled"
        info.func = ResourcePooling_OnClick
        info.checked = (currentRP == -1)
        UIDropDownMenu_AddButton(info, level)

        for _, pt in ipairs(types) do
            if not pt.special then
                info = UIDropDownMenu_CreateInfo()
                info.text = pt.name
                info.value = pt.type
                info.arg1 = pt.name
                info.func = ResourcePooling_OnClick
                info.checked = (currentRP == pt.type)
                UIDropDownMenu_AddButton(info, level)
            end
        end
    end)

    UIDropDownMenu_SetWidth(frame.resourcePoolingDD, 120)
    UIDropDownMenu_SetText(frame.resourcePoolingDD, GetPowerTypeName(core:GetAdvancedOption("resourcePoolingType")))

    frame.resourcePoolingThresholdBox = CreateFrame("EditBox", nil, page, "InputBoxTemplate")
    frame.resourcePoolingThresholdBox:SetSize(40, 22)
    frame.resourcePoolingThresholdBox:SetAutoFocus(false)
    frame.resourcePoolingThresholdBox:SetPoint("LEFT", frame.resourcePoolingDD, "RIGHT", -5, 2)
    frame.resourcePoolingThresholdBox:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Threshold %", 1, 1, 1)
        GameTooltip:AddLine("Icon stays blue while resource is below this percentage.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Value between 10 and 90.", 0.5, 0.5, 0.5)
        GameTooltip:Show()
    end)
    frame.resourcePoolingThresholdBox:SetScript("OnLeave", GameTooltip_Hide)
    frame.resourcePoolingThresholdBox:SetText(tostring(core:GetAdvancedOption("resourcePoolingThreshold")))
    frame.resourcePoolingThresholdBox:SetCursorPosition(0)

    frame.resourcePoolingThresholdBox:SetScript("OnEnterPressed", function(self)
        local val = tonumber(self:GetText())
        if val then
            val = math.max(10, math.min(90, math.floor(val)))
            core:SetAdvancedOption("resourcePoolingThreshold", val)
            core.poolingCachedThreshold = nil
        end
        self:SetText(tostring(core:GetAdvancedOption("resourcePoolingThreshold")))
        self:ClearFocus()
    end)
    frame.resourcePoolingThresholdBox:SetScript("OnEditFocusLost", function(self)
        local val = tonumber(self:GetText())
        if val then
            val = math.max(10, math.min(90, math.floor(val)))
            core:SetAdvancedOption("resourcePoolingThreshold", val)
            core.poolingCachedThreshold = nil
        end
        self:SetText(tostring(core:GetAdvancedOption("resourcePoolingThreshold")))
    end)
    frame.resourcePoolingThresholdBox:SetScript("OnEscapePressed", function(self)
        self:SetText(tostring(core:GetAdvancedOption("resourcePoolingThreshold")))
        self:ClearFocus()
    end)

    local function MovingOverride_OnEnter(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Cast While Moving", 1, 1, 1)
        GameTooltip:AddLine("While you are moving, if the rotation pick has a cast time,\nit will be replaced with the spell selected here.\nInstant casts from the rotation are kept as-is.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Pick a reliable instant fallback (e.g. Shadow Word: Pain,\nIce Lance) so the assistant stays useful while you reposition.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end

    local mvLabel = page:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    mvLabel:SetPoint("TOPLEFT", labelX, -135)
    mvLabel:SetText("Cast While Moving")
    mvLabel:EnableMouse(true)
    mvLabel:SetScript("OnEnter", MovingOverride_OnEnter)
    mvLabel:SetScript("OnLeave", GameTooltip_Hide)

    frame.movingOverrideCB = CreateFrame("CheckButton", nil, page, "UICheckButtonTemplate")
    frame.movingOverrideCB:SetSize(24, 24)
    frame.movingOverrideCB:SetPoint("LEFT", mvLabel, "RIGHT", 4, 0)
    frame.movingOverrideCB:SetChecked(core:GetAdvancedOption("movingOverrideEnabled"))
    frame.movingOverrideCB:SetScript("OnClick", function(self)
        core:SetAdvancedOption("movingOverrideEnabled", self:GetChecked())
    end)
    frame.movingOverrideCB:SetScript("OnEnter", MovingOverride_OnEnter)
    frame.movingOverrideCB:SetScript("OnLeave", GameTooltip_Hide)

    frame.movingOverrideDD = CreateFrame("Frame", "DefinitelyNotHekiliMovingOverrideDD", page, "UIDropDownMenuTemplate")
    frame.movingOverrideDD:SetPoint("LEFT", frame.movingOverrideCB, "RIGHT", -8, -2)
    frame.movingOverrideDD:SetScript("OnEnter", MovingOverride_OnEnter)
    frame.movingOverrideDD:SetScript("OnLeave", GameTooltip_Hide)

    HookDropdownToMenuUtil(frame.movingOverrideDD, "DefinitelyNotHekiliMovingOverrideDD",
        function() return core:GetAdvancedOption("movingOverrideSpellID") end,
        function(spellID)
            core:SetAdvancedOption("movingOverrideSpellID", spellID)
            UIDropDownMenu_SetText(frame.movingOverrideDD, FormatSpellDisplay(spellID))
        end)

    UIDropDownMenu_SetWidth(frame.movingOverrideDD, 140)
    UIDropDownMenu_SetText(frame.movingOverrideDD,
        FormatSpellDisplay(core:GetAdvancedOption("movingOverrideSpellID")))

    local function NPCounter_OnEnter(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Nameplate Counter", 1, 1, 1)
        GameTooltip:AddLine("Counts attackable nameplates within the selected range\nand shows the number at the top-right of the assistant icon.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Uses item-based range checking — available ranges depend on\nwhich items are currently cached.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end

    local npLabel = page:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    npLabel:SetPoint("TOPLEFT", labelX, -170)
    npLabel:SetText("Nameplate Counter")
    npLabel:EnableMouse(true)
    npLabel:SetScript("OnEnter", NPCounter_OnEnter)
    npLabel:SetScript("OnLeave", GameTooltip_Hide)

    frame.nameplateCounterCB = CreateFrame("CheckButton", nil, page, "UICheckButtonTemplate")
    frame.nameplateCounterCB:SetSize(24, 24)
    frame.nameplateCounterCB:SetPoint("LEFT", npLabel, "RIGHT", 4, 0)
    frame.nameplateCounterCB:SetChecked(core:GetAdvancedOption("nameplateCounterEnabled"))
    frame.nameplateCounterCB:SetScript("OnClick", function(self)
        local on = self:GetChecked()
        core:SetAdvancedOption("nameplateCounterEnabled", on)
        if on then core:ApplyNameplateCVars() end
    end)
    frame.nameplateCounterCB:SetScript("OnEnter", NPCounter_OnEnter)
    frame.nameplateCounterCB:SetScript("OnLeave", GameTooltip_Hide)

    frame.nameplateCounterDD = CreateFrame("Frame", "DefinitelyNotHekiliNPRangeDD", page, "UIDropDownMenuTemplate")
    frame.nameplateCounterDD:SetPoint("LEFT", frame.nameplateCounterCB, "RIGHT", -8, -2)
    frame.nameplateCounterDD:SetScript("OnEnter", NPCounter_OnEnter)
    frame.nameplateCounterDD:SetScript("OnLeave", GameTooltip_Hide)

    local function NPRange_OnClick(btnSelf, arg1)
        core:SetAdvancedOption("nameplateCounterRange", btnSelf.value)
        UIDropDownMenu_SetText(frame.nameplateCounterDD, arg1)
        CloseDropDownMenus()
    end

    UIDropDownMenu_Initialize(frame.nameplateCounterDD, function(self, level)
        local current = core:GetAdvancedOption("nameplateCounterRange")
        local available = (addon.range and addon.range.GetAvailableRanges and addon.range.GetAvailableRanges()) or {}
        for _, r in ipairs(available) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = tostring(r) .. " yd"
            info.value = r
            info.arg1 = info.text
            info.func = NPRange_OnClick
            info.checked = (current == r)
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    UIDropDownMenu_SetWidth(frame.nameplateCounterDD, 80)
    UIDropDownMenu_SetText(frame.nameplateCounterDD,
        tostring(core:GetAdvancedOption("nameplateCounterRange") or 30) .. " yd")

    frame.nameplateCounterCombatCB = CreateFrame("CheckButton", nil, page, "UICheckButtonTemplate")
    frame.nameplateCounterCombatCB:SetSize(24, 24)
    frame.nameplateCounterCombatCB:SetPoint("LEFT", frame.nameplateCounterDD, "RIGHT", -4, 2)
    frame.nameplateCounterCombatCB:SetChecked(core:GetAdvancedOption("nameplateCounterCombatOnly"))
    frame.nameplateCounterCombatCB:SetScript("OnClick", function(self)
        core:SetAdvancedOption("nameplateCounterCombatOnly", self:GetChecked())
    end)
    frame.nameplateCounterCombatCB:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("In Combat Only", 1, 1, 1)
        GameTooltip:AddLine("When checked, skip nameplates that are not in combat.\nOnly counts enemies actively fighting.", nil, nil, nil, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Useful for AoE timing — ignores trash patrolling nearby\nbut not engaged.", 0.5, 0.5, 0.5, true)
        GameTooltip:Show()
    end)
    frame.nameplateCounterCombatCB:SetScript("OnLeave", GameTooltip_Hide)

    return page
end


StaticPopupDialogs["BETTERASSISTANT_IMPORT_PROFILE"] = {
    text = "Importing this profile will replace your current Defensives, Advanced, Spell Range, and Auras settings for:\n%s\n\nContinue?",
    button1 = ACCEPT,
    button2 = CANCEL,
    OnAccept = function(self, data)
        if not data then return end
        local appliedKey = addon.Profile.Apply(data.core, data.profile)
        if data.statusFunc then data.statusFunc(appliedKey) end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}


local function CreateSpellRangePage(frame, core)
    local page = CreatePage(frame)
    local labelX = 12

    local title = page:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", labelX, -15)
    title:SetText("Spell Range (per spec)")

    local hint = page:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", labelX, -34)
    hint:SetWidth(CONTENT_WIDTH - 32)
    hint:SetJustifyH("LEFT")
    hint:SetText("When the target is farther than the chosen distance, the listed spell is colored red on the main icon and dimmed on defensive/interrupt icons.")

    local scrollFrame = CreateFrame("ScrollFrame", nil, page, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 0, -64)
    scrollFrame:SetPoint("BOTTOMRIGHT", -28, 0)

    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetWidth(CONTENT_WIDTH - 40)
    scrollChild:SetHeight(10)
    scrollFrame:SetScrollChild(scrollChild)

    local ROW_HEIGHT = 40
    local rowPool = {}
    local addButton
    local RebuildRows

    local function DistanceOptions()
        return (addon.range and addon.range.GetAvailableRanges and addon.range.GetAvailableRanges()) or {}
    end
    local function DistanceLabel(r) return tostring(r) .. " yd" end

    local function CreateRow(poolIndex)
        local row = CreateFrame("Frame", nil, scrollChild)
        row:SetSize(CONTENT_WIDTH - 40, ROW_HEIGHT)
        row.index = poolIndex

        local spellName = "BASpellRangeSpellDD" .. poolIndex
        local spellDD = CreateFrame("Frame", spellName, row, "UIDropDownMenuTemplate")
        spellDD:SetPoint("LEFT", -6, 0)
        HookDropdownToMenuUtil(spellDD, spellName,
            function()
                local list = core:GetOrCreateSpecRangeList()
                local e = list and list[row.index]
                return e and e.spellID or 0
            end,
            function(spellID)
                local list = core:GetOrCreateSpecRangeList()
                if list and list[row.index] then
                    list[row.index].spellID = spellID
                    UIDropDownMenu_SetText(spellDD, FormatSpellDisplay(spellID))
                    core:InvalidateSpellRangeCache()
                end
            end)
        UIDropDownMenu_SetWidth(spellDD, 105)
        local sText = _G[spellName .. "Text"]
        if sText then
            sText:ClearAllPoints()
            sText:SetPoint("LEFT", spellDD, "LEFT", 30, 2)
            sText:SetJustifyH("LEFT")
        end
        row.spellDD = spellDD

        local distName = "BASpellRangeDistDD" .. poolIndex
        local distDD = CreateFrame("Frame", distName, row, "UIDropDownMenuTemplate")
        distDD:SetPoint("LEFT", spellDD, "RIGHT", -8, 0)
        HookOptionsDropdown(distDD, distName,
            function()
                local list = core:GetOrCreateSpecRangeList()
                local e = list and list[row.index]
                return e and e.distance or 0
            end,
            function(value)
                local list = core:GetOrCreateSpecRangeList()
                if list and list[row.index] then
                    list[row.index].distance = value
                    UIDropDownMenu_SetText(distDD, DistanceLabel(value))
                    core:InvalidateSpellRangeCache()
                end
            end,
            DistanceOptions, DistanceLabel)
        UIDropDownMenu_SetWidth(distDD, 60)
        row.distDD = distDD

        local removeBtn = CreateFrame("Button", nil, row, "UIPanelCloseButton")
        removeBtn:SetSize(24, 24)
        removeBtn:SetPoint("LEFT", distDD, "RIGHT", -2, 2)
        removeBtn:SetScript("OnClick", function()
            local list = core:GetOrCreateSpecRangeList()
            if list and list[row.index] then
                table.remove(list, row.index)
                core:InvalidateSpellRangeCache()
                RebuildRows()
            end
        end)
        row.removeBtn = removeBtn

        return row
    end

    RebuildRows = function()
        local list = core:GetOrCreateSpecRangeList() or {}
        for i = 1, #list do
            local row = rowPool[i]
            if not row then
                row = CreateRow(i)
                rowPool[i] = row
            end
            row.index = i
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", 6, -(i - 1) * ROW_HEIGHT)
            UIDropDownMenu_SetText(row.spellDD, FormatSpellDisplay(list[i].spellID))
            UIDropDownMenu_SetText(row.distDD, DistanceLabel(list[i].distance))
            row:Show()
        end
        for i = #list + 1, #rowPool do
            rowPool[i]:Hide()
        end

        addButton:ClearAllPoints()
        addButton:SetPoint("TOPLEFT", 10, -(#list * ROW_HEIGHT) - 6)
        scrollChild:SetHeight(#list * ROW_HEIGHT + 44)
    end

    addButton = CreateFrame("Button", nil, scrollChild, "UIPanelButtonTemplate")
    addButton:SetSize(120, 24)
    addButton:SetText("Add Spell")
    addButton:SetScript("OnClick", function()
        local list = core:GetOrCreateSpecRangeList()
        if list then
            local avail = DistanceOptions()
            local defDist = avail[1] or 8
            for _, r in ipairs(avail) do
                if r == 8 then defDist = 8 break end
            end
            list[#list + 1] = { spellID = 0, distance = defDist }
            core:InvalidateSpellRangeCache()
            RebuildRows()
        end
    end)

    page:SetScript("OnShow", RebuildRows)

    frame.RebuildSpellRangeRows = RebuildRows
    RebuildRows()

    return page
end

local function CreateProfilePage(frame, core)
    local page = CreatePage(frame)
    local labelX = 12

    local title = page:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", labelX, -15)
    title:SetText("Profile (Defensives + Advanced + Spell Range)")

    local hint = page:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", labelX, -34)
    hint:SetWidth(CONTENT_WIDTH - 32)
    hint:SetJustifyH("LEFT")

    local boxBG = CreateFrame("Frame", nil, page, "BackdropTemplate")
    boxBG:SetPoint("TOPLEFT", labelX, -96)
    boxBG:SetPoint("TOPRIGHT", -20, -96)
    boxBG:SetHeight(170)
    boxBG:SetBackdrop({
        bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    boxBG:SetBackdropColor(0, 0, 0, 0.5)

    local scrollFrame = CreateFrame("ScrollFrame", nil, boxBG, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 6, -6)
    scrollFrame:SetPoint("BOTTOMRIGHT", -26, 6)

    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetAutoFocus(false)
    editBox:SetFontObject(ChatFontNormal)
    editBox:SetMaxLetters(0)
    editBox:SetWidth(CONTENT_WIDTH - 64)
    editBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    scrollFrame:SetScrollChild(editBox)
    frame.profileEditBox = editBox

    local status = page:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    status:SetPoint("TOPLEFT", labelX, -278)
    status:SetWidth(CONTENT_WIDTH - 32)
    status:SetJustifyH("LEFT")
    status:SetHeight(36)

    local function SetStatus(text, isError)
        if isError then
            status:SetTextColor(1, 0.3, 0.3)
        else
            status:SetTextColor(0.3, 1, 0.3)
        end
        status:SetText(text)
    end

    local function RefreshExport()
        local specKey = core:GetSpecKey()
        if specKey then
            hint:SetText(addon.Profile.DescribeSpec(specKey)
                .. "\nRebuilt each time you open this tab. Select the text(Ctrl+A) and press Ctrl+C to copy."
                .. "\nTo import, paste a string and click Apply.")
            local str = addon.Profile.Export(core)
            editBox:SetText(str or "")
            editBox:SetCursorPosition(0)
        else
            hint:SetText("No active specialization."
                .. "\nSwitch to a spec to export, or paste a string and click Apply to import.")
            editBox:SetText("")
        end
    end

    page:SetScript("OnShow", function()
        status:SetText("")
        RefreshExport()
    end)

    local applyBtn = CreateFrame("Button", nil, page, "UIPanelButtonTemplate")
    applyBtn:SetSize(150, 24)
    applyBtn:SetPoint("TOPRIGHT", -20, -328)
    applyBtn:SetText("Apply")
    applyBtn:SetScript("OnClick", function()
        local data, err = addon.Profile.Decode(editBox:GetText())
        if not data then
            SetStatus(err or "Import failed.", true)
            return
        end
        local dialog = StaticPopup_Show("BETTERASSISTANT_IMPORT_PROFILE", addon.Profile.DescribeSpec(data.specKey))
        if dialog then
            dialog.data = {
                core = core,
                profile = data,
                statusFunc = function(appliedKey)
                    if appliedKey == core:GetSpecKey() then
                        addon:UpdateSettingsFrame()
                        core:DetectDefensivesSpells()
                        RefreshExport()
                        SetStatus("Applied to current spec: " .. addon.Profile.DescribeSpec(appliedKey) .. ".", false)
                    else
                        SetStatus("Saved for " .. addon.Profile.DescribeSpec(appliedKey)
                            .. ". It will apply when you switch to that spec.", false)
                    end
                end,
            }
        end
    end)

    return page
end


local function CreateKeybindsPage(frame, core)
    local page = CreatePage(frame)
    local labelX = 12

    addon.keybinds.EnsureConfig(core)
    local cfg = core.config.keybinds

    local function MakeCheckbox(y, text, key, tooltipTitle, tooltipText)
        local cb = CreateFrame("CheckButton", nil, page, "ChatConfigCheckButtonTemplate")
        cb:SetPoint("TOPLEFT", labelX, y)
        cb.Text:SetText(text)
        cb:SetChecked(cfg[key])
        cb:SetScript("OnClick", function(self)
            cfg[key] = self:GetChecked()
            addon.keybinds.QueueRefresh()
        end)
        cb:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(tooltipTitle, 1, 1, 1)
            GameTooltip:AddLine(tooltipText, nil, nil, nil, true)
            GameTooltip:Show()
        end)
        cb:SetScript("OnLeave", GameTooltip_Hide)
        return cb
    end

    frame.kbEnabled = MakeCheckbox(-15, "Show Keybindings", "enabled",
        "Show Keybindings",
        "Displays the action bar keybind of each spell on the assistant,\ninterrupt and defensive icons (right edge, vertically centered).\n\nSupports Blizzard bars, ElvUI and Bartender4,\nincluding override/vehicle bars.")

    frame.kbBackground = MakeCheckbox(-50, "Show Background", "background",
        "Show Background",
        "Draws a black box behind the keybind text for readability.")

    frame.kbLargeFont = MakeCheckbox(-85, "Large Font (+50%)", "largeFont",
        "Large Font",
        "Uses a font 50% larger than the standard debug text size.")

    frame.kbColorMods = MakeCheckbox(-120, "Color By Modifier", "colorMods",
        "Color By Modifier",
        "Hides the modifier letter and encodes it as the text color instead,\nso only the main key is drawn.\n\nNo modifier: white\nCtrl: red\nShift: green\nAlt: blue\n\nOnly the first modifier of a combo is shown.")

    frame.kbDimWithIcon = MakeCheckbox(-155, "Dim With Icon", "dimWithIcon",
        "Dim With Icon",
        "Each keybind follows the opacity of the icon it sits on,\nso a faded icon gets a faded keybind.\n\nWhen off, keybinds stay fully opaque no matter\nhow faded the icon underneath is.")

    return page
end


function addon:CreateSettingsFrame()
    local core = addon.core

    local totalWidth = SIDEBAR_WIDTH + CONTENT_WIDTH
    local frame = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    frame:SetSize(totalWidth, FRAME_HEIGHT)
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 8, right = 8, top = 8, bottom = 8 }
    })
    frame:SetPoint("CENTER")
    frame:Hide()
    frame:SetFrameStrata("DIALOG")
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")

    local titleBg = frame:CreateTexture(nil, "OVERLAY")
    titleBg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
    titleBg:SetSize(220, 64)
    titleBg:SetPoint("TOP", 0, 12)

    local titleText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    titleText:SetPoint("TOP", titleBg, "TOP", 0, -14)
    titleText:SetText("BetterAssistant")

    local closeBtnX = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    closeBtnX:SetPoint("TOPRIGHT", -5, -5)
    closeBtnX:SetScript("OnClick", function() frame:Hide() end)

    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

    local separator = frame:CreateTexture(nil, "ARTWORK")
    separator:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Border")
    separator:SetTexCoord(0.25, 0.28, 0, 1)
    separator:SetWidth(4)
    separator:SetPoint("TOPLEFT", SIDEBAR_WIDTH - 2, -8)
    separator:SetPoint("BOTTOMLEFT", SIDEBAR_WIDTH - 2, 8)

    frame.pageNames = { "General", "Interrupt", "Defensives", "Auras", "Keybindings", "Advanced", "Spell Range", "Profile" }
    frame.pages = {}
    frame.sidebarButtons = {}

    frame.pages[1] = CreateGeneralPage(frame, core)
    frame.pages[2] = CreateInterruptPage(frame, core)
    frame.pages[3] = CreateDefensivesPage(frame, core)
    frame.pages[4] = CreateCDMPage(frame, core)
    frame.pages[5] = CreateKeybindsPage(frame, core)
    frame.pages[6] = CreateAdvancedPage(frame, core)
    frame.pages[7] = CreateSpellRangePage(frame, core)
    frame.pages[8] = CreateProfilePage(frame, core)

    for i, name in ipairs(frame.pageNames) do
        local btn = CreateSidebarButton(frame, name, function()
            ShowPage(frame, i)
        end)
        btn:SetPoint("TOPLEFT", 18, -32 - (i - 1) * (BUTTON_HEIGHT + 4))
        frame.sidebarButtons[i] = btn
    end

    ShowPage(frame, 1)

    frame:SetScript("OnShow", function(self)
        core.isConfiguring = true
        core:EnableMouse(false)
    end)

    frame:SetScript("OnHide", function(self)
        core.isConfiguring = false
        core:ApplyClickBehavior()
    end)

    return frame
end

function addon:UpdateSettingsFrame()
    local frame = self.settingsFrame
    local core = self.core
    if not frame then return end

    frame.xBox:SetText(string.format("%.2f", core.config.X))
    frame.yBox:SetText(string.format("%.2f", core.config.Y))
    frame.sizeBox:SetText(string.format("%.2f", core.config.size))

    frame.enabled:SetChecked(core.config.enabled)
    frame.hideWhenMounted:SetChecked(core.config.hideWhenMounted)
    frame.rangeCheck:SetChecked(core.config.rangeCheck)
    frame.castCheck:SetChecked(core.config.castCheck)
    frame.channelCheck:SetChecked(core.config.channelCheck)
    frame.checkForVisibleButton:SetChecked(core.config.checkForVisibleButton)
    frame.silentMode:SetChecked(core.config.silentMode)
    frame.ignoreClicks:SetChecked(core.config.ignoreClicks)
    frame.targetRangeEnabled:SetChecked(core.config.targetRangeEnabled)
    frame.interruptEnabled:SetChecked(core.config.interruptEnabled)

    UIDropDownMenu_SetText(frame.showWhenDropdown, core.config.showWhen)
    UIDropDownMenu_SetText(frame.strataDropdown, core.config.strata)

    frame.defensivesEnabled:SetChecked(core.config.defensivesEnabled)
    cachedLearnedSpellTree = nil
    local slots = core:GetOrCreateSpecSlots()
    if slots then
        for i = 1, core.config.maxDefensiveSlots do
            if slots[i] and frame.defensivesSlotDropdowns[i] then
                local slot = slots[i]
                UIDropDownMenu_SetText(frame.defensivesSlotDropdowns[i], FormatSpellDisplay(slot.spellID))
                frame.defensivesSlotHP[i]:SetText(tostring(slot.healthPct))
                frame.defensivesSlotHP[i]:SetCursorPosition(0)
                frame.defensivesSlotEnabled[i]:SetChecked(slot.enabled)
                frame.defensivesSlotBuffDuration[i]:SetText(tostring(slot.buffDuration))
                frame.defensivesSlotBuffDuration[i]:SetCursorPosition(0)
                UIDropDownMenu_SetText(frame.defensivesSlotShowWhen[i], slot.showWhen or "Always")
                UIDropDownMenu_SetText(frame.defensivesSlotUnit[i], slot.unit or "player")
                UIDropDownMenu_SetText(frame.defensivesSlotResource[i], slot.resource or "health")
                UIDropDownMenu_SetText(frame.defensivesSlotOperator[i], slot.operator or "<")
                frame.defensivesSlotGlow[i]:SetChecked(slot.glow or false)
                frame.defensivesSlotDispel[i]:SetChecked(slot.dispelable or false)
            end
        end
    end

    if frame.RebuildSpellRangeRows then
        frame.RebuildSpellRangeRows()
    end

    local currentThreshold = core:GetAdvancedOption("empoweredStageThreshold")
    for _, option in ipairs(empoweredThresholdOptions) do
        if option.value == currentThreshold then
            UIDropDownMenu_SetText(frame.empoweredThresholdDD, option.text)
            break
        end
    end

    UIDropDownMenu_SetText(frame.resourcePoolingDD, GetPowerTypeName(core:GetAdvancedOption("resourcePoolingType")))
    frame.resourcePoolingThresholdBox:SetText(tostring(core:GetAdvancedOption("resourcePoolingThreshold")))
    frame.resourcePoolingThresholdBox:SetCursorPosition(0)

    frame.movingOverrideCB:SetChecked(core:GetAdvancedOption("movingOverrideEnabled"))
    UIDropDownMenu_SetText(frame.movingOverrideDD,
        FormatSpellDisplay(core:GetAdvancedOption("movingOverrideSpellID")))

    frame.nameplateCounterCB:SetChecked(core:GetAdvancedOption("nameplateCounterEnabled"))
    UIDropDownMenu_SetText(frame.nameplateCounterDD,
        tostring(core:GetAdvancedOption("nameplateCounterRange") or 30) .. " yd")
    frame.nameplateCounterCombatCB:SetChecked(core:GetAdvancedOption("nameplateCounterCombatOnly"))

    addon.cdm.EnsureConfig(core)
    local cdmCfg = core.config.cdm
    frame.cdmEnabled:SetChecked(cdmCfg.enabled)
    frame.cdmIconSize:SetText(tostring(cdmCfg.iconSize))
    frame.cdmIconSize:SetCursorPosition(0)
    frame.cdmShowSwipe:SetChecked(cdmCfg.showSwipe)
    if frame.RefreshCDMAuraRows then
        frame.RefreshCDMAuraRows()
    end

    addon.keybinds.EnsureConfig(core)
    local kbCfg = core.config.keybinds
    frame.kbEnabled:SetChecked(kbCfg.enabled)
    frame.kbBackground:SetChecked(kbCfg.background)
    frame.kbLargeFont:SetChecked(kbCfg.largeFont)
    frame.kbColorMods:SetChecked(kbCfg.colorMods)
    frame.kbDimWithIcon:SetChecked(kbCfg.dimWithIcon)
end
