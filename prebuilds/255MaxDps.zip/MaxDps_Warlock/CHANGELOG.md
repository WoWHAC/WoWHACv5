# MaxDps_Warlock

## [v11.1.60](https://github.com/kaminaris/MaxDps-Warlock/tree/v11.1.60) (2026-04-14)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warlock/compare/v11.1.59...v11.1.60) [Previous Releases](https://github.com/kaminaris/MaxDps-Warlock/releases)

- Update All Retail  
