# MaxDps

## [v11.3.3](https://github.com/kaminaris/MaxDps/tree/v11.3.3) (2026-04-19)
[Full Changelog](https://github.com/kaminaris/MaxDps/compare/v11.3.2...v11.3.3) [Previous Releases](https://github.com/kaminaris/MaxDps/releases)

- Update Cooldowns  
