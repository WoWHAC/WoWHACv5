# MaxDps_Mage

## [v11.1.55](https://github.com/kaminaris/MaxDps-Mage/tree/v11.1.55) (2026-04-14)
[Full Changelog](https://github.com/kaminaris/MaxDps-Mage/compare/v11.1.54...v11.1.55) [Previous Releases](https://github.com/kaminaris/MaxDps-Mage/releases)

- Update All Retail  
