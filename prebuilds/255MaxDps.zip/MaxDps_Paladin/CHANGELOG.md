# MaxDps_Paladin

## [v11.1.53](https://github.com/kaminaris/MaxDps-Paladin/tree/v11.1.53) (2026-04-14)
[Full Changelog](https://github.com/kaminaris/MaxDps-Paladin/compare/v11.1.52...v11.1.53) [Previous Releases](https://github.com/kaminaris/MaxDps-Paladin/releases)

- Update All Retail  
