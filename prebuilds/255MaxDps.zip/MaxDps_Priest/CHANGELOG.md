# MaxDps_Priest

## [v11.1.30](https://github.com/kaminaris/MaxDps-Priest/tree/v11.1.30) (2026-04-14)
[Full Changelog](https://github.com/kaminaris/MaxDps-Priest/compare/v11.1.29...v11.1.30) [Previous Releases](https://github.com/kaminaris/MaxDps-Priest/releases)

- Update All Retail  
