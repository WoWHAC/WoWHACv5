local _, addonTable = ...
local Druid = addonTable.Druid
local MaxDps = _G.MaxDps
if not MaxDps then return end
local setSpell

local UnitPower = UnitPower
local UnitHealth = UnitHealth
local UnitAura = C_UnitAuras.GetAuraDataByIndex
local UnitAuraByName = C_UnitAuras.GetAuraDataBySpellName
local UnitHealthMax = UnitHealthMax
local UnitPowerMax = UnitPowerMax
local SpellHaste
local SpellCrit
local GetSpellInfo = C_Spell.GetSpellInfo
local GetSpellCooldown = C_Spell.GetSpellCooldown
local GetSpellCount = C_Spell.GetSpellCastCount
local GetSpellPowerCost = C_Spell.GetSpellPowerCost

local ManaPT = Enum.PowerType.Mana
local RagePT = Enum.PowerType.Rage
local FocusPT = Enum.PowerType.Focus
local EnergyPT = Enum.PowerType.Energy
local ComboPointsPT = Enum.PowerType.ComboPoints
local RunesPT = Enum.PowerType.Runes
local RunicPowerPT = Enum.PowerType.RunicPower
local SoulShardsPT = Enum.PowerType.SoulShards
local DemonicFuryPT = Enum.PowerType.DemonicFury
local BurningEmbersPT = Enum.PowerType.BurningEmbers
local LunarPowerPT = Enum.PowerType.LunarPower
local HolyPowerPT = Enum.PowerType.HolyPower
local MaelstromPT = Enum.PowerType.Maelstrom
local ChiPT = Enum.PowerType.Chi
local InsanityPT = Enum.PowerType.Insanity
local ArcaneChargesPT = Enum.PowerType.ArcaneCharges
local FuryPT = Enum.PowerType.Fury
local PainPT = Enum.PowerType.Pain
local EssencePT = Enum.PowerType.Essence
local RuneBloodPT = Enum.PowerType.RuneBlood
local RuneFrostPT = Enum.PowerType.RuneFrost
local RuneUnholyPT = Enum.PowerType.RuneUnholy

local fd
local ttd
local timeShift
local gcd
local cooldown
local buff
local debuff
local talents
local targets
local targetHP
local targetmaxHP
local targethealthPerc
local curentHP
local maxHP
local healthPerc
local timeInCombat
local className, classFilename, classId = UnitClass('player')
local classtable
local LibRangeCheck = LibStub('LibRangeCheck-3.0', true)

local Feral = {}

local ComboPoints
local ComboPointsMax
local ComboPointsDeficit
local Energy
local EnergyMax
local EnergyDeficit
local EnergyRegen
local EnergyTimeToMax
local EnergyPerc
local Mana
local ManaMax
local ManaPerc

local HasFuror

local base, posBuff, negBuff
local totalAP

local function ClearCDs()
    MaxDps:GlowCooldown(classtable.CatForm, false)
    MaxDps:GlowCooldown(classtable.DemoralizingRoar, false)
    MaxDps:GlowCooldown(classtable.FaerieFire, false)
    MaxDps:GlowCooldown(classtable.Thorns, false)
end

local function GetEnergyCost(spellId)
    local s = GetSpellInfo(spellId)
    if s and s.powerCosts then
        for _, p in ipairs(s.powerCosts) do
            if p and p.type == EnergyPT and p.cost and p.cost > 0 then
                return p.cost
            end
        end
    end

    local costs = GetSpellPowerCost and GetSpellPowerCost(spellId)
    if costs then
        for _, p in ipairs(costs) do
            if p and p.type == EnergyPT and p.cost and p.cost > 0 then
                return p.cost
            end
        end
    end

    return nil
end

local function NextCatActionEnergyCost(threat)
    if not UnitAffectingCombat('player') then return nil end
    if threat == nil then threat = 0 end

    if (MaxDps:FindDeBuffAuraData(classtable.MangleCat).refreshable or threat >= 2) and ComboPoints < 4 and cooldown[classtable.MangleCat].ready then
        return GetEnergyCost(classtable.MangleCat)
    end
    if (threat < 2) and ComboPoints < 4 and cooldown[classtable.Shred].ready then
        return GetEnergyCost(classtable.Shred)
    end
    if not MaxDps:FindDeBuffAuraData(classtable.Rip).up and ComboPoints >= 4 and ttd >= 8 and cooldown[classtable.Rip].ready then
        return GetEnergyCost(classtable.Rip)
    end
    if ComboPoints >= 4 and cooldown[classtable.FerociousBite].ready then
        return GetEnergyCost(classtable.FerociousBite)
    end
    if cooldown[classtable.Claw].ready then
        return GetEnergyCost(classtable.Claw)
    end

    return nil
end

function Feral:AoE()
    if MaxDps:FindBuffAuraData(classtable.BearForm).up or MaxDps:FindBuffAuraData(classtable.DireBearForm).up then
        if (MaxDps:CheckSpellUsable(classtable.DemoralizingRoar, 'DemoralizingRoar')) and (MaxDps:FindDeBuffAuraData(classtable.DemoralizingRoar).refreshable) and cooldown[classtable.DemoralizingRoar].ready then
            --if not setSpell then setSpell = classtable.DemoralizingRoar end
            MaxDps:GlowCooldown(classtable.DemoralizingRoar, true)
        end
        if (MaxDps:CheckSpellUsable(classtable.Swipe, 'Swipe')) and cooldown[classtable.Swipe].ready then
            if not setSpell then setSpell = classtable.Swipe end
        end
        if (MaxDps:CheckSpellUsable(classtable.Maul, 'Maul')) and cooldown[classtable.Maul].ready then
            if not setSpell then setSpell = classtable.Maul end
        end
    end
end

function Feral:Single()
    if MaxDps:FindBuffAuraData(classtable.CatForm) .up then
		if UnitAffectingCombat('player') and not MaxDps:FindBuffAuraData(classtable.Prowl).up then
			local nextCost = NextCatActionEnergyCost(UnitThreatSituation("player", "target") or 0)
			if HasFuror and nextCost and Energy < (nextCost - 20) and ManaPerc >= 10 then
				if not setSpell then setSpell = classtable.CatForm end
			end
		end
        if MaxDps:CheckSpellUsable(classtable.Prowl, 'Prowl') and not UnitAffectingCombat('player') and not MaxDps:FindBuffAuraData(classtable.Prowl).up and cooldown[classtable.Prowl].ready then
            if not setSpell then setSpell = classtable.Prowl end
        end
        if MaxDps:CheckSpellUsable(classtable.Pounce, 'Pounce') and not UnitAffectingCombat('player') and MaxDps:FindBuffAuraData(classtable.Prowl).up and cooldown[classtable.Pounce].ready then
            if not setSpell then setSpell = classtable.Pounce end
        end
		if MaxDps:CheckSpellUsable(classtable.FaerieFire, 'FaerieFire')	and not MaxDps:FindDeBuffAuraData(classtable.FaerieFire).up and not MaxDps:FindBuffAuraData(classtable.Prowl).up and cooldown[classtable.FaerieFire].ready then
			if not setSpell then setSpell = classtable.FaerieFire end
		end
        if MaxDps:CheckSpellUsable(classtable.MangleCat, 'MangleCat') and (MaxDps:FindDeBuffAuraData(classtable.MangleCat).refreshable or (UnitThreatSituation("player", "target") and UnitThreatSituation("player", "target") >= 2) ) and ComboPoints < 4 and cooldown[classtable.MangleCat].ready then
            if not setSpell then setSpell = classtable.MangleCat end
        end
        if MaxDps:CheckSpellUsable(classtable.Shred, 'Shred') and (not UnitThreatSituation("player", "target") or UnitThreatSituation("player", "target") < 2) and ComboPoints < 4 and cooldown[classtable.Shred].ready then
            if not setSpell then setSpell = classtable.Shred end
        end
        if MaxDps:CheckSpellUsable(classtable.Rip, 'Rip') and not MaxDps:FindDeBuffAuraData(classtable.Rip).up and ComboPoints >= 4 and ttd >= 8 and cooldown[classtable.Rip].ready then
            if not setSpell then setSpell = classtable.Rip end
        end
        if MaxDps:CheckSpellUsable(classtable.FerociousBite, 'Ferocious Bite') and ComboPoints >= 4 and cooldown[classtable.FerociousBite].ready then
            if not setSpell then setSpell = classtable.FerociousBite end
        end
        if (MaxDps:CheckSpellUsable(classtable.Claw, 'Claw')) and cooldown[classtable.Claw].ready and (not MaxDps:CheckSpellUsable(classtable.MangleCat, 'MangleCat')) then
            if not setSpell then setSpell = classtable.Claw end
        end
    end

    if MaxDps:FindBuffAuraData(classtable.BearForm).up or MaxDps:FindBuffAuraData(classtable.DireBearForm).up then
        if targets >=3 then
            Feral:AoE()
        else
            if (MaxDps:CheckSpellUsable(classtable.DemoralizingRoar, 'DemoralizingRoar')) and (MaxDps:FindDeBuffAuraData(classtable.DemoralizingRoar).refreshable) and cooldown[classtable.DemoralizingRoar].ready then
                --if not setSpell then setSpell = classtable.DemoralizingRoar end
                MaxDps:GlowCooldown(classtable.DemoralizingRoar, true)
            end
            if (MaxDps:CheckSpellUsable(classtable.MangleBear, 'MangleBear')) and cooldown[classtable.MangleBear].ready then
                if not setSpell then setSpell = classtable.MangleBear end
            end
            if (MaxDps:CheckSpellUsable(classtable.Lacerate, 'Lacerate')) and (MaxDps:FindDeBuffAuraData(classtable.Lacerate).refreshable or MaxDps:FindDeBuffAuraData(classtable.Lacerate).count < 5) and cooldown[classtable.Lacerate].ready then
                if not setSpell then setSpell = classtable.Lacerate end
            end
            if (MaxDps:CheckSpellUsable(classtable.Swipe, 'Swipe')) and totalAP >= 2700 and cooldown[classtable.Swipe].ready then
                if not setSpell then setSpell = classtable.Swipe end
            end
            if (MaxDps:CheckSpellUsable(classtable.Maul, 'Maul')) and cooldown[classtable.Maul].ready then
                if not setSpell then setSpell = classtable.Maul end
            end
        end
    end
end

function Druid:Feral()
    fd = MaxDps.FrameData
    ttd = (fd.timeToDie and fd.timeToDie) or 500
    timeShift = fd.timeShift
    gcd = fd.gcd
    cooldown = fd.cooldown
    buff = fd.buff
    debuff = fd.debuff
    talents = fd.talents
    targets = MaxDps:SmartAoe()
    targetHP = UnitHealth('target')
    targetmaxHP = UnitHealthMax('target')
    targethealthPerc = (targetHP >0 and targetmaxHP >0 and (targetHP / targetmaxHP) * 100) or 100
    curentHP = UnitHealth('player')
    maxHP = UnitHealthMax('player')
    healthPerc = (curentHP / maxHP) * 100
    Mana = UnitPower('player', ManaPT)
    ManaMax = UnitPowerMax('player', ManaPT)
    ManaPerc = (Mana / ManaMax) * 100
    timeInCombat = MaxDps.combatTime or 0
    classtable = MaxDps.SpellTable or {}
    SpellHaste = UnitSpellHaste('player')
    SpellCrit = GetCritChance()

    ComboPoints = UnitPower('player', ComboPointsPT)
    ComboPointsMax = UnitPowerMax('player', ComboPointsPT)
    ComboPointsDeficit = ComboPointsMax - ComboPoints
    Energy = UnitPower('player', EnergyPT)
    EnergyMax = UnitPowerMax('player', EnergyPT)
    EnergyDeficit = EnergyMax - Energy
    EnergyRegen = GetPowerRegenForPowerType(Enum.PowerType.Energy)
    EnergyTimeToMax = EnergyDeficit / EnergyRegen
    EnergyPerc = (Energy / EnergyMax) * 100

    base, posBuff, negBuff = UnitAttackPower("player")
    totalAP = base + posBuff + negBuff

    HasFuror = MaxDps.PlayerTalents[822] or false

    classtable.BearForm = 5487
    classtable.DireBearForm = 9634
	classtable.Lacerate=33745
    classtable.MangleBear=33878
    classtable.Berserk=417141
    classtable.Swipe=9908
    classtable.Maul=9881
    classtable.DemoralizingRoar=26998

    classtable.FaerieFire=16857
    --classtable.TigersFury=9846
    --classtable.Haste=13494
    classtable.CatForm=768
    classtable.Rip = 1079
    classtable.Shred=9830
    classtable.FerociousBite=22568
    classtable.Claw=9850
    --classtable.Innervate=29166
    classtable.MangleCat=33876
    classtable.Thorns=467
    classtable.MarkoftheWild = 1126
	classtable.GiftoftheWild = 21849
    classtable.OmenofClarity = 16864
    classtable.Prowl = 5215
    classtable.Pounce = 9005

    setSpell = nil

    ClearCDs()

	if MaxDps:NumGroupFriends() <= 1 and (MaxDps:CheckSpellUsable(classtable.MarkoftheWild, 'MarkoftheWild'))
    and MaxDps:FindBuffAuraData(classtable.MarkoftheWild).refreshable and cooldown[classtable.MarkoftheWild].ready
    and not MaxDps:FindBuffAuraData(classtable.GiftoftheWild).up then
		if not setSpell then setSpell = classtable.MarkoftheWild end
	end
	if MaxDps:NumGroupFriends() >= 2 and (MaxDps:CheckSpellUsable(classtable.GiftoftheWild, 'GiftoftheWild'))
    and MaxDps:FindBuffAuraData(classtable.GiftoftheWild).refreshable and cooldown[classtable.GiftoftheWild].ready then
		if not setSpell then setSpell = classtable.GiftoftheWild end
	end
	if (MaxDps:CheckSpellUsable(classtable.OmenofClarity, 'OmenofClarity')) and MaxDps:FindBuffAuraData(classtable.OmenofClarity).refreshable and cooldown[classtable.OmenofClarity].ready then
		if not setSpell then setSpell = classtable.OmenofClarity end
		--MaxDps:GlowCooldown(classtable.OmenofClarity, true)
	end
	if (MaxDps:CheckSpellUsable(classtable.Thorns, 'Thorns')) and MaxDps:FindBuffAuraData(classtable.Thorns).refreshable and cooldown[classtable.Thorns].ready and ( MaxDps:FindBuffAuraData(classtable.BearForm).up or MaxDps:FindBuffAuraData(classtable.DireBearForm).up or (UnitThreatSituation("player", "target") and UnitThreatSituation("player", "target") >= 2) ) then
        if not setSpell then setSpell = classtable.Thorns end
        --MaxDps:GlowCooldown(classtable.Thorns, true)
    end

    --AoE Rotation
    if targets >= 3 then
        Feral:AoE()
    end

    --Single Target Rotation
    Feral:Single()

    if setSpell then return setSpell end
end
