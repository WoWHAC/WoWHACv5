# MaxDps_Druid

## [v11.1.84](https://github.com/kaminaris/MaxDps-Druid/tree/v11.1.84) (2026-04-14)
[Full Changelog](https://github.com/kaminaris/MaxDps-Druid/compare/v11.1.83...v11.1.84) [Previous Releases](https://github.com/kaminaris/MaxDps-Druid/releases)

- Update All Retail  
