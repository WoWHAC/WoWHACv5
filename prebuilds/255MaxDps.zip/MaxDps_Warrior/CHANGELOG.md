# MaxDps_Warrior

## [v11.1.49](https://github.com/kaminaris/MaxDps-Warrior/tree/v11.1.49) (2026-04-14)
[Full Changelog](https://github.com/kaminaris/MaxDps-Warrior/compare/v11.1.48...v11.1.49) [Previous Releases](https://github.com/kaminaris/MaxDps-Warrior/releases)

- Update All Retail  
