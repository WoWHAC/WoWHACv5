# MaxDps_Shaman

## [v11.1.55](https://github.com/kaminaris/MaxDps-Shaman/tree/v11.1.55) (2026-04-14)
[Full Changelog](https://github.com/kaminaris/MaxDps-Shaman/compare/v11.1.54...v11.1.55) [Previous Releases](https://github.com/kaminaris/MaxDps-Shaman/releases)

- Update All Retail  
