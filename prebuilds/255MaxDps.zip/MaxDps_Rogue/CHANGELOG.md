# MaxDps_Rogue

## [v11.1.38](https://github.com/kaminaris/MaxDps-Rogue/tree/v11.1.38) (2026-04-14)
[Full Changelog](https://github.com/kaminaris/MaxDps-Rogue/compare/v11.1.37...v11.1.38) [Previous Releases](https://github.com/kaminaris/MaxDps-Rogue/releases)

- Update All Retail  
