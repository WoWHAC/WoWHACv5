# MaxDps_Hunter

## [v11.1.52](https://github.com/kaminaris/MaxDps-Hunter/tree/v11.1.52) (2026-04-14)
[Full Changelog](https://github.com/kaminaris/MaxDps-Hunter/compare/v11.1.51...v11.1.52) [Previous Releases](https://github.com/kaminaris/MaxDps-Hunter/releases)

- Update All Retail  
