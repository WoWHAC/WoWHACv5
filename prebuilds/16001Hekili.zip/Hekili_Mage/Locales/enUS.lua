-- Locales/enUS.lua
-- The English string table of Hekili_Mage (AceLocale-3.0, silent): every L[...] key its code uses, each its own text.
-- Written by tools/locales.py: do not edit. It loads first, so its NewLocale is the app's first (the one whose
-- `silent` counts): a key no table holds answers itself.

local L = LibStub("AceLocale-3.0"):NewLocale("Hekili_Mage", "enUS", true, true)

-- Hekili_Mage/Mage.lua
L["Arcane"] = true
L["Fire"] = true
L["Frost"] = true
L["Arcane (wowsims.com)"] = true
L["Fire (wowsims.com)"] = true
L["Frostfire (wowsims.com)"] = true
L["Frost (wowsims.com)"] = true
